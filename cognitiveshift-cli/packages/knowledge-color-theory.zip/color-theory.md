# Color Theory

> Source reference (UX/UI): `Color Theory.pdf` (this folder). Full text, verbatim — the
> corpus the design agents and Color Matching app draw on. Machine-applied rules live in
> `design-system/foundations/color-rules.md`; the seasonal subset in `seasons.md`.

---

Color Theory
#UX  #UI  #Design  #Color
💡 important notes
Blue and green are perfect colors for meditation and yoga apps and websites.
Color Properties & Perception
Traditional Color Meanings
Carrying the attributes of two colors, gray can be associated with the calmness and
neutrality of white and the elegance and intelligence of black.
Hue – The terms “color” and “hue” are often used interchangeably by artists and
designers. For all intents and purposes, this will get you by but the words “color” and
“hue” actually mean different things. In general, “color” is used to refer to all, well, colors,
including black, white and grey. While “hue” refers to the origin of the color we see. It is
the base of the color we see and is always one of the six primary and secondary colors
on the color wheel.
Tint – A “tint” is a lighter version of a given hue. It is a hue that has only white added to it.
Sometimes a tint can seem brighter than the original hue, but it is just a paler version. A
tint can range from a hue that is barely lighter than the original, to almost white with a
tiny amount of color in it.
Shade –  This is the opposite of a “tint.” A “shade” is a hue with only black added to it. It
can, of course, include varying amounts of black, and the resulting color may be barely
darker than the original hue, or it may be almost black. An easy way to remember this
one is to think of how the grass in the shade of a tree seems darker than the grass in the
sun. 
Tone – This is very similar to “tint” and “shade,” only instead of being a hue with white or
black added to it, it is a hue with only grey added to it. The grey that is added to make a
“tone” must only consist of black and white, no other colors (many colors that are
considered grey actually have a base that is a hue). Toned colors tend to be viewed as
more sophisticated than pure hues.
Warm Versus Cool – “Warm” colors are those that resemble or symbolize heat, while
“cool” colors are attributed to ice and cooler temperatures. For example: red, orange,
yellow, and red-purple are warm colors, while blue, purple, green and blue-green are
cool colors.

White: symbolizes new beginnings, exciting ideas, and a fresh start. It helps us clear our
minds and calm down by promoting feelings of peace, honesty, and simplicity.
Black: We associate black with luxury goods, high ranks, and noble richness.
Brown: is often seen as grounded, rugged, and solid, just like the earth
Green: is the most dominant color in nature and has strong associations with calmness and
harmony.
Beige: is a contradictory combination of warm brown and crisp, cold white. Some people
find beige calming, elegant, and flexible, while others think it's boring and conservative.
The simplicity and cleanliness of beige make it a perfect candidate for interface
backgrounds.
Red: is the most powerful and also contradictory of the colors. On the one hand, it stands for
love, passion, desire, and health. On the other hand, it conveys danger, anger, violence, and
fear. Such negative emotions are linked to associations with wars, blood, and fire.
Orange: can be described as energetic and enthusiastic, while its strong connection to the
autumn season and Halloween evokes warm and cozy feelings about this color.
Pink: is one of the most cheerful colors. It's associated with childhood, unicorns, cotton
candy, bubble gum, flowers, Barbie dolls, and sweets.
Cultural Differences in Color Perception & Meaning
Blue worldwide: Studies have shown that blue is the most universally favored color.
💡: Vivid colors in India
💡: Pan-Arab colors
💡: Pan-African colors
💡: Monochromatic colors in Nordic countries
💡: Green in the Southern Java
Why Color Affects Us
⚠️: Ecological valence theory #EvolutionnaryPsychology
In contrast to the evolutionary theory based on the development of retinal cones, the
ecological valence theory suggests another approach.
⚠️: Language effect on color perception #EvolutionnaryPsychology
Not only did our ancestors see colors differently from us, but people from other parts of the
world who speak different languages also see colors in different ways. Despite the criticism
of this theory, multiple studies show that the role language plays in color perception cannot
be denied.

⚠️: Evolution & color psychology #EvolutionnaryPsychology
Have you ever wondered why you prefer one color over another? Or why some people don't
like yellow and even find it disturbing or annoying, although it's commonly considered a
cheerful color? The reason for that lies far beyond traditional color associations.
According to studies, there are two sources that all color preferences originate from
— evolution and ecological valence theory.
There are 2 components the evolutionary approach relies on:
The Context of Color
Attraction: Research shows that we see warm colors like red, orange, and yellow as
attractive. There are several theories behind that
Duration: Research proves that light colors encourage action, and dark "heavy" colors
invite people to linger and take their time.
Visibility: The premise is that lighter colors are more visible than darker colors. This is
thought to be an evolutionary trait as we associate lighter colors with daytime and darker
colors with nighttime.
Stimulation: The theory about neurological arousal states that warm colors are
stimulating while cool colors are relaxing.
Importance: Research shows that heavy objects seem more important.
Aggression: Seeing red stimulates adrenaline production, which triggers our fight-or-flight
response.
⚠️ Actionability: While dark colors seem heavy and important, light colors encourage
action. The theory is that we simulate actions before we do them.
----> Pour qu'il y ai des action il faut du light.
Influencing Mood with Color Combinations
💡Amplifying energetic colors: Warm hues like yellow, red, and orange are easily
noticeable and stimulating.
Survival needs: In ancient times, the ability to identify certain colors was critical to
human survival. That's why human eyes developed special retinal cones to identify red
that could indicate ripe fruits, as well as blood, fire, or poisonous, dangerous plants or
animals.1(https://app.uxcel.com/#anchor-1)
Language: The development of languages has also shaped how humans perceive
colors. The existence of specific color names in certain languages indicates that
indigenous people could relate to these colors and identify them. For example, in ancient
times, Egypt was the only country that produced blue dye. Thus, only Egyptians had a
word for the color blue.2(https://app.uxcel.com/#anchor-2)

💡Energetic palettes: You can amplify the effect by using triadic colors.
💡Softening strong colors: One way is to create monochromatic pastel palettes. To do
this, increase the value of the hue and decrease its saturation.
💡Toning down bright colors: A trick to make it more exciting is adding a tint of its
complementary color — in this case, orange. It will add the necessary contrast and make the
combination more visually interesting.
💡Creating a more youthful palette: Go for triadic or tetradic color combinations — 3 or 4
hues equally distant from one another on the color wheel.
How Colors Impact Our Mood
To know COLOR PALETTES :
Color Scheme Personalities
Use monochromatic harmonies to:
Use triadic harmonies to:
Use split complementary schemes to:
Dreamy color palettes
Passionate colors
Youthful color palettes
Cheerful color palettes
whimsical color palettes
Elegant color palettes
Hopeful color palettes
Trustworthy color palettes
Mysterious color palettes
Industry-standard color palettes
Color palettes in nature
Color palettes of famous brands
Create calm and serene designs
Convey reliability
Create pages with a lot of text content
Create balanced drama and contrast
Create compositions that need more than two colors
Grab the viewer's eye without creating tension
Create bright designs that use full chroma colors

Add neutral colors to your color scheme to:
Use analogous harmonies to:
Use rectangular color schemes to:
Use complementary harmonies to:
Use square color schemes to:
Color Combination Preconceptions
Testing Color Combinations
Choosing palettes to test
Experiment with complementary harmonies — especially if you're a new designer
Make an impact without being too flashy
Create options for increasing contrast
Harmonize colors that are competing for attention
Serve as a background for the rest of the colors
Add visual interest to an otherwise monochrome color scheme
Create a calm and unified look that won’t distract users from your primary message
Create a connection with nature
Draw attention to a photo, room, or advertising piece
To create a typography hierarchy. Use the darkest color for body text and the three
remaining colors for headings and subheadings
Draw attention to your focal point
Express boldness and inspire action
Create youthful, lively designs
Designs with color-coded elements, such as signage or transit maps
Create a type hierarchy with a different color for each level of heading.
Testing for sufficient contrast
Measure accessibility color contrast. Stark plugin has a free version and works
in Figma, Sketch, Adobe XD, and Google Chrome.
Choose a suitable text/background contrast. Tools like Colorable can help you
here.
Measure the contrast between elements on a web page. Google Lighthouse in
Chrome tools implements such measurements.

Testing color helps answer the following questions:
Creating a Color Palette
 It's based on color theory. You followed color theory to create a harmonious color
combination.
 It fits your brand. The color palette represents your brand values according to color
psychology.
 It's accessible. The palette includes colors with a range of contrast sufficient to comply
with the Web Content Accessibility Guidelines.
 It doesn't have any controversial connotations. You took into consideration local
color meanings if your product targets a specific country or region.
Which color palette do users like more?
Which color palette represents brand values for the target audience?
Do the colors in the interface help users to complete their tasks?
Which color combinations result in better conversions?
1. Step 1: Pick a base color
Let's assume you've received a task from a client to create an exquisite color palette for
a fun, colorful, high-end fashion brand.
To start, you should pick a base color. If the client didn't provide any color preferences or
the brand's color guidelines, you have a couple of options:
Evaluate competitors. Take a look at the color palettes of existing brands and
companies.
Find inspiration. Explore ideas on Dribbble or Behance.
Compile your ideas. Create a mood board, picking up images and illustrations you
associate with the fashion brand.
Dive into color psychology. Consider the emotions and associations you want
users to have with the product.
2. Step 2: Test colors to pair
The split-complementary color scheme doesn't take the opposite hue, but rather colors
on either side of it. Triadic and tetradic schemes are harder to balance, but the result is
more exciting.
3. Step 3: Choose a base color scheme
Analogous and monochromatic schemes are the simplest and safest solutions to create.
4. Step 4: Adjust the colors
To spice things up, we need to adjust the current analogous color scheme. Changing the
saturation (how pale or pure the hue is) and brightness of colors
5. Step 5: Add in neutrals
Adding neutrals is the final touch of creating a custom color palette. Browns, tans, and
off-whites make color schemes feel warmer and cozier, but that's not what we need for a
luxury fashion brand.

Color & Branding
Criterias for defining palette color for a brand:
Color & Behavior
Creating hope:
Reassuring users:
Blues and greens are generally perceived as calming, relaxing, and soothing. Many studies
state that the natural environment — full of blue and green hues — promotes health,
reduces stress, fear, and anger, and positively affects cognitive recovery
Activating survival instincts:
Red is one of the most controversial colors. People associate red with the devil, blood,
aggressiveness, and violence, but it's also an ambassador for passion, love, and sex. At the
same time, that survival instinct can prompt users to take action toward a positive goal, as it
makes the action feel more urgent.
Prompting action:
Generally, warm colors (orange, red, yellow, pink, etc.) are associated with action, while cool
6. Step 6: Choose element colors
Once your color palette is ready, it's time to apply it to your designs. To make it right and
create a balanced composition, many designers swear by the 60-30-10 rule. It means
the dominant color takes 60% of the design area, a secondary color is used for 30%, and
10% is left for an accent color.
7. Step 7: Create a brand style guide
A brand style guide is your go-to solution that helps graphic designers, marketers, web
developers, etc...
exemple: https://blog.hubspot.com/marketing/examples-brand-style-guides
Brands and emotion
Appeal to your audience
Authenticity
Personality
Consumer perception
Color and competition
Color and brand personality
Differentiate your brand
Memorability
Yellow symbolizes the sun, warmth, energy, and joy
Green brings to mind thriving plants and nature, the spring season, and new beginnings
In most Western countries, white represents purity, enlightenment, and a fresh start

colors (blue, green, and purple) are more associated with passivity.
Fear of missing out:
This phenomenon refers to social anxiety that others' lives are much more interesting,
exciting, and fulfilling than our own. It develops into a deep sense of envy and makes people
feel less confident in their skills and personal qualities.
Creating disgust:
The color green is usually associated with new beginnings, good luck, health, and nature.
However, various shades and tones of it may trigger disgusts and relate to vomit, rot, decay,
feces, and sickness.
Color and the placebo effect:
Keep this in mind when selecting a color for your branding and marketing. Cool colors like
green, blue, or purple may not be strong enough to encourage your users to act (confirm an
order or make a purchase), while red or orange can impose too much pressure.
Perception of time:
This information empowers designers to be aware of the effect of color on users' mindset
and productivity. Using too much red on an interface puts users under pressure and makes it
harder to complete time-limited tasks.
Articles
How color affect you mood: https://www.verywellmind.com/the-color-psychology-of-
brown-2795816
Warm and Cool Colors: https://www.colorpsychology.org/warm-cool-colors/
The Color Psychology of Yellow: https://www.verywellmind.com/the-color-psychology-of-
yellow-2795823
SCANDINAVIAN COLOUR
SCHEMES:https://journal.projectnord.com/blog/scandinavian-colour-schemes-compared
There's Evidence Humans Didn't Actually See Blue Until Modern Times:
https://www.sciencealert.com/humans-didn-t-even-see-the-colour-blue-until-modern-
times-evidence-suggests
Evolutionnary psychology of red: https://www.bbc.com/future/article/20140827-how-the-
colour-red-warps-the-mind
The fundamentals of color psychology: https://99designs.com/blog/tips/color-psychology/
colors from evolution point of view
https://www.theguardian.com/science/2007/aug/21/sciencenews.fashion
Perceived distance and obesity: It's what you weigh, not what you think:
https://amplab.colostate.edu/reprints/Sugovic_etal_2016_Obesity.pdf

How Color Affects Mood & Emotion
There's a reason why healthy ecological products mostly use green packaging. Or why
athletes in red uniforms appear more confident and win more often. Or why you become
more relaxed and serene among lush green in a park after a long, hard day. Why does it
happen, and how does color work?
Color is a powerful tool people use for communicating, stimulating action, influencing mood,
and even modifying behavior. It can affect our performance and consumer behavior, increase
appetite, cause anxiety, or, oppositely, soothe emotions. However, while some colors evoke
universal associations, people may still react differently due to their memories, culture, and
current environment.
Understanding different color connotations will help you be more careful while selecting
colors for your next design project, marketing campaign, living room paint colors, or even a
new car.
Happy colors
Cues of being watched enhance cooperation in a real-world setting:
https://www.semanticscholar.org/paper/Cues-of-being-watched-enhance-cooperation-in-
a-Bateson-Nettle/48f87acd5008375edd45c3632c65cc9ba7350fa0
When to saturised color: https://thevisualcommunicationguy.com/2015/10/01/when-to-
use-saturated-colors/
70's colors: https://www.apartmenttherapy.com/house-colors-by-decade-36801915
The History of Color Television: https://www.thoughtco.com/color-television-history-
4070934
Popular Brand Colours in each industry: https://digitalsynopsis.com/design/logo-colour-
branding-psychology-industry-specific/
The Button Color A/B Test: Red Beats Green:
https://blog.hubspot.com/blog/tabid/6307/bid/20566/the-button-color-a-b-test-red-beats-
green.aspx
You Are Not the User: The False-Consensus Effect:
https://www.nngroup.com/articles/false-consensus/
The Impact of Interaction Design on Brand Perception:
https://www.nngroup.com/articles/interaction-branding/
Using Color to Enhance Your Design: https://www.nngroup.com/articles/color-enhance-
design/
The color psychology behind a relaxing and soothing home:
https://archive.curbed.com/2020/4/27/21232903/pantone-color-relaxing-soothing-home
The Influence of Forest Resting Environments on Stress Using Virtual Reality:
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6765889/

Happy colors
Although our experience and cultural backgrounds can influence personal color perception,
most colors of the yellow hue still come off as the happiest and stand for joy, warmth, and
optimism for many of us.
What other characteristics do people associate with yellow?
Avoid using yellow for a background that can cause severe eyestrain and hurt readability.
Energizing colors
Energizing colors
Now take a moment and think of an orange fruit. Imagine its tough, shiny bright skin and
refreshing citrus taste. What feelings does it call to your mind?
For many people, orange is associated with bursts of excitement and enthusiasm. Like
yellow and red, it draws attention and sparks energetic vibes. That's why many sports teams
use orange for their uniforms, mascots, and branding.[2]
Orange is also described as a warm and cozy color that brings back to memory Halloween,
autumn, pumpkin pies, sweet potatoes, carrots, and ginger cats.
In design, orange can be used to draw attention or alert users.
Sad colors
Sad colors
Looking at the image of the color blue for this practice, how blue does it make you feel? The
expression "feel blue" exists for a reason. Shades of the blue hue often create the feeling of
distance, coldness, loneliness, and sadness.
Remarkably, the nearly monochromatic palette of blues and blue-greens in Pablo Picasso's
paintings defined the artist's Blue Period (1901-1904) — his hard time of emotional and
financial insecurity.
Avoid using pale, low-saturated blue for CTA buttons.
Energetic: People often perceive yellow as a burst of excitement, energy, and positivity.
It tends to cheer you up and encourage action. No wonder marketers use yellow in
advertisements to grab viewers' attention and increase confidence.
Irritating: Highly saturated yellow can create a tense and irritating environment, while
dirty yellow may appear obnoxious and repulse people. To avoid such feelings in your
designs, stick to the cheery warm yellow that people associate with summer, sunflowers,
apricots, baby chickens, and sunbeams.[1]

Calming colors
Calming colors
Water makes up nearly 70% of our bodies, which explains the deep biological connection of
our body and mind with water. Simply staring at the bluish-green colors of the sea, ocean,
lake, or just a swimming pool causes an increase of neurochemicals that make us feel
calmer, happier, and more relaxed.[3]
However, clear skies can become stormy, and calming sea waves can rage. Deep blue and
greens can come off strong, powerful, and energetic, and even evoke awe.
Although white takes only 15th place in the ranking of favorite colors among adults, it's an
outright winner for evoking a quiet, peaceful atmosphere in living rooms and bedrooms.
Furthermore, it's the best option for creating a healthy working environment in offices and
conference rooms.[4]
Blue and green are perfect colors for meditation and yoga apps and websites. 
Trustworthy colors
Trustworthy colors
Many of us associate the color blue with serenity and tranquility. However, blue is also one of
the most trustworthy colors as it's primarily associated with positive and non-threatening
things, like a clear sky or clean water.[5] That's why banks or insurance companies often
leverage this color to project an aura of security and trust in their branding and marketing.
Like blue, green is a color of nature and also signifies safety and peace — think of green on
traffic lights.
Brown — the color of solid ground — also brings a sense of security, resilience, and safety.
However, like many dark colors, brown can be associated with negative emotions and
should be used sparingly.
Stimulating colors
Stimulating colors
Red is often considered a color of winners. At the 2004 Olympic Games in Athens,
contestants of 4 combat sports (boxing, tae kwon do, Greco-Roman wrestling, and freestyle
wrestling) were randomly assigned to wear a red or blue uniform. Scientists from the
University of Durham in England found that athletes wearing red won 55% of the time.[6]
Although some scientists are skeptical about those findings, the stimulating power of red is
undeniable. Being exposed to red can increase blood pressure, heart rate, and respiration

rate. More than that, red enhances metabolism and appetite. That explains why your mouth
waters each time you pass by a McDonald's restaurant or see an advertising banner.
Other warm colors like yellow or orange also evoke motivation and enthusiasm for life and
action.
Red, yellow, and orange are great colors for promoting food delivery apps and websites.
Peaceful colors
Peaceful colors
Color affects our mood, but can it influence our mental health? Researchers at the Aalborg
University of Copenhagen conducted an experiment observing the brain activity of
blindfolded participants being exposed to different colors of light. Red light stimulates
people's brains, while green light yields relaxation and tranquillity.
Another study showed the calming effects of the color blue.[7] Greens and blues symbolize
nature and tend to make people feel serene, peaceful, and relaxed. Notably, the research
conducted at the University of Exeter showed that people who live by the sea lead happier
lives. Having the opportunity to look at large water areas whenever they want prevents many
people from experiencing mental disorders.[8]
Light blues and greens can be the right base color for health institution websites or apps.
Creative colors
Creative colors
You rarely find purple in nature, so it's commonly associated with mysterious, spiritual, and
divine substances. The binary properties of purple — the combination of intense, stimulating
red and calming, tranquil blue — encourage imagination and boost creativity.
Notably, purple dye was very rare and extremely expensive in ancient times. Because only
rich individuals could afford such costly goods, this color became the symbol of both wealth
and royalty.
Restful colors
Restful colors
The color pink immediately brings to mind feminine and girly things, as well as Valentine's
Day, love, and romance. Surprisingly, pink possesses calming, tranquil qualities. In contrast
to red, it soothes rather than stimulates and can often be used for caring and nurturing
purposes.
The phenomenon of the Drunk-Tank Pink, also known as Baker-Miller Pink or Schauss pink,
claims that this particular tone of pink helps lower the heart rate, pulse, and respiration.

Prisoners placed in cells with pink-painted walls at the Naval correctional facility
demonstrated a reduction of hostile, violent, or aggressive behavior.
Other experiments, though, at the Santa Clara County Jail, proved the opposite. The positive
effect took place during only the first month of exposure to the color, but then rose after that.
[9]
Angry colors
Angry colors
If we ask you to name the first color that comes to your mind when you hear the word
"angry," you're likely to say "red." Among many cultures, red stands for blood, fire, anger, and
even rage. Notably, the expression "see red" is based on our physical reaction when we're
furious — the blood pressure rises, making our face and neck turn red.[10]
Red is fantastic for warnings and drawing attention but use this color thoughtfully to avoid
negative connotations.
Red is one of the problematic colors for color-blinded people, so don't rely on it solely to
inform users and accompany it with labels whenever possible.
Aggressive colors
Aggressive colors
Shades of red and orange color ranges are the most contradictory. On the one hand, they
stand for warmth and love, as well as passion, energy, and desire. On the other hand, these
colors represent power, aggressiveness, violence, and danger.
Being one of the most visible colors in the color spectrum makes red a winner when it comes
to grabbing attention. A red traffic light, warning or stop sign does more than inform people; it
warns them of a looming threat.
Orange, on the other hand, is often described as bright, happy, and uplifting. However, a by-
product of red and yellow, highly saturated orange can appear fierce, aggressive, and even
vulgar.
Grounded colors
Grounded colors
Brown is a down-to-earth color that appears grounded and authentic. Like the color blue,
brown embodies security and protection.
Depending on how dark and rich the color is, brown symbolizes wood or earth in feng shui.
Using brown in web and interior design creates a great sense of support and trust. Such
companies as UPS, Hershey's, Cotton, Edy's, J.P. Morgan, and M&Ms use brown in their

branding and marketing strategies to signify strong relations, reliability, and dependability.[11]
Don't go overboard with brown, though. Many people describe it as reserved, conservative,
and even boring.
Color Properties & Perception
Our eyes are the second most complex organ in our bodies — after the brain, of course.
Receptors in our eyes can see colors of certain wavelengths. The brain processes this
information, allowing us to see up to 10 million different colors
<sup>[1]</sup>
You've probably heard of the color wheel, different color models, and color properties. If you
haven't, check the lessons on color theory and color properties first. In this lesson, we dive
deeper into the physics and physiology of color perception and understanding color
relationships.
The better you can describe each color property, the better you become at detecting the
subtle differences between colors. This knowledge will help you create better color
harmonies for your projects.
How we see color
How we see color
We are able to see color because of photoreceptors in our eyes. There are two types of
receptors involved in sight: rods and cones.
Animals that see well in the dark have many more rods than humans.
Visible spectrum
Visible spectrum
Our modern understanding of light and color began with Sir Isaac Newton at the end of the
17th century. Newton used a prism to prove that white light is made up of a rainbow
spectrum of other colors. He created the color wheel by joining the opposite sides of the
color spectrum — dark red and dark blue-violet.
Rods work at very low levels of light. We use these for night vision because even a few
bits of light can activate them. Rods don't help with color vision, which is why we see
everything in shades of gray at night.
Cones need a lot more light, and they can see color. We have three types of cones:
blue, green, and red. The brain integrates the signals sent from these 3 types of cones to
allow us to see millions of colors. For example, we see yellow when green and red cones
are stimulated, but the blue cones aren't. When all the cones are stimulated equally, the
brain perceives the color as white.[1]

Human eyes can only process a tiny region of the electromagnetic spectrum — it's called the
visible spectrum. We call this visible light and its length is measured in nanometers (nm).
The colors we can see fall between 400-700nm.
Violet light and blue light have the shortest wavelengths, while red has the longest visible
wavelength of 635-700nm.[2] Interestingly, the color magenta doesn't actually exist in the
spectrum — it's an illusion.[3] Newton added it as a link to join the two sides of the spectrum
in a color wheel.
RGB additive color system
RGB additive color system
Newton formed what we call today an additive color wheel. It's called additive because if you
take the colors of light from the wheel and combine them, you get pure white.
Other color systems exist, too. Artists use one system when painting and there's another one
for printing (read more about them in our lesson on color theory). But in this lesson, we are
exploring the RGB color system. RGB is the color space for digital displays, and it's
used for cameras and other digital formats. Also, that's actually how our eyes perceive
color.
A light source within a device's screen creates any color users need to see by mixing red,
green, and blue with varying intensities. This is known as additive mixing. All colors begin as
black darkness, and then red, green, and blue light are added on top of one another. The
light brightens to create the desired hue. When red, green, and blue light is mixed together
at equal intensity, they create pure white.[4]
Designers can control aspects like value and chroma (saturation) by modifying any of the
three source colors.
Color hue
Color hue
In terms of physics, a hue is the dominant wavelength of light that a person can see. For
example, yellow, red, blue, and green are hues. The hue refers to the purest form of color
without any modifications.
However, hues are not just light at one wavelength. Blue does not exist because the other
wavelengths have disappeared from the light spectrum. Each hue contains the entire array
of wavelengths found in visible light. The dominant wavelength creates a distinct hue.[5]
Color chroma
Color chroma

Chroma is the level of saturation or the intensity and purity of a hue. A hue will be most
vivid in its natural state at 100% saturation.
You can decrease the intensity of a hue by adding gray. Every increment of gray adjusts the
tone of the pure hue. At 0% of saturation, every hue becomes gray.
You can also desaturate a hue by adding its complementary color. For example, if we take a
red and start adding cyan, red's complementary color, the red will become grayer. When
equal amounts of cyan and red are mixed, there will be no trace of either hue — only the
gray will remain.
Color value
Color value
Value refers to the lightness or darkness of a color. It defines a color in terms of how
close it is to white or black. This means that white is the color with the highest value while
black is the color with the lowest value.
For a particular hue, the more you increase saturation, the lighter the color will look.
However, different colors have different perceived lightness because of the difference in
wavelengths. For example, a saturated yellow will always look lighter than a saturated blue.
Adding white to a color makes it lighter, which creates tints. Adding black makes the color
darker and creates shades.
Tint
Tint
A tint is created when you add white to a color to lighten it. Tints are sometimes called
pastel colors. They can range from nearly the full saturation of the hue to practically white.
Sometimes artists add a small bit of white to acrylic paint to increase its opacity and cover
strength.
Tinting a color also desaturates the hue, making it less intense. For example, tinted red
becomes pink, and tinted blue becomes "baby blue." Using desaturated colors encourages
users to focus on another area of the design.[6]
Shade
Shade
Shades occur when you add black to a pure hue, usually forming darker, deeper, and
richer colors.
Just as with tints, you can add varying amounts of black to any hue to create shades of that
hue. Shades can range from a barely shaded pure hue that's only marginally darker than the

original to a deep black color that is only barely still in the color family of the original.
Tone
Tone
Tones are combinations of a pure hue with gray. Basically, toning a color decreases its
intensity or desaturates it. Tones are usually muted versions of your original hue. They can
be extremely useful for creating variation within your brand guidelines.[7]
Keep in mind that changing color value creates tints and shades, and changing saturation
creates tones.[8]
Primary colors
Primary colors
Primary colors are the ones we use to form all other colors. They can't be created by mixing
other hues together.
Additive color systems that are based on light — for example, in phone and computer
displays — use the primary colors of red, green, and blue. A light source within the device
creates any color by mixing these 3 and varying their intensity. This allows us to create all
the colors we see on our displays.
Secondary colors
Secondary colors
Secondary colors can each be produced by mixing two primary hues. For example, to see a
yellow light, red and green cones in our eyes need to be stimulated simultaneously.
The secondary colors in the RGB model are cyan, magenta, and yellow:
When you add all three of those together, you'll get white light.
Tertiary colors
Tertiary colors
Tertiary hues are usually named and created by mixing adjacent primary and secondary
hues. For example, orange is the tertiary hue between red and yellow. Other tertiary colors
are chartreuse green, spring green, azure, violet, and rose.
Perceived color temperature
Red light mixed with green light creates yellow.
Green light mixed with blue creates cyan.
Blue light mixed with red creates magenta.

Perceived color temperature
We categorize color temperature due to the feelings that we get when looking at the hues.
We see red hues as warm, while blue hues seem cold to us.
Research proves that color impacts object temperature perception, and this connection is
stronger in one direction. For example, the red color evokes a feeling of warmth, but warmth
isn't always associated with red. This is probably because colors are often used to indicate
temperature, but not the other way around.[9]
Perceived color temperature can change the mood, feeling of warmth or coolness, and alter
the perception of size and distance. This is something that we, as designers, should consider
when creating user interfaces.
Warm colors
Warm colors
Warm colors are evocative of the sun and fire, conveying a sense of warmth and comfort.
Yellow, red, orange, and variations of these colors are warm colors. These hues have the
longest wavelengths on the color spectrum. The resulting colors are lively and stand out.
Warm colors are perceived as inviting and comforting, but they can also be stimulating.
Gyms and living rooms often use these colors as they promote activity. Advertisers use warm
colors to provide a sense of urgency with red clearance signs, or cheerfulness in fast-food
chains.[10]
Cool colors
Cool colors
Cool colors have a cold effect on people. Green, blue, purple, and variations of these colors
are considered cool colors. They have shorter wavelengths compared to warm colors.
Cool colors are reminiscent of earthy objects, such as grass and water. These hues often
feel cool and refreshing, much like the outdoor areas that they are associated with.
Cool colors provide a sense of calm and relaxation. In interior design, they are used in
spaces intended to be tranquil, like bathrooms and bedrooms. Blue, purple, and green are
utilized in advertising and UI design to convey trustworthiness and respect.
Traditional Color Meanings
Although we can make general assumptions about colors and their symbolic meanings, our
memories, cultures, religions, and environment have a substantial impact on how we
perceive individual colors. For example, while in Western cultures, brides wear white dresses

as a symbol of purity and innocence, in Asian countries, white has the opposite meaning and
is linked to death, mourning rituals, and sadness.[1]
The right color selection gives users context, directs their eyes in the right directions, and
helps them make decisions. Knowing the traditional meanings of color and understanding
the thin line between color associations in different cultures helps designers select color
palettes for product branding and marketing campaigns more intentionally.
Red
Red
Red is the most powerful and also contradictory of the colors. On the one hand, it stands for
love, passion, desire, and health. On the other hand, it conveys danger, anger, violence, and
fear. Such negative emotions are linked to associations with wars, blood, and fire.
Above all, red is hard to ignore, and that's why red traffic lights and stop signs utilize red for
warning and getting people's attention fast. For similar reasons, people wear red to catch the
eye and stand out from the crowd. Roughly 64% of the cones in the human eye are sensitive
to red light wavelengths, which is why red stands out so much.[2]
In many cultures, red is a symbol of vital energy and health. For example, in Italy, children
wore a chip of red coral around their necks to attract good luck and protect them from
diseases. In many paintings of the 1500s, you can see kids with a small horn or a coral
branch.[3]
Orange
Orange
The binary nature of orange makes it both as energetic and powerful as red and as happy
and friendly as yellow. People associate orange with many positive things in life, including
sunsets, pumpkin pies, ginger hair and ginger cats, freckles, oranges, tangerines, apricots,
and peaches.
Orange can be described as energetic and enthusiastic, while its strong connection to the
autumn season and Halloween evokes warm and cozy feelings about this color.
Like red, orange is intensely visible and used for spacesuits and traffic cones to draw
attention and give a warning.
Yellow
Yellow
Yellow is the happiest color of all. No wonder it's the color of such positive characters as
Spongebob Squarepants, the Simpsons, Lego people, Pikachu, emojis, and, of course, the
Minions.

In most cultures, yellow represents warmth, sunshine, and joy. It's often used in situations
when you need to lift spirits and create an atmosphere of brightness, light, and optimism.
In turn, dull or dirty yellow may be associated with cowardice, deceit, sickness, and jealousy.
Certain shades of yellow can make people feel irritated or angry in a room. Some studies
suggest that babies feel more unsettled and cry more in yellow rooms.[4]
Green
Green
Green is the most dominant color in nature and has strong associations with calmness and
harmony. Simply spending time in a park or forest, or looking at pictures of lush, green trees
and grass has a healing and soothing effect on the human body and mind.
On top of that, green promotes concentration, improves focus, and reduces anxiety.[5] This
color also stands for growth, youth, and hope due to the associations with the spring season
and the rebirth of earth fertility.
The other side of green is linked to ambitions, financial stability, and success, as well as
greed and jealousy.
Blue
Blue
When you think of blue, you probably imagine large expanses of water and endless skies.
The color evokes feelings of freedom, reflection, and spirituality. However, blue is also a
highly corporate color and is often associated with intelligence, stability, reliability, and
conservatism. For this reason, blue is the color of police uniforms in many countries.
For the same reason, many bank institutions and insurance agencies use blue in their
branding and marketing to promote a sense of security and trust. Due to its calming and
tranquil properties, blue is one of the most likable colors globally, though by a larger margin
of men than women.[6]
It is better to avoid distant and cold dark or dull blue in designs that are meant to inspire
positive feelings. 
Purple
Purple
Rarely seen in nature, purple creates associations with the supernatural, spirituality, and
mystery. It's often described as creative and inspiring, which explains the meaning of the
expression "purple prose" — overly imaginative, hyperbolic writing.

Historically, purple is also a symbol of royalty and luxury. This connection goes back to when
purple dye used for coloring fabrics was extremely expensive, and only a royal family and
people of authority or high rank could afford such items.
Pink
Pink
Pink is one of the most cheerful colors. It's associated with childhood, unicorns, cotton
candy, bubble gum, flowers, Barbie dolls, and sweets.
Even though both red and pink symbolize love, red represents passion and desire, whereas
pink has more tender and romantic connotations.
People often describe pink with qualities like softness, compassion, nurturance, and
kindness. For this reason, the pink ribbon became an international symbol of breast cancer
awareness.
Some shades of pink represent youth and innocence and may appear childish, euphoric, or
lighthearted. On the flip side, highly saturated pink can look playful, flamboyant, and exotic.
Gray
Gray
Carrying the attributes of two colors, gray can be associated with the calmness and
neutrality of white and the elegance and intelligence of black.
Conservative and diplomatic, gray is the color of business suits, offices, and practical, down-
to-earth approach. The middle-ground position between black and white explains the
expression "gray area" — an unclear, ill-defined situation.
While soft gray appears calm and nonchalant, too much gray can be ice-cold, depressing, or
even authoritarian.
Black
Black
The legendary invention of Coco Chanel — the little black dress — tightened up the status of
black as a color of elegance, dignity, and sophistication.
We associate black with luxury goods, high ranks, and noble richness. More than that, in
many countries people like judges, police officers, and priests wear black to represent
security, power, and authority.
In many cultures, black is tied to such negative things as death, sorrow, evil, fear,
depression, and anger. These associations explain the origin of such expressions as in the
black, black mark, black sheep, blackmail, black market, blackout — you name it.

White
White
For many individuals, white symbolizes new beginnings, exciting ideas, and a fresh start. It
helps us clear our minds and calm down by promoting feelings of peace, honesty, and
simplicity.
In many western cultures, white represents purity, faith, and the heavens and is often linked
to angels and weddings. A bride's white dress is meant to symbolize virginity and innocence.
We often link white with medical centers, sterility, safety, and cleanliness. At the same time,
the color may appear cold, distant, and dispassionate.
Too much white in design can create a sense of emptiness.
Brown
Brown
Hazelnuts, coffee, chocolate, caramel, baking, wood, soil, and grizzly bears are likely things
that come to mind when you think of the color brown. It oozes reliability, security, and stability
and makes us think of warm fall evenings spent by the fireplace with our close circle of
friends and family.
Brown is often seen as grounded, rugged, and solid, just like the earth. It's often used in
marketing and branding to ensure a product's confidence, support, and comfort. Think of
Hershey's, Nescafe, M&M's, or Gloria Jean's Coffee.
Despite positive associations with brown, like all dark colors, it still can evoke negative
associations with things that are rustic, poverty, plainness, and even isolation. More than
that, it's one of the least favorite colors for all genders.[7]
Beige
Beige
Beige is a contradictory combination of warm brown and crisp, cold white. Some people find
beige calming, elegant, and flexible, while others think it's boring and conservative.
Variations of beige like ivory, taupe, pearl, off-white, or opaline create a perfect base color for
modern — even luxury — goods, house decorations, and interior designs.
Associations with ice cream, biscuits, cozy linen, and sweaters evoke feelings of comfort,
warmth, and calmness.
The simplicity and cleanliness of beige make it a perfect candidate for interface
backgrounds.

Cultural Differences in Color Perception & Meaning
Some color meanings are universal, which comes both from evolution and globalization.
Nowadays, you can find pink girl toys and blue boy toys in almost every country. But colors
also have historical meanings that differ by culture, nation, country, or region. Even if the
historical significance is lost, color schemes still evoke strong emotions.
Multinational companies adapt to local markets to succeed. They research how local
customers receive the product, its price, and marketing.[1] But it's also crucial to conduct
market research on color preferences. For example, a company that emphasizes its
country's national colors can succeed at home but fail abroad.
In this lesson, we'll look at some examples of how colors are perceived in different regions,
countries, and cultures. This is not an exhaustive list, though. The examples are to illustrate
why you should always do market research on local color meanings.
Blue worldwide
Blue worldwide
Studies have shown that blue is the most universally favored color. It's been like that since
early color psychology studies in the 1940s.[1] A survey conducted in 2015 revealed that blue
is the most popular color across all countries, genders, ages, races, and even political
affiliations.[2]
Between 23% (in Indonesia) and 33% (in Great Britain) of people like blue most out of the
colors listed, putting it far ahead of any other color. Blue even wins in Asia, where colors like
red, yellow, and green are traditionally loved. Blue tends to be more popular with men than
women, but women still like blue more than any other color.
According to the ecological valence theory, our color preferences are determined by the
color of things we like. If you look at things associated with blue, like the sky and water,
they're mostly positive for everyone.
Blue is a safe color choice in any environment or demographic. Just check out big digital
companies like Facebook, LinkedIn, and Skype that use blue in their branding. Brick and
mortar companies like GM, Ford, Intel, Boeing, and Walmart also leverage blue's
universality.
Pan-Arab colors
Pan-Arab colors
The Pan-Arab colors are black, white, green, and red. Individually, they each represent a
historical Arab dynasty or era.[3] These colors have significance across the Middle East and
are used in many Arab countries' flags across the region.

In a 2013 color marketing study in Saudi Arabia, participants chose black and white as their
favorite colors. They both are also associated with high quality.[4] Green is mainly associated
with peace, wealth, agriculture, and prosperity. Red isn't used on its own very much but
works together with the entire palette.
Pan-African colors
Pan-African colors
Let's go back in time for a moment. Ethiopia is the only African state that resisted European
colonialism. In 1897, after defeating the Italian colonial army that occupied Ethiopia for a
brief period, the country created a new flag. It was a red, yellow, and green tricolor.
The colors of the Ethiopian flag became the symbol of resistance against foreign occupation.
Newly independent countries would use these colors in their flags. Another variation of the
Pan-African color scheme was developed later. It includes red, green, and black.
The meaning of the individual colors varies from country to country. Generally, their
meanings are as follows:
National colors
National colors
National colors are part of a country's set of national symbols, along with the flag, coat of
arms, etc.[6] Some of them were very officially chosen; others became well-known through
popular use.
National colors often appear on countries' flags, athletes' uniforms, and local brands. Using
national colors emphasizes the bond with the country. Businesses prefer using these colors
on promotional campaigns related to national holidays.
Red in Asia
Red in Asia
Red is considered a positive color in many Asian cultures. It signifies long life, happiness,
prosperity, and good luck.
Green represents hope and growth and natural fertility.
Red represents the blood and common heritage of Africans during the fight against
oppression.
Yellow represents peace and harmony between various Ethiopian ethnic and religious
groups.
Black signifies the color of the people.[5]

In China and Vietnam, it's customary for brides to wear red wedding dresses. During Lunar
New Year, people give others red envelopes with money. Also, many Asian people wear red
during the celebration of the New Year.[7]
Keep in mind that in East Asian stock markets, red signifies a rise in stock prices. That's the
opposite to most other markets.[8]
White in Asia
White in Asia
In some Asian countries, the color white is the symbol of bad luck, mourning, and death. This
color is commonly worn at funerals in China and Vietnam.[9]
However, not all meanings of white are negative, just like black in the Western culture isn't
exclusive for mourning. White also symbolizes brightness, purity, and fulfillment. It's widely
used in consumer goods design, and it's a common color choice for cars.[10]
Monochromatic colors in Nordic countries
Monochromatic colors in Nordic countries
Even if you aren't familiar with Scandinavian design, you've probably heard of Ikea. It's a
popular Swedish company that sells affordable but good-quality furniture and home
appliances.
Scandinavian design is characterized by subtle and muted colors and pastels. Think greys,
white, and blues. Because winters are long and dark, it's important to make as much use of
natural light as possible. But in the last few years, more color has been appearing.[11]
Similar color palettes are also used in UI design. McDonald's uses light color schemes with a
lot of white for their websites in Norway, Denmark, and Sweden.[12]
Vivid colors in India
Vivid colors in India
India is a huge and diverse country, and it is reflected in its look. Everywhere — from the
architecture to clothes to food — you'll notice bright, vivid colors. That's because color has
been a large part of the Indian consciousness, and it stands out in every aspect of life.[13]
Neutral colors aren't common because of negative connotations. Black is usually associated
with negativity and even bareness; white is worn when mourning; brown is the color of
sadness.
However, primary and secondary colors like purple, yellow, orange, blue, and green have a
positive meaning. They are linked to comfort, wisdom, belief, virtue, and nature, respectively.
[14]

These color preferences are also reflected in UI design. Just check out the Lakme India
website to see how its palette is different from its global counterpart.
Yellow in Japan
Yellow in Japan
The traditional colors of Japan trace their historical origins to the dress code established in
the 7th century. In this system, rank and social hierarchy were displayed and determined by
specific colors based on the five Chinese elements.[15]
Some colors like purple and orange were reserved for the robes of the royalty and high-
ranking officials, respectively. Blue was for everyone, from samurai to the common folk.
Nowadays, yellow in Japan is associated with light, youth, hope, and change. The gold
shade of yellow symbolizes the sun and the gods’ power and mercy. Gold is often used at
temples and shrines.[16]
Green in the Southern Java
Green in the Southern Java
You might have read internet articles saying that wearing green is taboo in Indonesia. In
reality, that's not true for most parts of Indonesia. However, it's a perfect example of how a
color meaning can be specific to a small region.
In the southern part of Java Island, wearing green is discouraged. There's no official law
stating that you can't, but a local legend says that people who wear green are dragged to the
sea by the Queen of the Sea.
A less mythical possible explanation is that the waters of the Indian Ocean that wash the
southern shore of Java are green, and the waves are strong. If someone gets lost in the sea,
green clothes will make it difficult to find the person.[17]
When conducting market research about color, keep in mind that there might be regional
variations in meaning.
Why Color Affects Us
In recent years, color psychology has been a hot topic in marketing, art, design, and other
industries. Despite the general lack of theoretical knowledge of why we perceive colors in
specific ways, a few theories dig into the psychology of color and attempt to discover why
color has such a strong effect on our moods, feelings, and behaviors.
The evolutionary theory stems from the idea that ancient people saw colors differently and
gradually developed their vision in order to survive and adapt to rough conditions. In turn, the
supporters of the ecological valence theory believe that our feelings about colors and their

preferences root deeply in our own experience and environment. Unfortunately, there are still
many weaknesses in the theoretical and empirical works of both approaches.[1]
Yet, understanding the direction of experiments and research in this area will help designers
develop their expertise in color theory and take a more sensitive approach when applying
colors in their projects.
Evolution & color psychology
Evolution & color psychology
Have you ever wondered why you prefer one color over another? Or why some people don't
like yellow and even find it disturbing or annoying, although it's commonly considered a
cheerful color? The reason for that lies far beyond traditional color associations.
According to studies, there are two sources that all color preferences originate from
— evolution and ecological valence theory.
There are 2 components the evolutionary approach relies on:
Ecological valence theory
Ecological valence theory
In contrast to the evolutionary theory based on the development of retinal cones, the
ecological valence theory suggests another approach.
In their study, American psychologists Karen B. Schloss & Stephen E. Palmer proved that
people are attracted to colors associated with positive things or situations from their past.
More than that, individuals' color preferences can change after having an unpleasant
experience with a certain color.[4]
Blue, for example, is the most likable color because it represents clear skies and clean water
and has a calming and relaxing effect. In turn, brown is associated with negative things like
feces, dirt, diseases, and rotten fruit and is the least common favorite color.[5]
Survival needs: In ancient times, the ability to identify certain colors was critical to
human survival. That's why human eyes developed special retinal cones to identify red
that could indicate ripe fruits, as well as blood, fire, or poisonous, dangerous plants or
animals.[2]
Language: The development of languages has also shaped how humans perceive
colors. The existence of specific color names in certain languages indicates that
indigenous people could relate to these colors and identify them. For example, in ancient
times, Egypt was the only country that produced blue dye. Thus, only Egyptians had a
word for the color blue.[3]

What if you were hit by a blue color or get seasick when traveling by boat? You're more likely
to dislike the color blue in contrast to others' fondness for it.
Color preference as survival technique
Color preference as survival technique
Have you ever wondered why pink seems to be the de facto color for girls? Is it a cultural
thing related to the commercial image of femininity, or is there some biological basis for why
women prefer pink more than men do?
Some studies used an evolutionary approach to explain women's preferences for reddish
colors. The theory suggested that while women were primary gatherers in ancient times,
they developed a visual ability to spot ripe fruits and red berries.[6]
However, an experiment that involved 171 British adults and 37 recent immigrants from
China revealed that the most preferred color of both genders is blue. Although, women
indeed tend to like blues with a pinkish tone more.
The overall preference for blue can also be explained with an evolutionary theory. Blue
indicates such positive things as good weather for hunting and gathering and a source of
clean water.[7]
Both theories have not been thoroughly studied, though, and should be taken with a grain of
salt.
Language effect on color perception
Language effect on color perception
Not only did our ancestors see colors differently from us, but people from other parts of the
world who speak different languages also see colors in different ways. Despite the criticism
of this theory, multiple studies show that the role language plays in color perception cannot
be denied.
Back in 1858, British scholar William Gladstone, followed by German philosopher Lazarus
Geiger in 1880, researched Homeric Greek literature and found intriguing results.
Remarkably, the lack of color terminology for blue in classic poems like The Odyssey might
have influenced how Greeks saw this color until modern times.
In support of this research, a group of psychologists from Goldsmiths University of London
published an experiment in 2006. Participants from the Himba tribe (indigenous people of
northern Namibian areas) were asked to group similar color tiles or pick a tile of a different
shade.
Surprisingly, the findings showed that tribe members had only 5 color categories in their
language and used the same category for naming blues and greens.

Respectively, they were unable to distinguish blue tiles from green ones. In turn, the Himba
language has more terms describing different shades of green, and they quickly picked out
the different shades of green during the experiment. Notably, it took a while for English-
speaking participants to spot the same difference.[8]
You can take a small test to check how well you perceive colors and shades and compare
your results to the UK public.
Positive associations
Positive associations
According to both evolutionary and ecological valence theories, greens and blues evoke the
most positive emotions. In ancient times, green meant shelter from bad weather and wild
animals. It also was a sign of enough rain and humidity to cultivate the land and yield great
crops. Blue indicated a clean water source and perfect weather for hunting and gathering.
Likewise, in modern times, green and blue are linked to nature, health, and serenity. Just
thinking of these colors, we imagine lush green foliage, large areas of water, forests, and
waterfalls. It usually makes people feel relaxed and more peaceful.
Negative associations
Negative associations
Although people may have color preferences based on their experience and current
environment, dark brown and greenish-yellow rarely hold the top spot in lists of the most
favorite colors.
The reason for that is that we mostly encounter these colors in things such as dirt, feces,
vomit, and rotten produce. These colors also symbolize autumn and are automatically
associated with sadness, diseases, and depression.
On the contrary, the color brown also stands for fertile soil and wood from an evolutionary
standpoint. So, it can be associated with such positive things as stability, trust, and reliability.
Color preference changes
Color preference changes
Despite the evolutionary history and traditional color associations, our past takes the lead in
shaping our perceptions and color preferences.
For example, blue is generally a positive color. It's often found in nature and associated with
clear skies, blue water, and beautiful flora and fauna like irises, forget-me-nots, peacocks,
and bluebirds. People tend to love this color as it makes them feel serene and relaxed.
However, a damaging episode involving blue (for example, getting hit by a blue car) can
change a person's color perception permanently.

According to the ecological valence theory, the more positive memories an individual has
with objects of a given color, the more they like it. On the contrary, the less happy
experiences linked to the color, the less a person prefers it.[9]
The Context of Color
While some research about color psychology exists, it's a challenging topic to study. We can
gather quantitative data to base our theories on, but it's often impossible to recreate the
conditions to prove them. The two leading theories are the evolutionary theory and the
ecological valence theory.[1]
The ecological valence theory states that our color preferences depend on our experiences.
For example, people who like the sea will more likely like colors of the blue hue because of
their positive experience with it. This theory explains why color meanings differ among
individuals and cultures.[2]
The evolutionary theory claims that our color preferences are determined by evolution.
Keep in mind that both theories are based on inductive reasoning, which is uncertain by its
nature.[3] But the correlations are significant enough that we as designers can use them to
our advantage.
Visibility
Visibility Bad Practice
Visibility Best Practice
The premise is that lighter colors are more visible than darker colors. This is thought to be an
evolutionary trait as we associate lighter colors with daytime and darker colors with
nighttime. In turn, it makes us feel that white is more visible than black, and visibility
influences people's behavior.
Humans associate light with "good" behavior. In one study, people who recalled an ethical
behavior estimated the room to be brighter.[4] Another point is that people tend to behave
better when their actions are visible. In another study, people donated more money near an
image of eyes.[5] The conclusion is that, subconsciously, people want others to see their
good deeds.
And, on the contrary, darker colors feel less visible and can encourage "bad" behavior. For
example, research on aggression in professional sports findings shows that sports teams
with black uniforms get more penalties.
How can we as designers use this knowledge? Determine your desired user behavior.
Choose light colors to encourage "good" behaviors and dark colors for "bad" behaviors:

Importance
Importance Bad Practice
Importance Best Practice
Research shows that heavy objects seem more important. One study found that information
on a heavy clipboard appeared to be of more importance compared to lighter ones.[6]
What does that have to do with colors? Psychologist Edward Bullough studied the visual
weight of colors in the early 20th century. He concluded that paler shades are perceived as
lighter, and darker colors seem heavier.[7]
For designers, this means that we need to use darker colors to make information seem more
critical. This way, people will ascribe more "weight" to this content.
Actionability
Actionability Bad Practice
Actionability Best Practice
While dark colors seem heavy and important, light colors encourage action. The theory is
that we simulate actions before we do them. For example, before jumping a distance, we
imagine how we would do it. Physical weight can distort this simulation.[8] In other words,
when you imagine jumping in a dimly lit room, the distance seems farther.
How does this translate to UI? The assumption is that in dark interfaces, movements seem
to take more effort because the heavy colors "hold us down." And, on the opposite, lighter
interfaces are easy to move through.
How can we utilize this knowledge? Light themes are great for action goals — for example,
making a purchase. You have probably noticed that most e-commerce websites use light
mode by default.
Duration
Duration Bad Practice
Duration Best Practice
Use a white background for charity websites. The data shows that it results in more
donations. The white background makes users feel that their donations are more visible
to the world.
Use darker backgrounds for beginner software. New app users might prefer a dark
UI so that nobody will see their rookie mistakes.
Use dark themes for adult content. Visitors of an "adult" website might prefer a dark
website that subconsciously implies nobody will see them.

Research proves that light colors encourage action, and dark "heavy" colors invite people to
linger and take their time.[9] When movements feel more difficult, exit actions like leaving the
website decrease. Darker colors can result in visitors staying on the page longer.
In UI, dark themes are helpful when you want users to spend more time on your website.
Many streaming apps like Spotify use dark themes.
Attraction
Attraction Bad Practice
Attraction Best Practice
Research shows that we see warm colors like red, orange, and yellow as attractive. There
are several theories behind that.
One states that it's an evolutionary mechanism that primates developed to attract mates.[10]
For example, some monkeys develop red swellings on their butts to attract mates.
The other theory is that we associate warm colors not just with physical but also with
emotional warmth. The possible explanation is that, as babies, we experienced these two
concepts simultaneously whenever our parents held us. This means that activating physical
warmth activates social warmth. And research proves it — we perceive other people to be
friendlier when we hold a hot beverage.[11]
As UI designers, we need to use warm colors in contexts where people desire social
closeness, for example, in dating apps.
Details
Details Bad Practice
Details Best Practice
We know that our brain confuses physical warmth and social warmth, but there's also a third
concept that comes into play — proximity. When we feel the warmth from being held, it
means that the source of heat is really close to us.
How does this translate to design? Warmer-colored objects feel close, and that orients users'
attention towards details. Cold colors, on the contrary, seem farther away. This results in
users focusing on the bigger picture.
In one study, customers preferred red advertisements that described the details of a camera.
But for overview advertisements, they liked the color blue.[12]
The takeaway for designers is that red is suitable for details, but blue is better suited for
overviews.

Time
Time Bad Practice
Time Best Practice
Research shows that there's a connection between colors and time perception. The more
distant an event is, the less colorful we imagine it. In one study, researchers asked people to
color a blank drawing of a housewarming party. If the party was happening in the distant
future, people used more variations of grey.[13]
A possible explanation is that we think of events as material objects. And the farther objects
are from us in the real world, the less intensely colored they seem because of the
atmosphere.
People subconsciously like it when the event's distance in time matches the perceived
"distance" of a color — it's called congruence. The same study found that people donated
more money to a distant fundraiser with black-and-white imagery.
So when you design ads, reduce the color for "distant" events to match the timeline with the
perceived color "distance."
Stimulation
Stimulation Bad Practice
Stimulation Best Practice
The theory about neurological arousal states that warm colors are stimulating while cool
colors are relaxing.
When we are relaxed, time seems to pass faster.[14] It makes blue a good choice for loading
screens as it makes users a little bit more patient.
Red stimulates the production of adrenalin, which causes neurological arousal. In this state,
people are more likely to take action and less likely to rationalize or debate if they should.
This makes it a good option for checkout pages. Brick-and-mortar shops like Target use
saturated red at the checkout area too.
Aggression
Aggression Bad Practice
Aggression Best Practice
Seeing red stimulates adrenaline production, which triggers our fight-or-flight response. Our
body is getting ready to act against the stressor. Our air passages dilate to provide our

muscles with the oxygen to fight or run away. Our blood vessels contract to re-direct blood
towards major muscles, including the heart and lungs.[15] Our aggression level rises.
One study found that eBay auctions with red backgrounds get higher bids because users
behave aggressively.[16] The conclusion? If you want to increase users' willingness to act
aggressively and bid higher, use red hues in your design.
Blue, on the opposite, works better to reduce aggression. Our guess is that it might be one
reason why many social networks like Facebook or Linkedin use blue as their primary color.
Gender
Gender Bad Practice
Gender Best Practice
In 2007, researchers studied sex differences in color preferences in British and Chinese
subjects. The premise was that our biology has at least some impact on color preference.
The researchers found out that, on average, females prefer warmer colors like red and
purple hues, and males prefer cool colors like blue and green.[17]
The evolutionary theory of labor division states that women used to be primarily gatherers,
so the ability to see red and yellow fruits was crucial.
The ecological valence explanation goes back to the 1940s when pink became the "girl
color" and blue — the "boy color." Regardless of their gender, people of each biological sex
probably grew up with mostly pink or blue toys.
In the same research, Chinese males expressed more preference for red hues. It can be
explained by the fact that historically in Asia, red symbolizes luck, joy, and happiness, so it's
universally liked.[2] Also, many studies agree that worldwide, people prefer blue regardless
of their gender. It might be that girls' preference for pink evolved over a natural, universal
preference for blue.
There isn't enough research to make firm conclusions about gender preferences. However,
we can observe that many apps and marketing campaigns that target adults utilize
this color bias. Apps for women like the Flo Menstrual Tracker use red and pink colors. You
can also clearly see the color divide in shaving products. Razors for women are often pink or
other warm colors, while razors for men are traditionally blue and black, although the market
has slowly been changing.
Influencing Mood with Color Combinations
Not every designer has the freedom to create their color palette from scratch. When working
with established brands, we have to work with brand colors. These colors define a brand's
visual identity and complement its personality and style.

There are two different types of brand colors:
• Primary brand colors are the main colors used in all graphics, publications, logos, etc.
Avoid changing them unless you have to.
• Secondary brand colors act as a complementary color palette to the primary. These are
the colors you can update to reflect strategy trends and marketing goals.[1]
For example, you can change secondary colors to appeal to a younger demographic, create
sophistication, liven up dull colors or soften more "aggressive" color palettes. Keep in mind
that colors can look quite different in combination. Combinations can amplify and reinforce
individual color meanings.
Creating a more youthful palette
Creating a more youthful palette Bad Practice
Creating a more youthful palette Best Practice
Blue, as the world's favorite color, is a go-to choice for many products. This color evokes
feelings of calm, happiness, and trustworthiness, which is why banks or insurance
companies use it in their branding. On the flip side, many people associate blue UIs
with boring things for serious people.
So what colors can you add to blue to make it more exciting and appealing to younger
people? Go for triadic or tetradic color combinations — 3 or 4 hues equally distant from one
another on the color wheel.[2]
For blue, its tetradic colors are pink, yellow, and green. These color combinations tend to be
quite vibrant, even when toned down, tinted, or shaded. The colors can come across
as playful and youthful. Make sure to balance these combinations because they can be
easily overwhelming, for example, by lowering the color saturation and value.
Creating a more sophisticated palette
Creating a more sophisticated palette Bad Practice
Creating a more sophisticated palette Best Practice
Magenta is a purplish, pinkish color that has a few different versions. It's located exactly
midway between red and blue on the color wheel. Magenta is an extra-spectral color,
meaning that it's not associated with a single visible light wavelength.[3] On its own, it evokes
the feeling of mystery and magic.
Magenta also carries a sense of sophistication that you can emphasize by adding other
colors. You can keep the palette monochromatic by adding another version of the same or
similar hue. Or you can use analogous colors that sit directly side by side on the color wheel.
Then, add neutrals like grey and black, both of which are considered elegant and sleek.

Softening strong colors
Softening strong colors Bad Practice
Softening strong colors Best Practice
Red is an engaging and vibrant color that is proven to trigger the release of adrenaline. It's
associated with both passion and danger. So how can we soften such a powerful color?
One way is to create monochromatic pastel palettes. To do this, increase the value of the
hue and decrease its saturation.[4] In the example, adding pink colors of varying intensity to
the red creates a calmer and more harmonious palette.
Amplifying energetic colors
Amplifying energetic colors Bad Practice
Amplifying energetic colors Best Practice
Warm hues like yellow, red, and orange are easily noticeable and stimulating. So the first
step of creating an energetic palette is to start with a warm color. To amplify the effect,
increase color saturation. Similarly to how decreasing saturation creates calmer pastels,
increasing it produces an energizing effect.
Toning down bright colors
Toning down bright colors
Sometimes, the main brand color is too bright, and designers look for a way to tone it down.
Just like with bright red, using monochromatic pastels will have a softening effect. However,
blue isn't as energetic as red, so the resulting palette might be too boring. A trick to make it
more exciting is adding a tint of its complementary color — in this case, orange. It will add
the necessary contrast and make the combination more visually interesting.[5]
Energetic palettes
Energetic palettes
A brightly colored palette looks energetic. Bright colors work well when you need to attract
attention or inspire energy, excitement, and happiness.[6] To achieve this goal, use pure
saturated colors without adding black, grey, or white.
You can amplify the effect by using triadic colors. For example, if you're starting with yellow,
add magenta and cyan to create a vibrant palette that's full of energy.
Livening up dull palettes
Livening up dull palettes Bad Practice

Livening up dull palettes Best Practice
Overusing muted or neutral colors can make your palette appear dull. How can you remedy
that?
Create contrast. It can be a contrasting color or a contrast in saturation — which means
adding a brighter color. For example, adding a moderately intense orange to a palette of
orange pastels will be enough to liven it up.
Using neutrals to change the mood
Using neutrals to change the mood Bad Practice
Using neutrals to change the mood Best Practice
Sometimes we use neutral colors when we don’t know which colors to choose. But neutral
colors can do much more than that. They help create harmony between colors as they
highlight the rest of the colors and don't compete for attention. They also create more
contrast in the design and can alter the overall feel of the palette.
The pure neutral colors are black, gray, and white. Brown and beige are also considered
neutrals but are actually variations of orange (which is why they aren't considered pure
neutrals). Adding different neutral colors will produce different effects.
For example, adding white to a mostly red palette can make it feel softer and more romantic.
But adding black — another neutral color — would make it feel angrier or more passionate.
Experiment with adding different neutral colors to see what helps produce the right
impression.
How Colors Impact Our Mood
At this point, you might be already familiar with traditional color meanings and their variations
depending on culture, current environment, and personal experience. How can this
knowledge help designers create emotionally powerful color palettes?
Notably, the same color can have different psychological effects on people in different
surroundings. For example, soft blue combined with other muted positive colors like orange
or coral creates a dreamy, warm atmosphere. When the same shade of blue accompanies
dark blues and greens, it feels cold and distant.
By adjusting hues, saturation, and values (degree of lightness or darkness), you can create
a vast number of color palettes for any industry or product type. Speaking of that,
on Coolors, you can adjust the HSB, RGB, and CMYK values for any color, pick the exact
shade of each color, or isolate the color you like most and try it with different color
combinations. If you like the colors of a certain picture or movie scene, you can upload it to
Coolers and receive a color palette based on the image.

Elegant color palettes
Elegant color palettes Bad Practice
Elegant color palettes Best Practice
With low-saturated greens in the spotlight, this almost monochromatic color palette ensures
a sense of serenity, elegance, and calmness. Plus, dark green is often linked to money and
luxury. A pinch of beige intensifies these feelings, evoking associations with expensive
pearls, ivory silk, cashmere sweaters, and marble sculptures. This color palette could be a
great fit for e-commerce websites selling high-end beauty or eco-friendly products, as well as
for meditation or yoga studios.
Passionate colors
Passionate colors Bad Practice
Passionate colors Best Practice
When you think of passion, affection, and romance, you're more likely to imagine a color
range of reds and pinks. As far as reddish shades can also provoke emotions of anger and
violence, you should be particularly careful selecting colors and adjusting their properties.
Less saturated pink brings softness and carefulness, while more deep pink signifies intense
emotions and passion.
This color palette could work for a dating app, advertisements for Valentine's Day, or any
feminine app or website.
Cheerful color palettes
Cheerful color palettes Bad Practice
Cheerful color palettes Best Practice
Fully-saturated, bright yellow, playful coral, sky blue, and grass green bring up nothing but
cheerful and energizing emotions. These colors make us think of summer, sunshine, waters,
colorful beach umbrellas, and cocktails.
This color palette represents a surprisingly harmonious combination of complementary pink
and green, yellow and blue. Use it for apps and websites related to travel, entertainment,
kids' products, or anything implying fun and joy.
Think of logos that represent Slack, Google, eBay — they all use similar color palettes to
underline fun, friendliness, diversity, and even nonconformity.[1]
Trustworthy color palettes
Trustworthy color palettes Bad Practice

Trustworthy color palettes Best Practice
While light blues and greens evoke calmness and peacefulness, deeper and darker shades
are associated with loyalty, trust, and honesty. That makes those colors popular for banking,
insurance, investing, and other serious financial institutions.
Neutrals — light grey and black — intensify the down-to-earth impression and add a touch of
elegance and sophistication.
Whimsical color palettes
Whimsical color palettes Bad Practice
Whimsical color palettes Best Practice
This low-saturated but colorful palette calls to mind the magical factory of Willy Wonka with
heaps of lollipops, gummy bears, jelly beans, bonbons, and sorbets. Fresh greens with
accents of coral and warm peach set a cheerful, even whimsical, mood and fall into line with
e-commerce websites for things like clothing for younger audiences, beauty products, or
cakes and candies.
Mysterious color palettes
Mysterious color palettes Bad Practice
Mysterious color palettes Best Practice
Take deep shades of green, spice things up with dark purple, and voilà — you've got a
palette oozing spirituality, tranquility, and mystery. The surprising blend of green that you can
often encounter in nature and purple, which, oppositely, is rarely seen in nature, creates an
intriguing, supernatural feeling.
Such a palette can serve for websites of exotic products or services, like life coaching or
astrological forecasts.
Tense color palettes
Tense color palettes Bad Practice
Tense color palettes Best Practice
Red and black is a grim cocktail of colors often associated with violence, danger, blood, and
primal fear. Dark purple, which also symbolizes mourning and death in some European
countries, intensifies those feelings. In turn, the lack of light colors amplifies associations
with horror scenes even more.
Remarkably, Netflix uses a similar color palette to build associations with the darkness of
cinema halls.

Hopeful color palettes
Hopeful color palettes Bad Practice
Hopeful color palettes Best Practice
Soft aquamarine and tender pink are reminiscent of peaceful beach sunrises that symbolize
new beginnings and high hopes for better days. You can find these colors in birth centers
and children's and maternity hospitals, where they bring up feelings of calmness, kindness,
and compassion.
Notably, a similar shade of pink is used for the ribbon loop as an international symbol of
breast cancer awareness.
Dreamy color palettes
Dreamy color palettes Bad Practice
Dreamy color palettes Best Practice
At first sight, this color palette calls to mind the dreamy atmosphere of movies directed by
Wes Anderson. Muted sweet and tender yellows, pinks, and oranges perfectly complement
the topic of childhood and the innocence of the first love in the heartwarming movie
Moonrise Kingdom (2012).
In contrast to bright orange, yellow, or pink, these less saturated variations of colors
generally make us feel warm and nostalgic. A streak of calming light blue adds a refreshing
vibe but also feels sweet and relaxing.
Oppositely, muted versions of moss green and brown create a down-to-earth, secure, but
somewhat dull atmosphere.
Youthful color palettes
Youthful color palettes Bad Practice
Youthful color palettes Best Practice
Bright colors generally give a more youthful impression than darker and more muted colors.
Energetic bursts of golden yellow, ultramarine blue, and watermelon pink create a cheerful
and enthusiastic feeling. These colors may seem flashy, pop-artish, and chaotic to older
generations, but younger audiences will love them.
If you decide to use this color palette for your website or app, make sure to select a primary
color and use the others as accents. That will help you avoid visual clutter.
Color Scheme Personalities

Color schemes or color harmonies are patterns for choosing harmonious color palettes.
Different types of harmonies can produce vastly different effects on viewers. All you need is
a color wheel and the knowledge of these established combinations. There are six color
harmonies commonly used in the design:
To create a successful color palette, you need to decide what message you want to
communicate. Once you know the purpose of your design, you'll understand what color
combination best suits your needs.
Monochromatic color schemes
Monochromatic color schemes
A monochromatic color scheme consists of different variations of a single hue. For example,
a yellow monochromatic palette can include pure, saturated yellow along with its tints,
shades, and tones.
Monochromatic combinations create a harmonious and visually appealing look. The hue
unifies the design, which works well if you want your brand to be identified with a particular
color. Monochromatic palettes are also the easiest to create.
The downside of monochromatic palettes is that they can end up being boring and lacking
visual interest. To avoid that, make sure there's enough contrast between light and dark
hues. Another strategy to liven up a monochromatic scheme is to add a solid neutral like
white or black.
Use monochromatic harmonies to:
When creating monochromatic, text-based designs, use dark shades for text and lighter
shades for background. Save the brightest variation for graphic accents.
Analogous color schemes
Analogous color schemes
Monochromatic harmonies
Complementary harmonies
Split complementary harmonies
Analogous harmonies
Triadic harmonies
Tetradic harmonies
Create calm and serene designs
Convey reliability
Create pages with a lot of text content

Analogous color schemes consist of colors that sit directly side by side on the color wheel.
Similar to monochromatic harmonies, analogous schemes evoke serenity and peace. Some
say this is because these combinations exist in nature — like the colors of a sunset. While
quite harmonious, analogous color palettes feel more dynamic than monochromatic ones.
The simplest way to create an analogous palette is to choose a primary color as a base,
then choose 2-3 neighboring hues as accent shades or tints. Make sure your base color
dominates, and the other two are used as highlights and don't compete for attention.
It's easier to balance analogous colors if you use only warm or only cool colors. Also, be
wary of choosing colors that are too closely related, as they may blend together and wash
out your design.
Use analogous harmonies to:
Complementary color schemes
Complementary color schemes
Complementary color schemes include colors that sit directly across from one another on the
color wheel. These colors have high contrast to each other, which makes such compositions
feel more dynamic. Such color schemes can make your design stand out.
Complementary color schemes are often found in nature as well, so using them gives a
vibrant yet natural feel to a design. Imagine an orange coral standing out in the ocean's blue
or lavender against the soft green of the foliage.
Complementary palettes are one of the most difficult to pull off successfully — especially for
new designers. When done wrong, they can feel overwhelming, especially if you're using
saturated colors; the right balance is key. If you find the contrast too strong, shade or tint
your colors to make them more muted and less aggressive.
Use complementary harmonies to:
Avoid using complementary colors right beside each other, especially for text-based
compositions. The effect can be hard on the eyes and render text illegible or difficult to read.
A way to balance the colors is to pick one hue as your primary color. Then use the
complementary color as a highlight and to make essential elements stand out.
Add visual interest to an otherwise monochrome color scheme
Create a calm and unified look that won’t distract users from your primary message
Create a connection with nature
Draw attention to your focal point
Express boldness and inspire action
Create youthful, lively designs

Split complementary color schemes
Split complementary color schemes
Split complementary color schemes are a variation of the complementary color scheme.
Instead of picking the complementary color of your target color, use the 2 colors that sit on
either side of it. For example, if you start with orange, don't take its complementary blue but
use cyan and indigo instead.
Split complementary color schemes add more variety than complementary color schemes as
they include three hues. This results in dynamic palettes but doesn't create tension because
of the analogous colors of the contrasting hue.
Using split complementary color schemes, you'll get both warm and cool hues. This will give
you more room to balance the colors than a high-contrast complementary scheme.
Use split complementary schemes to:
Triadic color schemes
Triadic color schemes
A triadic color scheme uses three colors that are evenly spaced around the color wheel. It's a
variation of the split complementary color scheme. To find triadic colors, take an equilateral
triangle and place it on the color wheel. The colors at each point will be a triadic combination.
Triadic schemes are very vibrant and have a lot of energy, especially compared to
monochromatic and analogous schemes. But because the colors are evenly spaced around
the color wheel, they also feel balanced. This is especially true when you let one color
dominate and use the others as accent colors — similar to a split complementary harmony.
Depending on the mood you're trying to achieve, it can be a good idea to use one bright or
dark color and a paler tint or tone of the other two colors.
Tints and shades can help create a sense of calm and tranquility, while full chroma hues are
ideal for more youthful concepts. Triadic harmonies look vibrant even when toned down,
tinted, or shaded.
Use triadic harmonies to:
Experiment with complementary harmonies — especially if you're a new designer
Make an impact without being too flashy
Create balanced drama and contrast
Create compositions that need more than two colors
Grab the viewer's eye without creating tension
Create bright designs that use full chroma colors

Rectangular tetradic color schemes
Rectangular tetradic color schemes
There are two types of tetradic harmonies: rectangular and square. These harmonies use
four colors arranged in two complementary pairs. They are also known as double-
complementary schemes. While the complementary scheme can grab users' attention, a
tetradic color palette has more visual interest, which is better for keeping that attention.
Rectangular tetradic color schemes use two pairs of analogous colors that sit opposite each
other on the color wheel (i.e., two sets of neighboring complementary colors). The analogous
colors can be directly next to each other or have a single hue in between them.
A rectangular color scheme is the richest of all available color schemes. This gives you the
most variety when working with color. These schemes work best when you choose one of
the four colors to be a dominant color and others as accent colors. Otherwise, your project
may appear too busy and unbalanced. This simply means avoiding using all four colors in
equal portions.[1]
Use rectangular color schemes to:
Square tetradic color schemes
Square tetradic color schemes
A square tetradic color scheme is a variation of a tetradic color scheme. It uses two pairs of
complementary colors spaced evenly around the color wheel (with two colors in between
each one). You can find a tetradic combination by placing a square on the color wheel and
choosing the colors at each corner.
These color combinations are always loud and fun, and the vibrancy makes designs stand
out. However, be cautious while finding a balance because these combinations can easily be
overwhelming. For the best results, choose one dominant color and use others as accent
colors. This way, colors won't compete for attention or overwhelm users.
Use square color schemes to:
These harmonies naturally balance cool and warm colors, which helps to avoid
overwhelming users.
Draw attention to a photo, room, or advertising piece
To create a typography hierarchy. Use the darkest color for body text and the three
remaining colors for headings and subheadings
Designs with color-coded elements, such as signage or transit maps
Create a type hierarchy with a different color for each level of heading.

Adding neutrals to traditional color schemes
Adding neutrals to traditional color schemes
An easy way to harmonize your color palette is to add neutral colors to the scheme. Neutral
colors are black, gray, white, brown, and beige (even though the latter 2 aren't pure neutrals,
but variations of orange).
Each neutral color produces a different effect on the overall palette. For example, adding
white to a monochrome palette can make it look softer and friendlier. At the same time,
adding black can make it look sophisticated.[1] Experiment with different neutral colors to see
what best achieves the desired effect.
Add neutral colors to your color scheme to:
Take the lesson quiz and assess your knowledge
Completing the interactive quiz is proven to help you learn faster and remember the
information for longer.
Key skills
Share lesson
References
Color Combination Preconceptions
According to the ecological valence theory, our color preferences don't emerge out of thin air.
[1] Our likes and dislikes of colors are products of our past experience that, like a puzzle,
consist of various pieces.
Events in politics and culture, technological innovations, cinema, music, and fashion
influence our perception of reality. We watch movies, attend art exhibitions, buy new devices,
listen to music, go to restaurants, and celebrate holidays. On the go, we absorb everything
that happens around us to create our opinions. Positive events produce positive color
associations, while unpleasant events boost negative color impressions.
Understanding the mechanism of forming color preferences can help designers develop a
deeper knowledge of color psychology and grasp the nature of color trends.
Industry-standard color palettes
Industry-standard color palettes
Create options for increasing contrast
Harmonize colors that are competing for attention
Serve as a background for the rest of the colors

Let's play a small game. We tell you a chain of words, and you think of colors associated
with these concepts. Ready? Let's go!
For the first set of words, you're likely to imagine the color blue or red; for the second — red,
orange, or green; for the third — gray, blue, or black.
According to a study conducted by a UK insurance intermediary, many industries are prone
to using particular colors in their branding. They select colors that have the intended
psychological influence on consumers and also create the right image of the industry. In turn,
people start subconsciously associating those colors with particular industry sectors.[2]
For example, many airline companies pick blue to represent trust and security (e.g., United
Airlines or All Nippon Airways) and red to ensure a caring attitude (e.g., American Airlines,
British Airways, or Austrian Airlines).
Black represents strength and security, so you can see it in the logos of Queclink and Laird
PLC.
Red, yellow, and green are the most common colors for restaurants and food companies
(KFC, Subway, or Starbucks) as they're usually associated with appetite, energy, and health.
Color palettes of famous brands
Color palettes of famous brands
Reds and yellows are astonishingly stimulating, active, and outspoken colors. It's a pretty
well-known fact that you shouldn't eat from red, yellow, or orange plates if you want to lose
weight. These colors increase your metabolism and appetite — that's why they are the most
popular colors in fast-food chains, like McDonald's, KFC, Wendy's, and Pizza Hut.
Although those colors can make your customers feel hungry and crave your food, it's a
challenge for your brand to stand out. What you can do is incorporate other accent colors
(look at the Burger King logo that where even unappetizing blue looks on-point) and put a lot
of thought into the brand name and logomark.
Color palettes associated with holidays
Color palettes associated with holidays
Although there are cultural differences in holiday associations, certain color combinations
may evoke particular memories or feelings among many users.
Specific shades of red and green may be associated with Christmas time and its attributes
like magnificent Christmas trees, red stockings hanging over the fireplace, beautiful
Airplanes, flights, and airports
Tasty food, hunger, calories
Communications, technology, mobile devices

evergreen wreaths, candy canes, and mistletoe. In turn, a blend of orange and black
immediately brings to mind Halloween, carved pumpkins, candles, black cats, candy corn,
and vampires.
When selecting a color palette, keep these associations in mind and make sure to pick hues
that promote the feelings you would like users to have when they see your product.
Color palettes in film & TV
Color palettes in film & TV
In filmmaking, color is one of the most powerful tools used to express mood, evoke certain
emotions, or convey a spirit of specific eras. Moreover, the best film directors have a
recognizable style and color palettes that people associate with their movies.
Wes Anderson's pastel color palettes used in his works always feel dream-like and a bit
nostalgic. The muted pink in The Grand Budapest Hotel or hazy oranges and greens in
Moonrise Kingdom help the cinematographer create a unique atmosphere for his characters
to live in and creates a particular mood for viewers.[3]
People tend to associate romantic movies with consistently bright and more saturated colors.
They feel more relaxed, safe, and eager to laugh seeing characters highlighted with cheerful
light. Conversely, dramatic scenes are linked to melancholic dark or muted blue, green,
black, or gray. Not to mention that heroes and villains can also be easily revealed by color.[4]
Color palettes in nature
Color palettes in nature
Nature is probably the most talented artist in the world and uses a variety of colors to paint
every blade of grass and every bird's feather.
Just the thought of natural landscapes like seashores, mountains, meadows, or forests calls
to mind images of crystal blues and lush greens. Yellow, brown, and red hues can also be
found in nature, but they're rarer and don't evoke such strong feelings of tranquillity and
refreshment.
Scientists suggest that our positive associations with green and blue have been rooted in our
brains through evolution.[5]
Color palettes in pop culture
Color palettes in pop culture
Remember Apple's early iPod commercials, with dark silhouettes dancing to a tune against
colorful backgrounds? Well, that's an excellent example of how a company sold more than
just a product, but a feeling or lifestyle.

People got attached to the iPod on an emotional level, and colors from these commercials
became a trend. Lime green, Barbie doll pink, cyan blue, and bright yellow crawled into
many iconic movies and TV shows, like Mean Girls, Skins, or Family Guy. Not to mention the
rise in popularity of colored skinny jeans and Crocs observed at that time. Nowadays, flashy
colors of the early 2000s look outdated and create a somewhat retro feeling instead of being
trendy and refreshing.[6]
While selecting the color palette for your website or app, don't focus on trendy colors only.
What may seem absolutely up-to-date today will feel like a passing fad in a few years.
Color palettes for specific eras
Color palettes for specific eras
If you enjoy watching movies from different decades, you're likely to notice that some colors
dominate particular eras, creating specific moods and feelings. The popularity of different
colors across the decades isn't accidental. Events in society, fashion, music, and art shaped
the role of color.
For example, in the 1950s, America was swept by consumerism, glamor, and prosperity.
Delicate and powdery pastels, such as pinks, blues, and greens, conveyed feelings of youth,
warmth, and joy. Nowadays, these colors are used to create a vintage atmosphere
associated with this era.
The 1970s were signified by a tremendous revolution in television when most stations
worldwide upgraded from black-and-white to color transmission.[7] Furthermore, on the 22nd
of April in 1970, Earth Day was celebrated for the first time in the US and aimed at
increasing public awareness of the world's environmental problems. Earth tones took the
scene in this era, and the palette became decidedly more nature-inspired in general: harvest
gold, rusty oranges, chocolate browns, overripe avocado green, etc.[8]
Testing Color Combinations
Visual design, content, and interaction design are all part of the holistic user experience.
Testing colors within the visual design allows you to determine:
Different types of testing are suitable for each goal, but the most common methods are
testing color perceptions, ensuring sufficient contrast, optimizing conversions, and more
general usability testing.
If your users respond positively to the palette
If your brand colors convey your brand values
If the color choices help users achieve their takes
If the design results in conversions

Even if you don't have the time or resources to conduct independent color testing, you can
implement it within usability testing. When you do have the resources to test color
independently, there are a variety of models you can implement, from user interviews to A/B
tests.
Why it's important to test color
Why it's important to test color
Suppose you chose a beautiful color palette for your design and already got started on the
mockup. You've discussed it with your team, and everyone agrees that the design looks
fantastic. Should you still test your color palette and designs for color perception?
The answer is yes, you should. "You are not the user" has become one of the mantras of
user experience, and it's especially true when it comes to color perception. There's an
individual component to the way we perceive colors — what looks nice to you might be
unappealing to your target audience.[1]
Another point for testing is that it's the only way to determine if your color palette conveys
your brand's values. So even if you followed color psychology and picked the colors that
should communicate the intended message, there's no guarantee that users will recognize it.
Last but not least, small changes to color palettes can have dramatic effects. For example,
changing the shade of the CTA button can majorly impact conversions. You don't want to
leave this to chance if you can gather actual data and see what performs better.
Choosing palettes to test
Choosing palettes to test
To start testing color palettes, you must first create them. How do you know if your palette is
ready for testing?
If these 4 conditions are satisfied, you're ready to move to the testing stage.
Color testing methods
Color testing methods
It's based on color theory. You followed color theory to create a harmonious color
combination.
It fits your brand. The color palette represents your brand values according to color
psychology.
It's accessible. The palette includes colors with a range of contrast sufficient to comply
with the Web Content Accessibility Guidelines.
It doesn't have any controversial connotations. You took into consideration local color
meanings if your product targets a specific country or region.

There are several ways of testing color palettes. The most common ones are testing color
perceptions before finalizing the color choice, usability testing of the final design, and A/B
testing after the launch.
Testing color helps answer the following questions:
As color perception is highly individual, all color testing should involve real users — your
product's target audience. This means that methods that use personas instead — for
example, cognitive walkthroughs — aren't very useful.
Testing for color perception
Testing for color perception
Testing color perception consists of showing users the design and assessing their reactions.
How you do it depends on the purpose of your testing.
If you're interested in first impressions, it's better to show the colors for only a short amount
of time. The 5-second test and the First-click test are good instruments to test the first
impression of the design. To understand what users like about a particular design, offer them
several color combinations or designs to compare.
Testing color combinations in isolation will help you choose the right colors. However, users
can have other impressions when seeing these colors in the design, so it's crucial to test the
colors in UI. Elements that color choice affects the most are CTAs, text, and background. For
remote assessments, you can use any survey tool — like Typeform — that can display
images.
When testing elements in UI, do it one element at a time. Otherwise, it's hard to determine
what affects users' perceptions. Make sure the difference is noticeable enough for a non-
designer to see.
To conduct an in-person evaluation, you can use a static image on paper or a screen.
Testing for sufficient contrast
Testing for sufficient contrast Bad Practice
Testing for sufficient contrast Best Practice
Color vision deficiency affects approximately 1 in 12 men (8%) and 1 in 200 women globally.
[2] If they struggle to see the content, people likely won't use your product. Also, accessible
Which color palette do users like more?
Which color palette represents brand values for the target audience?
Do the colors in the interface help users to complete their tasks?
Which color combinations result in better conversions?

color contrast makes your design more legible to everyone, so all users benefit. Before
starting UI testing, make sure that your colors comply with web accessibility guidelines.
WCAG 2.0 level AA requires a contrast ratio of at least 4.5:1 for normal-sized text, and there
are similar requirements for large text, icons, input borders, and other elements. Check out
the Accessible Colors lesson from our Accessibility course for more information.
There are many tools to help you check color contrast. For example:
Testing for usability
Testing for usability
Visual elements like colors are part of a holistic experience, which also includes content and
interaction.[3] Although first impressions are important, they don't tell the whole story. That's
why it's vital to assess how colors affect users' behavior and task success when they interact
with the product.
Colors can change the usability of buttons, links, or any other type of component. For
example, gray buttons can sometimes appear disabled even if they are not intended to be.
If usability testing suggests that some of your colors don't work, go back and iterate on your
palette again. Then keep testing until you (and your users) are satisfied with the results.
If you only have the time and resources to do one test before launching the product, make it
a usability test with added techniques to assess visual design effects.
A/B testing for conversions
Once you've created your product based on user behavior and feedback, you can run A/ B
tests to keep improving conversions further. The purpose of A/B testing is to compare two
designs to find out which one performs better. This is better done at the stage when your
website already generates traffic. Otherwise, the testing will take too long.
When it comes to testing color, it's important to test only one element at a time. The color of
a button can dramatically change the effectiveness of a CTA, making it one of the crucial
elements to test for conversions.
In 2011, the marketing automation platform Performable ran a test on their "Get Started
Now!" button. They tested the red color against their usual green button and found out that
the red button gave a 21% increase in conversions.[4]
Measure accessibility color contrast. Stark plugin has a free version and works in
Figma, Sketch, Adobe XD, and Google Chrome.
Choose a suitable text/background contrast. Tools like Colorable can help you here.
Measure the contrast between elements on a web page. Google Lighthouse in
Chrome tools implements such measurements.

Does that mean that red is the best CTA color? Well, it was for their website, but it doesn't
necessarily mean that it will be for yours. A/B testing for conversions can determine what
color your audience responds to best.
Testing frequency
Testing frequency Bad Practice
Testing frequency Best Practice
How frequently should you test colors? Color psychology is complex and can be dependent
on a number of factors. This means that it's vital to test whenever there's been a significant
change.
Before adding a new design or changing the colors of an existing one, test color perception
or run a usability test with an extra color assessment. After launching the product and getting
enough traffic, use A/B tests to test for conversion.
Significant changes include cases when your competition makes a big change. For example,
if your competitor switched from light to dark mode, it makes sense to test how your
audience would react to similar changes. The design industry is constantly evolving, and
testing when the industry changes allows you to keep your hand on the pulse.
Creating a Color Palette
Creating a color palette that serves a product's needs can be challenging and carries a lot of
responsibility. Colors help make the right impression of your brand identity and evoke certain
emotions about the product. Failing this task risks losing your target audience.
Unfortunately, having a basic understanding of color theory isn't enough. Finding the right
combination also requires practice and a sense of aesthetics and harmony. You can start
with the simplest monochromatic or analogous scheme and enhance it by switching different
colors and observing how they work together until you find a winning combination.
If you feel stuck or have zero experience, find inspiration on Coolors or similar websites
selecting from existing palettes. Explore colors and their parameters — like saturation and
value — to understand what makes them work together and use this knowledge when
crafting your own color palette.
Step 1: Pick a base color
Step 1: Pick a base color Bad Practice
Step 1: Pick a base color Best Practice
Let's assume you've received a task from a client to create an exquisite color palette for a
fun, colorful, high-end fashion brand.

To start, you should pick a base color. If the client didn't provide any color preferences or the
brand's color guidelines, you have a couple of options:
We've picked a bright purple as a base color for our palette, which stands for creativity,
luxury, individualism, and mystery. The color may appear a little spiritual, but it also carries
positive and vibrant emotions.[1] Make sure the base color is not too saturated or dark so it
doesn't evoke the wrong associations or repulse users.
Step 2: Test colors to pair
Step 2: Test colors to pair Bad Practice
Step 2: Test colors to pair Best Practice
A complementary color scheme is usually the first thing to try when working on your personal
color palette. It consists of colors from opposite sides of the color wheel and can be
expanded using tones, tints, and shades. In our case, the opposite color is grass green. As
you might notice, opposites of the same chroma or value can feel too dramatic and intense.
Instead, you can experiment by adding transitional colors (pale purple or tender green) or try
more complex color schemes.
The split-complementary color scheme doesn't take the opposite hue, but rather colors on
either side of it. Triadic and tetradic schemes are harder to balance, but the result is more
exciting. Triadic harmonies contain colors equally spaced around the color wheel, e.g., blue,
yellow, and red. Tetradic schemes are also known as double complementary and take two
pairs of complementary colors.
Step 3: Choose a base color scheme
Step 3: Choose a base color scheme Bad Practice
Step 3: Choose a base color scheme Best Practice
Analogous and monochromatic schemes are the simplest and safest solutions to create.
They have less contrast than complementary color harmonies and fit better in the high-end
fashion industry. While monochromatic schemes use different tones, shades, and tints within
the same hue, an analogous scheme takes a slightly different approach. It takes 3 colors of
usually the same chroma level that are placed next to each other on the 12-spoke color
wheel. To add more visual interest, you can also use various shades, tints, and tones.
Evaluate competitors. Take a look at the color palettes of existing brands and
companies.
Find inspiration. Explore ideas on Dribbble or Behance.
Compile your ideas. Create a mood board, picking up images and illustrations you
associate with the fashion brand.
Dive into color psychology. Consider the emotions and associations you want users to
have with the product.

The analogous color scheme seems like a perfect base in our case. It's vibrant, bright,
catchy, and with a couple of adjustments, will meet the needs of a high-end fashion brand's
color palette.
Step 4: Adjust the colors
Step 4: Adjust the colors Bad Practice
Step 4: Adjust the colors Best Practice
To spice things up, we need to adjust the current analogous color scheme. Changing the
saturation (how pale or pure the hue is) and brightness of colors, we replace a rather
aggressive maroon with more positive and beaming pink. Instead of dreamy purple, we pick
a darker shade to emphasize luxury and style. Now, the color palette has more variety and
provides more flexibility. 
Step 5: Add in neutrals
Step 5: Add in neutrals Bad Practice
Step 5: Add in neutrals Best Practice
Adding neutrals is the final touch of creating a custom color palette. Browns, tans, and off-
whites make color schemes feel warmer and cozier, but that's not what we need for a luxury
fashion brand. In turn, blacks, grays, and whites in the right surroundings can make the color
palette look more sophisticated, profound, and minimalistic.
In combination with purple and pink, black intensifies the fanciness and elegance of the
palette, while white feels more refreshing and sharp.
Step 6: Choose element colors
Step 6: Choose element colors Bad Practice
Step 6: Choose element colors Best Practice
Once your color palette is ready, it's time to apply it to your designs. To make it right and
create a balanced composition, many designers swear by the 60-30-10 rule. It means the
dominant color takes 60% of the design area, a secondary color is used for 30%, and 10% is
left for an accent color.
Accents are usually applied to elements you want to stand out, like the CTA button.
Dominant and secondary colors should be relatively neutral. This helps you enhance
readability and make the website accessible for all kinds of users.[2]
Following this 60-30-10 guideline helps you avoid visual clutter on a page and create
aesthetically pleasing designs.

Don't forget about consistency: if you use red as a warning color, don't use it for the CTA
button or somewhere else.
Step 7: Create a brand style guide
Step 7: Create a brand style guide
As a project expands, it gets harder to make sure colors are applied consistently throughout
the product. A brand style guide is your go-to solution that helps graphic designers,
marketers, web developers, and other team members stay on the same page and present a
consistent vision of the brand identity to the public.[3]
The essential elements of the brand style guide are logo, typography, imagery guidelines,
brand voice, and of course, color palette. Make sure to include CMYK, HEX, and RGB color
codes to ensure your colors are used consistently both in digital and printed brand materials.
Color & Branding
You only have one chance to make a first impression. One of the best ways to influence
users' initial impression of your product is through your color palette. In fact, depending on
the product, people make up to 90% of their snap decisions based on color alone.[1]
While designers can't always start from scratch on a brand's color palette (since there may
be existing brand colors), understanding how to use additional colors to influence user
perception is vital. With the right color palette, you can make a brand color that's a little
boring (or way too flashy for the brand's values) convey exactly the message you want to
express.
Consumer perception
Consumer perception
Color is one of the first things people notice about a design composition. It has a dramatic
impact on their perception of the design they're looking at.
Want to build trust and loyalty? Blue is the way to go. Want consumers to think of your
company as youthful and fun? Bright colors are your ticket. Want them to view your brand as
solid and trustworthy? Try a dark green, navy blue, or burgundy palette.
The psychological impact of color has been widely studied, giving designers insights into the
effects particular colors have depending on the situation. For example, if you want your
football team to win more often, red uniforms may give them an edge — likely due to
associations of red with aggression and passion.[2] But if you want students to perform better
on tests, avoid exposing them to red beforehand, as their test scores are more likely to drop.
The theory suggests that red can heighten anxiety, not to mention the association with red
marks on a test indicating incorrect answers.[3]

Brands and emotion
Brands and emotion
When choosing a color palette, brands should consider several factors. The emotional
association with particular colors should be first and foremost. For example, if you're trying to
create an association with tradition and formality, hot pink might not be the best color to base
your palette around. For most people, it sparks feelings of joy, enthusiasm, and playfulness. 
Remember that cultural association with particular colors can play an important role. For
example, white is associated with minimalism, purity, and peace in much of the West. But in
many Eastern countries, it's associated with death and mourning. Be sure to thoroughly
research the cultural associations with any colors you're considering and your target
audience. But beware; many references online discuss cultural meanings of various colors
that simply aren't correct. When in doubt, ask locals if the meanings are accurate or not.
Finally, brands want to create a memorable color palette. McDonald's red and gold palette is
memorable, and those colors immediately bring to mind the fast-food chain. But
memorability isn't the only reason those colors were chosen; red can stimulate hunger, while
yellow is associated with happiness. The memorability of a color palette is often based more
on the emotions that the palette evokes in consumers than the colors themselves.
Memorability
Memorability
Choosing a color palette is just the first step in using color to establish a brand. Even the
most strikingly original color palettes won't immediately have a brand association. That takes
careful planning, implementation, and time. But by consistently using a color palette, it
becomes part of a brand's identity.[4]
Use your chosen color palette throughout your brand and marketing materials. It should be
incorporated into your website designs, social media graphics, logo, business cards, ads,
and any other materials associated with your brand. Through consistent use and repetition,
consumers will come to recognize your color palette and the values and personality it
represents for your brand.
Color and brand personality
Color and brand personality Bad Practice
Color and brand personality Best Practice
While neutrals serve a purpose in a brand's color palette, sticking to an entirely neutral
palette is unlikely to leave a lasting impression on consumers. If you want to create a
memorable color palette, pick colors that stand out and are unique.

Combining different tones, tints, and shades of primary colors (reds and yellows in this case)
creates a memorable palette that customers are more likely to associate with a particular
brand. Save the neutrals for the background or to unify other colors within the palette.
Color and competition
Color and competition
When determining a brand's color palette, it's important to check out what the competition is
doing. Certain colors and palettes have become synonymous with particular industries such
as yellow and red for fast food. While that doesn't mean you have to stick to those colors in
your own branding, it's a good idea to consider why those color palettes are so common.
You may decide that you want the brand you're designing for to stand out from its
competitors. In that case, choosing an entirely unique color palette could be the way to go.
But in some industries — banking and finance, for example — standing out as different and
unique isn't always a smart decision. Using similar colors to the competition shows that your
brand shares similar values and adheres to industry standards.
Authenticity
Authenticity Bad Practice
Authenticity Best Practice
Authenticity is one of those marketing buzzwords that can feel, well, inauthentic. But the
underlying principle is essential. The brand's color palette should feel in line with the type of
business or industry that the brand is in and meet that particular company's values.
If a consumer feels like the color palette is inappropriate for the type of business, it can
subconsciously deter them from doing business with that company. For example, a bank that
uses a bright blue and purple color palette (instead of more common industry colors like
navy blue, burgundy, or green) may have to fight an uphill battle to gain brand recognition
and build consumer trust.
Personality
Personality Bad Practice
Personality Best Practice
Every brand has a personality. When choosing colors for a brand, be sure to keep that
personality in mind. Otherwise, it creates subconscious conflict in the minds of consumers,
which can lead them to feel uneasy about the company as a whole.
For example, a brand with a fun, playful, and modern personality should stick to colors that
evoke the same associations. A playful company wouldn't use a palette that's dark and

traditional. Instead, they should choose bright, cheerful colors that reinforce their brand's
personality.
When testing a color palette with users, ask them to describe the palette with a few
adjectives to make sure it evokes the right associations for the brand.
Appeal to your audience
Appeal to your audience Bad Practice
Appeal to your audience Best Practice
Considering a brand's personality is vital to creating an effective color palette. But it's also
critical to acknowledge the personalities of the audience. What types of brands do they want
to associate themselves with?
For example, if the brand wants to target a youthful, trendsetting audience, its color palette
needs to evoke those feelings. If it doesn't, then the palette won't resonate emotionally with
its target audience.
Differentiate your brand
Differentiate your brand Bad Practice
Differentiate your brand Best Practice
Different industries have standard color palettes that a majority of companies use. For
example, a lot of social media sites (Facebook, LinkedIn, and Twitter included) use color
palettes that rely heavily on blue. If someone wanted to create a competitor to these sites
and use color to set themselves apart, then avoiding blue would be the first step.
That said, it's important to consider other factors when choosing a color palette, not just
picking a color because it's different. In this example, green feels fresh and inviting, while
dark gray gives the palette a grounded but modern appeal (especially when paired with
white). Such a palette would stand out among the competition while also working with the
brand's values.
Color & Behavior
There's so much power behind something as common as color. We wake up and feel more
energized when golden sunlight streams in through our windows; we decide to have
breakfast and feel healthier selecting a gluten-free muffin from a brown paper bag with a
green leaf on it from a nearby bakery; we pick a blue t-shirt when we want to feel calmer or a
red jacket when we want to look more confident.
Marketers have understood how colors could influence people's choices for some time.
Colors can stimulate people to make a purchase, make them feel anxious or relaxed, boost
their performance, create hope, or, oppositely, repulse. For example, according to multiple

studies, sedative pills of blue, green, or purple are more effective, while antidepressants tend
to work better when the pills are warm colors.[1] Another study shows that students who were
exposed to the color red before taking an exam showed 20% worse results than those
presented with green and black.[2]
The impact of color is undeniable, but the subject still needs additional research, and
designers should consider other personal, cultural, and situational aspects when selecting
colors.
Prompting action
Prompting action Bad Practice
Prompting action Best Practice
What is the primary marketing goal of any product? That's right, keep your conversion rates
as high as possible. A Big Orange Button (BOB) is the right solution to catch users' eye and
encourage them to click. Don't take it literally, though — it doesn't necessarily have to be
orange. BOB is an acronym made up by conversion rate optimization platforms to
define an obviously clickable button color.[3]
Generally, warm colors (orange, red, yellow, pink, etc.) are associated with action, while cool
colors (blue, green, and purple) are more associated with passivity. According to A/B testing
conducted at HubSpot, a red CTA button outperformed a green button by 21%.[4] Although
red can signify warning and aggressiveness, it also feels more encouraging than green. In
part, this likely has to do with red prompting us to feel like taking action is urgent.
That said, don't go to extremes and blindly switch your green or blue CTA buttons to red and
orange. First off, consider the overall color palette and contrast between the CTA buttons
and surrounding content. Second, test your assumptions on your pages with your users.
Activating survival instincts
Activating survival instincts Bad Practice
Activating survival instincts Best Practice
Red is one of the most controversial colors. People associate red with the devil, blood,
aggressiveness, and violence, but it's also an ambassador for passion, love, and sex. It's a
remarkably vibrant and stimulating color that can be found in every human language, like
black and white.
Some theories suggest that people are hardwired to see red in order to survive. In fact,
human eyes possess significantly more cones that are receptive to red and yellow
wavelengths than those receptive to short, blue ones. This helped our ancestors to
distinguish a flash of red that could mean a warning of poisonous animals or plants. At the
same time, red meant ripe fruits — a sign of health and life.[5]

The use of red in design serves to warn or stop users from making irreversible changes. For
example, red often indicates an error state or destructive action, like account removal or data
loss.
At the same time, that survival instinct can prompt users to take action toward a positive
goal, as it makes the action feel more urgent.
Accompany red with some additional visual cues to make the warning stronger for all people,
including color-blinded individuals. 
Reassuring users
Reassuring users Bad Practice
Reassuring users Best Practice
Blues and greens are generally perceived as calming, relaxing, and soothing. Many studies
state that the natural environment — full of blue and green hues — promotes health,
reduces stress, fear, and anger, and positively affects cognitive recovery.[6]
In the early 1900s, a New York City psychiatric hospital even had different colored wards to
treat different kinds of patients. Blue and green rooms were designed for boisterous
individuals, while red rooms, oppositely, were used to increase mood and ward off sadness.
[7]
The right combination of soft blues and greens can be a perfect fit for meditation or yoga
apps. Also, those colors signify trust and security and can have a soothing effect on
customers of banks or insurance institutions.
Perception of time
Perception of time
Have you noticed how time flies and days pass when you're on vacation, lying on a beach,
swimming in a pool, and having the best time of your life? Oppositely, being in a tense
situation — taking an exam or having a hard conversation with your boss — makes the time
pass as slow as molasses. Surprisingly, colors also control our perception of time.
In 1975, professors K.W Jacobs and J.F. Suess conducted an experiment that involved 40
undergraduates (13 male, 27 female). Participants were shown colored slides (red, yellow, or
blue) on a screen with the help of a Kodak Carousel projector. The research showed that
participants experienced less anxiety after seeing blue than red or yellow.
Later on, in 2004, a group of scientists conducted another research where participants were
asked to evaluate the downloading speed of web pages after they saw red, yellow, or blue.
Notably, the downloading seemed to finish quicker and time passed faster for people
exposed to blue than for red and yellow-exposed participants. The reason for that was

participants exposed to blue felt more relaxed than those exposed to red or yellow who
demonstrated higher levels of anxiety.[8]
This information empowers designers to be aware of the effect of color on users' mindset
and productivity. Using too much red on an interface puts users under pressure and makes it
harder to complete time-limited tasks.
Color and the placebo effect
Color and the placebo effect Bad Practice
Color and the placebo effect Best Practice
The human mind is an astonishing mechanism that can make our body believe in anything.
We can get relaxed, calm down, grow tense, start healing, or even recover from illness in
response to our brain processes. This phenomenon is called the placebo effect.
The placebo effect isn't about positive thinking, though. People are usually not aware they
are treated with "sugar pills" that have no medical effect. In turn, patients think they receive
real treatment, and their minds trick them into thinking that the medicine works and has
therapeutic results.[9]
More than that, larger pills have a stronger placebo effect than smaller ones; injections work
better than pills, and two tablets produce greater reactions than one. Tablets or capsules of
warm, active colors (orange, red, or yellow) are believed to create a stimulating effect.
Oppositely, blue medicine oozes relaxation and tranquillity.[10]
Keep this in mind when selecting a color for your branding and marketing. Cool colors like
green, blue, or purple may not be strong enough to encourage your users to act (confirm an
order or make a purchase), while red or orange can impose too much pressure.
Creating hope
Creating hope Bad Practice
Creating hope Best Practice
Despite cultural differences and personal experience, people generally have similar positive
and negative associations with some colors.
Although yellow, green, and white have other associations, including negative ones, their
harmonious blending creates a sense of tenderness, quietness, and hope.
Yellow symbolizes the sun, warmth, energy, and joy
Green brings to mind thriving plants and nature, the spring season, and new beginnings
In most Western countries, white represents purity, enlightenment, and a fresh start

Maroon, black, and gray together bring intense feelings of anger, power, and passion. They
tend to make users feel anxious and uneasy rather than happy and hopeful.
Creating disgust
Creating disgust Bad Practice
Creating disgust Best Practice
In the biological world, decay and growth go side by side, and life is always accompanied by
death. The color green is usually associated with new beginnings, good luck, health, and
nature. However, various shades and tones of it may trigger disgusts and relate to vomit, rot,
decay, feces, and sickness.
Additionally, brown and black are often described as negative colors that bring to mind
darkness, dirt, mourning, and poverty.
In turn, soft, romantic, muted pink, peach, and rosy colors look appealing and make you
think of good, positive things.
Fear of missing out
Fear of missing out Bad Practice
Fear of missing out Best Practice
FOMO is an acronym that stands for the "fear of missing out." It was coined in 1996 by
marketing strategist Dr. Dan Herman. This phenomenon refers to social anxiety that others'
lives are much more interesting, exciting, and fulfilling than our own. It develops into a deep
sense of envy and makes people feel less confident in their skills and personal qualities.
More than that, Social media websites like Instagram, TikTok, Facebook, and Snapchat feed
on this feeling of regret that you might miss a great opportunity, information, event,
experience, or social interaction.
Using too much red and orange in advertising or marketing provokes a sense of anxiety,
stress, and mental exhaustion that intensify FOMO. While it might increase your conversion
rates and boost sales, use FOMO with caution to avoid triggering feelings of unhappiness
and even depression.[11]
