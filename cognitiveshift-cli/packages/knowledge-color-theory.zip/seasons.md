# Seasonal color analysis (corpus)

Reference used by the Color Matching app to map extracted tones -> a season.
This is the knowledge corpus, not code; the CV model feeds features, this maps them.

## The 4 seasons (12-subtype model simplified)
| Season | Undertone | Contrast | Palette feel |
|---|---|---|---|
| Spring | Warm | Medium-high | Bright, warm, clear |
| Summer | Cool | Low-medium | Soft, cool, muted |
| Autumn | Warm | Medium | Deep, warm, earthy |
| Winter | Cool | High | Bright, cool, saturated |

## Decision inputs (from skin-tone-cv features)
- Undertone: warm vs cool (skin + eye hue).
- Value: light vs deep (overall luminance).
- Chroma: muted vs bright (saturation tolerance).

## Output
Season label + a palette of N recommended hex swatches + 2-3 colors to avoid.
Outfit match (in-app) scores a garment's dominant hue against the palette.

> Sources / citations to add as the corpus grows. Keep entries small and mergeable.
