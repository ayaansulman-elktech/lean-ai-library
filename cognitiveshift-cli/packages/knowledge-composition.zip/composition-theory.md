# Design Composition

source: https://app.uxcel.com/courses/design-composition

Full text, verbatim, of `Design Composition.pdf` (242 pages) — a UI/UX design-composition reference covering composition types, elements and their properties, contrast, similarity, repetition, rhythm, balance, hierarchy, grids, gestalt, and focal points, applied to interface design. Extraction artifacts (footnote anchor links, page breaks, hyphenation at line wraps) have been cleaned; wording is unchanged.

---

Design Composition
#UI  #UX  #Design
⚛️ Importante Notes
Composition:
Composition is an artistic way of combining elements to tell a story. It applies to
any artistic medium that arranges conscious thought, including music, writing,
architecture, fine art, and design.
The purpose of composition in web design is to influence the user journey.
Type of Composition:
Formal composition
Formal composition is the most important type of 2D composition and
possibly the most difficult to really excel at. It starts with basic geometric
shapes — squares, circles, triangles, etc.
3D composition
Visual composition
One way of approaching a composition is to build it around a prominent visual
element. They draw the eye to a specific focal point within the composition.
Unlike formal compositions that can easily be broken down into their basic
elements, visual compositions should appear whole and indivisible.
2D composition
Two-dimensional compositions lay on a single plane — they have a length and
width but no depth. They’re viewed from a single angle and don’t require side
views. For example, a blueprint of a house would be a 2D composition
Narrative composition
Narrative composition tells a story. Like a
novel, it has a setting, characters, and a plot that unfolds as users decipher it.
3D scene composition
3D scenes are some of the most complex forms of design composition. They
combine multiple 3D objects within a 3D scene.
Many great compositions in design, photography, and fine art display a strong
sense and understanding of formal composition.

⚛️--> Analyse compositions of great artists.
How to compose:
1. Pick a format
2. Use a grid
3. Group elements
4. Define the interaction between elements
Establish a solid hierarchy and a grid before you start worrying about
aesthetics.
Design Format Properties
⚠️: By balancing elements on both sides of the vertical axis, a stable
composition is created.
Dynamic format: This is done by placing elements in such a way that forces users’
eyes to move.
Active zones
Placing elements according to the rule of thirds tells your users where to look first.
Place things like header text, hero images, or CTA buttons in the active zones.
Less important elements, like menus or secondary links, can be placed in
passive zones where they don't stand out to users as much but are still readily
available.
Passive zones
The rule of thirds determines where the focal points of your composition should
be. Elements that fall outside of those areas receive less attention.
Design Elements
Designers combine basic building blocks — elements — to create their products.
The most basic of these elements are dots, lines, and planes, all of which can be
affected by the volume property. When working with these, artists and designers
can create images, icons, textures, patterns, diagrams, animations, and
typographic systems, among others.
💡: Lines can add a sophisticated look to minimalist design projects.
💡: 3D backgrounds can even add a futuristic vibe to your designs.
💡: Volume assists with visual hierarchy in your designs. It can also help users
determine which elements are interactive.

A well-executed 3D design can be used for attracting user attention.
All UI components consist of simple geometric planes and lines. The
arrangement of these planes determines how users interact with them.
about dots:
Dot elements are an excellent way to attract attention without attracting too much
attention. Showing a green dot to indicate that a user is online is immediately
noticeable and recognizable without cluttering up your interface. Dots used in
radio buttons help us immediately identify which control is selected.
Design Element Properties
⚠️: Many UI elements use particular shapes that users are used to and recognize
at a glance.
About shapes: geometric, organic, and abstract.
scale: By playing with scale, we can create dominance, focal points, rhythm,
balance, and visual hierarchy.
shape: Users know that rectangles are for buttons, cards, images, or videos;
circles for avatars or badges; and arrows for navigation or a Play button. If you
want users to intuitively know how to use your interface, stick to common
shapes.
colors: Color not only makes elements more noticeable, but it also has the
power to evoke emotions. Use color to emphasize certain aspects of your
content but always keep accessibility in mind.
texture: When you want to give users a tactile impression, texture is the way
to go. They can also be used to set a certain mood, and are commonly used
on marketing websites and in illustrations. Background textures and patterns
also add visual interest to your designs that can set them apart from the
competition.
pattern: Texture and pattern can be used to set the mood of a design. For
example, using vivid colors with simple patterns creates a friendly and playful
mood.
about texture and pattern:
Both texture and pattern can be used to create designs that more closely
resemble the physical world. They can also be used to reinforce visual hierarchy,
create focal points, and entice users to interact with parts of your design.
about color: Color plays one of the most significant roles in graphic design. We
use colors to convey emotions, add variety, emphasize hierarchy, organize units,

and ultimately create a unique style
Color for composition:
Achromatic colors
Achromatic colors possess no dominant hue — they absorb or reflect all light
wavelengths equally. White, black, and all shades of gray are achromatic colors.
White reflects all light and absorbs none, while black is the opposite (gray reflects
all light wavelengths equally, to varying degrees). They lack hue and temperature
and have only one property — value, which is the relative lightness or darkness of
a color.
Contrast
Contrast is all about the juxtaposition of elements — small or large, bright or pale,
round or square, etc. Imagine a Great Dane sitting next to a Chihuahua — the
greater the difference, the more we take note. Contrast helps guide users through
their journey, aids in creating accessible designs, and wows us when applied to
marketing websites.
Context contrast: It’s important that the contrasting concepts reinforce and
enhance the message, though, rather than leaving users confused.
Position contrast: Aligning images and text to the bottom makes them look
heavier in contrast with a "feather-light" title. Position within a composition can
add (or subtract) visual weight to certain elements. Elements near the bottom of
the composition will naturally appear heavier than those near the top.
Size contrast: When combining shapes, each of a different size, we create size
contrast and emphasize that the larger one is more important. Different font
weights increase contrast, adding even more emphasis on a title.
visual weight contrast: Balancing complex elements with simple ones is an
excellent way to add visual weight contrast to a composition.
Shape contrast: Highlighting differences in shape can help us understand that
elements in a composition perform different functions. For example, a rectangle
button with sharp corners will immediately stand out among a sea of images with
rounded corners, signaling to users that it’s an interactive element.
Orientation contrast: Experiment with the orientation of elements to create more
dynamic compositions. An angled background shape, for example, creates a
sense of movement on the page compared with a shape that’s oriented on strict

vertical and horizontal axes. In turn, that makes your focal point image stand out
more.
Color contrast: Using high-contrast colors is a bold move not every designer can
pull off.
Quantity contrast: Experimenting with the number of elements on either side of a
vertical axis can create balanced asymmetry, add a dynamic feeling, and disperse
user attention.
Relationships
Subtlety with size: Subtle differences in the size of images on a page adds
emphasis to the larger image while also capturing users’ attention. It makes a
stronger visual impression than two equally-sized images while still allowing both
images to shine.
Subtlety with shape: it helps users recognize and distinguish between elements
to avoid confusion.
Subtlety with texture: Playing with textures can add subtle differences between
elements while also unifying them. A subtle texture effect on the sweater and skirt
tie the two characters in this example together, without being mirror images of
each other. At the same time, it balances out the composition.
Subtlety with color: While bright, contrasting colors have their time and place in
design, they can run the risk of making your composition resemble Willy Wonka’s
Chocolate Factory. An analogous color palette avoids that effect. Subtle
differences in tints and shades help create a minimalistic and appealing look that’s
easy to implement in many types of designs.
Subtlety is an excellent way to emphasize an element without overdoing it or
making it stand out too much. A small change — say, the background color for
a hover state on a product card — can set it apart in a powerful way without
being visually overwhelming.
Be careful with subtlety, though, as too little contrast can actually feel like a
mistake to users, and make a composition appear unbalanced when used
incorrectly.
⚠️: Similarity doesn’t necessarily mean that elements need to be identical. But
they should have enough in common to immediately be identified as related and in
a single group. Use shape, color, size, and
similar properties to unify similar elements.

Similarity with shape: Similar elements are immediately perceived as related by
users. Elements that share the same shape, color, size, or other properties are
viewed as a group. It’s one of the main reasons designers stick to one button
shape throughout a design or use all black and white images of the same size and
shape.
Similarity with size: Size is often used to emphasize an element and call attention
to it. Same-sized elements, on the other hand, usually look related and carry the
same level of importance.
Similarity with color: Color is a powerful tool for designers and can help unify
elements within a composition. Think of football players — they wear the same
colored jerseys to signify that they belong to the same team. Using the same
analogous color palette for elements — the CTA button, title, and hero image —
creates a cohesive vibe and makes the entire composition look complete.
Similarity: When your elements are of equal importance, similarity is your
friend.
Repetition
⚠️: Repetition is the best friend of consistency in design, making users feel
relaxed and comfortable.
Repetition in UI: Some interfaces just naturally lend themselves to repetition —
calculators, calendars, tables, and the like.
simple repetition in UI: Simple repetition focuses on equal relationships between
elements. Every element — for example, days in a calendar — has the same
shape, color, and carries the same visual weight.
Rhythm
The core difference between rhythm and repetition is that rhythm implies
movement, progress, and sometimes surprising variations. Waltz is all about
rhythm and includes a step, slide, and step in 3/4 time. On the contrary,
marching is a repetition of monotonous footsteps without any irregularities.
When designing, rhythm can help establish the mood and make a composition
more dynamic and exciting.
Internal rhythm in UI:
Internal rhythm is created within groups of elements. It’s the repetition of parts
and spacing between them within a component.

How do you set the internal rhythm designing something as necessary as a signup form? You add spaces between inputs, titles, and CTAs, making sure users can
quickly scan them without being distracted or confused.
External rhythm in UI:
External rhythm is the rhythm that exists between different groups of elements. In
design, the external rhythm — the repetition of content groups and the negative
space between them — creates the flow and leads users’ eyes throughout the
page. Rhythm, when done well, is also used to create harmony within the
composition.
When designing a pricing page, we may want to differentiate each plan with more
than just words and numbers! Instead of making the height the same, we can
increase it for each subsequent plan, creating a progressive rhythm
Principles of Composition
Design composition, in simple terms, refers to how elements are placed on a page.
Successful composition means arranging your design in a manner that not only
looks good but also serves its purpose. To achieve that, follow the principles of
design composition: harmony, visual hierarchy, balance, scale, repetition, contrast,
emphasis, and unity, among others.
Compositional center: The geometric center of your design will always be in
the same place. The compositional center, however, is located based on how
your design is organized.
Geometric center: like rectangles, ovals, and squares — it’s the point where
the axes of symmetry meet.
Visual center: In design, that means that if we place elements at the
geometric center, they can actually appear to be unbalanced and slightly too
low.
closed composition: A closed composition occurs when all elements work
together to create a frame.
Balancing elements around the visual, not geometric, center
draws more attention to your subject.

Balanced composition: Balanced composition occurs when all elements work
together — the design is both stable and aesthetically pleasing. While some
elements may be more prominent, no single one draws our attention away from
the composition as a whole. In turn, in an unbalanced composition, individual
elements dominate the whole, leading to tension and uneasiness.
Dynamic composition: Dynamic compositions feel energetic and exciting —
there’s an illusion of movement, activity, or even conflict. To achieve this effect,
use open composition, intersecting diagonals of various angles, vigorous
contrasts of color, and light and dark accents. Irregularities attract our attention
and invite us to examine the composition further.
💡: Irregularities attract our attention and invite us to examine the composition
further.
Geometric Perception
Active shapes: Active shapes are those that attract and keep our attention.
Shapes with rounded edges, such as circles or many organic and abstract shapes,
are perceived by users as more active. Those with straight lines and right angles,
such as squares and rectangles, are more passive.
Stable shapes:Stable shapes are those that we perceive as well-grounded and
difficult to topple.
Grouping:
Visual Perception
Design perception #Perception
Design perception is entirely visual. Our
perception of a design is influenced by things like color, shape, patterns,
typography, light, images, and organization of elements. Designers need to have a
Our brain has a perception threshold — it can’t simultaneously
perceive more than 7 elements at once. When there’s more, we
automatically try to organize and group elements similar in size,
shape, or color. If there are too many diverse elements, the
composition seems fragmented and incomplete. This is why it’s
important to consider how elements are grouped when creating a
composition.

solid understanding of visual perception since graphical user interfaces are
perceived entirely through a user’s vision.
Gestalt theory forms the basic study of perception in design, and was developed
in the 1920s. Our perception of designs is
heavily influenced by artistic tradition (which largely influences our perspective),
our writing systems (which determines where we start looking on a page), and
real-world experience (which influences things like our understanding of heavy
and light elements).
Active zones: The upper-left and center of a page usually get more attention than
other areas. The top part also gets more attention than the bottom, which is why
we perceive the optical center to be higher than the actual geometric
center. The lower-right part gets the least
attention, as it requires more conscious effort to concentrate on that area.
When designing a product, be sure to place the most important parts in these
active zones. Otherwise, they may be overlooked.
⚠️: Consider the importance of your elements when deciding where to position
them. If the text carries more meaning than the image, place it on the left to
instantly grab the eye and appear closer to users.
Working with Composition
Leading lines
Closed composition: Closed compositions arrange all elements within a (mostly
invisible) frame. They provide a sense of
completeness. When users look at a closed composition, their eyes focus on the
main elements and don’t wander. Such designs feel finished and stable.
4-Point composition : 4-point compositions generally create a frame on the page,
resulting in a closed composition. They allow users to concentrate on the
elements within the page without their attention wandering out of the frame. The
different focal points can compete for user attention, so use this type of
composition with care. They’re great for things like product listings or other pages
where content should all carry equal weight.
⚠️: Use open compositions for websites with long and text-heavy pages.
Positive & Negative Space

Positive space: If negative space is an empty area around UI elements, positive
space is the actual UI elements — the essence and the focus of the design. It can
take any shape or form, geometric or organic, solid or outlined. Just as there's no
light without darkness, there's no positive space without negative space — they're
codependent.
Positive space is good for focus.
Negative space: also known as white space, is an empty area around, between,
and inside the text, images, and graphic elements. It creates breathing room for all
objects on a page, makes the design more comfortable to scan, and adds
emphasis and clarity.
--> Negative space ensures legibility
--> Negative space can highlight elements
--> Negative space improves UX
--> Negative space around elements helps establish the order of importance
Adding negative space to a design doesn't just mean creating bigger gaps
between elements. When done right, negative space helps maintain visual
balance, adds to the feeling of spaciousness, and emphasizes the intended
message.
Use active negative space to bring a specific element into the spotlight and
encourage users to take action.
Applying active negative space to text: Increasing the space between paragraphs
or headlines is an example of applying active negative space to text. This helps us
separate different ideas and emphasize the headline's importance. Notice how
just a bit more space makes the headling stand out that much more from the body
text.
Active negative space on a web page aims to direct focus on a specific area.
Passive negative space is the space between elements — such as text and icons
— that helps arrange them in a balanced way. It doesn't act as an element of its
own, but rather keeps the composition from appearing too cluttered. Think of
passive negative space as oxygen — you don't notice it until there's too little of it.
--> Reducing passive negative space between a group of elements helps
emphasize their direct relationship.
Applying passive negative space to text:
The line spacing here represents passive negative space applied to
text. It can reduce eye strain and help users quickly scan the
composition to find what they need. The text feels airy, and the

--> Passive negative space improves legibility.
⚠️: Before adding active negative space to the design, make sure you apply
enough passive negative space.
⚠️: Passive negative space in web design doesn't emphasize elements. Its role is
to add distance between elements within the same logical group to prevent the
design from feeling cluttered and aid in things like readability.
Internal negative space: is all about the relationship between elements of one
group. Some examples include margin and line spacing.
External negative space: helps direct the flow of the page and establish
hierarchy.
Grid
Regardless of the variety of grid types, they all have a similar structure and
consist of columns and gutters. Columns are vertical sections of the grid, while
the spaces in between are gutters. Gutters ensure that elements and components
from different columns don't bump into one other.
Grids strive for consistency. In the responsive design era — phones, tablets,
laptops, and monitors — grids help create consistent designs that fit any
screen. Plus, users can always be sure they would find things where they
expect them to be.
Grids maintain hierarchy and arrange elements in the most logical and
intuitive way.
Grids keep things clear so that nothing distracts users from the content.
Integrated grid: an integrated grid is a combination of two grid types. For
example, one can exist for media content and another — for typography.
Modular grid: While the column grid breaks a page down into vertical sections,
the modular grid adds a horizontal subdivision. Intersecting columns, rows, and
alleys form a matrix of cells — or what designers refer to as modules. In general,
modular grids give more control over both alignment and composition.
Use a single module for one unit of content or combine several modules to create
content blocks.
space itself doesn't stand out. But when there's not enough passive
negative space, the composition feels cluttered and hard to
navigate.

Column grid: All columns and all gutters are of equal sizes, and as a result, such
grids allow creating well-balanced, harmonious compositions. The more columns
you add, the more flexible your grid becomes. But don't go overboard.
📏: Traditionally, if the gutter size is X, the margin size is 2X. Such measurements
help guide users' attention inward and make reading more comfortable.
Symmetrical grids: Symmetrical grids use an equal amount of same-sized
columns that mirror each other. They also have the same gutter width. In book
layouts, symmetrical grids use a one-column grid for one page, which is
duplicated on the opposite page. Simple symmetrical grid structures create a
classic and elegant solution. Pages with this type of grid can also appear boring
and lack movement.
Manuscript grid: Manuscript grids are structurally the simplest types of grids. It
usually serves for arranging text on a page and thus can be encountered in books,
research papers, essays, or manuscripts, as the name implies. Large margins
create asymmetry, which creates visual interest.
Hierarchical grid: From an outside perspective, hierarchical grids appear chaotic
and don't obey the rules of standard grids. However, those grids rely on
agreements inside a design team that dictate the alignment of various elements.
Asymmetrical grids: Asymmetrical grids feel more dynamic and modern. They use
differently sized columns that don't mirror each other.
Manuscript grid: Manuscript grids are classic grids for printing, especially for
continuous blocks of text, like in books, essays, or manuscripts. However, images
can also be used to add more visual interest, decrease cognitive load, and simplify
scanning.
⚠💡: To prevent a page from looking like a monotonous block of text,
designers should add enough white space to margins.
Hierarchical grids: Although hierarchical grids may look a bit chaotic, lack regular
structuring, and don't contain repeated intervals, the layout naturally relies on a
website's specific content.
Hierarchical grids place elements intuitively — the content itself defines the
logical alignment and overall composition. Designers can adjust grid rows,
columns, flow lines, margins, modules, etc., according to the need of the website's
content.
Design Workflow
Step 1: Research and ideate

The first stage of any product is communication. Initiate discussions with your
clients to ideate — to stimulate the brain thinking and define what product you're
going to implement. Take all information provided by stakeholders, including
marketing research and their business goals. If it's not enough or you have time
and resources, conduct your own user research. Data collected during user
interviews, surveys, competitive overview, etc., will help you gain insights and
organize the information into a diagram or map of a solution.
Step 2: Start sketching
All ideas start on paper — make sure to have a pen handy to visualize your ideas.
Don't think of color, typography, media, or features. Sketches shouldn't focus on
the details. Instead, they focus on the big picture — it's the skeleton of what's to
come. Don't get attached to your ideas on sketches. Instead, use them to ignite
discussions, communicate, and find the best solution.
Create quick and cheap sketches to get immediate feedback, test ideas,
discard them, and repeat.
Step 3: Digitize your sketches
Okay, now's the time to get your hands clean — let's put down the pen and pick
up a computer! This is the time to start putting together a digital visualization.
Without being distracted by fancy colors, neat typefaces, and actual content
move your sketches on a screen, focusing on the overall composition. You may
refer to your sketch but don't be afraid to adjust the composition if you see that
some elements look off on a screen. At this point, you'll want to focus on the user
journey and getting users from point A to point B.
We recommend creating a color palette of 6 grey tones to help speed up your
mockup workflow.
Step 4: Apply a grid
Now, with your barebone mockup in hand, you can define the grid. It's essential to
carefully consider your grid at this point, as it'll help speed up your workflow
further down the line. Depending on the content, you can settle with a more
traditional, proportional column grid or choose a modular grid for a content-heavy
website. You can also play around with asymmetry for more interesting,
unexpected layouts.
More columns mean more complexity. If you strive for simple solutions, stick to
simpler grids.

Step 5: Build your wireframes
A wireframe is a simplified version of your future product. Its level of detail and
interactivity is up to you, but remember that we create wireframes for testing
ideas and insights. You can use some basic drag&drop software for drawing the
layout — Balsamiq or even PowerPoint or Keynote can serve the purpose. Keep it
simple and informative, gradually replacing placeholders and dummy text with
actual or more or less realistic content. Draft, replace, and fix before you settle on
a final version.
Step 6: Add typography
Once you've done a couple of rounds of wireframe testing and receive some
valuable feedback, it's time to polish wireframes. At this stage, you can start
thinking of the aesthetics of a product. One of the components of visual design is
typography. We know how your head goes spinning when it comes to this subject
— there are so many choices! There are also plenty of aspects to consider. Start
selecting the legible typeface with the right mood and intent to fit your brand
identity and website topic. Stick to the typeface that works in multiple sizes and
contains font variations with bolds, italics, and small caps.
Step 7: Add visuals
Once the typography is good-to-go, it's time to fine-tune the visuals. As human
beings, we seek order and consistency. That's why your first step should be to
establish a well-structured style guide — a document containing all the branding
and visual style rules.
What does a style guide usually contain? Generally, it consists of branding
guidelines (logo usage, typography, color palette, brand principles) and a pattern
library that describes basic UI components, including colors, fonts, and page
layouts. This tool ensures design consistency and a smooth developer handoff.
Step 8: Add microinteractions
Successful usage of microinteractions not only enhances the user experience but
also helps users accomplish their goals.
Microinteractions let users know what is happening in the system and provide
feedback, often helping them prevent errors. Simply put, users should clearly see
what they can click, tap, or swipe and view the response on their actions.
Examples include pull-to-refresh animation or a validation message on wrong data
input.

With the help of tools like Invision, Figma, or Marvelapp, you can add simple
microinteractions to your designs and visualize how users will interact with your
product.
Use microinteractions to enhance the general user experience and brand
personality.
Step 9: Verify consistency
When the first page is done, it's time to reproduce your design language across all
other pages — consistently. The style guide is your single source of truth. On the
one hand, it makes the system more familiar and easy to learn for users. On the
other hand, it helps you and other designers stick to the right colors, fonts, sizes,
and other properties to maintain a consistent
look. After all, consistency is key, and it
ensures predictability and a cohesive user experience.
Step 10: Make it responsive
The days are long gone when users accessed your website from only one device
— that's all water under the bridge. Nowadays, users jump between multiple
devices to complete even one task. As designers — no wait, as product people —
we should take responsive design seriously. Initially, it takes a lot of time, but once
you've established the rules and breakpoints, the execution will be smooth as
butter.
When designing a website, aim for at least 3 types of screens: desktop, mobile,
and tablet. Always consider the product's content and the target audience's
device preferences.
Don't forget to adapt grids for mobile screens — they are limited in space and
require a different approach.
Component anatomy
Body
📏 16px is the minimum size you should use for body text, specifically for textheavy pages.
Icons
Keep icons simple and use familiar physical analogues to avoid confusion.

Dividers: A divider is a horizontal or vertical line that provides a visual
differentiator between sections of content. Dividers create a clear delineation
between groups of content and can provide structure to your layout.
Dividers should be used sparingly, though, as they can create a cluttered
interface. Consider using white space instead to differentiate between groups
of content.
Color placeholders more subtly so that users won't mistake them for data they've
entered themselves.
Overlays: sit above content and disable whatever is behind them while keeping
that content partially visible.
Articles
#Article
The most important compositional principles in graphic design:
https://yesimadesigner.com/composition-techniques/
The 8 Elements of Composition in Art: https://www.thoughtco.com/elementsof-composition-in-art-2577514
Golden ration and how to use it: https://www.invisionapp.com/insidedesign/golden-ratio-designers/
Sense of Beauty Partly Innate, Study Suggests:
https://www.livescience.com/7389-sense-beauty-partly-innate-studysuggests.html
Rule of third: https://www.interaction-design.org/literature/article/the-rule-ofthirds-know-your-layout-sweet-spots
Communication, Mood and Meaning: Lines in Web Design:
https://tympanus.net/codrops/2011/11/17/lines-in-web-design/
Points, Dots, And Lines: The Elements Of Design Part II:
https://vanseodesign.com/web-design/points-dots-lines/
How To Use Size, Scale, And Proportion In Web Design:
https://vanseodesign.com/web-design/size-scale-proportion/
The Meaning Of Shapes: Developing Visual Grammar:
http://vanseodesign.com/web-design/visual-grammar-shapes/
Bubble gum color history: https://www.thoughtco.com/the-invention-ofbubble-gum-1779256
Contrast in design: https://www.webdesignerdepot.com/2010/09/fullyunderstanding-contrast-in-design/

Key elements of visual design: https://www.interactiondesign.org/literature/article/the-building-blocks-of-visual-design
How repetition leads to rythm: https://creativemarket.com/blog/learn-webdesign-how-repetition-leads-to-rhythm
Repetition, Pattern, and Rhythm: https://www.interactiondesign.org/literature/article/repetition-pattern-and-rhythm
Developp rythm: https://tympanus.net/codrops/2011/08/19/developing-visualrhythm-in-web-design/
Composition Principle: https://www.invisionapp.com/defined/principles-ofdesign
Element of Design: http://www.makart.com/resources/artclass/elements.html
The Psychology of Lines and Shapes in Web Design:
https://prototype.net/blog/web-design-shapes
Visual Hierarchy - organizing content: https://www.interactiondesign.org/literature/article/visual-hierarchy-organizing-content-to-follownatural-eye-movement-patterns
Visual perception: https://www.interaction-design.org/literature/article/visualhierarchy-organizing-content-to-follow-natural-eye-movement-patterns
Leading lines: https://www.bbc.co.uk/bitesize/guides/z3pp3k7/revision/7
Negative space tips: https://blog.tubikstudio.com/negative-space-in-designtips-and-best-practices2/#:~:text=Basically%2C%20negative%20space%20%E2%80%93%20or%20w
hite,on%20the%20page%20or%20screen.
Maintain consistency: https://www.nngroup.com/articles/consistency-andstandards/
Intro to Composition
The arrangement of elements within a design has a profound impact on the way
users perceive and interact with it. That’s why composition is such an important
concept for designers to excel at.
Building a strong foundation for further explorations into design composition is
vital. Once you understand the basics, you can expand your expertise to become
a master of creating compositions that thrill users and keep them coming back for
more.
Design composition

Design composition is the way that text, images, and other UI elements are
arranged, aligned, and compiled on a page. When composition is done well,
designs are both aesthetically pleasing and highly effective. Designers also refer
to composition as layout, design, or artwork.
As designers, we master composition by applying the principles of design.
These include things like contrast, balance, white space, hierarchy, repetition, and
rhythm, among others.
Composition is an artistic way of combining elements to tell a story. It applies to
any artistic medium that arranges conscious thought, including music, writing,
architecture, fine art, and design.
2D composition
Two-dimensional compositions lay on a single plane — they have a length and
width but no depth. They’re viewed from a single angle and don’t require side
views. For example, a blueprint of a house would be a 2D composition. They’re
commonly seen in paintings, photography, 2D computer graphics, and crafts like
tapestries and stained glass windows.
3D composition

3D objects have, as the name implies, three dimensions: height, width, and depth.
They exist in a three-dimensional space, even when depicted on a twodimensional display. In product design, you’re most likely to see them in 3D
product views or in illustrative components.
3D scene composition

3D scenes are some of the most complex forms of design composition. They
combine multiple 3D objects within a 3D scene. Because of that, they present
additional challenges in regard to perspective and the relationship between
objects that aren’t present in a 2D scene.
Space is the key element in a 3D composition. When creating a 3D composition,
it’s important to consider how objects appear in that space from multiple angles,
as well as the positioning of the overall ensemble. Thankfully, we’re surrounded by
3D compositions in the real world, which we can use for inspiration.
Narrative composition
Narrative composition tells a story. Like a novel, it has a setting, characters, and
a plot that unfolds as users decipher it.
Every element in a narrative composition is intentional — nothing is random. Each
piece is there to add information to the plot and move it forward. It can even
include coded references, adding additional depth and interest for those viewing
it.
Rely on images, videos, and shapes to help move users through their journey.
Visual composition

One way of approaching a composition is to build it around a prominent visual
element. They draw the eye to a specific focal point within the composition. Unlike
formal compositions that can easily be broken down into their basic elements,
visual compositions should appear whole and indivisible.
Formal composition

Formal composition is the most important type of 2D composition and possibly
the most difficult to really excel at. It starts with basic geometric shapes —
squares, circles, triangles, etc. — arranged in a way that conveys a meaning or
message.
Many great compositions in design, photography, and fine art display a strong
sense and understanding of formal composition.
Web design composition
Good composition requires a solid foundation. It allows you to engage users, help
them find the information they need, and get your message across.
We’ve all come across websites that were poorly composed. Sites where we
couldn’t find the information we were looking for and couldn’t wait to leave. Solid
composition prevents your design from falling apart, creating a more pleasant
experience for users.
Composition should be easy to follow

Poorly designed websites appear cluttered, disorganized, confusing, or just not
user-friendly. Bad composition causes frustration for users and leaves them never
wanting to return to the site.
There's a simple guide for creating a good composition:
1. Pick a format
2. Use a grid
3. Group elements
4. Define the interaction between elements
Establish a solid hierarchy and a grid before you start worrying about aesthetics.
Composition should communicate a journey

The purpose of composition in web design is to influence the user journey. Think
about how users will interact with your design — which elements you want them
to notice instantly and which are less important. Scale and visual hierarchy are
your best friends for arranging elements to signal the focal point.
Position elements in ways to naturally lead users to the most important parts,
such as the CTA button in the example.

Design Formats
Portraits, landscapes, horizons — learn what defines a design format! Where is it
appropriate to use each type and what effect does it tend to achieve? Find out
with this lesson!
Format
The format of a design defines its overall composition — the spatial constraints
within which you’ll create your design.
Think of the format as an artist’s canvas. For UX designers, the format is usually
determined by the device you’re designing for — phone, tablet, desktop, TV, etc.
And when you rotate that device, it changes from portrait to landscape, and the
design constraints change accordingly. For graphic designers, formats can be of
any shape and depend on what you're designing for: packaging, ads, banners,
book illustration, etc.
Rectangular format
The rectangular format is also referred to the rectangular format as the "quadro"
—an Italian word meaning painting or picture.
This is the most popular format for designing mobile and web products. It's easy
to construct, frame, and display. Additionally, many human-made objects are
rectangular — TV's, phones, and computer screens. We have been designing on
rectangular formats for millennia, using paper, canvases, and even walls to
express ourselves.
Landscape format

When a rectangular format is wider than it is tall, we refer to it as landscape
format. This type of format is more natural for us since our eyes are aligned
horizontally and we live in a horizontal plane. We’ve also grown accustomed to it
because most pre-mobile device displays (TVs, computer monitors, movie
screens, etc.) were landscape-oriented.
With most designing digital products, especially those meant to be used on a
desktop or laptop, landscape format will be the default starting point. On products
meant for a mobile audience, landscape may take a backseat to portrait format
due to people’s reluctance to turn their phones.
Portrait format

When a rectangle’s height is larger than its width, you’re looking at a portrait
format. This format naturally encourages us to scan a composition from top to
bottom. It’s commonly seen in printed material — magazines, posters, flyers, etc.
— as well as on mobile devices.
People have a tendency to keep their phone in portrait orientation even when
viewing content that could better be viewed by turning their phone sideways
(such as widescreen video). That’s important to keep in mind when designing
for mobile devices.
Orientation affects how we perceive the subject. Use the portrait format to
emphasize vertical elements.
Square format
As you may imagine, the square format has the same height and width. The
square has 4 axes of symmetry — the vertical, the horizontal, and the two
diagonals. As a result, a user's gaze moves in a circle, not along the axes. The
central subject is surrounded by equal space from all sides. The square format is
great for balanced, symmetrical compositions.
Use the square format when you want to draw attention to the center
composition.
Round format

A circle is the universal symbol of completeness. As it has an infinite number of
symmetry axes, it creates a sense of harmony and balance. In turn, this circular
format separates and insulates a composition from its surroundings, placing it in
its very own world.
Oval format
Artists have favored the oval format when creating portraits for a very long time. It
makes sense because the format perfectly complements a human face or bust
outline. In turn, web designers often use this format in buttons or decorative
elements, leading the eye along an elliptical path throughout the composition.
Horizontal element
Considering landscape formats are most common on desktop displays, it’s no
surprise that horizontal elements dominate those UIs. Things like horizontal
images, many logos, and navigation bars tend to work better with a landscape
orientation. And some elements — like inputs or search bars — have to be
horizontal in order to work correctly.
Vertical element

Vertical elements are an excellent way to save space in your UI design. They’re
popular for mobile designs, partly for that reason and partly because mobile
devices are more likely to be used in portrait mode. Vertical elements are also
more scrollable than horizontal elements — it just feels more natural scrolling up
and down vs. left and right.
Horizontal layout

Desktop displays have taken advantage of horizontal layouts for decades. But as
smartphones have grown in size and functionality, horizontal layouts have become
more important for mobile devices.
While some users will keep their phones in portrait mode regardless of what
they’re doing on their phones, many others will rotate their phones for certain
tasks. Consider how creating a horizontal layout for mobile devices can benefit
your users.
Vertical layout
Vertical layouts are the default orientation for smartphones, and the way the vast
majority of people hold their phones. For that reason, a lot of apps stick to this
layout exclusively.
While vertical layouts limit the amount of horizontal space you can use, you’ve got
virtually limitless vertical depth to take advantage of. Just realize that not every
user will scroll endlessly.
Design Format Properties
The way a layout is composed affects how users perceive information. These
design format types and their properties can control where users’ eyes land and
make them focus on the most important parts of your design composition.

From the rule of thirds and the golden ratio to the difference between static and
dynamic compositions, learning these format properties will allow you to create
designs that have the impact you’re aiming for.
Active zones
Create a grid of 2 equally spaced vertical and 2 equally spaced horizontal lines —
dividing a rectangle into 9 equal parts — and you’ll have an example of the rule of
thirds. According to this rule, people tend to concentrate their attention along
these lines and particularly at their intersections — the active zones of a
composition.
Photographers are taught the rule of thirds early on in their studies, as it’s one of
the easiest ways to create a visually appealing, balanced composition. Designers
should pay careful attention to these intersections when placing important page
elements.
Not all intersections in the rule of thirds receive equal attention — it varies by
culture — but the top always gets more attention than the bottom.
Passive zones

The rule of thirds determines where the focal points of your composition should
be. Elements that fall outside of those areas receive less attention. These passive
zones are perfect for secondary elements that don’t require immediate attention
from users.
For example, you can place headers in the passive top zone. They’re easy to find
when users need them, but don’t distract from the rest of the page.
Dynamic format

Dynamic formats create the illusion of internal dynamics and movement, despite
being made up of static elements. This is done by placing elements in such a
way that forces users’ eyes to move. Placing elements at an angle, leaving
negative space before or after an element, and positioning on the page can all
give the impression of movement.
Static format

If you’re trying to create a calm and balanced composition, look to the static
format. It doesn’t force movement of users’ eyes, allowing more natural eye
tracking movement.
Static compositions use shapes that are balanced (often symmetrically) and don’t
give the impression of movement. Consider them more like a resting state
compared to the active state of a dynamic composition.
Format harmony

From Greek sculptors to the first typographers, humanity has always searched for
perfect proportions. Their search led them to what we now know as the Golden
Ratio (1:1.618), which is based on the Fibonacci sequence.
The Golden Ratio brings harmony and structure to your designs. It gives them a
certain sense of artistry. They’re also more appealing to the human eye — in fact,
we may be biologically hardwired to prefer structures that follow this rule.

Golden ratio
The Golden ratio, also known as the golden section, divine proportion, Fibonacci
spiral, or Phi (not to be mistaken for Pi), has been used in art and design since
ancient times. Many examples exist in nature — including hurricanes, sunflower
seed heads, certain seashells, and pinecones, among many other examples.
Using the golden ratio in your designs can pull users’ attention to the most
important elements, like a CTA button. It can also give your design a sense of
balance and harmony that’s immediately appealing to users.
In design, calculating the golden ratio for something like a rectangle is simple:
determine the length of the shorter side, then multiply by 1.618 to find the most
aesthetically pleasing length to use for the longer side.
Golden ratio grid

When setting up grid proportions, using the Golden Ratio will create a more
visually appealing grid than other methods. To make calculating that grid easier,
you can use Fibonacci numbers — a never-ending sequence where every
subsequent number is the sum of two previous ones (3, 5, 8, 13, 21, and so on).
According to this method, the most pleasing aspects are 3:5, 5:8, 8:13, etc.
Placing important design elements at points where the golden ratio grid intersects
can also have a profound impact on how much they stand out to users. This is the
perfect place to put important links or CTAs.
Active zones

Placing elements according to the rule of thirds tells your users where to look first.
Elements in active zones immediately draw our attention. Elements in passive
zones are only noticed after, making them feel less important.
Place things like header text, hero images, or CTA buttons in the active zones.
Less important elements, like menus or secondary links, can be placed in passive
zones where they don't stand out to users as much but are still readily available.

Passive zones
Elements that don’t need immediate attention — menus, secondary links, search
functions, etc. — should be placed in passive zones. Placing more important
elements there makes them less likely to be noticed — users would rather see
them aligned along a rule of thirds grid. Avoid passive zones for elements that

should immediately engage users and motivate them to take action, like the title,
hero image, or CTA button.
Dynamic format
Vertical layouts naturally lend themselves to movement and dynamic formats —
our eyes start at the top and work their way down the page. Placing elements in a

way that forces eye movement (such as vertical text in two columns) also adds to
the sense of movement.
Static format
For calm, relaxing interfaces, static formats are best. Horizontal layouts can more
naturally lend themselves to static formats, as they don’t force users’ eye

movement. By balancing elements on both sides of the vertical axis, a stable
composition is created.
Golden ratio
Applying the golden ratio to your layouts can result in an exquisite design. If you
draw an invisible spiral line from the bottom left corner through the entire example

interface, you’ll see the larger focus on the left part, narrowing down to the box on
the lower right. Subconsciously, naturally balanced designs like this are
immediately appealing to users.
Design Elements
All designs boil down to the most basic elements: planes, points, and lines.
Combining those design elements, and adding volume to them as needed, can
give you an infinite number of geometric and organic shapes to work with in your
designs.
Learning how to take advantage of these basic elements presents a wealth of
options for your designs. You can use them for everything from backgrounds to
interactive elements to placing emphasis on specific content.
What's an element?
Designers combine basic building blocks — elements — to create their products.
The most basic of these elements are dots, lines, and planes, all of which can be
affected by the volume property. When working with these, artists and designers
can create images, icons, textures, patterns, diagrams, animations, and
typographic systems, among others.
Points and dots

Points form the basis of every other design element. In math, a point is a set of
coordinates indicating a position. It has no height, width, or depth — it’s invisible.
In design, we use dots to indicate a point. These dots direct and focus attention
or create emphasis. We can combine dots to create interface elements (such as
kebab menus).
Technically speaking, all other elements are created by combining dots and
points. A line, for example, is simply a series of tightly overlapping dots
connecting two points.
Lines

A line is one of the most basic design elements — consisting of two connected
points (in geometry, this would be called a line segment, but in design, we just call
it a line). Lines can be used on their own or to form other shapes, such as a circle,
or combined together to form shapes like a square or triangle.
In design, lines are often used as dividers or to outline something like an image.
Lines don’t have to be straight; they can curve or wave. And in design, we
sometimes use dotted or dashed lines to create a less visually impactful divider.
Planes

In design, planes are flat enclosed areas created through lines, textures, and
colors. They can be made in any shape you choose.
Planes are excellent compositional tools for clustering elements into visual fields
or, on the contrary, separating unrelated information.
All UI components consist of simple geometric planes and lines. The arrangement
of these planes determines how users interact with them.
Volume of elements

Three-dimensional objects occupy space — they have volume. For rectangular
objects, volume is a product of their length, width, and height.
Adding a third dimension to your designs can create visual interest and make
elements stand out. You’ll need to have a good understanding of perspective to
create these objects (or rely on 3D compositing software), but they help achieve
amazing results.
A well-executed 3D design can be used for attracting user attention.
Dots in elements

Dots are one of the simplest design elements, and simplicity often creates better
products. That’s one reason the kebab menu (consisting of three vertically-aligned
dots) has endured across countless products. Companies like Google, Microsoft,
Atlassian, and many others use this icon often thanks to its simplicity.
Lines in elements

Linear elements consist of lines only with no internal fill. Examples include Like or
Comment icons on Instagram, the Bookmarks icon on many web browsers, and
any other icon that consists of only an outline. Linear elements can also be used
for things like borders around specific content.
Planes in Elements

Solid shapes — planes — can be faster to recognize than outlined ones, as they
appear more like physical objects. That said, you may want to use outlined versus
solid icons depending on the use case, such as an icon button’s default and hover
or active states.
Some icons like bookmarks usually change style depending on their status.

How to use volume
Volume assists with visual hierarchy in your designs. It can also help users
determine which elements are interactive. With buttons, it gives the impression of
something that can be pressed. Use shadows, angles, and highlights to give
volume to elements.

Dots in compositions
Dot elements are an excellent way to attract attention without attracting too much
attention. Showing a green dot to indicate that a user is online is immediately
noticeable and recognizable without cluttering up your interface. Dots used in
radio buttons help us immediately identify which control is selected.

Lines in compositions
Lines can be used for a variety of purposes in design. They can help us structure a
composition, direct attention, divide content blocks, and help frame various
pieces of information. Using lines to create shapes looks lighter than using solid
shapes. They can add a sophisticated look to minimalist design projects.

Planes in compositions
Combining various planes, each in different colors, shapes, and orientations, can
add a ton of visual interest to a simple design. Use planes to create images, to
differentiate between design components, or to draw users’ eyes to particular
parts of your interface.

How to use volume in compositions
Volume isn’t just for interactive elements. Adding a 3D background to your
designs can make for a whimsical experience for users. A sphere instead of a flat
circle, for example, is more eye-catching.

3D backgrounds can even add a futuristic vibe to your designs. Just be sure not
to go overboard, as 3D shapes can get overwhelming if used too much.
Design Element Properties
Elements are the basic building blocks of any digital product. The properties of
those elements — their shape, scale, color, pattern, texture, and orientation — are
some of the most important factors in the tone and mood your design creates.
Learning to apply those properties effectively starts to set your designs apart
from the crowd. Figuring out how to create particular moods or tones, how to use
properties to influence user behavior, and how to combine them to create visually
appealing designs is vital for any designer.
There are various properties we can apply to visual elements: shape, size, color,
texture, pattern, and orientation. These properties, used individually or together,
are used to create aesthetically pleasing designs. They can also influence users’
perceptions of the elements, guiding them toward taking certain actions.
Shape
There are three types of shapes: geometric, organic, and abstract. Think of
geometric shapes like those we studied in math class, such as squares and
circles. Whether simple or complex, these shapes create a feeling of order and
control.
As for organic shapes, we can draw them freehand — often, they are the shapes
found in nature, like leaves or clouds. Organic shapes produce a natural feel.

Abstract shapes are often pictorial representations of objects, such as traditional
"male" and "female" icons for restrooms. They're often used as icons in design.
Scale
If size is an absolute measurement, like 14px, scale is a comparison measurement,
i.e., how large one object is in comparison to another. By playing with scale, we
can create dominance, focal points, rhythm, balance, and visual hierarchy.
Color
Color plays one of the most significant roles in graphic design. We use colors to
convey emotions, add variety, emphasize hierarchy, organize units, and ultimately
create a unique style. Keep in mind that due to cultural differences and personal
associations, colors may elicit different reactions and emotions.
Texture and pattern
Textures are all about how surfaces feel to the touch. In design, we can simulate a
tactile feeling with visual patterns — the better the texture is, the easier it is to
imagine how it would feel.
Patterns are similar to texture, but give less of a tactile impression and rely more
on visual appeal. Think of wallpaper patterns or the pattern of a tiled floor.
Both texture and pattern can be used to create designs that more closely
resemble the physical world. They can also be used to reinforce visual hierarchy,
create focal points, and entice users to interact with parts of your design.
Applying shape

Many UI elements use particular shapes that users are used to and recognize at a
glance. For example, radio buttons are usually round while checkboxes are square.
Changing the shape of these elements can cause friction and confusion.
Applying scale

Scale helps establish dominance and create visual hierarchy. Make more
important elements larger than less important ones to catch users’ attention. For
example, in a slideshow, make sure the images are significantly larger than the
navigational controls to scroll through them.
Applying color

Color is a great way to draw attention to an element without changing the entire
design. For example, using accent color in pagination lets users know where they
are and improves their experience.
Make sure to use appropriate contrast so that the text is legible.
Applying texture and pattern

Texture and pattern can be used to set the mood of a design. For example, using
vivid colors with simple patterns creates a friendly and playful mood. Apart from
making your designs more tactile and visually appealing, applying texture and
pattern helps reinforce a product’s mood, tone, and voice.
Applying shape

Using recognizable shapes for various functions helps them stand out in your
design. Users know that rectangles are for buttons, cards, images, or videos;
circles for avatars or badges; and arrows for navigation or a Play button. If you
want users to intuitively know how to use your interface, stick to common shapes.
Applying scale

Larger elements grab users’ attention from the start. Use scale to emphasize the
most important elements of your design and create a focal point. Less important
elements should be smaller so they don’t compete with the main focus.
Applying color

Color not only makes elements more noticeable, but it also has the power to
evoke emotions. Use color to emphasize certain aspects of your content but
always keep accessibility in mind. Be careful, though, as using too many bright
colors can be distracting and overwhelming to some users.
Applying texture

When you want to give users a tactile impression, texture is the way to go. They
can also be used to set a certain mood, and are commonly used on marketing
websites and in illustrations.
An illustrated sweater with a texture applied, for example, gives a more realistic
impression than one with a flat color. Background textures and patterns also add
visual interest to your designs that can set them apart from the competition.

Color
Color is one of the most powerful tools that UX designers have at their disposal. It
can be used to draw attention to an element and emphasize its importance. But it
can also be used to strongly influence user emotions and behavior.
Keep in mind that colors may elicit different reactions and emotions based on
cultural differences and personal associations, but there are certain universal
meanings associated with various hues. Designers should learn the ins and outs of
associative composition in order to send users the right message and encourage
them to take the desired action.

Color fulfills several essential functions in design. For example, we use color to
communicate states, highlight crucial components, and alert users when
something goes wrong.
More importantly, though, color profoundly affects us on a psychological level — it
can set the mood, create an atmosphere, and evoke deep emotions.
Color composition

Color composition refers to utilizing colors in a way that produces a specific
impression. Color preferences are somewhat subjective — culture, prior
association, or even personal taste can influence our reaction to various colors.
While individual users may have a specific association with a particular color,
there are some fairly universal associations you should learn. By utilizing color in a

way that most people will perceive in a certain way, you can influence the
emotions and even behaviors of your users.
Chromatic colors
An object's color depends on its ability to filter out the light of a particular
wavelength. For example, a red apple's surface absorbs blue-green wavelengths

and reflects the red one.
Colors with a dominating wavelength or hue are called chromatic. They include
colors like red, orange, yellow, green, blue, indigo, and violet, as well as their
shades and tints. Black, white, and gray are not chromatic, as they include an
equal distribution of wavelengths.
Achromatic colors

Achromatic colors possess no dominant hue — they absorb or reflect all light
wavelengths equally. White, black, and all shades of gray are achromatic colors.
White reflects all light and absorbs none, while black is the opposite (gray reflects
all light wavelengths equally, to varying degrees). They lack hue and temperature
and have only one property — value, which is the relative lightness or darkness of
a color.
Monochromatic colors

If you start with a single base hue and extend it through its tints, shades, and
tones, you'll get a monochromatic color palette. To create a tint, you need to
lighten a color by mixing it with white. Creating shades is the opposite — mix a
color with black to obtain darker colors. To produce a tone, you mix the initial
color with gray.

Monochromatic compositions feel visually cohesive, easy on the eyes, and often
minimalist. Just be sure to add texture and experiment with tint, shade, and tone
variations to avoid monotony.
Neutral colors

Neutral colors include beige, brown, ivory, cream, and achromatic colors like
white, black, and gray. Beige and brown tones create a warm, welcoming
atmosphere. Ivory and cream are sophisticated, with some of the warmth of
brown mixed with the coolness of white — they can lend a sense of elegance and
calm. Off-white shades of ivory or gray can lighten the overall composition
without the stark contrast of white.
Calm colors

Blue has long been the most popular color in the world — as early as the 1940s it
was a clear winner as the most preferred hue. Blue is used widely in marketing,
partly for this reason and partly for the emotional impression it makes.
Blue has a strong association with being calm, orderly, secure, and reliable. It’s a
passive color, often associated with loyalty and humility.
Energetic colors

Orange is the mix of the two warm primary colors — yellow and red. It reminds us
of fire and sunlight. We associate it with energy, happiness, and vitality. Yellow
has similar connotations, bringing up images of bright morning sun shining over a
field of wheat. Both hues lend energy to your compositions, evoking feelings of
excitement.
Mysterious colors

Purple and violet refer to colors that fall between red and blue on the color wheel.
They’re relatively rare in nature, and before the invention of synthetic dyes, they
were costly to produce. That’s one reason they’re often associated with wealth,
royalty, intelligence, and achievement. They’re also associated with spirituality,
mystery, and the unconscious. Purple and violet can even evoke feelings of
individuality, creativity, and inventiveness.

Hot colors
Hot colors — red, orange, yellow, and their variations — are engaging, energetic,
and playful. Many cultures associate them with physical energy, health, vitality,
and fire. Colors that lean more toward red feel hotter than those that favor yellow.
Cool colors

Blue is the only primary color within the cool spectrum. It reminds us of cold
winter nights and forests covered with snow. Lighter tints of blue can give the
coldest impressions, as they’re heavily associated with ice.
In general, blue is reserved and loyal but also calming and relaxing. Other cold
colors include green and purple, secondary colors that mix blue with yellow or red,
respectively.

Light colors
Compositions using lighter colors like white, yellow, or soft tints of blue and green,
feel bright and airy, like a breezy room with lots of natural light. Lighter colors
have less visual weight, although there’s no scientific consensus about why. It

may be related to being used to darker colors closer to the ground, like the earth
under our feet, with lighter ones above, like the sky and clouds.
Heavy colors
Darker colors like black, blue, violet have more visual weight than their paler
counterparts. Red, though, is perceived to be the heaviest of all colors.

Keep in mind that we subconsciously expect to see heavier objects at the bottom
— otherwise, the composition looks top-heavy and makes us feel uncomfortable.
Vibrant colors
The color yellow is the brightest and most energizing of all warm colors, while red
is considered the most powerful. Vibrant combinations of yellow and red create an

impression of radiant energy like a halogen heater in winter. These colors can
easily overwhelm users, so keep that in mind when using them in your
compositions.
Sweet colors

When Walter Deimer invented the first bubble gum and made it pink (because it
was the only food coloring he had available), he had no idea how much impact it
would have on society’s perception of the color. We associate tones and shades
of red, pink, and purple with strawberry, blueberry, and raspberry sweets. Using
any combination of these colors in a composition will make it look delicious and
appealing.
Sour colors

Lemon and lime are some of the first foods that come to mind when we think of a
sour taste. Sour is an intense taste that is only evoked by a few foods. So like the
taste itself, sour color schemes utilizing greens and yellows also appear intense
and vibrant, often leave a lasting impression.
Contrast
Contrast is an essential ingredient in any design recipe. It spices up your design
“dish” and emphasizes elements, adding visual interest and vibrancy.
Learning the different types of contrast you can add to your compositions to
create specific effects is vital for designers. Combining different kinds of contrast
creates a complex composition that grabs user attention and keeps them coming
back for more.
Contrast is all about the juxtaposition of elements — small or large, bright or pale,
round or square, etc. Imagine a Great Dane sitting next to a Chihuahua — the
greater the difference, the more we take note. Contrast helps guide users through
their journey, aids in creating accessible designs, and wows us when applied to
marketing websites.
Shape contrast

Highlighting differences in shape can help us understand that elements in a
composition perform different functions. For example, a rectangle button with
sharp corners will immediately stand out among a sea of images with rounded
corners, signaling to users that it’s an interactive element.
Size contrast

When combining shapes, each of a different size, we create size contrast and
emphasize that the larger one is more important. Think of things like notification
badges over avatars or icons. If the notification badge and avatar are the same
size, it’s not immediately apparent which element is more important. By using a
larger avatar and small notification badge, we get a sense of the hierarchy of

those two elements — the avatar is the primary element and the notification
badge is secondary.
Color contrast
Color contrast usually overpowers shape contrast, especially if the colors are very
dissimilar, like red and gray. It’s one of the primary reasons designers use color

contrast to differentiate things like button functions. For example, using red for a
button with a destructive action (like “Delete”) clues users into the importance of
that button and the visual weight warns them of the action they’re about to take. It
gives them a chance to think twice before clicking it.
Shape contrast

Contrast creates complex relationships between objects, which, in turn, generates
interest. Using a combination of contrast types creates more interest. For
example, using color contrast along with shape contrast by combining circles with
squares makes an interactive element way more eye-catching than using squares
alone with contrasting colors.
Size contrast

Size contrast is one of the easiest and most straightforward ways to create visual
hierarchy on a page. Using a large headline immediately grabs a user’s attention
and makes it stand out as the most compelling feature on a page. It immediately
sets the hierarchy for the page, especially when there’s a distinct contrast
between the headline and subhead.
Different font weights increase contrast, adding even more emphasis on a title.
Color contrast

Using high-contrast colors is a bold move not every designer can pull off. One of
the safest ways to pull this technique off, though, is to combine a bright color with
a neutral. For example, a combination of black with dynamic red is a safe bet that
is high contrast while avoiding visual conflict.
Knowledge of color theory can come in handy to create striking and practical
color palettes with high contrast.
Quantity contrast

Experimenting with the number of elements on either side of a vertical axis can
create balanced asymmetry, add a dynamic feeling, and disperse user attention.
Combining a large image that serves as the focal point with a column of
thumbnails creates a more balanced composition, for example, than simply a large
image and text.
Position contrast

Changing the position of elements on a page helps break up any monotony and
keep users engaged. What’s more, it guides attention to the most important
element — a product image, for example — and makes the design more
memorable.
Position within a composition can add (or subtract) visual weight to certain
elements. Elements near the bottom of the composition will naturally appear

heavier than those near the top.
Aligning images and text to the bottom makes them look heavier in contrast with a
"feather-light" title.
Orientation contrast

Experiment with the orientation of elements to create more dynamic
compositions. An angled background shape, for example, creates a sense of
movement on the page compared with a shape that’s oriented on strict vertical
and horizontal axes. In turn, that makes your focal point image stand out more.
Context contrast

Advertising and marketing agencies love to use contrasting concepts to
strengthen their message and grab users’ attention. For example, adding an
obviously salty snack to a bottled water advertisement can make consumers
thirsty, resulting in them buying more water.
It’s important that the contrasting concepts reinforce and enhance the message,
though, rather than leaving users confused. For example, a gothic typeface fails to
enhance the message of this example and doesn’t encourage users to order
delicious sweets.
Visual weight contrast

Balancing complex elements with simple ones is an excellent way to add visual
weight contrast to a composition. For example, a large image is heavy and stands
out due to its size. White space and contrast immediately direct viewers’
attention to the subject. Pairing it with lighter text balances the composition
without overpowering the image.
In turn, a busier composition with lighter elements is still balanced, but the main
image won’t stand out as much and the overall impression is much busier.
Relationships
Establishing relationships between elements in your design through subtlety and
similarity can create an elegant, unified look for your designs when stark contrast
just isn’t appropriate.
When used correctly, subtle differences between elements can add emphasis
without allowing any single element to overpower the composition. And similarity
is an excellent tool when you want to unify elements and create a cohesive whole.
Learning to implement both expands your designer toolbox.
Subtlety
Subtlety, or subtle contrast, occurs when elements are nearly identical but each
has a unique quality that sets it apart. It could be a subtle difference in color,
shape, size, texture, or other properties. While contrast generally makes elements

stand out, a slight difference is a more elegant and delicate approach to
emphasize particular content and set elements apart.
Similarity
Similarity refers to elements that do not contrast with one another. Like two peas
in a pod, similar elements generally have the same color, shape, size, and/or other
properties.
Similarity can help designers achieve compositional emphasis, but compared to
contrast, this principle is less potent in capturing and holding users’ attention.
Where similarity really shines, though, is in making sure particular elements are
perceived as a group.
Subtlety

Subtle contrast can make a big impact on user perceptions. For example, buttons
with slightly different corner radii stand out from one another. A button with a
smaller corner radius looks more conventional, while one with a larger radius
seems friendlier, encouraging users to interact with it.
Be careful with subtlety, though, as too little contrast can actually feel like a
mistake to users, and make a composition appear unbalanced when used
incorrectly.
Similarity

Similarity doesn’t necessarily mean that elements need to be identical. But they
should have enough in common to immediately be identified as related and in a
single group. Use shape, color, size, and similar properties to unify similar
elements.
Subtlety

Subtlety is an excellent way to emphasize an element without overdoing it or
making it stand out too much. A small change — say, the background color for a
hover state on a product card — can set it apart in a powerful way without being
visually overwhelming.
Similarity

When your elements are of equal importance, similarity is your friend. Take a
series of cards on a page. They’re all important and no individual card should try
to steal the show. When they’re all formatted in the same way, they appear
unified.
Subtlety with shape

While all of these elements are rectangular, there are subtle differences between
them. The cards have sharp corners, while the button corners are slightly
rounded. It’s a small detail, but it helps users recognize and distinguish between
elements to avoid confusion. The rounded corners on the buttons are also more
inviting for users to interact with.
Subtlety with size

Subtle differences in the size of images on a page adds emphasis to the larger
image while also capturing users’ attention. It makes a stronger visual impression
than two equally-sized images while still allowing both images to shine.
Subtlety with color

While bright, contrasting colors have their time and place in design, they can run
the risk of making your composition resemble Willy Wonka’s Chocolate Factory. An
analogous color palette avoids that effect. Subtle differences in tints and shades
help create a minimalistic and appealing look that’s easy to implement in many
types of designs.

Subtlety with texture
Playing with textures can add subtle differences between elements while also
unifying them. A subtle texture effect on the sweater and skirt tie the two
characters in this example together, without being mirror images of each other. At
the same time, it balances out the composition.

Similarity with shape
Similar elements are immediately perceived as related by users. Elements that
share the same shape, color, size, or other properties are viewed as a group. It’s
one of the main reasons designers stick to one button shape throughout a design
or use all black and white images of the same size and shape. The same-shaped
images in this example demonstrate they belong to a single group.

Be careful not to use the same shape for elements that are not related, as it can
make users perceive them as a group.
Similarity with size
Size is often used to emphasize an element and call attention to it. Same-sized
elements, on the other hand, usually look related and carry the same level of

importance. Due to size similarity, the example page from an e-commerce site
looks consistent and makes it easy for users to scan and assess their options.
Similarity with color
Color is a powerful tool for designers and can help unify elements within a
composition. Think of football players — they wear the same colored jerseys to

signify that they belong to the same team. Using the same analogous color
palette for elements — the CTA button, title, and hero image — creates a cohesive
vibe and makes the entire composition look complete.
Repetition
One of the most effective ways to establish a habit in real life is through repetition.
In UI design, repetition brings consistency to designs and, depending on how it’s
used, can add energy to a composition.
Learning the various ways in which repetition can be used, including both simple
and complex repetition, gives you more options as a designer. Repetition is a
powerful composition technique that can add life to your designs — or make them
boring and monotonous if done poorly.
Repetition refers to duplicating a single element many times. Railroad tracks,
stairs, and bookshelves all represent the repetition of objects in real life.
Repetition is best used in small doses within a composition to avoid creating a
design that becomes monotonous. That said, it can help maintain consistency in
your compositions.
Repetition is the best friend of consistency in design, making users feel relaxed
and comfortable.
Simple repetition

Simple repetition is best kept to small doses (such as three repeating lines in a
hamburger menu icon). When used too much, it can become boring and
monotonous. It’s useful in reinforcing an idea or concept, however, it is vital to
understand how to use it effectively.
Complex repetition

To understand the idea of complex repetition, think of carpets or wallpapers. They
create rhythms and patterns — repetition of more than one design element
working together as a group. Complex repetition can be quite dynamic and
refreshing, adding more visual interest than simple repetition.
Designers can use complex repetition to make particular elements stand out
within a group. They can also use complex repetition more subtly for things like
patterns and textures within a composition.
Repetition of elements

Repetition — particularly simple repetition — is common for balanced,
symmetrical, and static compositions. It’s also popular for smaller elements, such
as a hamburger menu icon (made up of three parallel horizontal lines on top of
each other). It’s clear-cut and recognizable to users, eliminating distractions from
the content in focus.
Simple repetition of elements

Simple repetition doesn’t necessarily require that all elements are identical. For
example, icons of the same style, size, and color can create simple repetition even
though the specific images are different for each. Each icon is a single element,
but combined together and equally spaced they create a reliable, simple pattern in
a navigation bar.
Complex repetition of elements

Pagination is ordinarily an example of simple repetition. Sometimes, though, there
are too many pages to display all at once.
That's when complex repetition can give users a sense of continuity without
overwhelming your users with too much information. By using complex repetition
to create an internal rhythm, users can clearly orient themselves within the
pagination while keeping the overall design clean.
Repetition in UI

Some interfaces just naturally lend themselves to repetition — calculators,
calendars, tables, and the like. Repetition in these cases orients users and makes
the interface intuitive to use. Colored boxes repeated at equal intervals give a
sense of order and balance.
Simple repetition in UI

Simple repetition focuses on equal relationships between elements. Every element
— for example, days in a calendar — has the same shape, color, and carries the
same visual weight.
Simple repetition creates consistency and order and eliminates confusion in the
design. It’s immediately apparent to users what the element is and its function.

Complex repetition in UI
Complex repetition involves variations of shape, color, or position of elements
repeated in a recurring, regular arrangement. A composition that includes groups
of boxes in different styles that follow equal intervals is an excellent example.
Black blocks mark the category and create contrast, while other content is placed
in white blocks, making the page more dynamic and easy to navigate.

Rhythm
The repetition of sounds and pauses creates rhythm in music. In design, it’s
created in similar ways: through the repetition of elements and the space in
between them. Rhythm brings harmony to designs and shepherds users through
your compositions.
Rhythm comes in three basic types: regular (where elements are repeated at
regular intervals), flowing (created through the repetition of organic shapes
placed naturally), and progressive (where there are slight variations in each
subsequent repetition). Master all three to create movement and harmony in your
compositions.
You’re probably already familiar with the concept of rhythm from music: it’s the
pattern created by the arrangement of notes and the space in between them. In
design, the concept is similar. Rhythm is the arrangement of elements at regular or
random intervals that create a sense of movement.
Successful design rhythm is much like musical rhythm. It’s not just about the
arrangement of the elements themselves, but also the negative space in between
them. Rhythm also relies on the repetition of certain elements, tying the entire
composition together.
External rhythm

External rhythm is the rhythm that exists between different groups of elements. In
design, the external rhythm — the repetition of content groups and the negative
space between them — creates the flow and leads users’ eyes throughout the
page. Rhythm, when done well, is also used to create harmony within the
composition.
Internal rhythm

Internal rhythm is created within groups of elements. It’s the repetition of parts
and spacing between them within a component. Designers can repeat elements
inside components or more complex content blocks, such as a menu, photo
gallery, or footer, to direct users’ natural eye flow and make the content easy to
scan and navigate.
Rhythm vs. repetition
The core difference between rhythm and repetition is that rhythm implies
movement, progress, and sometimes surprising variations. Waltz is all about
rhythm and includes a step, slide, and step in 3/4 time. On the contrary, marching
is a repetition of monotonous footsteps without any irregularities.
That said, rhythm should always include some form of repetition. It creates a
pattern that keeps users feeling grounded on the page. Compositions with entirely
random elements don't create a sense of rhythm or repetition.
External rhythm in elements

A nested list is an excellent example of external rhythm. It contains categories —
colors or brands in this example — placed at equal intervals from each other.
However, each category includes a different amount of items that have, in turn,
their own internal rhythm.
Internal rhythm in elements

The card here contains pricing information, where each element, such as a title,
body text, and the CTA, is a part of an internal rhythm. Take note that some
elements, such as the pricing card in this example, communicate with surrounding
elements, creating an external rhythm.
Rhythm in UI

When designing, rhythm can help establish the mood and make a composition
more dynamic and exciting. Here, we use rhythm to break up the monotony and
make things pop a bit more. It also creates a focal point within the composition,
guiding the user toward the largest image and text.
External rhythm in UI

When designing a pricing page, we may want to differentiate each plan with more
than just words and numbers! Instead of making the height the same, we can
increase it for each subsequent plan, creating a progressive rhythm. This
external rhythm creates not only a unique layout but also highlights how each
pricing plan increases in importance.

Internal rhythm in UI
How do you set the internal rhythm designing something as necessary as a signup form? You add spaces between inputs, titles, and CTAs, making sure users can
quickly scan them without being distracted or confused.

Principles of Composition
Understanding the basic principles of design composition helps you solve design
problems, whether you want to help users complete a task, purchase a product, or
both.
The way a design is composed has a strong influence on the way it’s perceived by
users. Different types of compositions can have dramatically different effects on
those viewing the composition, in both positive and negative ways.
Design composition, in simple terms, refers to how elements are placed on a page.
Successful composition means arranging your design in a manner that not only
looks good but also serves its purpose. To achieve that, follow the principles of
design composition: harmony, visual hierarchy, balance, scale, repetition, contrast,
emphasis, and unity, among others.
Geometric center
Every shape has a geometric center. For basic shapes — like rectangles, ovals,
and squares — it’s the point where the axes of symmetry meet. For a circle with
an infinite number of symmetry axes, a center is a point equally distant from all
edge points. Placing vital elements in a geometric center makes for the easiest,
although not the most imaginative composition. It feels stable, static, and
unchanging.

Compositional center
The geometric center of your design will always be in the same place. The
compositional center, however, is located based on how your design is organized.
It could be a point, several points, or a line along which you place elements.
Visual center

If you ask someone to point to the center of a shape, they’ll generally point to a
spot slightly above the geometric center. Because of the emphasis we place on
the top of a composition or element, we perceive the visual center to be slightly
higher than the actual center.
In design, that means that if we place elements at the geometric center, they can
actually appear to be unbalanced and slightly too low. Placing elements in the
visual center gives a more balanced and harmonious look to your designs.
Balancing elements around the visual, not geometric, center draws more attention
to your subject.
Dominant elements
In many compositions, one element will dominate over the others, through some
combination of size, shape, color, texture, or space. This dominant element carries
more visual weight and gets noticed first. Think of it as the entry point to your
design or the starting point for the story you’re telling.
When designing a composition, make sure that the most important elements are
dominant. The goal is for them to stand out among surrounding elements and grab
the user’s attention.
The dominant element should emphasize the most critical information as it might
be the only thing users will see.

Symmetry
The perceived weight of a visual element is called its visual weight. A composition
with equal visual weight on all sides is considered symmetrical. Symmetrical
balance feels formal and elegant, but is also predictable and sometimes boring.
Asymmetry

Asymmetry occurs when there's unequal visual weight on each side of the
composition. For example, we can balance a dominant element on one side by
adding several secondary elements on the other side. Asymmetrical balance is
more dynamic and exciting, as it offers more variety and feels modern and
energetic.
Closed composition
A closed composition occurs when all elements work together to create a frame.
Generally, we’ll position the primary element near or overlapping the middle of the
composition, while the secondary elements, acting as complementary features,
close the frame.
Open composition

Open compositions encourage the eye to move from one area to the next. They
create a feeling of movement and, unsurprisingly, a sense of openness. Elements
in open compositions do not form a frame, giving the impression that the
composition continues beyond the edge.
Try closed and open compositions to see what works best for different situations.
Static composition

Static compositions appear orderly, poised, and geometrically stable. The
compositional center usually coincides with the geometric center or one of the
axes of symmetry. Static compositions are usually closed, have subdued color and
tonal contrasts, and use straight horizontal and vertical lines crossing at 90degree angles.
Dynamic composition

Dynamic compositions feel energetic and exciting — there’s an illusion of
movement, activity, or even conflict. To achieve this effect, use open composition,
intersecting diagonals of various angles, vigorous contrasts of color, and light and
dark accents. Irregularities attract our attention and invite us to examine the
composition further.
Balanced composition
Balanced composition occurs when all elements work together — the design is
both stable and aesthetically pleasing. While some elements may be more
prominent, no single one draws our attention away from the composition as a
whole. In turn, in an unbalanced composition, individual elements dominate the
whole, leading to tension and uneasiness.
Geometric Perception
The way users perceive different geometric shapes and their properties can have
a profound effect on your compositions. Which shapes attract the most attention?
Why do some designs — just like some smells — make users feel uncomfortable?
What makes users group some elements together and not others?
Understanding the way different shapes are perceived and how they can
influence user behavior is vital to designing effective compositions. Pay attention
to things like shape, color, and grouping when creating UI designs.

Element shape
An element's shape is one of the first things we notice. Shapes are found
everywhere around us, in both natural and manmade objects, in all different sizes
and configurations. Shapes are recognizable at a glance and, in design especially,
users can often immediately identify common components by shape alone.
Active shapes
Active shapes are those that attract and keep our attention. Shapes with rounded
edges, such as circles or many organic and abstract shapes, are perceived by
users as more active. Those with straight lines and right angles, such as squares
and rectangles, are more passive.
Passive shapes

Passive shapes are the opposite of active ones — they lurk in the background and
stay out of the limelight. Most geometric shapes are passive. Squares are
considerably less engaging than circles or organic shapes. They feel deeply
grounded in their surroundings — think of how much more difficult it is to move a
square, angular object than it is to move a round one. Squares produce the
impression of stability and firmness.
Stable shapes

Subconsciously, we compare design elements to real-world objects. Stable
shapes are those that we perceive as well-grounded and difficult to topple. A
triangle is a versatile shape — it can be either stable or unstable, depending on
which direction it's pointing. A triangle pointing up looks solid and well-balanced
— it would be difficult to tip over — similar to a pyramid in the physical world.
Unstable shapes

Unstable shapes look like they’re about to tip over. They can give users an uneasy,
and even uncomfortable, feeling. A downward-pointing triangle is one such
example. In the real world, it would be difficult to balance such a shape so it would
stay upright. The same goes for rhombuses or squares rotated to stand on one
corner.
Organic shapes
Organic shapes resemble shapes you’d find in nature — leaves, clouds, flowers,
and the like. They’re irregular and often asymmetric. Depending on how they’re
used, organic shapes can appear more active than most geometric shapes due to
their fluid lines or they can be made to blend into their surroundings.
Grouping

Our brain has a perception threshold — it can’t simultaneously perceive more than
7 elements at once. When there’s more, we automatically try to organize and
group elements similar in size, shape, or color. If there are too many diverse
elements, the composition seems fragmented and incomplete. This is why it’s
important to consider how elements are grouped when creating a composition.
Grouping by size

Objects with similar sizes are perceived to be related to one another — they form
a group. Elements that are larger or smaller than those in a group will stand apart,
which can be used to your advantage. But if you want certain elements to be
perceived as related, ensure they’re of similar size.
Grouping by shape

Shape can help differentiate between groups of objects that are of similar sizes.
For example, in a composition that includes both circles and squares, users will
perceive the circles as one group and the squares as another group.
Grouping by color

We perceive elements of the same color as belonging together. For example, if
you line up 5 white dogs and 1 white cat, at first glance, most people would see 6
white dogs. That’s the power color can have over perception. Use color wisely to
group elements together, even when they have disparate shapes or sizes.
Grouping by proximity

One effective way of grouping objects is to put them in close proximity to each
other. Just like a long queue to get into a nightclub, closely positioned elements
are often viewed as one, even if they’re different sizes, shapes, and colors.
Grouping by spatial orientation

Objects facing the same direction are naturally perceived as related. Like a crowd
facing the stage at a concert, they appear as a single group. In contrast, objects
facing different directions — imagine a busy park with people facing every which
way — don’t appear unified.
Grouping by movement direction

Elements moving in the same direction look more uniform and closely related than
those moving randomly. Think of how the German Autobahn’s traffic looks more
structured than chaotic traffic in India or South-East Asia.
Visual Perception
The placement of elements within a composition has a significant impact on the
way users perceive the design. This visual perception is based heavily on Gestalt
principles of psychology (Gestalt means “unified whole”) and can heavily influence
user behavior and emotions.
Mastering how element placement can impact a user’s progression through your
product allows you to control that progression much more effectively.
Design perception

Design perception is entirely visual. Our perception of a design is influenced by
things like color, shape, patterns, typography, light, images, and organization of
elements. Designers need to have a solid understanding of visual perception since
graphical user interfaces are perceived entirely through a user’s vision.
Gestalt theory forms the basic study of perception in design, and was developed
in the 1920s. Our perception of designs is heavily influenced by artistic tradition
(which largely influences our perspective), our writing systems (which determines
where we start looking on a page), and real-world experience (which influences
things like our understanding of heavy and light elements).
Writing systems

We tend to scan designs in the same way that we read, expecting to find the most
important information at the beginning. Most modern writing systems use top-tobottom writing patterns, which is why information at the top of a page is
perceived as more valuable.
Most languages are also written left-to-right, making the left-hand side of the
page appear more valuable. However, for over 1.7 billion people, writing is done
from right to left, meaning that they’ll perceive the right-hand side of the page as
more important.
Eye movement

When studying an object, particularly one that’s very visual and not heavy on text,
our eye movement follows a certain pattern. Usually, we start in the upper-left
corner, slide across to the upper-right, and then pass through the center to the
lower-left corner (generally referred to as a Z-pattern). After that, the gaze
becomes less focused and repeats the same trajectory, moving more chaotically
and discerning more details each time.
Knowing this likely pattern allows designers to place the most important parts of a
design along this path, making them more likely to be seen. Of course, in regions
where the writing system is right-to-left, mirror this eye movement pattern for the
same results.
Active zones

The upper-left and center of a page usually get more attention than other areas.
The top part also gets more attention than the bottom, which is why we perceive
the optical center to be higher than the actual geometric center. The lower-right
part gets the least attention, as it requires more conscious effort to concentrate
on that area.
When designing a product, be sure to place the most important parts in these
active zones. Otherwise, they may be overlooked.
Prominence of elements

What we notice first seems more important to us. In cultures with left-to-right
writing systems, people look at the left side of the page first. This is why
information on the left side appears more important. To make an element more
prominent, place it on the left.
Close elements

Objects on the left side feel closer to us than those in the center or right. There's
a couple of factors contributing to this perception.
Things we look at first seem closer to us than things we notice later. Also,
European art has been traditionally depicting closer objects on the left — like in
Michelangelo's The Creation of Adam, where the earthly is on the left and the
divine is on the right.

Distant elements
Italian Renaissance painters and architects discovered linear perspective to create
the illusion of depth on a flat surface. They achieved it by converging all parallel
lines in a single vanishing point at the painting's horizon line. Generations of

artworks with linear perspective taught us to perceive the center of the
composition as farther away from us than the sides.
Light elements
We perceive elements at the top to weigh less than those at the bottom. This
perception of lighter objects is directly tied to our real-world experience with

gravity. We know, for example, that helium balloons float in the air as do empty
plastic bottles in water.
Heavy elements
Our real-world experience with gravity strongly influences our visual perceptions.
We know that in the real world, heavier objects will stay on the ground, so we

naturally assume design elements behave the same way. Placing an element lower
within your composition will give it more weight, and can also make it appear more
stable.
Ascending elements

Any element that starts in the lower left corner and ends in the upper right one will
appear to ascend. Ascending elements elicit emotions of success, growth, and
development. It’s why many companies — Adidas is probably the best-known —
use ascending logos.
Descending elements

Generally, we perceive elements with left corners higher than their right as
descending. This comes from the fact that we scan designs from left to right.
Sometimes, other factors can avert this effect. For example, Puma's feline logo is
clearly leaping towards the left corner and doesn't appear to be falling backward.
Rightward direction
User attention is dynamic — it doesn't stay in one place but follows a
predetermined path, often conditioned by our writing system. While active zones
attract attention, directional vectors determine how the attention moves. For
example, wide text columns naturally direct us from left to right.
Downward direction

Changing the width of a column allows us to control the direction of users'
attention. Narrower columns gently guide users' gaze downward.
Play with the column width to find the right balance in directing users' attention.
Upward & downward directions

The more we move through design, the more details we notice. To make users
scan the page up and down, place text in the middle with center alignment.
Multi-directional movement
By positioning elements in a certain way, designers can direct users' attention
wherever they want it, and even create custom paths for users' gaze to follow. For

example, placing the title to the right will direct users' gaze rightward, and the
narrow text column will then send it downward.
How to use prominent elements
Positioning text on the left with left alignment creates a prominent visual element
— it stands out in the design and immediately grabs users' attention.

How to use close elements
Consider the importance of your elements when deciding where to position them.
If the text carries more meaning than the image, place it on the left to instantly
grab the eye and appear closer to users.

We usually look at the left side more, and, as a result, better remember the
information we see there. Don't waste this space by placing less important
elements there.
How to use distant elements

If you want users to pay more attention to the image, place it on the left and place
the text to the right. We perceive the right side as being more distant as we slowly
move our gaze from left to right. The right side naturally gets less attention.
How to use light elements

Think of the style that better fits your brand personality. If the emotions you want
to elicit are excitement, happiness, and a sense of ease, consider making your
elements appear lighter. To do that, place them above the horizontal middle line.
How to use heavy elements

If the impression you want to make is one of power, elegance, and solemnity,
heavier elements may be the right choice for your composition. Place elements
below the horizontal middle line to appear heavier, as though gravity is pulling
them down.
How to use ascending elements

A well-designed logo can offer substantial benefits to brands. Besides garnering
interest and helping differentiate yourself, it’s your chance to tell the world a
story.
Ascending logos make people think of success and growth. They’ll associate your
brand with their own personal development.
How to use descending elements

The design characteristics of logos can considerably impact consumer behavior
and brand performance. If your brand logo makes people think of decline or
stagnation, you probably won't see your sales soar.
As a rule of thumb, avoid descending logos unless there's an excellent reason to
use them. For example, if your brand is all about saving people money or getting
rid of a problem, then a descending logo might be appropriate.
Working with Composition
All the compositional theory knowledge in the world will only get you so far if you
don’t know how to apply it. Being able to identify and implement symmetrical vs
asymmetrical designs, dynamic vs static compositions, geometric vs visual
centers, etc., will make you a better designer.
While designs in the real world don’t always follow these compositional guidelines,
the most effective ones almost always do. It’s smart for designers to understand
how these compositional techniques work and when to use them.
Geometric center

Building your compositions around the screen’s geometric center is a simple, safe
way to arrange elements. It gives users a sense of stability, while also capturing
their attention effectively. It’s a great option for landing pages or posters but may
lack vibrancy and energy. That said, the geometric center isn't always appropriate
for some design elements.

Compositional center
When defining a compositional center, decide where your users' eyes should go
first. You can achieve balanced and stable compositions, overlapping
compositional and geometric centers, or you can spice things up by moving the
center further away. Don't forget to use larger fonts, accent colors, or distinct
shapes to make elements stand out.

Visual center
A visually centered composition is generally preferable over a geometrical one
because it appears more balanced without looking boring. Users’ eyes generally
gravitate toward the top of the composition, so positioning the center of your
composition just above the geometrical center is more aesthetically pleasing.
Dominant element

Which element within a composition immediately grabs your attention? The
dominant element on a page dictates the alignment and tone for all of the other
elements and, of course, stands out the most.
For example, a landing page may include a lot of elements — headline, subhead,
image, signup button, etc. — but the headline is the first thing that stands out to

users. Set your dominant element apart from the rest of the page via scale, color,
and placement.
Symmetrical composition
Symmetrical compositions work like mirror images, creating designs with equal
visual weight on both sides of the center axis. Symmetrical designs feel natural

and graceful, but be careful that they don’t appear too stagnant.
Symmetrical interfaces are well-suited to particular digital projects, such as a
website devoted to one product or an artist’s portfolio. They’re an elegant solution
and also easier to create than asymmetrical compositions.
Asymmetrical composition

Asymmetrical compositions are well-suited for more complex and exciting designs
with several focal points. They’re also more difficult to do well than symmetrical
compositions since there’s no mathematical formula for creating them — they rely
on a designer’s eye instead.
In this example, the headline on the left is the main focal point for the design,
while less significant focal points — the subhead and CTA button — are on the
right. Achieving an asymmetrical composition like this that’s still aesthetically
pleasing and balanced requires more practice.
Closed composition

Closed compositions arrange all elements within a (mostly invisible) frame.
They provide a sense of completeness. When users look at a closed composition,
their eyes focus on the main elements and don’t wander. Such designs feel
finished and stable.
Open composition

Open compositions have no boundaries or defined borders. Elements can be
placed without regard to the frame of the screen, providing a feeling of freedom
and movement.
Open compositions are like ongoing stories that intrigue users to scroll and
explore. They’re perfect for pages with a lot of content. Using leading lines,
unfinished shapes and images, and unusual orientations, designers can make their
interfaces more dynamic and inviting.
Use open compositions for websites with long and text-heavy pages.
Static composition

Static compositions appear calm and pleasant to the eye. They’re usually
symmetrical in structure, lack movement, and feel safe and predictable.
Use static compositions to organize blocks of information that need to be easy to
scan, like forms or infographics. Because of their stable nature, they’re well-suited
to activities users might consider high risk (such as making a purchase or
reservation).

Dynamic composition
Our eyes instinctively look for balance, and unbalance unsettles us. The
irregularities of dynamic compositions take advantage of this to add a sense of
depth and movement. They can even create feelings of tension (not always a bad
thing).

Dynamic compositions are a powerful tool that can guide users through your
design and help them embark on an exciting user journey. Use them when you
want your users to feel energized by your products.
Compositional balance

Compositional balance is about an even distribution of visual weight. To achieve it,
play with the size, shape, and color of your elements, as well as the negative
space between them. Large, heavy elements, like a hero image, can be balanced
out with negative space or a few smaller features on the opposite side of the
center vertical axis.
Balance doesn't equal symmetry — it can be achieved with asymmetric
composition, resulting in more complex and intriguing designs.
The rule of thirds

The rule of thirds is a fantastic compositional tool that came to digital design from
the world of photography. Imagine the screen divided into equal horizontal and
vertical thirds by invisible lines. Our gaze intuitively gravitates toward the
intersections of those lines.
According to the rule of thirds, those intersection points are the ideal spots to
place key elements, like CTA buttons, headlines, and hero images. They’re most
likely to grab users’ attention in these focal points.
Leading lines

Designers use leading lines — similar to grid lines — as a scaffold to build their
compositions around. They work because our eyes are naturally drawn to follow
the lines within a design, even when the lines themselves are invisible.
Unlike grids, leading lines provide more freedom in creating unconventional,
outstanding layouts. It’s up to you to set the rules for arranging and grouping

content along those lines, making them a very flexible tool in the designer’s
toolbox.
1-Point composition
As the name suggests, a 1-point composition has only one compositional center,
where most of a user’s attention goes. It makes for simple, straightforward layouts

and allows users’ gaze to float around and explore the design in more detail.
Elements aren't fighting for a user’s attention with this type of composition,
making it ideal for landing pages or websites focusing on a single product.
This type of composition is great for concise designs that aren't overloaded with
information.
2-Point composition

Designs with 2 compositional centers convey a sense of balance and harmony. In
our example, you can notice that elements on the left and right sides work to
counterbalance each other, creating an asymmetrical yet harmonious
composition.
As you add more information and functionality, the number of focal points in your
composition naturally increases.
3-Point composition

3-point compositions generally create a triangle within your design. Depending on
its orientation, that triangle can be either stable or unstable.
Upward triangles create a sense of stability and strength and can provide a sense
of unity to your design. Downward triangles, on the other hand, are exciting and
create a sense of movement and even urgency.

3-point compositions are often used for home pages — with focal points being
the headline, the hero image, and the CTA button.
4-Point composition
4-point compositions generally create a frame on the page, resulting in a closed
composition. They allow users to concentrate on the elements within the page

without their attention wandering out of the frame.
The different focal points can compete for user attention, so use this type of
composition with care. They’re great for things like product listings or other pages
where content should all carry equal weight.
Because of their stable, focused structure, 4-point compositions are great for
graphs, tables, and forms.
Positive and Negative Space
Unlike other design elements that may or may not be present, space exists in
every composition. Positive space includes the elements and areas of interest.
Negative space is the area around these elements.
Some web creators might think that negative space has no purpose. Why not
cram as much content as possible on the page? After all, that's what users come
for. In reality, such designs are difficult to read, understand, and enjoy.
When applied correctly, negative space helps focus users' attention and
contributes to a seamless user experience. In fact, users won't even notice
these blank areas. Instead, they will be able to focus on the important points and
achieve their goals easily. The trick is to find the right balance of negative and
positive space for your intended purpose.
Negative space, also known as white space, is an empty area around, between,
and inside the text, images, and graphic elements. It creates breathing room for all
objects on a page, makes the design more comfortable to scan, and adds
emphasis and clarity.
Negative space works because of Gestalt principles. Grouping elements is in
human nature. We subconsciously arrange the elements we see into an organized
system that creates a whole. Empty spaces in a layout help this grouping by
creating clear boundaries between those design elements.
In print, negative space is the white space around text and between lines. In UI
design, it can be any color, or even a subtle pattern or texture.
Positive space
If negative space is an empty area around UI elements, positive space is the
actual UI elements — the essence and the focus of the design. It can take any
shape or form, geometric or organic, solid or outlined. Just as there's no light

without darkness, there's no positive space without negative space — they're
codependent.
To make positive space stand out, ensure there's enough negative space
surrounding it.
Active negative space
Negative space can be active or passive. Active negative space is applied
deliberately to emphasize a particular design element or layout area. The
emptiness created by large negative space acts as an element of its own. Active
negative space enhances the appearance of elements and draws users' attention
to them.
Use active negative space to bring a specific element into the spotlight and
encourage users to take action.
Passive negative space

Passive negative space is the space between elements — such as text and icons
— that helps arrange them in a balanced way. It doesn't act as an element of its
own, but rather keeps the composition from appearing too cluttered. Think of
passive negative space as oxygen — you don't notice it until there's too little of it.
Reducing passive negative space between a group of elements helps emphasize
their direct relationship.
Applying positive space to elements

Many elements consist of positive space. A simple 2-dimensional geometric shape
like the Heart icon is one of the most common examples of positive space.
Designers can use a positive space shape independently as an icon or as part of a
more complex component.
Applying negative space to elements

It's also possible to use negative space to create elements. In this example, the
counter form occupies the space around the heart outline, creating a unified
image. Without the colored counter form, the design would look as white as snow.
This shows how powerful negative space can be!
Applying active negative space to text

Increasing the space between paragraphs or headlines is an example of applying
active negative space to text. This helps us separate different ideas and
emphasize the headline's importance. Notice how just a bit more space makes the
headling stand out that much more from the body text.
Applying passive negative space to text

The line spacing here represents passive negative space applied to text. It can
reduce eye strain and help users quickly scan the composition to find what they
need. The text feels airy, and the space itself doesn't stand out. But when there's
not enough passive negative space, the composition feels cluttered and hard to
navigate.
Positive space in layouts

As designers, we should leverage both positive and negative space when creating
layouts. This allows us to tell a harmonious, logical, and complete story. However,
we may want to create focus first — and that's what positive space helps achieve.
In the example, the composition draws users' attention to the black and red
blocks. At the same time, passive negative space subtly separates them.

Negative space in layouts
Active negative space acts as an element in and of itself. In this layout, the
negative space is quite visible — it leaves room for the other design elements to
breathe.

In a simplistic design like this, it's important to separate content groups. On this
webpage, the headline, body, navigational icons, and hero image are clearly
differentiated by the white space surrounding them.
Active negative space in web design

Active negative space on a web page aims to direct focus on a specific area. At
the same time, it adds breathing room around the elements. As a result, the
message you're trying to communicate becomes much clearer to the audience.
As in many things, it's important not to go overboard. Too much active negative
space can distract users and make them lose focus and interest.
Passive negative space in web design

Passive negative space in web design doesn't emphasize elements. Its role is to
add distance between elements within the same logical group to prevent the
design from feeling cluttered and aid in things like readability.
In the example, we identify the title and image as related due to the modest
spacing.
Applying Negative Space
Negative or white space describes the area between elements and content
groups. It's important to understand that negative space isn't empty space. It's
not that there's nothing to put in there — negative space doesn't display any
content deliberately.
Negative space can serve many purposes. It increases readability, establishes
hierarchy, emphasizes important elements, and guides users' attention where
designers want it. Plus, well-spaced designs look more appealing and
professional.
Negative space provides "breathing room" on the
page
Adding negative space to a design doesn't just mean creating bigger gaps
between elements. When done right, negative space helps maintain visual

balance, adds to the feeling of spaciousness, and emphasizes the intended
message.
In the example, scaling down an image brings it to focus. The design looks spatial
but at the same time balanced.
Remember that negative space is an active element of design, so you need to
balance it with other content.
Active negative space makes for visually interesting
designs

Active negative space can create vibrance and provide energy to composition. It
acts as an independent design element, breaking the repetitive pattern. The
unequal intervals between the elements in the example create a sense of
movement and rhythm. As a result, the design looks more visually interesting, and
the UI resembles a magazine page.
Passive negative space improves legibility

Passive negative space improves legibility and overall user experience. Seeing too
many elements or words appear in a small space can be overwhelming to users.
Adding a consistent margin between images and text makes the content easy to
follow and scan.
Before adding active negative space to the design, make sure you apply enough
passive negative space.

External negative space ensures spacial balance
By external negative space, we mean the space that surrounds content blocks or
separates them from one another. Its goal is to provide a nice spatial balance and
create paths for the eye to follow. When used effectively, external negative space
frames the focal object and ensures that it gets users' attention.

Internal negative space ensures that elements don't
clash
Internal negative space is all about the relationship between elements of one
group. Some examples include margin and line spacing.

This internal negative space aims to control element proximity and make sure
that elements don't clash with one another. The spacing between small elements
can have an impact on readability and the flow of the page.
Negative space can highlight elements

Sometimes the easiest way to highlight an element is to increase the negative
space around it. Sizing down elements and keeping a comfortable distance
between content groups draws attention to the focal points.
Fight the urge to fill any white space you have with more content. Each time you
add another element to your design, ask yourself if it serves the purpose and
helps users complete their goal.
Negative space ensures legibility

Good typography is not only about positive forms but also the spaces between
them. Internal negative space — for example, space between lines and characters
— helps ensure that the text is legible.
External negative space helps direct the flow of the page and establish hierarchy.
 The space around the contact details draws users' attention to it. At the same
time, the body text that flows around it emphasizes the connection between
these 2 content groups.
According to the web accessibility guidelines, the line spacing should be at least
150% bigger than the font size.
Negative space around elements helps establish
the order of importance

Adding extra negative space around images, illustrations, or videos draws
attention to them. When done right, it builds up a strong visual hierarchy. In turn,
this helps users understand the message much faster.
In the example, the negative space establishes the order of importance. Viewers
immediately notice the larger image and then move on to the smaller picture.
Together with the title, the composition effectively communicates the message.

Negative space improves UX
Negative space serves several purposes on pages with a lot of text and images.
The line spacing ensures the legibility and scannability of the page. The space
between the elements creates the hierarchy of information. Having enough
negative space allows the page to breathe.

When done correctly, negative space on web pages can significantly improve the
UX. Moreover, users are more likely to return to beautiful, well-structured pages
where they manage to find what they are looking for.
Negative space should never be an afterthought — use it actively throughout your
design process.
Applying Composition Grids
Quoting a Canadian designer, typographer, artist, illustrator, and writer Marian
Bantjes, "design and typography are like a well-tailored suit." Composition grids
help designers craft exquisite designs that feel like a genuine masterpiece.
Users may overlook intricate details and delicate work, but when it's done
professionally, they can tell "it looks like a million bucks."But what type of grid
should you use?
Content is a king, and your choice of a grid should, first of all, rely on what content
your product provides. Some grids have a structure that perfectly fits large pieces
of text, while others are designed for websites with various types of data. Some
grids are more organized and traditional, while others can help you bring a streak
of creativity. Understand the pros and cons of various grid types to make the right
choice of grid for your project.
Column grids

Traditional column grids are common for products with a large range of material
types, like magazines or newspapers. Those grids are flexible and allow to
organize content in an easy-to-read format. More than that, you can manipulate
the size and number of columns to create something unique, asymmetrical, and
fresh. The website example uses a three-column grid with proportional widths,
while the title takes up the space of all three columns, balancing out the
composition.
Traditionally, if the gutter size is X, the margin size is 2X. Such measurements help
guide users' attention inward and make reading more comfortable.
Three-column grids

Three-column grids provide a uniform solution — they're standard and can be
applied to many websites.
Typography can help define columns. Using different weights and sizes, you can
determine the order of information and create a hierarchy that can be either
horizontal (title, description) or vertical columns, left to right).

Three-column layouts can feel dense. You can avoid it by lowering columns and
creating a clear area for a header, title, or photos.
Unexpected types of grids
Selecting a grid on a certain degree angle or using the golden rectangle as a
proportion, you can present a website in an entirely new light or from an

absolutely different angle. Rotated grids display an exceptional diagonal
composition and carry a sense of movement.
Modular grids
Modular grids apart from columns have rows that allow organizing multiple
content areas — modules — more flexibly and give more control than a column

grid can offer. They're quite popular for presenting tabular information, such as
graphs, charts, tables, schedules, or forms, as well as for e-commerce sites or
image galleries — think of the Instagram explore page. However, they may create
a feeling of too much order and mathematical rationality.
Integrated grids
Integrated grids are for designers who love challenges and want to add more
variations to a layout. Such grids consist at least of two grid systems — one can
be designed specifically for images and graphics, while the second — for
typography. The example interface overlays two grids, and the overall
composition looks fresh and a bit eccentric.
Use symmetrical grids for uniform content

Traditionally, column grids use equally-sized columns that fit perfectly for uniform
content with an equal level of priority. Symmetrical grids establish a sense of
great order and allow for various amounts of space and image sizes. This type of
grid is perfect for presenting the same information in two different languages or
comparing opposite options.
Be cautious as interfaces with symmetrical grids may look monotonous and lack
vibrancy.
Use asymmetrical grids to emphasize content

Asymmetrical grids have more visual interest and feel less monotonous. You can
use asymmetry to make a contrast between content groups and emphasize
certain elements.
Make sure asymmetry doesn't create chaos on a page and doesn't break a
reading pattern. People should easily scan a page from the most critical
information to the less important.

Manuscript grid
Manuscript grids are classic grids for printing, especially for continuous blocks of
text, like in books, essays, or manuscripts. However, images can also be used to
add more visual interest, decrease cognitive load, and simplify scanning.

To prevent a page from looking like a monotonous block of text, designers should
add enough white space to margins.
Hierarchical grids
Although hierarchical grids may look a bit chaotic, lack regular structuring, and
don't contain repeated intervals, the layout naturally relies on a website's specific

content.
Hierarchical grids place elements intuitively — the content itself defines the
logical alignment and overall composition. Designers can adjust grid rows,
columns, flow lines, margins, modules, etc., according to the need of the website's
content.
This grid type helps navigate users through the information in the desired way,
from the most vital elements to the less important ones.
You can apply a more precise approach and use math calculations to define the
content arrangement.
Design Workflow
The design workflow is a non-linear multifaceted process that involves
cooperation with team members, user research practices, churning out, testing,
refining, throwing away dozens of ideas, sketching, wireframing, and other
essential activities. Sometimes, you may even turn out to be the only designer on
a project to handle such an enormous scope of tasks. Don't panic, though.
Your design workflow may include more or less 10 steps, the amount of prominent
activities is up to you. The only thing to worry about is that they lead you from
initial conception to realization.
Step 1: Research and ideate

The first stage of any product is communication. Initiate discussions with your
clients to ideate — to stimulate the brain thinking and define what product you're
going to implement. Take all information provided by stakeholders, including
marketing research and their business goals. If it's not enough or you have time
and resources, conduct your own user research. Data collected during user
interviews, surveys, competitive overview, etc., will help you gain insights and
organize the information into a diagram or map of a solution.
Step 2: Start sketching

All ideas start on paper — make sure to have a pen handy to visualize your ideas.
Don't think of color, typography, media, or features. Sketches shouldn't focus on
the details. Instead, they focus on the big picture — it's the skeleton of what's to
come. Don't get attached to your ideas on sketches. Instead, use them to ignite
discussions, communicate, and find the best solution.
Create quick and cheap sketches to get immediate feedback, test ideas, discard
them, and repeat.
Step 3: Digitize your sketches
Okay, now's the time to get your hands clean — let's put down the pen and pick
up a computer! This is the time to start putting together a digital visualization.
Without being distracted by fancy colors, neat typefaces, and actual content
move your sketches on a screen, focusing on the overall composition. You may
refer to your sketch but don't be afraid to adjust the composition if you see that
some elements look off on a screen. At this point, you'll want to focus on the user
journey and getting users from point A to point B.
We recommend creating a color palette of 6 grey tones to help speed up your
mockup workflow.
Step 4: Apply a grid

Now, with your barebone mockup in hand, you can define the grid. It's essential to
carefully consider your grid at this point, as it'll help speed up your workflow
further down the line. Depending on the content, you can settle with a more
traditional, proportional column grid or choose a modular grid for a content-heavy
website. You can also play around with asymmetry for more interesting,
unexpected layouts.
More columns mean more complexity. If you strive for simple solutions, stick to
simpler grids.
Step 5: Build your wireframes
A wireframe is a simplified version of your future product. Its level of detail and
interactivity is up to you, but remember that we create wireframes for testing
ideas and insights. You can use some basic drag&drop software for drawing the
layout — Balsamiq or even PowerPoint or Keynote can serve the purpose.
Keep it simple and informative, gradually replacing placeholders and dummy text
with actual or more or less realistic content. Draft, replace, and fix before you
settle on a final version.
Step 6: Add typography

Once you've done a couple of rounds of wireframe testing and receive some
valuable feedback, it's time to polish wireframes.
At this stage, you can start thinking of the aesthetics of a product. One of the
components of visual design is typography.
We know how your head goes spinning when it comes to this subject — there are
so many choices! There are also plenty of aspects to consider. Start selecting the
legible typeface with the right mood and intent to fit your brand identity and
website topic. Stick to the typeface that works in multiple sizes and contains font
variations with bolds, italics, and small caps.
Feel free to select more than one typeface. One for headlines and another for
body text.
Step 7: Add visuals

Once the typography is good-to-go, it's time to fine-tune the visuals. As human
beings, we seek order and consistency. That's why your first step should be to
establish a well-structured style guide — a document containing all the branding
and visual style rules.
What does a style guide usually contain? Generally, it consists of branding
guidelines (logo usage, typography, color palette, brand principles) and a pattern
library that describes basic UI components, including colors, fonts, and page
layouts. This tool ensures design consistency and a smooth developer handoff.
Step 8: Add microinteractions

Successful usage of microinteractions not only enhances the user experience but
also helps users accomplish their goals.
Microinteractions let users know what is happening in the system and provide
feedback, often helping them prevent errors. Simply put, users should clearly see
what they can click, tap, or swipe and view the response on their actions.
Examples include pull-to-refresh animation or a validation message on wrong data
input.
With the help of tools like Invision, Figma, or Marvelapp, you can add simple
microinteractions to your designs and visualize how users will interact with your
product.
Use microinteractions to enhance the general user experience and brand
personality.
Step 9: Verify consistency
When the first page is done, it's time to reproduce your design language across all
other pages — consistently. The style guide is your single source of truth. On the
one hand, it makes the system more familiar and easy to learn for users. On the
other hand, it helps you and other designers stick to the right colors, fonts, sizes,
and other properties to maintain a consistent look. After all, consistency is key,
and it ensures predictability and a cohesive user experience.

Step 10: Make it responsive
The days are long gone when users accessed your website from only one device
— that's all water under the bridge. Nowadays, users jump between multiple
devices to complete even one task. As designers — no wait, as product people —
we should take responsive design seriously. Initially, it takes a lot of time, but once
you've established the rules and breakpoints, the execution will be smooth as
butter.
When designing a website, aim for at least 3 types of screens: desktop, mobile,
and tablet. Always consider the product's content and the target audience's
device preferences.
Don't forget to adapt grids for mobile screens — they are limited in space and
require a different approach.
Component Anatomy
There are a lot of elements that make up usable UI components. Understanding
these components' anatomy allows you to design and implement them better.
Well-designed components add to the overall usability and functionality of digital
products.
Components can be broken down into a few categories: text, icons, media, and
layout components being chief among them. These anatomical elements can be

combined in various ways to create unique UIs that engage your users and guide
them through using your product in the most effective ways.
Body text
Can you imagine an interface without body text? Even highly-visual interfaces that
focus on multimedia content include some text. Understanding how various text
elements are used within an interface is vital to creating effective text content.
Text is used to provide insight and detail, describe functions, help complete tasks,
and engage users in general. For many sites, it's the primary form of content, and
even on sites with largely multimedia content, text can serve to provide further
information (such as transcripts or meta-information). Without text, most websites
and apps would be entirely unusable.
16px is the minimum size you should use for body text, specifically for text-heavy
pages.
Heading

Generally the most prominent text component on a website or in an app, headings
are signs that give users the most important information they need to orient
themselves on a given page. They should be sized noticeably larger than other
texts on the page, particularly the body text.
Headings should be concise and immediately grab the user’s attention. They
should also provide some kind of useful information or otherwise entice users to
read the content under them.
Make sure headings stand out from every other text element on a page through
size, weight, and style.
Subhead

Subheads are second-level headings that can provide additional information
about the heading and its content.
Subheads should be styled to stand out from the body text under them but
shouldn’t compete with the headline for the user's attention. Use a font size that's
in between the heading and body text sizes and in a less eye-catching styling.
Labels

Labels are a vital part of the text on a website as they clarify a component’s
purpose. They’re typically used on things like form fields, buttons, next to icons,
and in other areas where users need a little extra information to understand how
to use a component quickly.
Make sure labels are readable. Stick to short phrases that can be quickly scanned
and a legible font that doesn't stand out too much.
Icons

Icons are simplified images that represent actions, objects, or ideas. They are a
vital part of most user interfaces, helping users find their way around. Their
meaning should be clear and explicit to help users rather than confuse them. They
work best when they represent similar physical objects (such as a house for
“home” or a disk for “save”).
Icons can also appear independently, without a label or other text information. In
that case, though, the icon must be commonly used across the Internet and
immediately recognizable to users.
Keep icons simple and use familiar physical analogues to avoid confusion.
Leading icon

Within an interface, icons are often accompanied by labels or other text content.
Icons that appear before the content are called leading icons. They add context
to the element they’re contained within, such as clarifying the action of a button
or the message contained in a notification.
Trailing icon

Trailing icons are found after an element’s content. They’re generally interactive,
triggering an action on nearby elements, such as showing or hiding a password
or opening a dropdown menu. Be sure to use icons that are easily recognizable to
help users figure out what the trailing icon's purpose is.
Container
Containers are squares or rectangles that hold a component’s content, including
text, images, or action items. They’re often included as a visible part of the
design, with a background color, shadow, and/or border. They can also be more or
less invisible and only provide structure or balance behind the scenes in the
interface’s code.
Dimensions

The dimensions of a component include its width and height. They should be
specified whenever possible. Dimensions do not include margins around an
element, but they do include any padding and borders.
Height and width can be specified with minimum and/or maximum values, allowing
them to shrink or expand to fit the layout.
When describing an element’s dimensions, the width goes first. So, if an element
is 12×10px, then it’s 12px wide and 10px high.
Dividers

A divider is a horizontal or vertical line that provides a visual differentiator
between sections of content. Dividers create a clear delineation between groups
of content and can provide structure to your layout.
Dividers should be used sparingly, though, as they can create a cluttered
interface. Consider using white space instead to differentiate between groups of
content.
Overlays

Overlays sit above content and disable whatever is behind them while keeping
that content partially visible. They can be used in a variety of ways: in response
to an action taken by a user, behind modals to make them stand out from the
content behind them, or permanently stay between an image and text to enhance
the text’s visibility and readability.
When overlays are used behind a modal or in response to an action, be sure to
make it easy for users to close them. This can be done by including Cancel (X)
buttons or clicking outside the overlay area.
Border radius

Components that appear with their own background color or visible border
include a border radius. Border radius defines how rounded the corners of the
component should be.
Sharp edges are sometimes associated — consciously or unconsciously — with
pain (think of how painful it is to bang your shin on the sharp corner of a coffee
table).
Rounded corners are easier on the eyes, guiding users toward the element's
center. Even a slightly rounded corner can avoid the painful association of sharp
corners. Be careful not to overdo border radius, though, as disproportionately
large radii (that's the plural of "radius") can also be unpleasant to look at.
Multimedia

Multimedia content is a term used to describe multiple content formats such as
text, images, illustrations, photos, videos, GIFs, among others.
Using a variety of content forms can make interfaces feel more natural. Beware of
including auto-playing audio and video content, though, as it can annoy some
users and lead to a negative user experience.
Thumbnail

Thumbnails are scaled-down images that navigate to a new page or open a fullsize media element when clicked. If you’ve ever searched for images or videos,
you’ve likely seen sets of thumbnails show up in the results.
They are often used within interfaces that include a lot of images or videos that
don’t need to be displayed at full size at the same time. They can save users time
by making it easier to scan through large groups of images or videos while saving
bandwidth.
Placeholders

Placeholders hold the place for content that users add, disappearing when the
user fills in the content to replace it.
They're an excellent opportunity to provide an additional hint or an example of the
requested information. This improves user experience by giving them an
immediate visual cue to the kind of content the user should add.
Color placeholders more subtly so that users won't mistake them for data they've
entered themselves.
