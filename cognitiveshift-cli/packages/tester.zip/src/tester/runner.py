"""Deterministic smoke-test orchestration — runs with no LLM.

Wraps the two canonical shell scripts (`scripts/build.sh`, `scripts/smoke.sh`, the real
macOS xcodebuild/simctl capability) behind a structured, injectable command runner so the
orchestration + parsing + gate logic is exercised offline (no Mac, no Xcode) in CI. The agent
layer adds budget/observability and an optional LLM crash diagnosis on top of this.

`smoke_test(...)` is the analog of security-review's `scan()`: pure, deterministic, testable.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from tester.models import SmokeReport, StepResult

# src/tester/runner.py -> parents[2] == agents/tester
SCRIPTS_DIR = Path(__file__).resolve().parents[2] / "scripts"

# Defaults mirror the shell scripts' own defaults. APP_DIR is relative to the scripts/ dir,
# which is where the scripts are designed to run from (build.sh does `cd "$APP_DIR"`).
DEFAULT_APP_DIR = "../../../apps/color-matching"
DEFAULT_SCHEME = "ColorMatching"
DEFAULT_BUNDLE_ID = "co.elktech.colormatching"

_TOOLCHAIN_MISSING = 127          # `command -v xcodebuild/xcrun` -> exit 127 off macOS
_TAIL_LINES = 20


@dataclass
class CommandResult:
    returncode: int
    stdout: str = ""
    stderr: str = ""


# A command runner takes (argv, cwd) and returns a CommandResult. Injected so tests can stub
# xcodebuild/xcrun without a Mac; production uses `subprocess_runner`.
CommandRunner = Callable[[list[str], "Path | None"], CommandResult]


def subprocess_runner(cmd: list[str], cwd: Path | None = None) -> CommandResult:
    import subprocess  # local import: keeps the module import-safe in restricted sandboxes
    import sys

    # xcodebuild/simctl exist only on macOS. Off-platform, don't shell out (a Windows WSL stub or
    # a wrong `bash` would report a spurious build failure) — report the toolchain as unavailable.
    if sys.platform != "darwin":
        return CommandResult(_TOOLCHAIN_MISSING, "", "iOS build/simulator toolchain requires macOS")
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)  # noqa: S603
        return CommandResult(p.returncode, p.stdout or "", p.stderr or "")
    except FileNotFoundError:
        # No `bash` on PATH — treat as toolchain-unavailable, not a crash.
        return CommandResult(_TOOLCHAIN_MISSING, "", "bash not found")


def _tail(text: str, n: int = _TAIL_LINES) -> str:
    lines = (text or "").strip().splitlines()
    return "\n".join(lines[-n:])


def _crash_log(output: str) -> str | None:
    """Best-effort crash-log location from the smoke output."""
    m = re.search(r"(\S+\.(?:crash|ips))", output)
    if m:
        return m.group(1)
    if "DiagnosticReports" in output:
        return "~/Library/Logs/DiagnosticReports"
    return None


def smoke_test(
    app_dir: str = DEFAULT_APP_DIR,
    scheme: str = DEFAULT_SCHEME,
    bundle_id: str = DEFAULT_BUNDLE_ID,
    *,
    runner: CommandRunner = subprocess_runner,
    scripts_dir: Path = SCRIPTS_DIR,
) -> SmokeReport:
    """Build the app, launch it in the simulator, and assert it stays up.

    Returns a structured SmokeReport. `status` distinguishes build-failed / launch-failed /
    unavailable (no toolchain) so the gate never confuses "broken app" with "can't run here".
    """
    build_sh = scripts_dir / "build.sh"
    smoke_sh = scripts_dir / "smoke.sh"
    if not build_sh.exists() or not smoke_sh.exists():
        return SmokeReport(passed=False, status="error", steps=[],
                           summary=f"smoke scripts missing under {scripts_dir}")

    # Run the scripts *from* scripts/ (relative name, no absolute path) so a space in the repo
    # path (e.g. "EIK Tech") can't break the bash invocation, and the scripts' relative defaults
    # resolve correctly.
    # --- phase 1: build -------------------------------------------------------------------
    b = runner(["bash", "./" + build_sh.name, app_dir, scheme], scripts_dir)
    build = StepResult(name="build", ran=True, ok=(b.returncode == 0),
                       returncode=b.returncode, output=_tail(b.stdout + "\n" + b.stderr))
    if b.returncode == _TOOLCHAIN_MISSING:
        return SmokeReport(passed=False, status="unavailable", steps=[build],
                           summary="xcodebuild not available (macOS-only) - build skipped.")
    if b.returncode != 0:
        return SmokeReport(passed=False, status="build-failed", steps=[build],
                           summary=f"Build failed for scheme {scheme} (exit {b.returncode}).")

    # --- phase 2: launch + liveness -------------------------------------------------------
    s = runner(["bash", "./" + smoke_sh.name, bundle_id], scripts_dir)
    combined = s.stdout + "\n" + s.stderr
    launched = s.returncode == 0 and "PASS:" in s.stdout
    launch = StepResult(name="launch", ran=True, ok=launched,
                        returncode=s.returncode, output=_tail(combined))
    if s.returncode == _TOOLCHAIN_MISSING:
        return SmokeReport(passed=False, status="unavailable", steps=[build, launch],
                           summary="xcrun/simulator not available (macOS-only) - launch skipped.")
    if launched:
        return SmokeReport(passed=True, status="pass", steps=[build, launch],
                           summary=f"{bundle_id} built, launched, and is running.")
    return SmokeReport(passed=False, status="launch-failed", steps=[build, launch],
                       crash_log=_crash_log(combined),
                       summary=f"{bundle_id} did not stay up after launch.")
