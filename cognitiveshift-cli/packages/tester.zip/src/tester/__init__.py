"""iOS build tester — compile + launch in the simulator, gate on a clean smoke test.

Deterministic runner (`smoke_test`) wraps the real macOS build/launch shell scripts; the
`TesterAgent` adds the agent-core contract plus an LLM crash-diagnosis layer on failure.

`TesterAgent` is imported lazily (PEP 562) so the deterministic CLI (`python -m tester`) and the
`smoke_test` core stay dependency-light — they need only pydantic, not agent-core.
"""

from tester.models import Diagnosis, SmokeReport, StepResult
from tester.runner import CommandResult, smoke_test, subprocess_runner

__all__ = [
    "TesterAgent", "SmokeReport", "StepResult", "Diagnosis",
    "smoke_test", "subprocess_runner", "CommandResult",
]


def __getattr__(name: str):
    if name == "TesterAgent":               # pulls in agent-core only when actually used
        from tester.agent import TesterAgent
        return TesterAgent
    raise AttributeError(f"module 'tester' has no attribute {name!r}")
