"""CLI: run the deterministic smoke test (no LLM) and print the report.

    python -m tester [APP_DIR] [SCHEME] [BUNDLE_ID]
    tester-smoke     [APP_DIR] [SCHEME] [BUNDLE_ID]

Exit code mirrors the gate: 0 = pass, 1 = build/launch failure, 2 = unavailable/error.
The LLM crash-diagnosis layer lives in `TesterAgent`; this CLI is the deterministic core only.
"""

from __future__ import annotations

import argparse
import json
import sys

from tester.runner import (
    DEFAULT_APP_DIR,
    DEFAULT_BUNDLE_ID,
    DEFAULT_SCHEME,
    smoke_test,
)

_EXIT = {"pass": 0, "build-failed": 1, "launch-failed": 1, "unavailable": 2, "error": 2}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="tester", description="iOS simulator smoke test.")
    ap.add_argument("app_dir", nargs="?", default=DEFAULT_APP_DIR)
    ap.add_argument("scheme", nargs="?", default=DEFAULT_SCHEME)
    ap.add_argument("bundle_id", nargs="?", default=DEFAULT_BUNDLE_ID)
    ap.add_argument("--json", action="store_true", help="emit the full report as JSON")
    args = ap.parse_args(argv)

    report = smoke_test(args.app_dir, args.scheme, args.bundle_id)
    if args.json:
        print(json.dumps(report.model_dump(), indent=2))
    else:
        print(f"{report.status.upper()}: {report.summary}")
        if report.crash_log:
            print(f"crash log: {report.crash_log}")
    return _EXIT.get(report.status, 2)


if __name__ == "__main__":
    sys.exit(main())
