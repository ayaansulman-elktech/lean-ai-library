"""Tester report schema.

The smoke test has three phases — build, launch, liveness assertion — collapsed into one
overall gate. `SmokeReport.passes()` is what the pipeline blocks on. `status` explains *why*
a run did not pass so the caller can tell "the app is broken" apart from "can't run here"
(no Xcode toolchain), which are very different signals.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

# pass          -> built, launched, and still running after the liveness check
# build-failed  -> xcodebuild returned non-zero
# launch-failed -> built, but crashed/didn't stay up on launch (see crash_log)
# unavailable   -> toolchain missing (not macOS / no xcodebuild|xcrun) — inconclusive, not a fail
# error         -> the runner itself errored (bad paths, script missing)
Status = Literal["pass", "build-failed", "launch-failed", "unavailable", "error"]


class StepResult(BaseModel):
    name: str                       # "build" | "launch"
    ran: bool = False
    ok: bool = False
    returncode: int = 0
    output: str = ""                # tail of stdout+stderr, trimmed for the report


class Diagnosis(BaseModel):
    """LLM-produced explanation of a failed run (only requested on failure)."""

    likely_cause: str = ""
    fix: str = ""
    summary: str = ""


class SmokeReport(BaseModel):
    passed: bool
    status: Status
    steps: list[StepResult] = []
    crash_log: str | None = None
    diagnosis: Diagnosis | None = None
    summary: str = ""

    def passes(self) -> bool:
        """Gate: only a clean build+launch+liveness passes. Anything else blocks."""
        return self.status == "pass" and self.passed
