"""TesterAgent — compile + launch an iOS app in the simulator, gate on a clean smoke test.

Deterministic core: `smoke_test()` builds the scheme, launches it in the simulator, and asserts
liveness (no LLM). If the run FAILS with build/log output, an LLM layer turns that output into a
short, actionable diagnosis (likely cause + fix). A passing run needs no LLM, so the happy path
costs nothing. `output["passes"]` is the gate. Runs under the agent-core contract (budget,
cost, tracking).
"""

from __future__ import annotations

from agent_core import Agent, AgentContext

from tester.models import Diagnosis, SmokeReport
from tester.runner import (
    DEFAULT_APP_DIR,
    DEFAULT_BUNDLE_ID,
    DEFAULT_SCHEME,
    CommandRunner,
    smoke_test,
    subprocess_runner,
)

SYSTEM = (
    "You are an iOS build/CI engineer. You are given the STATUS and the build/launch LOG of a "
    "failed simulator smoke test (xcodebuild + simctl) for a SwiftUI app. Diagnose it.\n"
    "- build-failed: read the compiler/linker errors and name the specific cause.\n"
    "- launch-failed: the app crashed or did not stay up; infer the likely runtime cause.\n"
    "Be concrete and short. Do not invent errors that aren't in the log.\n"
    'Return ONLY JSON: {"likely_cause": str, "fix": str, "summary": str}.'
)

# status values worth spending an LLM call to diagnose (a real failure with a log to read).
_DIAGNOSABLE = {"build-failed", "launch-failed"}


class TesterAgent(Agent):
    name = "tester"

    def __init__(self, ctx: AgentContext, *, model: str | None = None,
                 runner: CommandRunner = subprocess_runner) -> None:
        super().__init__(ctx)
        self.model = model
        self.runner = runner            # injectable so tests stub xcodebuild/xcrun

    def _run(self, app: dict | None = None) -> dict:
        app = app or {}
        report: SmokeReport = smoke_test(
            app.get("app_dir", DEFAULT_APP_DIR),
            app.get("scheme", DEFAULT_SCHEME),
            app.get("bundle_id", DEFAULT_BUNDLE_ID),
            runner=self.runner,
        )

        if report.status in _DIAGNOSABLE:
            log = "\n\n".join(f"[{s.name} exit {s.returncode}]\n{s.output}" for s in report.steps)
            user = (f"STATUS: {report.status}\n"
                    f"CRASH LOG: {report.crash_log or 'n/a'}\n\nLOG:\n{log}")
            diag = self.llm_json(system=SYSTEM, user=user, model=self.model, schema=Diagnosis)
            report.diagnosis = Diagnosis(**{k: diag.get(k, "") for k in
                                            ("likely_cause", "fix", "summary")})

        out = report.model_dump()
        out["passes"] = report.passes()
        self.ctx.tracker.log_metrics({"tester_pass": 1.0 if report.passes() else 0.0,
                                      "build_ok": 1.0 if any(s.name == "build" and s.ok
                                                             for s in report.steps) else 0.0})
        return out
