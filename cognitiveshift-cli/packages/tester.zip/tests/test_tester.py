"""Offline tests — a stub command runner stands in for xcodebuild/xcrun, so the orchestration,
parsing, gate, and LLM-diagnosis logic all run with no Mac and no API keys."""

from agent_core import AgentContext
from ml_core import CostMeter, ProvidersConfig, build_gateway
from ml_core.config import ModelSpec
from tester.agent import TesterAgent
from tester.models import SmokeReport
from tester.runner import CommandResult, smoke_test

DIAG = '{"likely_cause":"Missing symbol","fix":"Add the import","summary":"Link error."}'


def _ctx(responder):
    cfg = ProvidersConfig(gateway="mock",
                          models={"deepseek": ModelSpec(provider="deepseek", model="deepseek-chat")})
    meter = CostMeter(budget_usd=1.0)
    return AgentContext(gateway=build_gateway(cfg, meter, offline=True, responder=responder),
                        meter=meter, default_model="deepseek")


def _fake(*, build=0, build_out="", smoke_rc=0, smoke_out="PASS: launched"):
    """A CommandRunner that returns canned results for build.sh vs smoke.sh."""
    def run(cmd, cwd=None):
        script = " ".join(cmd)
        if "build.sh" in script:
            return CommandResult(build, build_out or "Build succeeded", "")
        return CommandResult(smoke_rc, smoke_out, "")
    return run


# --- deterministic runner (no LLM) --------------------------------------------------------

def test_clean_build_and_launch_passes():
    r = smoke_test(runner=_fake())
    assert r.status == "pass" and r.passes() is True
    assert [s.name for s in r.steps] == ["build", "launch"]
    assert all(s.ok for s in r.steps)


def test_build_failure_stops_before_launch():
    r = smoke_test(runner=_fake(build=65, build_out="error: cannot find 'Foo' in scope"))
    assert r.status == "build-failed" and r.passes() is False
    assert [s.name for s in r.steps] == ["build"]        # never attempted launch


def test_launch_crash_reports_crash_log():
    out = "FAIL: not running (check ~/Library/Logs/DiagnosticReports for App.crash)"
    r = smoke_test(runner=_fake(smoke_rc=1, smoke_out=out))
    assert r.status == "launch-failed" and r.passes() is False
    assert r.crash_log == "App.crash"


def test_missing_toolchain_is_unavailable_not_failure():
    r = smoke_test(runner=_fake(build=127))
    assert r.status == "unavailable" and r.passes() is False   # inconclusive, not "app broken"


def test_launch_nonzero_without_pass_marker_is_launch_failed():
    r = smoke_test(runner=_fake(smoke_rc=0, smoke_out="booting..."))  # rc 0 but no PASS:
    assert r.status == "launch-failed" and r.passes() is False


# --- agent layer (deterministic core + LLM diagnosis on failure) --------------------------

def test_agent_passes_without_spending_llm_on_success():
    ctx = _ctx(lambda a, m: DIAG)
    r = TesterAgent(ctx, runner=_fake()).run({})
    assert r.success and r.output["passes"] is True
    assert r.output["diagnosis"] is None
    assert ctx.meter.calls == 0                 # happy path never calls the model


def test_agent_diagnoses_a_build_failure():
    ctx = _ctx(lambda a, m: DIAG)
    r = TesterAgent(ctx, runner=_fake(build=65, build_out="error: use of unresolved identifier"))
    res = r.run({"scheme": "ColorMatching"})
    assert res.success                          # a failed build is a clean agent run, not a crash
    assert res.output["passes"] is False
    assert res.output["status"] == "build-failed"
    assert res.output["diagnosis"]["fix"] == "Add the import"
    assert ctx.meter.calls == 1


def test_report_gate_only_passes_on_clean_status():
    assert SmokeReport(passed=True, status="pass").passes() is True
    assert SmokeReport(passed=True, status="unavailable").passes() is False
    assert SmokeReport(passed=False, status="launch-failed").passes() is False
