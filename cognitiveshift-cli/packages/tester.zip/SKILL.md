---
name: tester
description: Smoke-test an iOS app build — compile, launch in the simulator, confirm the core screen renders without crash, and diagnose failures. Use at the end of a sprint day.
allowed-tools: Bash, Read
---
# Tester

Compiles an iOS app scheme, launches it in the simulator, and asserts it stays up (core screen
renders, no crash on launch). Scope = **compile + launch + one liveness assertion**, not full UI
automation. The gate is a clean `pass`; a build/launch failure is reported with the log tail, the
crash-log path, and an LLM-written diagnosis (likely cause + fix).

## Layers
- `src/tester/runner.py` — deterministic `smoke_test(app_dir, scheme, bundle_id)`. Orchestrates the
  two shell scripts, parses the result, and returns a structured `SmokeReport`. No LLM. The command
  runner is injectable, so the logic is unit-tested offline (no Mac) in CI.
- `src/tester/agent.py` — `TesterAgent` on the agent-core contract (budget, cost, tracking). Runs
  the smoke test; on a **build-failed / launch-failed** result it asks the model for a short
  diagnosis. A passing run spends no tokens.
- `scripts/build.sh` / `scripts/smoke.sh` — the real macOS `xcodebuild` + `simctl` capability.

## Run it
```
python -m tester [APP_DIR] [SCHEME] [BUNDLE_ID]     # deterministic core, prints status
python -m tester --json                              # full SmokeReport as JSON
```
Exit code: `0` pass · `1` build/launch failure · `2` unavailable (not macOS / no Xcode) or error.

`status` separates a broken app (`build-failed` / `launch-failed`) from "can't run here"
(`unavailable`), so off-macOS runs are inconclusive rather than false failures.
