# Tester notes

Scope = compile + launch + one assertion (core screen renders, no crash on launch).

- `runner.smoke_test()`: deterministic orchestration + parsing; returns a `SmokeReport`
  (`status` ∈ pass | build-failed | launch-failed | unavailable | error). The command runner is
  injectable, so build/launch/parse/gate logic is unit-tested offline (no Mac) in CI.
- `TesterAgent`: runs the smoke test under the agent-core contract; on failure, adds an LLM
  diagnosis (likely cause + fix). Passing runs spend no tokens.
- `scripts/build.sh`: `xcodebuild` for the app scheme (macOS).
- `scripts/smoke.sh`: boot a simulator, install, launch, assert the core screen, capture crash log.

The `unavailable` status keeps off-macOS CI (Linux/Windows) inconclusive rather than a false fail —
the offline test suite exercises every path via a stubbed command runner.

Full UI automation comes in a later step (deck Step 3+).
