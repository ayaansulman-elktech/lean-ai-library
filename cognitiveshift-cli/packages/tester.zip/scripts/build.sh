#!/usr/bin/env bash
# build.sh - compile the app scheme with xcodebuild (macOS-only).
# Usage: ./build.sh [APP_DIR] [SCHEME]
set -euo pipefail

APP_DIR="${1:-../../../apps/color-matching}"
SCHEME="${2:-ColorMatching}"
DEST="${DEST:-platform=iOS Simulator,name=iPhone 15}"

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "xcodebuild not found - this step runs on macOS only." >&2
  exit 127
fi

cd "$APP_DIR"
xcodebuild \
  -scheme "$SCHEME" \
  -destination "$DEST" \
  -configuration Debug \
  build | tail -20
