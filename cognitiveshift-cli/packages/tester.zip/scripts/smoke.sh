#!/usr/bin/env bash
# smoke.sh - boot a simulator, install the app, launch it, assert it did not crash.
# Beta scope: compile + launch + one liveness check. Usage: ./smoke.sh [BUNDLE_ID]
set -euo pipefail

BUNDLE_ID="${1:-co.elktech.colormatching}"
DEVICE="${DEVICE:-iPhone 15}"

if ! command -v xcrun >/dev/null 2>&1; then
  echo "xcrun not found - this step runs on macOS only." >&2
  exit 127
fi

echo "Booting $DEVICE ..."
xcrun simctl boot "$DEVICE" 2>/dev/null || true
xcrun simctl bootstatus "$DEVICE" -b

# Expect build.sh to have produced a .app; locate the newest one.
APP_PATH="$(find "${DERIVED:-$HOME/Library/Developer/Xcode/DerivedData}" -name '*.app' -path '*Debug-iphonesimulator*' 2>/dev/null | head -1 || true)"
if [ -z "$APP_PATH" ]; then
  echo "No built .app found - run build.sh first." >&2
  exit 1
fi

xcrun simctl install "$DEVICE" "$APP_PATH"
xcrun simctl launch "$DEVICE" "$BUNDLE_ID"
sleep 3

# Liveness: the process should still be running (did not crash on launch).
if xcrun simctl spawn "$DEVICE" launchctl list | grep -q "$BUNDLE_ID"; then
  echo "PASS: $BUNDLE_ID launched and is running."
  exit 0
else
  echo "FAIL: $BUNDLE_ID not running after launch (check crash logs in ~/Library/Logs/DiagnosticReports)." >&2
  exit 1
fi
