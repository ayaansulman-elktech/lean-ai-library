import json
import re

from agent_core import AgentContext
from microcopy import MicrocopyAgent, check_copy
from ml_core import CostMeter, ProvidersConfig, build_gateway
from ml_core.config import ModelSpec


def _screen_from(messages) -> dict:
    m = re.search(r"SCREEN:\n(\{.*?\})\n\n", messages[-1]["content"], re.S)
    return json.loads(m.group(1))


def _good_copy(screen: dict) -> dict:
    return {
        "screen_id": screen["id"],
        "title": (screen.get("title") or screen["id"])[:38],
        "elements": {e: f"{e} shown here" for e in screen.get("elements", [])},
        "actions": {a: a.capitalize()[:20] for a in screen.get("actions", [])},
        "links": {lk["to"]: lk["label"][:20] for lk in screen.get("links", [])},
    }


def _good_responder(alias, messages):
    return json.dumps(_good_copy(_screen_from(messages)))


def _flaky_responder():
    """First reply has an over-long button label; second is clean."""
    calls = {"n": 0}

    def r(alias, messages):
        calls["n"] += 1
        screen = _screen_from(messages)
        copy = _good_copy(screen)
        if calls["n"] == 1 and copy["actions"]:
            k = next(iter(copy["actions"]))
            copy["actions"][k] = "Tap here to begin the full analysis now"   # > 22 chars
        return json.dumps(copy)

    return r


def _ctx(responder):
    cfg = ProvidersConfig(gateway="mock",
                          models={"deepseek": ModelSpec(provider="deepseek", model="deepseek-chat")})
    meter = CostMeter(budget_usd=2.0)
    return AgentContext(gateway=build_gateway(cfg, meter, offline=True, responder=responder),
                        meter=meter, default_model="deepseek")


CAPTURE = {"id": "capture", "title": "Take a selfie", "elements": ["Camera frame"],
           "links": [{"label": "See result", "to": "result"}], "actions": ["capture"]}


def test_check_copy_flags_problems():
    assert check_copy({"title": "Ok", "actions": {}, "elements": {}}, {"elements": []}) == []
    assert any("too long" in i for i in
               check_copy({"title": "x" * 50, "actions": {}}, {"elements": []}))
    assert any("trailing period" in i for i in
               check_copy({"title": "Hi", "actions": {"go": "Start."}}, {"elements": []}))
    assert any("ALL CAPS" in i for i in
               check_copy({"title": "Hi", "actions": {"go": "START NOW"}}, {"elements": []}))
    assert any("missing copy" in i for i in
               check_copy({"title": "Hi", "elements": {}}, {"elements": ["Headline"]}))


def test_generates_copy_for_a_screen():
    r = MicrocopyAgent(_ctx(_good_responder)).run({"spec": {"screens": [CAPTURE]}, "persona": "Zoe, 28"})
    assert r.success and r.output["all_passed"]
    copy = r.output["copy"]["capture"]
    assert copy["title"] and copy["actions"]["capture"] == "Capture"
    assert copy["elements"]["Camera frame"]


def test_multi_screen_copy_map():
    spec = {"screens": [CAPTURE, {"id": "paywall", "actions": ["subscribe"]}]}
    r = MicrocopyAgent(_ctx(_good_responder)).run({"spec": spec})
    assert set(r.output["copy"]) == {"capture", "paywall"}


def test_bad_copy_is_corrected_on_retry():
    ctx = _ctx(_flaky_responder())
    r = MicrocopyAgent(ctx).run({"spec": {"screens": [CAPTURE]}})
    assert r.output["screens"][0]["passed"]        # over-long label fixed on retry
    assert ctx.meter.calls == 2


def test_unfixable_copy_reported_failed():
    def always_long(alias, messages):
        screen = _screen_from(messages)
        copy = _good_copy(screen)
        copy["actions"]["capture"] = "Tap here to begin the full analysis now"
        return json.dumps(copy)

    r = MicrocopyAgent(_ctx(always_long)).run({"spec": {"screens": [CAPTURE]}})
    f = r.output["screens"][0]
    assert not f["passed"] and any("too long" in i for i in f["issues"])
