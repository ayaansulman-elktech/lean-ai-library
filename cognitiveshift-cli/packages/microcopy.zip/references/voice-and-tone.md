# Voice & tone (Apple HIG writing)

The rules the microcopy agent follows. Copy should feel like the system wrote it, not marketing.

## Principles
- **Short and human.** Say the least that's clear. Cut filler ("simply", "just", "easily").
- **Benefit-led.** Tell the user what they get, not what the app does.
- **Speak to the persona.** Match their words and context; no jargon.
- **Sentence case** for content (titles, body). **Title Case** for buttons.
- **No shouting.** Never ALL CAPS; no exclamation-mark spam.

## Slot rules
| Slot | Rule |
|---|---|
| Title | ≤ 40 chars; one clear idea; sentence case |
| Body / element | one benefit or instruction; concrete, not abstract |
| Button | 1–4 words, ≤ 22 chars, **no trailing period**, action verb ("Take a selfie", "Continue") |
| Link | short, scannable; the destination's value ("See your palette") |
| Empty state | reassure + one next step |
| Paywall | value first, price second; honest, no dark patterns |

## Examples
- ✅ "Take a selfie" · ❌ "CLICK HERE TO START THE ANALYSIS NOW!"
- ✅ "Your season is Autumn" · ❌ "We have successfully computed your seasonal palette result."
- ✅ "See your palette" · ❌ "Proceed"
