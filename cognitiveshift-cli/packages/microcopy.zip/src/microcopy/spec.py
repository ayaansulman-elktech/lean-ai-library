"""Microcopy contracts: the per-screen copy schema + the style limits the checker enforces."""

from __future__ import annotations

from pydantic import BaseModel

# Style limits (Apple HIG writing: short, human, benefit-led).
TITLE_MAX = 40      # characters
BUTTON_MAX = 22     # characters — button labels are 1-4 words


class ScreenCopy(BaseModel):
    screen_id: str
    title: str = ""
    elements: dict[str, str] = {}   # wireframe element label -> real copy
    actions: dict[str, str] = {}    # action id -> button label
    links: dict[str, str] = {}      # link target id -> link label
