"""Deterministic checks on generated copy — enforce the HIG writing rules with no LLM, so the
non-deterministic writer can't slip through an over-long or shouty label."""

from __future__ import annotations

from microcopy.spec import BUTTON_MAX, TITLE_MAX


def check_copy(copy: dict, screen: dict) -> list[str]:
    """Return a list of issue strings (empty = passes)."""
    issues: list[str] = []

    title = copy.get("title", "")
    if not title.strip():
        issues.append("empty title")
    elif len(title) > TITLE_MAX:
        issues.append(f"title too long ({len(title)}>{TITLE_MAX})")

    for aid, label in (copy.get("actions") or {}).items():
        if not label.strip():
            issues.append(f"empty label for action '{aid}'")
        elif len(label) > BUTTON_MAX:
            issues.append(f"button '{aid}' label too long ({len(label)}>{BUTTON_MAX})")
        elif label.rstrip().endswith("."):
            issues.append(f"button '{aid}' label has a trailing period")
        elif label.isupper() and len(label) > 3:
            issues.append(f"button '{aid}' label is ALL CAPS")

    for name in screen.get("elements", []):
        if not (copy.get("elements") or {}).get(name, "").strip():
            issues.append(f"missing copy for element '{name}'")

    return issues
