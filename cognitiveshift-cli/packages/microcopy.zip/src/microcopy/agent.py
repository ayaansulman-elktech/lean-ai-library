"""MicrocopyAgent — write Apple-HIG microcopy for each wireframe screen.

Step 4 of the design-automation pipeline (deck p.60): given the wireframe slots + the persona
voice, write concise, benefit-led copy for each title / element / button / link. Generation is
per screen; a deterministic checker enforces the HIG length/style rules and re-asks once on
failure. Output feeds swiftui-gen (the `copy` map, injected into the generated views).
"""

from __future__ import annotations

import json

from agent_core import Agent, AgentContext

from microcopy.checks import check_copy
from microcopy.spec import ScreenCopy

SYSTEM = (
    "You write Apple-HIG microcopy for ONE iOS screen. Given the screen's wireframe slots and the "
    "persona/voice, write concise, benefit-led copy for each slot.\n"
    "Rules: short and human; sentence case for content, Title Case for buttons; no jargon or "
    "marketing fluff; button labels 1-4 words with NO trailing period; title <= 40 chars; speak "
    "to the persona.\n"
    'Return ONLY JSON: {"screen_id": "<id>", "title": "<text>", "elements": {"<label>": "<text>"}, '
    '"actions": {"<id>": "<button label>"}, "links": {"<to>": "<link label>"}}.'
)


class MicrocopyAgent(Agent):
    name = "microcopy"

    def __init__(self, ctx: AgentContext, *, model: str | None = None,
                 max_fix_attempts: int = 2) -> None:
        super().__init__(ctx)
        self.model = model
        self.max_fix_attempts = max_fix_attempts

    def _run(self, task: dict) -> dict:
        # task = {"spec": WireframeSpec-dict (or wireframing output), "persona": str,
        #         "voice": str, "app": str}
        spec = task.get("spec", task)
        screens = spec.get("screens", [])
        persona = task.get("persona", "")
        voice = task.get("voice", "")
        app = task.get("app", "App")

        results = [self._gen(s, persona, voice) for s in screens]
        all_passed = bool(results) and all(r["passed"] for r in results)
        copy = {r["screen_id"]: r["copy"] for r in results}
        self.ctx.tracker.log_metrics({"screens": len(results),
                                      "screens_passed": sum(r["passed"] for r in results)})
        return {"app": app, "screens": results, "copy": copy, "all_passed": all_passed}

    def _gen(self, screen: dict, persona: str, voice: str) -> dict:
        base_user = (
            f"SCREEN:\n{json.dumps(screen, indent=2)}\n\n"
            f"SCREEN ID: {screen.get('id')}\n"
            f"PERSONA: {persona or '(unspecified)'}\n"
            f"VOICE: {voice or 'warm, clear, confident'}\n"
        )
        user, issues, copy = base_user, [], None
        for _ in range(self.max_fix_attempts):
            copy = self.llm_json(system=SYSTEM, user=user, model=self.model, schema=ScreenCopy)
            issues = check_copy(copy, screen)
            if not issues:
                break
            user = base_user + ("\nThe previous copy FAILED these checks; fix them and return the "
                                "corrected copy:\n- " + "\n- ".join(issues))
        return {"screen_id": screen.get("id"), "copy": copy, "passed": not issues, "issues": issues}
