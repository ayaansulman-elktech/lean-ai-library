"""microcopy — Apple-HIG UI copy per wireframe screen, feeding swiftui-gen."""

from __future__ import annotations

from microcopy.agent import MicrocopyAgent
from microcopy.checks import check_copy
from microcopy.spec import BUTTON_MAX, TITLE_MAX, ScreenCopy

__all__ = ["MicrocopyAgent", "check_copy", "ScreenCopy", "BUTTON_MAX", "TITLE_MAX"]
