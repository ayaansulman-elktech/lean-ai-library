"""Color matching — two independent approaches, seasonal first.

1. SEASONAL (primary): classify a color's undertone + value into a season (Spring / Summer /
   Autumn / Winter) and return the season's recommended palette + colors to avoid. This is the
   Color-Matching app's core (skin tone -> "your colors"); see
   `libraries/knowledge/color-theory/color-theory.md` and `../../knowledge/color-theory/seasons.md`.

2. HARMONIES (secondary): classic color-wheel schemes off a base color (complementary, analogous,
   triadic, split-complementary, tetradic, monochromatic).

Pure Python (stdlib `colorsys`), no dependencies.

CLI:  python color_matching.py "#0E1B2A"   ->   {seasonal, harmonies}
"""

from __future__ import annotations

import colorsys


# ============================================================ hex <-> rgb / hls
def to_rgb(hex_color: str) -> tuple[int, int, int]:
    h = hex_color.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def to_hex(rgb) -> str:
    return "#{:02X}{:02X}{:02X}".format(*tuple(max(0, min(255, round(c))) for c in rgb))


def _hls(hex_color: str) -> tuple[float, float, float]:
    r, g, b = (c / 255 for c in to_rgb(hex_color))
    return colorsys.rgb_to_hls(r, g, b)   # (hue 0..1, lightness 0..1, saturation 0..1)


# ============================================================ 1. SEASONAL (primary)
# The palette is COMPUTED, not looked up (per color-rules.md: "computed by rule, not hand-picked"):
# harmonic hues off the person's own color, rendered into the season's saturation/lightness band.
SEASON_FEEL = {"Spring": "bright, warm, clear", "Summer": "soft, cool, muted",
               "Autumn": "deep, warm, earthy", "Winter": "bright, cool, saturated"}
# Each season's target (saturation, lightness) band — the "feel" as measurable color properties.
SEASON_BAND = {"Spring": (0.78, 0.62), "Summer": (0.32, 0.70),
               "Autumn": (0.60, 0.40), "Winter": (0.85, 0.52)}
# What clashes = the season across BOTH axes (undertone-flip + value-flip).
_OPPOSITE = {"Spring": "Winter", "Winter": "Spring", "Summer": "Autumn", "Autumn": "Summer"}
# Harmonic hue offsets (deg) off the base: itself, analogous ±30, complementary 180, triadic ±120.
_HARMONIC_OFFSETS = (0, 30, -30, 180, 120, -120)


def undertone(hex_color: str) -> str:
    """Warm (reds/oranges/yellows) vs cool (greens/blues/purples), by hue."""
    deg = _hls(hex_color)[0] * 360
    return "warm" if (deg <= 70 or deg >= 330) else "cool"


def value_level(hex_color: str) -> str:
    lightness = _hls(hex_color)[1]
    return "light" if lightness >= 0.5 else ("deep" if lightness < 0.3 else "medium")


def chroma_level(hex_color: str) -> str:
    sat = _hls(hex_color)[2]
    return "bright" if sat >= 0.5 else ("muted" if sat < 0.3 else "medium")


def season_of(hex_color: str) -> str:
    """Undertone × value → season (the two axes from seasons.md)."""
    warm = undertone(hex_color) == "warm"
    light = _hls(hex_color)[1] >= 0.5
    if warm:
        return "Spring" if light else "Autumn"
    return "Summer" if light else "Winter"


def _render(hue_turns: float, sat: float, light: float) -> str:
    return to_hex([c * 255 for c in colorsys.hls_to_rgb(hue_turns % 1.0, light, sat)])


def _neutral(season: str) -> str:
    """A season-appropriate neutral (color-theory step: add neutrals)."""
    warm = season in ("Spring", "Autumn")
    hue = 0.09 if warm else 0.60                       # warm beige vs cool slate
    light = 0.90 if season in ("Spring", "Summer") else 0.35
    return _render(hue, 0.12, light)


def seasonal_palette(hex_color: str) -> list[str]:
    """Compute the recommended palette: harmonic hues off the input, rendered into the season's
    saturation/lightness band, plus a rule-based neutral (+ contrast anchors for Winter)."""
    season = season_of(hex_color)
    sat, light = SEASON_BAND[season]
    base_hue = _hls(hex_color)[0]
    colors = [_render(base_hue + off / 360.0, sat, light) for off in _HARMONIC_OFFSETS]
    colors.append(_neutral(season))
    if season == "Winter":                             # winter = high contrast
        colors += ["#0B0B0F", "#FAFAFC"]
    seen, out = set(), []
    for c in colors:                                   # dedupe, keep order
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out


def seasonal_avoid(hex_color: str) -> list[str]:
    """Colors that clash = harmonic hues rendered into the OPPOSITE season's band."""
    sat, light = SEASON_BAND[_OPPOSITE[season_of(hex_color)]]
    base_hue = _hls(hex_color)[0]
    return [_render(base_hue + off / 360.0, sat, light) for off in (0, 180, 120)]


def seasonal_match(hex_color: str) -> dict:
    """Primary matcher: a color -> its season + a COMPUTED palette + colors to avoid."""
    season = season_of(hex_color)
    return {"input": to_hex(to_rgb(hex_color)), "season": season,
            "undertone": undertone(hex_color), "value": value_level(hex_color),
            "chroma": chroma_level(hex_color), "feel": SEASON_FEEL[season],
            "palette": seasonal_palette(hex_color), "avoid": seasonal_avoid(hex_color)}


def seasonal_match_from_colors(colors) -> dict:
    """Season from extracted colors — pass the skin/dominant tone first. Accepts hex strings or
    the color_extraction dicts ({'hex': ...})."""
    if not colors:
        raise ValueError("no colors to match")
    first = colors[0]
    hex_color = first["hex"] if isinstance(first, dict) else first
    return seasonal_match(hex_color)


# ============================================================ 2. HARMONIES (secondary)
def _rotate_hue(hex_color: str, degrees: float) -> str:
    h, lit, s = _hls(hex_color)
    h = (h + degrees / 360.0) % 1.0
    return to_hex([c * 255 for c in colorsys.hls_to_rgb(h, lit, s)])


def _shift_lightness(hex_color: str, delta: float) -> str:
    h, lit, s = _hls(hex_color)
    lit = max(0.0, min(1.0, lit + delta))
    return to_hex([c * 255 for c in colorsys.hls_to_rgb(h, lit, s)])


def complementary(hex_color: str) -> list[str]:
    return [hex_color, _rotate_hue(hex_color, 180)]


def analogous(hex_color: str) -> list[str]:
    return [_rotate_hue(hex_color, -30), hex_color, _rotate_hue(hex_color, 30)]


def triadic(hex_color: str) -> list[str]:
    return [hex_color, _rotate_hue(hex_color, 120), _rotate_hue(hex_color, 240)]


def split_complementary(hex_color: str) -> list[str]:
    return [hex_color, _rotate_hue(hex_color, 150), _rotate_hue(hex_color, 210)]


def tetradic(hex_color: str) -> list[str]:
    return [hex_color, _rotate_hue(hex_color, 90),
            _rotate_hue(hex_color, 180), _rotate_hue(hex_color, 270)]


def monochromatic(hex_color: str, k: int = 5) -> list[str]:
    return [_shift_lightness(hex_color, d) for d in (-0.30, -0.15, 0.0, 0.15, 0.30)][:k]


SCHEMES = {
    "complementary": complementary, "analogous": analogous, "triadic": triadic,
    "split_complementary": split_complementary, "tetradic": tetradic, "monochromatic": monochromatic,
}


def harmonies(hex_color: str) -> dict[str, list[str]]:
    """Every color-wheel harmony scheme -> its list of hex colors."""
    return {name: fn(hex_color) for name, fn in SCHEMES.items()}


# ============================================================ combined (seasonal on top)
def match(hex_color: str) -> dict:
    """Both approaches, seasonal first."""
    return {"seasonal": seasonal_match(hex_color), "harmonies": harmonies(hex_color)}


def _main(argv: list[str]) -> int:
    import json
    if not argv:
        print('usage: color_matching.py "#RRGGBB"')
        return 2
    print(json.dumps(match(argv[0]), indent=2))
    return 0


if __name__ == "__main__":
    import sys
    raise SystemExit(_main(sys.argv[1:]))
