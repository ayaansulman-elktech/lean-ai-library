"""Color-matching block — the public seam.

`match(hex_color)` is the block's entry point (see `block.json` `entry`): given a base color it
returns the seasonal analysis (primary) plus the color-wheel harmonies (secondary). The individual
functions are re-exported for direct reuse.
"""

from __future__ import annotations

from blocks.color_matching.src.color_matching import (
    analogous,
    complementary,
    harmonies,
    match,
    monochromatic,
    season_of,
    seasonal_avoid,
    seasonal_match,
    seasonal_match_from_colors,
    seasonal_palette,
    split_complementary,
    tetradic,
    to_hex,
    to_rgb,
    triadic,
    undertone,
)

__all__ = [
    "match", "seasonal_match", "seasonal_match_from_colors", "season_of", "undertone",
    "seasonal_palette", "seasonal_avoid", "harmonies", "complementary", "analogous",
    "triadic", "split_complementary", "tetradic", "monochromatic", "to_hex", "to_rgb",
]
