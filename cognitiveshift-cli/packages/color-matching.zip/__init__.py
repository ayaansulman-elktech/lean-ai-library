"""Color-matching code block."""
