# Color matching

Two independent approaches, **seasonal first**.

**1. Seasonal (primary)** — classify a color's undertone + value into a **season**, then **compute**
a recommended palette + colors to avoid. This is the Color-Matching app's core (skin tone → "your
colors"). See `libraries/knowledge/color-theory/` (`color-theory.md`, `seasons.md`).

```python
from color_matching import seasonal_match, seasonal_match_from_colors

seasonal_match("#FF6600")          # {season:"Spring", undertone, value, chroma, feel, palette[], avoid[]}
seasonal_match_from_colors(extracted)   # pass color_extraction output; uses the dominant/skin tone
```
- **Classify** by undertone × value (from `seasons.md`): warm+light → **Spring**, warm+deep →
  **Autumn**, cool+light → **Summer**, cool+deep → **Winter**.
- **Compute the palette by rule** (per `color-rules.md` "computed, not hand-picked"): take harmonic
  hues off the person's own color (base + analogous + complementary + triadic) and render each into
  the **season's saturation/lightness band** (Spring = bright+light, Autumn = deep+muted, …), add a
  rule-based neutral (+ black/white contrast for Winter). `avoid` = the same hues in the **opposite**
  season's band. So the palette **varies per person** — it's not a static table.

**2. Harmonies (secondary)** — classic color-wheel schemes off a base color.

```python
from color_matching import harmonies, complementary, triadic
harmonies("#0E1B2A")               # complementary / analogous / triadic / split / tetradic / mono
complementary("#FF0000")           # -> ["#FF0000", "#00FFFF"]
```

`match(hex)` returns **both**, seasonal on top. Pure Python (stdlib `colorsys`), no dependencies.
CLI: `python color_matching.py "#FF6600"`. Visual test: `../color-test-ui/index.html`.
