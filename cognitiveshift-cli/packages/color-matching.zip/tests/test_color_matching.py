import colorsys

from blocks.color_matching.src.color_matching import (
    analogous,
    complementary,
    harmonies,
    match,
    monochromatic,
    season_of,
    seasonal_avoid,
    seasonal_match,
    seasonal_match_from_colors,
    seasonal_palette,
    tetradic,
    to_hex,
    to_rgb,
    triadic,
    undertone,
)


def _lightness(hex_):
    r, g, b = (c / 255 for c in to_rgb(hex_))
    return colorsys.rgb_to_hls(r, g, b)[1]


# ---- seasonal (primary) -------------------------------------------------------------------
def test_undertone_warm_vs_cool():
    assert undertone("#FF6600") == "warm"    # orange
    assert undertone("#FFD34E") == "warm"    # yellow
    assert undertone("#0033A0") == "cool"    # blue
    assert undertone("#009B77") == "cool"    # green


def test_season_from_undertone_and_value():
    assert season_of("#FF6600") == "Spring"   # warm + light
    assert season_of("#808000") == "Autumn"   # warm + deep (olive)
    assert season_of("#A7C7E7") == "Summer"   # cool + light (powder blue)
    assert season_of("#0033A0") == "Winter"   # cool + deep (royal blue)


def test_seasonal_match_returns_palette_and_avoid():
    m = seasonal_match("#FF6600")
    assert m["season"] == "Spring"
    assert m["undertone"] == "warm"
    assert len(m["palette"]) >= 6 and all(c.startswith("#") and len(c) == 7 for c in m["palette"])
    assert m["avoid"]
    assert m["feel"]


def test_palette_is_computed_from_the_season_band():
    # Spring (light band) palettes read lighter than Autumn (deep band) palettes.
    spring = [c for c in seasonal_palette("#FF6600")]      # warm + light
    autumn = [c for c in seasonal_palette("#808000")]      # warm + deep
    def avg(cs):
        return sum(_lightness(c) for c in cs) / len(cs)
    assert avg(spring) > avg(autumn)


def test_palette_varies_with_the_input_hue():
    # two different Spring-classified hues -> different computed palettes (not a static table)
    a = seasonal_palette("#FF6600")   # orange, Spring
    b = seasonal_palette("#FFD34E")   # light warm yellow, also light+warm -> Spring
    assert season_of("#FF6600") == season_of("#FFD34E") == "Spring"
    assert a != b


def test_avoid_uses_the_opposite_season_band():
    # Spring's avoid comes from the Winter band (deep) -> darker than the Spring palette.
    avoid = seasonal_avoid("#FF6600")
    assert avoid and all(c.startswith("#") for c in avoid)
    assert sum(_lightness(c) for c in avoid) / len(avoid) < 0.6


def test_winter_palette_has_contrast_anchors():
    pal = seasonal_palette("#0033A0")   # cool + deep -> Winter
    assert "#0B0B0F" in pal and "#FAFAFC" in pal


def test_seasonal_match_from_extracted_colors():
    # accepts color_extraction dicts; uses the first (dominant/skin) tone
    extracted = [{"hex": "#0033A0", "percentage": 60.0}, {"hex": "#FFFFFF", "percentage": 40.0}]
    assert seasonal_match_from_colors(extracted)["season"] == "Winter"
    assert seasonal_match_from_colors(["#FF6600"])["season"] == "Spring"


# ---- harmonies (secondary) ----------------------------------------------------------------
def test_hex_rgb_roundtrip():
    assert to_rgb("#0E1B2A") == (14, 27, 42)
    assert to_hex((14, 27, 42)) == "#0E1B2A"
    assert to_rgb("#fff") == (255, 255, 255)


def test_complementary_is_opposite_hue():
    assert complementary("#FF0000")[1] == "#00FFFF"
    assert complementary("#00FF00")[1] == "#FF00FF"
    assert complementary("#0000FF")[1] == "#FFFF00"


def test_scheme_sizes_and_base_included():
    assert len(analogous("#0E1B2A")) == 3
    assert len(triadic("#0E1B2A")) == 3 and triadic("#0E1B2A")[0] == "#0E1B2A"
    assert len(tetradic("#0E1B2A")) == 4
    assert len(monochromatic("#0E1B2A")) == 5


def test_triadic_rotates_120_degrees():
    assert triadic("#FF0000") == ["#FF0000", "#00FF00", "#0000FF"]


def test_harmonies_returns_every_scheme():
    m = harmonies("#0E1B2A")
    assert set(m) == {"complementary", "analogous", "triadic",
                      "split_complementary", "tetradic", "monochromatic"}
    assert all(c.startswith("#") and len(c) == 7 for scheme in m.values() for c in scheme)


# ---- combined (seasonal on top) -----------------------------------------------------------
def test_match_returns_both_seasonal_first():
    m = match("#FF6600")
    assert list(m) == ["seasonal", "harmonies"]     # seasonal on top
    assert m["seasonal"]["season"] == "Spring"
    assert "complementary" in m["harmonies"]
