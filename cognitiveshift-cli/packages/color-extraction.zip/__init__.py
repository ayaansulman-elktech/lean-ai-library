"""Color-extraction code block."""
