from blocks.color_extraction.src.color_extraction import extract_from_pixels


def test_percentages_and_ranking():
    # 3 red pixels, 1 blue -> two swatches, red dominant at 75%.
    pixels = [(255, 0, 0)] * 3 + [(0, 0, 255)] * 1
    out = extract_from_pixels(pixels, n=8)
    assert len(out) == 2
    assert out[0]["percentage"] == 75.0
    assert out[1]["percentage"] == 25.0
    assert sum(c["percentage"] for c in out) == 100.0


def test_near_identical_colors_are_grouped():
    # two nearly-equal reds fall in one bucket -> a single swatch.
    out = extract_from_pixels([(254, 1, 1), (255, 0, 2)], n=8)
    assert len(out) == 1
    assert out[0]["percentage"] == 100.0


def test_n_limits_returned_swatches():
    pixels = ([(255, 0, 0)] * 4 + [(0, 255, 0)] * 3 + [(0, 0, 255)] * 2 + [(255, 255, 0)] * 1)
    assert len(extract_from_pixels(pixels, n=2)) == 2      # only the top 2
    assert len(extract_from_pixels(pixels, n=None)) == 4   # all buckets


def test_empty_input():
    assert extract_from_pixels([]) == []


def test_hex_format():
    out = extract_from_pixels([(255, 0, 0)])
    assert out[0]["hex"].startswith("#") and len(out[0]["hex"]) == 7
