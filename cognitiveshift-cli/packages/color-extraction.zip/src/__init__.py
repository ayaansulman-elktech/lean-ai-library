"""Color-extraction block — the public seam.

`extract_colors(image_path)` is the block's entry point (see `block.json` `entry`): the dominant
colors of an image with coverage percentages. `extract_from_pixels` is the dependency-free core
(no Pillow) used by the tests and by callers that already hold pixels.
"""

from __future__ import annotations

from blocks.color_extraction.src.color_extraction import (
    extract_colors,
    extract_from_pixels,
)

__all__ = ["extract_colors", "extract_from_pixels"]
