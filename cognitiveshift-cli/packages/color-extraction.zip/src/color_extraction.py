"""Extract the dominant colors of an image with their coverage percentages.

Output: `[{"hex": "#RRGGBB", "percentage": <float>}, ...]`, sorted by coverage descending.

The pure-Python core (`extract_from_pixels`) is dependency-free and tested; `extract_colors()`
reads an image via Pillow (optional `[image]` extra: `pip install pillow`). Near-identical colors
are grouped by snapping each channel to a small grid, so the result is a handful of meaningful
swatches rather than thousands of near-duplicates.

CLI:  python color_extraction.py path/to/image.jpg [n]   ->   JSON of colors + percentages
"""

from __future__ import annotations

from collections import Counter


def _hex(rgb) -> str:
    return "#{:02X}{:02X}{:02X}".format(*tuple(int(c) for c in rgb))


def _quantize(rgb, levels: int) -> tuple[int, int, int]:
    """Snap each channel to `levels` buckets (grouping near-identical colors)."""
    step = max(1, 256 // levels)
    return tuple(min(255, (c // step) * step + step // 2) for c in rgb[:3])


def extract_from_pixels(pixels, n: int | None = 8, levels: int = 6) -> list[dict]:
    """Colors + percentages from a list of (r,g,b) pixels. `n=None` returns every bucket."""
    if not pixels:
        return []
    counts = Counter(_quantize(tuple(p), levels) for p in pixels)
    total = sum(counts.values())
    ranked = counts.most_common(n)   # most_common(None) returns all, sorted
    return [{"hex": _hex(rgb), "percentage": round(100 * c / total, 2)} for rgb, c in ranked]


def extract_colors(image_path, n: int | None = 8, levels: int = 6, resize: int = 200) -> list[dict]:
    """Dominant colors of an image file. Requires Pillow (`pip install pillow`)."""
    from PIL import Image  # optional dependency

    img = Image.open(image_path).convert("RGB")
    img.thumbnail((resize, resize))   # downsample for speed; ratios are preserved
    return extract_from_pixels(list(img.getdata()), n=n, levels=levels)


def _main(argv: list[str]) -> int:
    import json
    if not argv:
        print("usage: color_extraction.py image.jpg [n]")
        return 2
    n = int(argv[1]) if len(argv) > 1 else 8
    print(json.dumps(extract_colors(argv[0], n=n), indent=2))
    return 0


if __name__ == "__main__":
    import sys
    raise SystemExit(_main(sys.argv[1:]))
