# Color extraction

**What:** image → its dominant colors with coverage percentages.
**In / out:** `image_path` → `[{"hex": "#RRGGBB", "percentage": <float>}, …]` (sorted desc).
**First needed by:** Color Matching (Sprint 1) — the selfie's tones feed the palette match.

```python
from color_extraction import extract_colors, extract_from_pixels

extract_colors("selfie.jpg", n=8)          # top 8 colors + % (needs Pillow)
extract_from_pixels(pixels, n=8)           # pure-Python core (tested, no deps)
```

- Near-identical colors are grouped (channel quantization) → a few meaningful swatches, not
  thousands of near-duplicates. `n=None` returns every bucket.
- Pure-Python core is dependency-free and tested; `extract_colors()` needs **Pillow**
  (`pip install pillow`). CLI: `python color_extraction.py image.jpg [n]`.
- Visual test: `../color-test-ui/index.html`.
