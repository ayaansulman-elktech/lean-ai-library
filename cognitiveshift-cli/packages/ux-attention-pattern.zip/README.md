# ux-attention-pattern (code block)

Decides **which reading pattern an iOS screen follows — and whether it's healthy.** The attention
companion to `ux-position-mask` (geometry): this one uses the *attention* signal. Tuned for iOS
(narrow, vertical, component-driven), grounded in NN/g eye-tracking research + Apple HIG.

- **`audit_attention(path, backend="sum")`** — runs the screen through the attention modules
  (`vis_models.saliency`: real **SUM** on the farm, classical/mock offline) → attention map → classify.
- **`classify_pattern(values, width, height, cta=None)`** — the pure, stdlib rule core (the
  `entry`): reads the grid's row/column profiles and classifies the flow. If a `cta` point is given,
  a gutenberg/vertical screen is only fully *good* when attention reaches the CTA in the thumb zone.

## The iOS pattern set
| Pattern | Screen | Verdict |
|---|---|---|
| **vertical** | centered column of sections (layer-cake: nav title → cards → tab bar) | ✅ good |
| **gutenberg** | top anchor + bottom terminal CTA (onboarding / paywall / hero) | ✅ good |
| **focused** | one dominant hero/action | ✅ good |
| **f-skim** | top-left concentration on an unstructured text wall | ⚠️ warn — add sections/bold |
| **scattered** | no column, order, or terminal action | ❌ bad |

*Web F/Z collapse into vertical motion on phones: F → an f-skim, Z → a gutenberg top-to-bottom flow.*

**Output:** `{ pattern, level (good|ok|warn|bad), good, confidence, focal, dispersion, features, reasons }`.

**Depends on** `vis_models.saliency` (the SUM/ViNet attention modules). The rule core has no deps and
is always exercised in CI; the image layer runs offline via the mock. On real screens, the classical
fallback is diffuse — accurate attention needs the SUM weights on an iOS Ready host.
