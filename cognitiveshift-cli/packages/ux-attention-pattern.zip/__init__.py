"""UX attention-pattern code block (F/Z reading-flow audit)."""
