"""UX attention-pattern audit — which reading pattern (F / Z / other) a screen follows, and if it's good.

The image layer over `patterns.classify_pattern`: runs a screen through the attention modules
(`vis_models.saliency` — real SUM when its weights are on the box, else the classical pixel model,
else the deterministic mock) to get an attention grid, then classifies the reading flow.

    audit_attention(image_path, backend="sum", cta=None) -> classify_pattern result + {backend}

Depends on `vis_models.saliency` (the attention modules from Task-3/SUM + ViNet work).
"""

from __future__ import annotations

from blocks.ux_attention_pattern.src.patterns import classify_pattern


def audit_attention(image_path, backend: str = "sum", cta=None, *, offline: bool = False) -> dict:
    """Predict a screen's attention map and classify its reading pattern.

    backend: "sum" (real model when available, else classical) | "classical" | "mock".
    offline=True forces the deterministic mock (no pixels needed) — for demos/tests.
    cta: optional (x, y) of the primary action in [0,1].
    """
    from vis_models.saliency import build_saliency

    model = build_saliency(backend, offline=offline)
    smap = model.predict(image_path)
    result = classify_pattern(smap.values, smap.width, smap.height, cta=cta)
    result["backend"] = type(model).__name__
    return result
