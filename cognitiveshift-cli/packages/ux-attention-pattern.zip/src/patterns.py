"""Reading-pattern classifier for iOS app screens — pure stdlib, on an attention grid.

Given a saliency/attention grid (flat row-major values + width/height), decide which scanning
pattern an **iOS screen** follows and whether it's healthy. iOS screens are narrow and vertical, so
the web F/Z shapes collapse into vertical motion; we classify the patterns that actually occur on
phones (grounded in NN/g eye-tracking research + Apple HIG):

- **vertical**  — a centered column with several stacked bands (layer-cake: nav title → sections/
  cards → tab bar). The healthy default for lists/feeds. GOOD.
- **gutenberg** — a top anchor (title/visual) and a bottom terminal anchor (the primary action in
  the thumb zone), sparse middle — onboarding / paywall / hero / single-action screens. GOOD.
- **focused**   — one dominant focal point (a single hero/action). GOOD.
- **f-skim**    — top + left concentration (a text wall with no structure); on mobile the web
  F-pattern shows up as this lazy skim. WARN — add sections / bold / grouping.
- **scattered** — no clear column, order, or terminal action. BAD.

This is the LLM-free rule core (the block's `entry`). The image layer (`ux_attention_pattern.py`)
produces the grid from a screen via the attention modules (`vis_models.saliency`).
"""

from __future__ import annotations

_LEVEL = {"vertical": "good", "gutenberg": "good", "focused": "good",
          "spotted": "ok", "f-skim": "warn", "scattered": "bad", "none": "bad"}


def _profiles(values, W, H):
    total = sum(values) or 1.0
    row_p = [0.0] * H
    col_p = [0.0] * W
    for r in range(H):
        base = r * W
        for c in range(W):
            v = values[base + c] / total
            row_p[r] += v
            col_p[c] += v
    return row_p, col_p


def _seg(p, a, b):
    n = len(p)
    return sum(p[i] for i in range(int(a * n), max(int(a * n) + 1, int(b * n))))


def _bands(row_p):
    """Count distinct horizontal content bands (local maxima clearly above the mean)."""
    m = sum(row_p) / len(row_p) if row_p else 0.0
    cnt, n = 0, len(row_p)
    for i in range(n):
        if row_p[i] > 1.4 * m and (i == 0 or row_p[i] >= row_p[i - 1]) \
                and (i == n - 1 or row_p[i] > row_p[i + 1]):
            cnt += 1
    return cnt


def _stats(values, W, H):
    total = sum(values) or 1.0
    fx = fy = 0.0
    for r in range(H):
        for c in range(W):
            w = values[r * W + c] / total
            fx += w * (c + 0.5) / W
            fy += w * (r + 0.5) / H
    disp = 0.0
    for r in range(H):
        for c in range(W):
            w = values[r * W + c] / total
            dx = (c + 0.5) / W - fx
            dy = (r + 0.5) / H - fy
            disp += w * (dx * dx + dy * dy) ** 0.5
    return (fx, fy), disp


def classify_pattern(values, width: int, height: int, cta=None) -> dict:
    """Classify the attention grid's iOS reading pattern.

    values: flat row-major attention weights (>=0), length width*height.
    cta: optional (x, y) of the primary action in [0,1] — a gutenberg/vertical screen is only
         fully "good" when the terminal attention actually lands on the CTA (thumb zone).
    Returns {pattern, level (good|ok|warn|bad), good, confidence, focal, dispersion, features, reasons}.
    """
    if not values or width <= 0 or height <= 0:
        return _result("none", 0.0, None, 0.0, {}, ["no attention data"])

    vals = [max(0.0, v) for v in values]
    row_p, col_p = _profiles(vals, width, height)
    focal, disp = _stats(vals, width, height)

    top = _seg(row_p, 0.0, 0.20)
    bottom = _seg(row_p, 0.80, 1.0)
    mid = _seg(row_p, 0.34, 0.66)
    left = _seg(col_p, 0.0, 0.25)
    center = _seg(col_p, 0.28, 0.72)
    bands = _bands(row_p)
    row_peak = max(row_p) / (1.0 / height)      # 1 = uniform down the screen
    col_peak = max(col_p) / (1.0 / width)       # 1 = uniform across the screen
    feats = {"top": round(top, 2), "bottom": round(bottom, 2), "mid": round(mid, 2),
             "left": round(left, 2), "center": round(center, 2), "bands": bands}

    reasons: list[str] = []

    # 1) f-skim — top + left heavy, weak center (a text wall skimmed lazily). Checked before
    #    scattered because its top-left signature also looks off-center.
    if top >= 0.28 and left >= 0.40 and center < 0.46:
        reasons.append("attention piles into the top-left (an F-skim of unstructured text) — "
                       "break it into sections with clear headings, bold, and grouping")
        return _result("f-skim", round((top + left) / 2, 3), focal, disp, feats, reasons)

    # 2) scattered — attention spread wide: either near-uniform (flat profiles), or high
    #    dispersion with no central column (mass flung to the sides/corners)
    if disp >= 0.34 and (center < 0.42 or (row_peak < 1.7 and col_peak < 1.7)):
        reasons.append(f"attention is scattered (dispersion {disp:.2f}) with no clear column or "
                       "order — establish a hierarchy and a single primary action")
        return _result("scattered", disp_conf(disp), focal, disp, feats, reasons)

    # 3) gutenberg / z-flow — strong top and bottom anchors, sparse middle (hero -> CTA)
    if top >= 0.20 and bottom >= 0.20 and mid <= 0.30:
        good = True
        reasons.append("a top anchor and a bottom terminal anchor with a light middle "
                       "(a hero → primary-action flow)")
        if cta is not None and not _near(vals, width, height, cta):
            good = False
            reasons.append("but the primary action isn't where the flow ends — move it into the "
                           "bottom thumb zone")
        return _result("gutenberg", round(min(top, bottom) * 2, 3), focal, disp, feats, reasons,
                       good=good)

    # 4) vertical / layer-cake — centered column with several bands
    if center >= 0.45 and bands >= 3:
        reasons.append(f"a centered vertical column with {bands} content bands "
                       "(a layer-cake of sections) — the healthy iOS default")
        return _result("vertical", round(center, 3), focal, disp, feats, reasons)

    # 5) focused — a single dominant focal point
    if disp <= 0.25:
        reasons.append(f"a single strong focal point (dispersion {disp:.2f}) — fine for a "
                       "one-action screen")
        return _result("focused", round(1 - disp, 3), focal, disp, feats, reasons)

    # 6) fallback — some structure but no dominant pattern: treat as a (weak) vertical flow
    reasons.append("a loose vertical flow without a strong pattern — tighten the sections and the "
                   "primary action")
    return _result("vertical", round(center, 3), focal, disp, feats, reasons)


def _result(pattern, confidence, focal, disp, feats, reasons, good=None):
    level = _LEVEL.get(pattern, "bad")
    return {"pattern": pattern, "level": level,
            "good": (level in ("good", "ok")) if good is None else good,
            "confidence": round(float(confidence), 3),
            "focal": [round(focal[0], 3), round(focal[1], 3)] if focal else None,
            "dispersion": round(disp, 3), "features": feats, "reasons": reasons}


def disp_conf(disp):
    return round(min(1.0, disp / 0.45), 3)


def _near(values, W, H, pt, radius: float = 0.18) -> bool:
    cx, cy = pt
    total = sum(values) or 1.0
    near = 0.0
    for r in range(H):
        for c in range(W):
            dx = (c + 0.5) / W - cx
            dy = (r + 0.5) / H - cy
            if dx * dx + dy * dy <= radius * radius:
                near += values[r * W + c]
    return near / total >= 0.12
