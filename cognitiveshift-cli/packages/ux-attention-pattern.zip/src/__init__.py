"""UX attention-pattern block — the public seam.

`classify_pattern(values, width, height)` is the pure stdlib rule core (the `entry`).
`audit_attention(path)` adds the image layer via `vis_models.saliency` (imported lazily).
"""

from __future__ import annotations

from blocks.ux_attention_pattern.src.patterns import classify_pattern
from blocks.ux_attention_pattern.src.ux_attention_pattern import audit_attention

__all__ = ["classify_pattern", "audit_attention"]
