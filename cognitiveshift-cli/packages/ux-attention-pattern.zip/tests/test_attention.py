"""Image-layer test — runs the offline mock attention model (no weights, no pixels)."""
import pytest

pytest.importorskip("vis_models.saliency")

from blocks.ux_attention_pattern.src.ux_attention_pattern import audit_attention  # noqa: E402


def test_offline_audit_center_biased_is_focused():
    # the deterministic mock is centre-biased -> a single focal point
    res = audit_attention("unused.png", offline=True)
    assert res["pattern"] == "focused"
    assert res["good"] is True
    assert "Mock" in res["backend"]


def test_result_shape():
    res = audit_attention("unused.png", offline=True)
    for k in ("pattern", "level", "good", "confidence", "focal", "dispersion", "features", "reasons"):
        assert k in res
