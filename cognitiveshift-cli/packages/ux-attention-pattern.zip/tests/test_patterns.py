"""Pure classifier tests — stdlib only, always run in CI. iOS pattern set."""
from blocks.ux_attention_pattern.src.patterns import classify_pattern

W, H = 14, 24


def _grid(fn):
    return [max(0.0, fn((r + 0.5) / H, (c + 0.5) / W)) for r in range(H) for c in range(W)]


def test_vertical_layer_cake():
    # centered column with 4 bands (sections stacked down the middle)
    bands = [0.12, 0.34, 0.58, 0.84]
    def f(r, c):
        col = 1.0 if 0.30 < c < 0.70 else 0.05
        band = 1.0 if any(abs(r - b) < 0.05 for b in bands) else 0.10
        return col * band
    res = classify_pattern(_grid(f), W, H)
    assert res["pattern"] == "vertical" and res["good"] is True


def test_gutenberg_hero_to_cta():
    # strong top + strong bottom, empty middle
    g = _grid(lambda r, c: 1.0 if (r < 0.16 or r > 0.84) else 0.03)
    res = classify_pattern(g, W, H)
    assert res["pattern"] == "gutenberg" and res["good"] is True


def test_f_skim_warns():
    # top band + left column (a text wall)
    g = _grid(lambda r, c: 1.0 if (r < 0.14 or c < 0.18) else 0.03)
    res = classify_pattern(g, W, H)
    assert res["pattern"] == "f-skim"
    assert res["level"] == "warn" and res["good"] is False


def test_focused_single_point():
    import math
    g = _grid(lambda r, c: math.exp(-(((r - 0.5) ** 2 + (c - 0.5) ** 2) / (2 * 0.09 ** 2))))
    res = classify_pattern(g, W, H)
    assert res["pattern"] == "focused" and res["good"] is True


def test_scattered_is_bad():
    g = _grid(lambda r, c: 1.0)                     # uniform, no structure
    res = classify_pattern(g, W, H)
    assert res["pattern"] == "scattered"
    assert res["level"] == "bad" and res["good"] is False


def test_gutenberg_cta_off_thumb_zone_not_good():
    g = _grid(lambda r, c: 1.0 if (r < 0.16 or r > 0.84) else 0.03)
    off = classify_pattern(g, W, H, cta=(0.5, 0.5))     # CTA stranded in the empty middle
    on = classify_pattern(g, W, H, cta=(0.5, 0.9))      # CTA at the bottom terminal
    assert off["good"] is False and on["good"] is True


def test_empty_input():
    assert classify_pattern([], 0, 0)["pattern"] == "none"
