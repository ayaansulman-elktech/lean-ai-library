# Models library (`vis_models`)

The factory's **vision-model layer**. Two parts: - **`catalog.json`** — a human-readable discovery view over the AI-farm registry: model name, task, status, license, and the niche(s) it serves. It stores **no weights** (those live in `../ai-farm`). - **`src/vis_models/`** — the importable adapters Sprint Engineers and agents call. Today this is `saliency`.
