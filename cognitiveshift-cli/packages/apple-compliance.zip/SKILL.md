---
name: apple-compliance
description: Pre-submission App Store Review gate. Assesses an app descriptor against the review guidelines, weighted toward Guideline 4.3 (Spam/duplicate). Use before submitting any app.
allowed-tools: Read, Bash
---
# Apple Compliance gate

The existential gate for a high-volume app factory: **Guideline 4.3 (Spam)** bans near-duplicate
apps that differ only cosmetically. This agent (`src/apple_compliance/`, on `agent-core`) reviews
an app descriptor and returns a structured `ComplianceReport`.

Two layers (like security-review):
- **Deterministic checks** (`checks.py`, no LLM) — a **real 4.3 duplicate scan** that measures
  lexical similarity of the app against its **sibling catalog** (not a self-reported "how I differ"
  field), plus 2.3 metadata, 4.2 native/min-functionality (web-wrapper detection), 3.1 external
  payments, and 5.1 privacy. Any **high-severity** finding **hard-blocks** regardless of the model.
- **LLM review** for the judgement calls, given the deterministic findings as context.

```python
from apple_compliance import AppleComplianceAgent
agent = AppleComplianceAgent(ctx, catalog=[sibling1, sibling2, ...])   # catalog powers the 4.3 scan
res = agent.run({"name": ..., "value": ..., "features": [...], "category": ...})
if not res.output["passes"]:   # gate: block submission
    ...
```
The sibling catalog can also be passed per-run as the task's `"siblings"` key.

- `verdict`: pass | flag | fail · `risk_level`: low | medium | high · `findings[]` (LLM + deterministic).
- `static_findings[]`: the deterministic-only findings; any `high` here hard-blocks.
- `passes()` blocks on a `fail`, any `high` overall risk, or any high-severity deterministic finding.
- Canonical source: developer.apple.com/app-store/review/guidelines (see `references/guidelines.md`).
