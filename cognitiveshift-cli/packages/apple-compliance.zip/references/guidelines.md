# App Store guidelines (high-risk subset)

Canonical source: <https://developer.apple.com/app-store/review/guidelines/>

The factory cares most about these (kept in sync with the agent's system prompt):

| # | Guideline | Why it matters here |
|---|---|---|
| **4.3** | **Spam** — no duplicate/variant apps differing only cosmetically (visuals, branding, dataset, locale). Each must be a meaningfully different experience. | **Existential.** The factory ships many similar apps; this is the #1 rejection/ban risk. |
| 2.3 | Accurate Metadata — name/description/screenshots match real functionality. | Auto-generated metadata must not over-claim. |
| 4.2 | Minimum Functionality — more than a repackaged website / thin wrapper. | "MVP, fast" must still clear the bar. |
| 3.1 | Payments — digital goods via IAP; no external purchase links. | Paywall implementation. |
| 5.1 | Privacy — on-device handling, privacy policy, accurate data-use disclosure. | Local-AI-first is an advantage; still must disclose. |

The agent weights **4.3** most heavily and is strict about cosmetic-variant risk.

## Deterministic checks (no LLM, hard-blocking)

`checks.py` runs before the model and any **high**-severity finding hard-blocks the gate:

| Guideline | Deterministic rule | Severity |
|---|---|---|
| **4.3** | Token-similarity of the descriptor vs each **sibling** in the catalog; a same-category match ≥ 0.60 overlap is a cosmetic-variant block (≥ 0.45 flags). | high / medium |
| 4.2 | Web-wrapper / non-native signals (`platform: webview`, "wrapper around our site", `native: false`). | high |
| 3.1 | External/website purchase for digital goods (`external_purchase`, "buy on our website"). | high |
| 5.1 | `collects_data` with no `privacy_policy`; tracking without ATT disclosure. | high / medium |
| 2.3 | App name > 30 chars / subtitle > 30 chars. | medium / low |

The 4.3 scan is a real comparison against the sibling catalog — pass the catalog via
`AppleComplianceAgent(ctx, catalog=[...])` or a per-run `"siblings"` key — not a self-reported field.
