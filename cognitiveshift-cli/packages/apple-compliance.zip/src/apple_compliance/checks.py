"""Deterministic App Store compliance checks — run with no LLM, no deps.

The unambiguous, rule-checkable violations live here so a lenient model answer can never open
the gate: every HIGH-severity finding hard-blocks in the agent regardless of the LLM verdict
(the same design as security-review's static scan).

The centrepiece is a REAL Guideline 4.3 (Spam/duplicate) scan: a lexical-similarity comparison
of the app against its sibling catalog — not a self-reported "how I differ" field. For a factory
that ships many similar apps, 4.3 is the existential risk, so it is measured, not asked.
"""

from __future__ import annotations

import re

# --- 4.3 duplicate thresholds (max token similarity vs any sibling, 0..1) -----------------
DUP_HIGH = 0.60   # near-duplicate of a same-category sibling -> hard block
DUP_MED = 0.45    # notably similar -> flag for review

_APP_NAME_MAX = 30            # App Store display-name limit
_SUBTITLE_MAX = 30            # App Store subtitle limit

_WORD = re.compile(r"[a-z0-9]+")
_STOP = {
    "the", "a", "an", "and", "or", "for", "to", "of", "in", "on", "with", "your", "you",
    "app", "application", "ios", "iphone", "ipad", "apple", "that", "this", "it", "is", "are",
    "lets", "let", "helps", "help", "easy", "simple", "best", "free",
}

# tokens that signal a non-native web wrapper (Guideline 4.2 / "must be Apple-native")
_WRAPPER = re.compile(
    r"\b(web ?view|web ?wrapper|wrapper around|just a web ?site|repackaged web ?site|"
    r"html5 app|cordova|phonegap|react[\s-]?native[\s-]?web|hybrid web)\b")
_WEB_PLATFORM = {"web", "website", "webview", "web-app", "webapp", "html", "cordova", "phonegap"}

# external-purchase signals for digital goods (Guideline 3.1 — must use IAP)
_EXTERNAL_PAY = re.compile(
    r"\b(buy|purchase|subscribe|pay|checkout)\b[^.]{0,40}\b(our|the|my)?\s?(web ?site|site|web)\b"
    r"|\bexternal (payment|purchase|checkout|link)\b"
    r"|\b(stripe|paypal|braintree|razorpay|gumroad)\b[^.]{0,30}\b(link|checkout|purchase|web)\b")


def _truthy(v) -> bool:
    if isinstance(v, str):
        return v.strip().lower() in {"1", "true", "yes", "y", "on"}
    return bool(v)


def _first(app: dict, *keys, default=None):
    for k in keys:
        if k in app and app[k] not in (None, ""):
            return app[k]
    return default


def _tokens(text: str) -> set[str]:
    return {w for w in _WORD.findall((text or "").lower()) if w not in _STOP and len(w) > 2}


def _descriptor_text(app: dict) -> str:
    feats = _first(app, "features", default=[]) or []
    if isinstance(feats, str):
        feats = [feats]
    parts = [
        str(_first(app, "name", "title", default="")),
        str(_first(app, "subtitle", "tagline", default="")),
        str(_first(app, "value", "value_proposition", "pitch", default="")),
        str(_first(app, "description", "desc", default="")),
        " ".join(str(f) for f in feats),
        " ".join(str(k) for k in (_first(app, "keywords", default=[]) or [])),
    ]
    return " ".join(p for p in parts if p)


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _norm_cat(app: dict) -> str:
    return str(_first(app, "category", "genre", default="")).strip().lower()


def _as_app(app) -> dict:
    """Normalize a str-or-dict descriptor to a dict so checks are uniform."""
    if isinstance(app, str):
        return {"description": app}
    return app if isinstance(app, dict) else {"description": str(app)}


# --- Guideline 4.3: real duplicate scan against the sibling catalog -----------------------
def duplicate_scan(app, siblings: list | None) -> list[dict]:
    """Compare `app` to each sibling by token similarity; flag near-duplicates.

    This is the deterministic heart of the gate: high similarity to a SAME-CATEGORY sibling is a
    hard block (a cosmetic variant is exactly what 4.3 rejects). Returns 0 or 1 findings.
    """
    app = _as_app(app)
    if not siblings:
        return []
    ta = _tokens(_descriptor_text(app))
    if not ta:
        return []
    cat = _norm_cat(app)
    best_sim, best_name, best_same_cat = 0.0, "", False
    for sib in siblings:
        sib = _as_app(sib)
        sim = _jaccard(ta, _tokens(_descriptor_text(sib)))
        if sim > best_sim:
            best_sim = sim
            best_name = str(_first(sib, "name", "title", default="a sibling app"))
            best_same_cat = bool(cat) and _norm_cat(sib) == cat

    pct = f"{best_sim:.0%}"
    if best_same_cat and best_sim >= DUP_HIGH:
        sev, issue = "high", (
            f"Near-duplicate of same-category app '{best_name}' ({pct} descriptor overlap). "
            "Likely a cosmetic variant — the #1 Guideline 4.3 rejection/ban risk.")
    elif best_sim >= DUP_HIGH or (best_same_cat and best_sim >= DUP_MED):
        sev, issue = "medium", (
            f"High similarity to '{best_name}' ({pct} descriptor overlap) — review for "
            "4.3 cosmetic-variant risk before submitting.")
    elif best_sim >= DUP_MED:
        sev, issue = "low", (
            f"Some overlap with '{best_name}' ({pct}); ensure a distinct value proposition.")
    else:
        return []
    return [{"guideline": "4.3 Spam", "issue": issue, "severity": sev,
             "recommendation": "Differentiate core functionality/content, not just visuals, "
                               "branding, dataset, or locale."}]


# --- Guideline 2.3: metadata correctness --------------------------------------------------
def metadata_checks(app: dict) -> list[dict]:
    out = []
    name = str(_first(app, "name", "title", default=""))
    if len(name) > _APP_NAME_MAX:
        out.append({"guideline": "2.3 Accurate Metadata",
                    "issue": f"App name is {len(name)} chars (App Store limit {_APP_NAME_MAX}).",
                    "severity": "medium", "recommendation": "Shorten the display name."})
    sub = str(_first(app, "subtitle", "tagline", default=""))
    if len(sub) > _SUBTITLE_MAX:
        out.append({"guideline": "2.3 Accurate Metadata",
                    "issue": f"Subtitle is {len(sub)} chars (limit {_SUBTITLE_MAX}).",
                    "severity": "low", "recommendation": "Shorten the subtitle."})
    return out


# --- Guideline 4.2 / native: minimum functionality, not a web wrapper ---------------------
def functionality_checks(app: dict) -> list[dict]:
    out = []
    text = _descriptor_text(app).lower()
    platform = str(_first(app, "platform", "tech", "type", "stack", default="")).lower()
    native = app.get("native")
    is_web = (any(tok in _WEB_PLATFORM for tok in re.split(r"[\s,/]+", platform))
              or bool(_WRAPPER.search(text))
              or (native is not None and not _truthy(native)))
    if is_web:
        out.append({"guideline": "4.2 Minimum Functionality",
                    "issue": "Appears to be a web wrapper / non-native app — 4.2 requires a "
                             "real, Apple-native experience (SwiftUI/UIKit), not a repackaged site.",
                    "severity": "high",
                    "recommendation": "Ship a native SwiftUI app with device-integrated "
                                      "functionality beyond a website."})
    feats = _first(app, "features", default=None)
    if isinstance(feats, list) and len(feats) == 0:
        out.append({"guideline": "4.2 Minimum Functionality",
                    "issue": "No features declared — risks being seen as too thin to approve.",
                    "severity": "medium", "recommendation": "Provide meaningful core features."})
    return out


# --- Guideline 3.1: payments must use IAP -------------------------------------------------
def payment_checks(app: dict) -> list[dict]:
    text = _descriptor_text(app).lower()
    if _truthy(app.get("external_purchase")) or _EXTERNAL_PAY.search(text):
        return [{"guideline": "3.1 Payments",
                 "issue": "Steers users to an external/website purchase for digital goods — "
                          "3.1 requires in-app purchase; external links are a hard rejection.",
                 "severity": "high",
                 "recommendation": "Sell digital goods through StoreKit in-app purchase."}]
    return []


# --- Guideline 5.1: privacy ---------------------------------------------------------------
def privacy_checks(app: dict) -> list[dict]:
    out = []
    collects = _truthy(_first(app, "collects_data", "collects_user_data", default=False))
    has_policy = bool(_first(app, "privacy_policy", "privacy_policy_url", default=""))
    if collects and not has_policy:
        out.append({"guideline": "5.1 Privacy",
                    "issue": "Collects user data but declares no privacy policy — required by 5.1.",
                    "severity": "high",
                    "recommendation": "Add a privacy policy URL and an accurate data-use "
                                      "disclosure (prefer on-device handling)."})
    if _truthy(app.get("tracking")) and not _truthy(app.get("tracking_disclosed")):
        out.append({"guideline": "5.1 Privacy",
                    "issue": "Tracks users without declaring App Tracking Transparency consent.",
                    "severity": "medium",
                    "recommendation": "Request ATT permission and disclose tracking."})
    return out


def check(app, siblings: list | None = None) -> list[dict]:
    """Run every deterministic check. Returns findings [{guideline, issue, severity, recommendation}].

    HIGH-severity findings hard-block in the agent regardless of the LLM verdict.
    """
    a = _as_app(app)
    return [
        *duplicate_scan(a, siblings),
        *metadata_checks(a),
        *functionality_checks(a),
        *payment_checks(a),
        *privacy_checks(a),
    ]
