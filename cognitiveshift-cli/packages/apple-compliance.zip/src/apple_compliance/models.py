"""The compliance report schema — the contract the gate returns."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

Severity = Literal["low", "medium", "high"]
Verdict = Literal["pass", "flag", "fail"]


class Finding(BaseModel):
    guideline: str          # e.g. "4.3 Spam"
    issue: str
    severity: Severity
    recommendation: str


class ComplianceReport(BaseModel):
    verdict: Verdict
    risk_level: Severity
    findings: list[Finding] = []
    summary: str = ""

    def passes(self) -> bool:
        """Gate: block submission on a fail, or any high overall risk."""
        return self.verdict != "fail" and self.risk_level != "high"
