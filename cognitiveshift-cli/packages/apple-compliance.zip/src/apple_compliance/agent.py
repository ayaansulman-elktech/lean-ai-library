"""AppleComplianceAgent — pre-submission App Store Review gate.

Two layers, mirroring security-review: a deterministic check pass (always runs, no LLM) for the
rule-checkable violations — the real Guideline 4.3 duplicate scan against the sibling catalog,
plus 2.3 metadata, 4.2 native/min-functionality, 3.1 payments, and 5.1 privacy — plus an LLM
review for judgement calls. Any HIGH-severity deterministic finding is an automatic hard block
regardless of what the model says. `output["passes"]` is the gate; block submission when False.
"""

from __future__ import annotations

import json

from agent_core import Agent, AgentContext

from apple_compliance.checks import check
from apple_compliance.models import ComplianceReport

GUIDELINES = (
    "Apple App Store Review Guidelines — the high-risk ones for this factory:\n"
    "- 4.3 Spam: an app must NOT be a duplicate/variant of an existing app with only cosmetic "
    "differences (visuals, branding, dataset, locale, audience). Each app MUST deliver a "
    "meaningfully different experience or unique content/functionality. THIS IS THE #1 RISK.\n"
    "- 2.3 Accurate Metadata: name/description/screenshots must match real functionality.\n"
    "- 4.2 Minimum Functionality: a real Apple-native app, not a repackaged website or thin wrapper.\n"
    "- 3.1 Payments: digital goods go through in-app purchase; no external purchase links.\n"
    "- 5.1 Privacy: on-device handling, a privacy policy, accurate data-use disclosure.\n"
    "Canonical source: https://developer.apple.com/app-store/review/guidelines/"
)

SYSTEM = (
    "You are a strict Apple App Store compliance reviewer. Assess the APP DESCRIPTOR against "
    "the guidelines below, weighting 4.3 (Spam/duplicate) most heavily because this app is "
    "produced by a factory that ships many similar apps. You are also given DETERMINISTIC "
    "CHECKS already computed from the descriptor and its sibling catalog — incorporate them; "
    "do not contradict a high-severity check.\n\n" + GUIDELINES + "\n\n"
    'Return ONLY JSON: {"verdict": "pass|flag|fail", "risk_level": "low|medium|high", '
    '"findings": [{"guideline", "issue", "severity": "low|medium|high", "recommendation"}], '
    '"summary"}. '
    "verdict=fail for a clear violation that would be rejected; flag for real risk needing "
    "changes before submission; pass if it would plausibly be accepted. Be strict on 4.3."
)


class AppleComplianceAgent(Agent):
    name = "apple-compliance"

    def __init__(self, ctx: AgentContext, *, model: str | None = None,
                 catalog: list | None = None) -> None:
        """`catalog` is the sibling-app list the 4.3 duplicate scan compares against (each a
        descriptor dict/str). A per-run catalog can also be passed as the task's "siblings" key."""
        super().__init__(ctx)
        self.model = model
        self.catalog = catalog or []

    def _run(self, app: dict | str) -> dict:
        siblings = (app.get("siblings") if isinstance(app, dict) else None) or self.catalog
        static = check(app, siblings)

        descriptor = app if isinstance(app, str) else json.dumps(app, indent=2)
        user = (f"APP DESCRIPTOR:\n{descriptor}\n\n"
                f"DETERMINISTIC CHECKS:\n{json.dumps(static, indent=2)}")
        report = self.llm_json(system=SYSTEM, user=user, model=self.model, schema=ComplianceReport)

        # Hard rule: any high-severity deterministic finding (e.g. a same-category duplicate, a web
        # wrapper, an external-purchase link) blocks, no matter what the model concluded.
        has_critical = any(f["severity"] == "high" for f in static)
        core = {k: report[k] for k in ("verdict", "risk_level", "findings", "summary")}
        passes = ComplianceReport(**core).passes() and not has_critical

        report["findings"] = report.get("findings", []) + static
        report["static_findings"] = static
        report["passes"] = passes
        self.ctx.tracker.log_metrics({"compliance_pass": 1.0 if passes else 0.0,
                                      "static_findings": len(static),
                                      "findings": len(report["findings"])})
        return report
