"""Apple App Store compliance gate (Guideline 4.3-weighted), on agent-core.

Deterministic checks (real 4.3 duplicate scan vs a sibling catalog, plus 2.3/4.2/3.1/5.1 rules)
hard-block on any high-severity finding; an LLM layer handles the judgement calls.
"""

from apple_compliance.agent import AppleComplianceAgent
from apple_compliance.checks import check, duplicate_scan
from apple_compliance.models import ComplianceReport, Finding

__all__ = ["AppleComplianceAgent", "ComplianceReport", "Finding", "check", "duplicate_scan"]
