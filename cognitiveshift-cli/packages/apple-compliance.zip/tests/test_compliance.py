from agent_core import AgentContext
from apple_compliance.agent import AppleComplianceAgent
from apple_compliance.checks import check, duplicate_scan
from ml_core import CostMeter, ProvidersConfig, build_gateway
from ml_core.config import ModelSpec

PASS = ('{"verdict":"pass","risk_level":"low","findings":[],'
        '"summary":"Distinct value proposition; not a cosmetic variant."}')

FAIL = ('{"verdict":"fail","risk_level":"high","findings":[{"guideline":"4.3 Spam",'
        '"issue":"Cosmetic variant of an existing app (same core, new dataset only).",'
        '"severity":"high","recommendation":"Change the core value proposition."}],'
        '"summary":"Likely 4.3 rejection."}')


def _ctx(responder):
    cfg = ProvidersConfig(gateway="mock",
                          models={"deepseek": ModelSpec(provider="deepseek", model="deepseek-chat")})
    meter = CostMeter(budget_usd=1.0)
    return AgentContext(gateway=build_gateway(cfg, meter, offline=True, responder=responder),
                        meter=meter, default_model="deepseek")


def test_pass_gate_opens():
    r = AppleComplianceAgent(_ctx(lambda a, m: PASS)).run({"name": "X", "value": "unique"})
    assert r.success
    assert r.output["verdict"] == "pass"
    assert r.output["passes"] is True


def test_fail_gate_blocks_on_4_3():
    r = AppleComplianceAgent(_ctx(lambda a, m: FAIL)).run({"name": "Y", "value": "variant"})
    assert r.success
    assert r.output["verdict"] == "fail"
    assert r.output["passes"] is False
    assert r.output["findings"][0]["guideline"].startswith("4.3")


def test_accepts_text_descriptor():
    r = AppleComplianceAgent(_ctx(lambda a, m: PASS)).run("A plain-text app description")
    assert r.success and r.output["passes"] is True


# --- deterministic layer: real 4.3 duplicate scan vs a sibling catalog ---------------------

_SEASONS = {"name": "Season Colors", "category": "lifestyle",
            "value": "find your seasonal color palette from a selfie",
            "features": ["selfie capture", "seasonal palette", "shade recommendations"]}


def test_duplicate_scan_flags_same_category_near_duplicate_high():
    # A cosmetic variant of a same-category sibling (only the dataset/locale differs).
    app = {"name": "Season Colours UK", "category": "lifestyle",
           "value": "find your seasonal color palette from a selfie",
           "features": ["selfie capture", "seasonal palette", "shade recommendations"]}
    findings = duplicate_scan(app, [_SEASONS])
    assert findings and findings[0]["severity"] == "high"
    assert findings[0]["guideline"].startswith("4.3")


def test_duplicate_scan_clears_a_genuinely_different_app():
    app = {"name": "Tide Tracker", "category": "weather",
           "value": "real-time tide charts and surf forecasts for your beach",
           "features": ["tide charts", "surf height", "wind"]}
    assert duplicate_scan(app, [_SEASONS]) == []


def test_duplicate_hard_blocks_even_if_model_is_lenient():
    # LLM says pass, but a same-category near-duplicate in the catalog must hard-block.
    app = {"name": "Season Colours UK", "category": "lifestyle",
           "value": "find your seasonal color palette from a selfie",
           "features": ["selfie capture", "seasonal palette", "shade recommendations"]}
    r = AppleComplianceAgent(_ctx(lambda a, m: PASS), catalog=[_SEASONS]).run(app)
    assert r.success
    assert r.output["passes"] is False
    assert any(f["guideline"].startswith("4.3") and f["severity"] == "high"
               for f in r.output["static_findings"])


def test_web_wrapper_hard_blocks():
    app = {"name": "News Reader", "platform": "webview",
           "value": "a wrapper around our news website"}
    r = AppleComplianceAgent(_ctx(lambda a, m: PASS)).run(app)
    assert r.output["passes"] is False
    assert any(f["guideline"].startswith("4.2") for f in r.output["static_findings"])


def test_external_purchase_hard_blocks():
    app = {"name": "Coins", "value": "buy coin packs", "external_purchase": True}
    findings = check(app)
    assert any(f["guideline"].startswith("3.1") and f["severity"] == "high" for f in findings)


def test_privacy_collects_without_policy_hard_blocks():
    app = {"name": "Tracker", "value": "log your habits", "collects_data": True}
    r = AppleComplianceAgent(_ctx(lambda a, m: PASS)).run(app)
    assert r.output["passes"] is False
    assert any(f["guideline"].startswith("5.1") for f in r.output["static_findings"])


def test_long_name_flags_but_does_not_block_a_passing_app():
    app = {"name": "The Ultimate Seasonal Color Palette Finder Pro Max", "value": "unique idea"}
    r = AppleComplianceAgent(_ctx(lambda a, m: PASS)).run(app)
    assert r.output["passes"] is True                       # medium metadata note doesn't block
    assert any(f["guideline"].startswith("2.3") for f in r.output["static_findings"])
