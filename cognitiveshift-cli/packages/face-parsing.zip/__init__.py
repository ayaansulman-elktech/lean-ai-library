"""face-parsing block — facial segmentation (skin/eyes/lips/hair). See ../README.md."""
