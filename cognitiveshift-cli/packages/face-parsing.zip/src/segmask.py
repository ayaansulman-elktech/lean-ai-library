"""A lightweight segmentation mask — a grid of class ids, plus part-region queries.

Dependency-free (plain Python lists), so the mock, metrics, and tests run in CI. The real BiSeNet
adapter downsamples its full-res label map into this grid.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SegMask:
    width: int
    height: int
    labels: list[int]          # class id per cell, row-major (len == width * height)

    def __post_init__(self) -> None:
        if self.width <= 0 or self.height <= 0:
            raise ValueError("segmentation mask must be non-empty")
        if len(self.labels) != self.width * self.height:
            raise ValueError(f"labels length {len(self.labels)} != {self.width}x{self.height}")

    def present(self, class_ids) -> bool:
        s = set(class_ids)
        return any(v in s for v in self.labels)

    def coverage(self, class_ids) -> float:
        """Fraction of the whole image occupied by the given classes (0..1)."""
        s = set(class_ids)
        return sum(1 for v in self.labels if v in s) / len(self.labels)

    def bbox(self, class_ids):
        """Normalized (x, y, w, h) bounding box of the given classes, or None if absent."""
        s = set(class_ids)
        xs, ys = [], []
        for i, v in enumerate(self.labels):
            if v in s:
                xs.append(i % self.width)
                ys.append(i // self.width)
        if not xs:
            return None
        x0, x1, y0, y1 = min(xs), max(xs) + 1, min(ys), max(ys) + 1
        return (round(x0 / self.width, 4), round(y0 / self.height, 4),
                round((x1 - x0) / self.width, 4), round((y1 - y0) / self.height, 4))
