"""Real face-parsing adapter — BiSeNet (https://github.com/yakhyo/face-parsing).

19-class CelebAMask-HQ face segmentation (ResNet18/34 backbone). Runs in the **iOS Ready**: needs
`torch`, Pillow, the repo (`models/bisenet.py: BiSeNet`), and a `.pt` weight in
`ios-ready/raw/face-parsing`. Imports are lazy so importing this module never pulls in torch;
`is_available()` gates the fallback to the mock. Preprocessing/constructor args are pinned on the
farm against the repo revision.
"""

from __future__ import annotations

from pathlib import Path

from blocks.face_parsing.src.labels import NUM_CLASSES
from blocks.face_parsing.src.segmask import SegMask

# libraries/models/blocks/face_parsing/src/model.py -> parents[4] == libraries
_DEFAULT_DIR = Path(__file__).resolve().parents[4] / "ios-ready" / "raw" / "face-parsing"


class FaceParsingModel:
    def __init__(self, *, repo_dir=None, weights=None, backbone: str = "resnet18",
                 device: str = "cpu", grid: int = 96, num_classes: int = NUM_CLASSES) -> None:
        self.repo_dir = Path(repo_dir) if repo_dir else _DEFAULT_DIR
        self.weights = Path(weights) if weights else None
        self.backbone = backbone
        self.device = device
        self.grid = grid
        self.num_classes = num_classes
        self._net = None

    def _find_weights(self) -> Path | None:
        if self.weights and self.weights.exists():
            return self.weights
        for ext in ("*.pt", "*.pth", "*.onnx"):
            hit = next(self.repo_dir.glob(f"**/{ext}"), None)
            if hit:
                return hit
        return None

    def is_available(self) -> bool:
        """True only if torch is importable AND the repo + a weight are present."""
        try:
            import torch  # noqa: F401
        except Exception:
            return False
        return self.repo_dir.exists() and self._find_weights() is not None

    def _load(self):
        if self._net is not None:
            return self._net
        import sys

        import torch
        if not self.is_available():
            raise RuntimeError(
                f"face-parsing not available: need torch + the repo and a weight in "
                f"{self.repo_dir}. Fetch it per libraries/ios-ready/registry.json, or use "
                "build(offline=True) for the mock."
            )
        sys.path.insert(0, str(self.repo_dir))
        from models.bisenet import BiSeNet  # yakhyo/face-parsing repo
        net = BiSeNet(num_classes=self.num_classes, backbone_name=self.backbone)
        net.load_state_dict(torch.load(str(self._find_weights()), map_location=self.device))
        net.to(self.device).eval()
        self._net = net
        return net

    def predict(self, image) -> SegMask:
        """Segment a face image into a 19-class SegMask (downsampled to the grid).

        Preprocessing matches the repo's inference.py: 512x512 bilinear resize + ImageNet
        normalize; the model returns a tuple, whose first output is the class logits.
        """
        import numpy as np
        import torch
        from PIL import Image

        net = self._load()
        im = Image.open(str(image)).convert("RGB").resize((512, 512), Image.BILINEAR)
        arr = np.asarray(im, dtype="float32") / 255.0
        arr = (arr - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
        t = torch.from_numpy(arr.transpose(2, 0, 1)[None].astype("float32")).to(self.device)
        with torch.no_grad():
            out = net(t)
            logits = out[0] if isinstance(out, (list, tuple)) else out
            lab = np.asarray(logits.squeeze(0).argmax(0).cpu())   # (H, W) class ids
        return _labels_to_grid(lab, self.grid)


def _labels_to_grid(lab, grid: int) -> SegMask:
    """Nearest-sample a full-res class map into a grid×grid SegMask (labels, not averages)."""
    import numpy as np

    a = np.asarray(lab)
    h, w = a.shape
    values: list[int] = []
    for gy in range(grid):
        y = min(h - 1, (gy * h) // grid + h // (2 * grid))
        for gx in range(grid):
            x = min(w - 1, (gx * w) // grid + w // (2 * grid))
            values.append(int(a[y, x]))
    return SegMask(width=grid, height=grid, labels=values)
