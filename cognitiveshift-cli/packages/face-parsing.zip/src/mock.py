"""Deterministic offline stand-in for face-parsing — no torch, runs in CI.

Paints a plausible synthetic face onto the grid (hair frame, skin oval, two eyes, lips) so the
part-region logic, metrics, and tests exercise real shapes without the segmentation model.
Pixels are ignored by design — this is for offline tests/demos, not real parsing.
"""

from __future__ import annotations

from blocks.face_parsing.src.segmask import SegMask


class MockFaceParsing:
    def __init__(self, *, grid: int = 96) -> None:
        self.grid = grid

    def is_available(self) -> bool:
        return True

    def predict(self, image) -> SegMask:  # noqa: ARG002 — pixels ignored by design
        g = self.grid
        labels = [0] * (g * g)
        for row in range(g):
            for col in range(g):
                nx, ny = (col + 0.5) / g, (row + 0.5) / g
                lab = 0
                # hair: top band + upper side framing
                if ny < 0.30 or (ny < 0.66 and (nx < 0.26 or nx > 0.74)):
                    lab = 13
                # skin: face oval (overrides hair on the forehead/cheeks)
                if ((nx - 0.5) / 0.26) ** 2 + ((ny - 0.58) / 0.34) ** 2 <= 1.0:
                    lab = 1
                    # facial features sit on the skin
                    if (nx - 0.39) ** 2 + (ny - 0.52) ** 2 <= 0.0028:
                        lab = 4                          # left eye
                    elif (nx - 0.61) ** 2 + (ny - 0.52) ** 2 <= 0.0028:
                        lab = 5                          # right eye
                    elif ((nx - 0.5) / 0.11) ** 2 + ((ny - 0.75) / 0.05) ** 2 <= 1.0:
                        lab = 11 if ny < 0.75 else 12    # upper / lower lip
                labels[row * g + col] = lab
        return SegMask(width=g, height=g, labels=labels)
