"""face-parsing block factory. `build(offline=False)` returns the real BiSeNet adapter when torch +
a weight are on the box, else the deterministic mock."""

from __future__ import annotations

from blocks.face_parsing.src.mock import MockFaceParsing
from blocks.face_parsing.src.model import FaceParsingModel


def build(offline: bool = False, **kwargs):
    if not offline:
        model = FaceParsingModel(**{k: v for k, v in kwargs.items()
                                    if k in {"repo_dir", "weights", "backbone", "device",
                                             "grid", "num_classes"}})
        if model.is_available():
            return model
    return MockFaceParsing(**{k: v for k, v in kwargs.items() if k in {"grid"}})


__all__ = ["build", "FaceParsingModel", "MockFaceParsing"]
