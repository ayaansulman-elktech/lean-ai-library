"""CelebAMask-HQ 19-class labels for BiSeNet face parsing, plus the color-relevant part groups.

The model emits one of 19 class ids per pixel; `PARTS` groups the raw classes into the regions the
Colors Matching app extracts colors from (skin, eyes, lips, hair).
"""

from __future__ import annotations

CLASSES = {
    0: "background", 1: "skin", 2: "nose", 3: "eye_g", 4: "l_eye", 5: "r_eye",
    6: "l_brow", 7: "r_brow", 8: "l_ear", 9: "r_ear", 10: "mouth", 11: "u_lip",
    12: "l_lip", 13: "hair", 14: "hat", 15: "ear_r", 16: "neck_l", 17: "neck", 18: "cloth",
}
NUM_CLASSES = 19

# color-extraction parts -> the raw class ids that compose them
PARTS = {
    "skin": [1, 2, 8, 9],   # face skin, nose, ears
    "eyes": [4, 5],         # left / right eye
    "lips": [11, 12],       # upper / lower lip
    "hair": [13],
}
