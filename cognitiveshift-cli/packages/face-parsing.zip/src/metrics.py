"""Part summaries from a face-parsing mask — the answer the color app wants: which regions were
found, how much of the image they cover, and where they are. Pure Python (operates on SegMask)."""

from __future__ import annotations

from blocks.face_parsing.src.labels import PARTS


def part_summary(mask) -> dict:
    """For each color-relevant part (skin/eyes/lips/hair): present, coverage (0..1), bbox."""
    return {
        part: {
            "present": mask.present(ids),
            "coverage": round(mask.coverage(ids), 4),
            "bbox": mask.bbox(ids),
        }
        for part, ids in PARTS.items()
    }
