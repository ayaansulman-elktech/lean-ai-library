# face-parsing (model card)

Facial segmentation — per-pixel face-part masks
([yakhyo/face-parsing](https://github.com/yakhyo/face-parsing), BiSeNet / ResNet18–34).

- **Task:** segment a selfie into 19 CelebAMask-HQ classes; grouped here into **skin / eyes / lips
  / hair** — the regions the Colors Matching app extracts colors from.
- **Inputs:** a face image (RGB). **Outputs:** a `SegMask` (grid of class ids) + `part_summary`
  (present / coverage / bbox per part).
- **Status:** `raw` — self-contained block (`deps: []`). Real `.pt`/`.onnx` weights run in the
  iOS Ready (`ios-ready/raw/face-parsing`); CI uses a deterministic synthetic mask.
- **Apple-native:** *partial* — Apple has on-device **skin & hair** pixel mattes
  (`AVSemanticSegmentationMatte`, iOS 13+) and eye/lip **landmarks** (Vision). See below.

## Use
```python
from blocks.face_parsing.src import build
from blocks.face_parsing.src.metrics import part_summary

model = build()                         # real BiSeNet on the farm; synthetic mask elsewhere
mask  = model.predict("selfie.png")
part_summary(mask)                      # {"skin": {...}, "eyes": {...}, "lips": {...}, "hair": {...}}
mask.bbox([4, 5])                       # where the eyes are (normalized box)
```

## Apple-native alternatives (researched)

Checked per the task requirement — Apple *partially* covers this on-device:

| Apple API | Covers | Since | Gap vs face-parsing |
|---|---|---|---|
| AVFoundation `AVSemanticSegmentationMatte` (`.skin`, `.hair`, `.teeth`, `.glasses`) | per-pixel **skin & hair** mattes | iOS 13 | no eyes/lips class; produced at photo **capture** (`enabledSemanticSegmentationMatteTypes`), not on an arbitrary image |
| Vision `VNDetectFaceLandmarksRequest` | eyes, lips, brows, nose, contour, pupils — as **points** | iOS 11 | geometric landmarks, not pixel masks |
| Vision `VNGeneratePersonSegmentationRequest` / `…PersonInstanceMaskRequest` | whole **person** foreground | iOS 15 / 17 | not face parts |
| ARKit `ARFaceAnchor` | 3D face mesh + blendshapes | iOS 11 | needs TrueDepth; no semantic part masks |

**Verdict — partial.** For a captured selfie, Apple's native **skin + hair** mattes are a strong
on-device option and worth preferring for those parts. face-parsing is still needed for **eyes +
lips** as pixel regions, a unified parse, and running on non-capture images. Recommendation for
Colors Matching: use Apple's native skin/hair mattes where available, face-parsing for eyes/lips
(and as the cross-part fallback).

## Running the real model (iOS Ready)
Fetch the repo + a weight (`resnet18.pt`) into `ios-ready/raw/face-parsing/`, install `torch` +
`opencv`, then `build()` returns the real `FaceParsingModel` (`is_available()` gates the fallback).
