"""Offline tests for the face-parsing block — mock-backed, no torch/weights (green in CI)."""

import json
from pathlib import Path

from blocks.face_parsing.src import build
from blocks.face_parsing.src.labels import CLASSES, PARTS
from blocks.face_parsing.src.metrics import part_summary
from blocks.face_parsing.src.mock import MockFaceParsing

BLOCK = Path(__file__).resolve().parents[1]


def test_offline_build_is_the_mock():
    # offline always forces the deterministic mock (env-independent — a box with weights would
    # otherwise return the real model).
    assert isinstance(build(offline=True), MockFaceParsing)


def test_mock_segments_every_color_part():
    mask = build(offline=True).predict("selfie.png")
    for part in ("skin", "eyes", "lips", "hair"):
        assert mask.present(PARTS[part]), f"{part} not segmented"


def test_part_summary_shape_and_ordering():
    summary = part_summary(build(offline=True).predict("x"))
    assert set(summary) == {"skin", "eyes", "lips", "hair"}
    assert summary["skin"]["coverage"] > 0 and summary["skin"]["bbox"] is not None
    # eyes are two small regions inside the face -> far less coverage than skin
    assert summary["eyes"]["coverage"] < summary["skin"]["coverage"]
    # lips sit low on the face; skin bbox spans more vertically than the lip bbox
    assert summary["lips"]["bbox"][3] < summary["skin"]["bbox"][3]


def test_deterministic():
    assert build(offline=True).predict("x").labels == build(offline=True).predict("x").labels


def test_labels_are_the_19_class_celebamask():
    assert len(CLASSES) == 19 and CLASSES[13] == "hair" and CLASSES[1] == "skin"


def test_manifest_and_required_files():
    man = json.loads((BLOCK / "block.json").read_text(encoding="utf-8"))
    for key in ("name", "version", "task", "status", "adapter", "mock", "deps", "apple_native",
                "weights"):
        assert key in man
    assert isinstance(man["deps"], list) and man["deps"] == []      # self-contained block
    assert man["adapter"].startswith("blocks.face_parsing.")
    assert man["apple_native"]["verdict"] == "partial"
    for rel in ("block.json", "README.md", "src/__init__.py", "src/model.py", "src/mock.py"):
        assert (BLOCK / rel).exists(), f"missing {rel}"
