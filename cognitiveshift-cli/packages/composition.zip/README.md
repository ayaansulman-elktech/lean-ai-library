# composition

A lean-ai-factory block.
