# skill-name-here

One line — what it does AND when to trigger it. Used for discovery.
