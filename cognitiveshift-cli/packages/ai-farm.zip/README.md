# AI Farm

Productionized models, each packaged as an MCP-compatible capability.
