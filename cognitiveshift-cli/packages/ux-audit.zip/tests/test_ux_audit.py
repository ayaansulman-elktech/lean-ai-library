from agent_core import AgentContext
from ml_core import CostMeter, ProvidersConfig, build_gateway
from ml_core.config import ModelSpec
from ux_audit.agent import UXAuditAgent

HIGH = ('{"scores":{"hierarchy":5,"patterns":5,"rhythm":5,"contrast":5,"consistency":5,'
        '"scannability":4,"readability":5,"emphasis":4,"flow":5,"hig":5},'
        '"notes":"Clean, HIG-native."}')   # avg 4.8 -> A
LOW = ('{"scores":{"hierarchy":2,"patterns":2,"rhythm":2,"contrast":2,"consistency":2,'
       '"scannability":2,"readability":2,"emphasis":2,"flow":2,"hig":2},'
       '"notes":"Non-native, low contrast."}')  # avg 2 -> D


def _ctx(responder):
    cfg = ProvidersConfig(gateway="mock",
                          models={"deepseek": ModelSpec(provider="deepseek", model="deepseek-chat")})
    meter = CostMeter(budget_usd=1.0)
    return AgentContext(gateway=build_gateway(cfg, meter, offline=True, responder=responder),
                        meter=meter, default_model="deepseek")


def test_high_scores_grade_A():
    r = UXAuditAgent(_ctx(lambda a, m: HIGH)).run("<html>...</html>")
    assert r.success
    assert r.output["grade"] == "A"
    assert r.output["average"] >= 4.5


def test_low_scores_grade_D():
    r = UXAuditAgent(_ctx(lambda a, m: LOW)).run("plain screen description")
    assert r.success
    assert r.output["grade"] == "D"


def test_saliency_deferred_without_model_or_screenshot():
    r = UXAuditAgent(_ctx(lambda a, m: HIGH)).run("x")
    assert r.output["saliency"]["status"] == "deferred"


def test_checklist_has_patterns_rhythm_and_hig():
    from ux_audit.models import CRITERIA
    assert {"patterns", "rhythm", "hig"} <= set(CRITERIA)
    assert len(CRITERIA) == 10
    r = UXAuditAgent(_ctx(lambda a, m: HIGH)).run("x")
    assert {"patterns", "rhythm", "hig"} <= set(r.output["scores"])


def test_writes_scored_html_report(tmp_path):
    agent = UXAuditAgent(_ctx(lambda a, m: HIGH), report_dir=str(tmp_path))
    r = agent.run({"screen": "<html>...</html>", "name": "Onboarding"})
    path = r.output["report_path"]
    assert path.endswith("ux-report.html")
    html = (tmp_path / "ux-report.html").read_text(encoding="utf-8")
    assert "UX Audit — Onboarding" in html
    assert ">A<" in html or "A </div>" in html or "A " in html   # grade rendered
    assert "patterns" in html and "rhythm" in html               # all 10 criteria in the table


def test_saliency_attention_check_runs_with_a_model():
    from vis_models.saliency import MockSaliencyModel, Region

    cta = [0.25, 0.80, 0.50, 0.12]
    # Mock attention landing on the CTA -> the attention check passes.
    sal = MockSaliencyModel(grid=40, hot_regions=[Region(*cta)])
    agent = UXAuditAgent(_ctx(lambda a, m: HIGH), saliency=sal)
    r = agent.run({"screen": "<html>...</html>", "screenshot": "screen.png", "cta_region": cta})
    assert r.success
    s = r.output["saliency"]
    assert s["status"] == "ok"
    assert s["passes"] is True
    assert s["primary_attention"] >= s["threshold"]

    # Attention parked away from the CTA -> the attention check fails (audit still returns).
    sal_cold = MockSaliencyModel(grid=40, hot_regions=[Region(0.0, 0.0, 0.2, 0.2)])
    r2 = UXAuditAgent(_ctx(lambda a, m: HIGH), saliency=sal_cold).run(
        {"screen": "x", "screenshot": "screen.png", "cta_region": cta})
    assert r2.output["saliency"]["passes"] is False


def test_report_embeds_a_heatmap_image(tmp_path):
    from vis_models.saliency import MockSaliencyModel, Region
    cta = [0.25, 0.80, 0.50, 0.12]
    sal = MockSaliencyModel(grid=32, hot_regions=[Region(*cta)])
    agent = UXAuditAgent(_ctx(lambda a, m: HIGH), saliency=sal, report_dir=str(tmp_path))
    r = agent.run({"screen": "<html>..</html>", "name": "Home",
                   "screenshot": "screen.png", "cta_region": cta})
    assert r.output["saliency"]["heatmap"].startswith("data:image/png;base64,")
    html = (tmp_path / "ux-report.html").read_text(encoding="utf-8")
    assert '<img class="heatmap"' in html and "data:image/png;base64," in html


def test_bad_screenshot_reports_error_not_crash():
    # No injected model -> auto-builds the classical model, which reads pixels; a missing file
    # must surface as saliency 'error' and never fail the whole audit.
    r = UXAuditAgent(_ctx(lambda a, m: HIGH)).run(
        {"screen": "x", "screenshot": "does-not-exist.png", "cta_region": [0.2, 0.8, 0.5, 0.1]})
    assert r.success
    assert r.output["saliency"]["status"] == "error"
    assert r.output["grade"] == "A"        # the UX score still comes through
