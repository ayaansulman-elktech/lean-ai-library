"""Render a UX-audit result into a self-contained HTML report.

HTML (not a bespoke PDF library) keeps this dependency-free and CI-safe; produce a PDF by
rendering this HTML with the same headless browser used for screenshots (the render step).
"""

from __future__ import annotations

from pathlib import Path

from ux_audit.models import CRITERIA

_TEMPLATE = Path(__file__).resolve().parents[2] / "assets" / "report-template" / "report.html"


def render_html(screen_name: str, result: dict) -> str:
    scores = result.get("scores", {})
    rows = "".join(
        f"<tr><td>{c}</td><td>{int(scores.get(c, 0))}/5</td></tr>" for c in CRITERIA
    )
    sal = result.get("saliency", {})
    heatmap = ""
    if sal.get("status") == "ok":
        verdict = "PASS" if sal.get("passes") else "FAIL"
        saliency = (f"Attention on primary action: {sal.get('primary_attention')} "
                    f"(target {sal.get('threshold')}) — {verdict}. "
                    f"Focal point {sal.get('focal_point')}, dispersion {sal.get('dispersion')}.")
        if sal.get("heatmap"):
            heatmap = (f'<img class="heatmap" alt="predicted attention heatmap" '
                       f'src="{sal["heatmap"]}">'
                       '<div class="legend">Cool = ignored · warm = high predicted attention · '
                       'white box = primary action.</div>')
    else:
        saliency = sal.get("detail", "deferred")

    return (_TEMPLATE.read_text(encoding="utf-8")
            .replace("{{SCREEN}}", screen_name)
            .replace("{{GRADE}}", f"{result.get('grade', '?')}")
            .replace("{{AVERAGE}}", f"{result.get('average', '?')}")
            .replace("{{NOTES}}", result.get("notes", ""))
            .replace("{{ROWS}}", rows)
            .replace("{{SALIENCY}}", saliency)
            .replace("{{HEATMAP}}", heatmap))


def write_report(out_dir, screen_name: str, result: dict) -> str:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "ux-report.html"
    path.write_text(render_html(screen_name, result), encoding="utf-8")
    return str(path)
