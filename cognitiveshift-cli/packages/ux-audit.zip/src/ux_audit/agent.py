"""UXAuditAgent — score an iOS screen against the UX checklist (the LLM part).

Scores a screen (HTML or description) 0-5 on the ten checklist criteria (nine core UX criteria
+ `hig`) and grades A-F. The criteria are anchored to Apple's Human Interface Guidelines.
Optionally runs the SUM saliency attention check, and emits a self-contained HTML report
(rendered to PDF later via the same headless browser as the screenshot render step).
"""

from __future__ import annotations

from agent_core import Agent, AgentContext

from ux_audit.models import CRITERIA, UXReport

SYSTEM = (
    "You are a UX auditor for native iOS apps. Judge the SCREEN against Apple's Human Interface "
    "Guidelines (HIG). Score each criterion 0-5 (5 = excellent, 0 = absent/broken), judging only "
    "what is actually present:\n"
    "- hierarchy: clear visual priority; one focal action; large-title / section structure.\n"
    "- patterns: uses familiar, platform-standard UI patterns users already recognize "
    "(97%-familiar); no novel or confusing interactions.\n"
    "- rhythm: consistent spacing/alignment cadence down the screen; even margins and grouping.\n"
    "- contrast: meets WCAG AA (4.5:1 text); legible in light and dark mode.\n"
    "- consistency: uses native components, SF Symbols, and system patterns over custom ones.\n"
    "- scannability: content grouped in standard lists/cards; not a wall of text.\n"
    "- readability: respects Dynamic Type; body >= 17pt feel; sensible line length.\n"
    "- emphasis: the primary call-to-action is unmistakable and uses the tint role.\n"
    "- flow: standard navigation (tab/stack); back/dismiss obvious; reachable in few taps.\n"
    "- hig: overall HIG conformance — 44pt minimum hit targets, safe-area respect, no non-native "
    "patterns, platform-correct controls, and accessible labels.\n"
    'Return ONLY JSON: {"scores": {' + ", ".join(f'"{c}": 0-5' for c in CRITERIA) + '}, '
    '"notes": "<one or two sentences, cite the weakest HIG issue>"}.'
)


class UXAuditAgent(Agent):
    name = "ux-audit"

    def __init__(self, ctx: AgentContext, *, model: str | None = None, saliency=None,
                 report_dir: str | None = None) -> None:
        """`saliency` is an optional vis_models SaliencyModel. When a screenshot is present the
        audit runs the attention check — using the injected model, else a real pixel-based
        `ClassicalSaliencyModel` (SUM when its weights are on the box). Without a screenshot it is
        reported deferred. `report_dir` (or a per-task "report_dir") writes a scored HTML report."""
        super().__init__(ctx)
        self.model = model
        self.saliency = saliency
        self.report_dir = report_dir

    def _run(self, task) -> dict:
        # Accept a plain screen (text/HTML) or a dict carrying an optional rendered screenshot:
        #   {"screen": str, "screenshot": path, "cta_region": [x, y, w, h]}  (normalized coords)
        if isinstance(task, dict):
            screen = task.get("screen", "")
            screenshot = task.get("screenshot")
            cta_region = task.get("cta_region")
            report_dir = task.get("report_dir", self.report_dir)
            screen_name = task.get("name", "screen")
        else:
            screen, screenshot, cta_region = task, None, None
            report_dir, screen_name = self.report_dir, "screen"

        rep = self.llm_json(system=SYSTEM, user=f"SCREEN:\n{screen}",
                            model=self.model, schema=UXReport)
        obj = UXReport(**rep)
        out = {"scores": rep["scores"], "notes": rep.get("notes", ""),
               "average": round(obj.average(), 2), "grade": obj.grade(),
               "saliency": self._saliency(screenshot, cta_region)}
        if report_dir:
            from ux_audit.report import write_report
            out["report_path"] = write_report(report_dir, screen_name, out)
        self.ctx.tracker.log_metrics({"ux_average": out["average"]})
        return out

    def _saliency(self, screenshot, cta_region) -> dict:
        """Run the attention check when a screenshot is available; else deferred.

        Predicts an attention heatmap from the screenshot (injected model, else a real pixel-based
        classical model / SUM when present), checks whether attention peaks on the primary action,
        and returns a colour-mapped heatmap data-URI for the report. A bad/unreadable screenshot is
        reported as `error` rather than failing the whole audit.
        """
        if not screenshot:
            return {"status": "deferred",
                    "detail": "attach a screenshot to run the attention check "
                              "(SUM=stills; ViNet/video still deferred)"}
        from vis_models.saliency import Region, analyze, build_saliency, heatmap_data_uri
        model = self.saliency or build_saliency("classical")
        region = Region(*cta_region) if cta_region else None
        try:
            smap = model.predict(screenshot)
        except Exception as e:  # noqa: BLE001 — a bad screenshot must not fail the audit
            return {"status": "error", "detail": f"saliency skipped: {type(e).__name__}: {e}"}
        report = analyze(smap, region)
        self.ctx.tracker.log_metrics({"saliency_pass": 1.0 if report.passes else 0.0})
        return {"status": "ok", "heatmap": heatmap_data_uri(smap, region), **report.to_dict()}
