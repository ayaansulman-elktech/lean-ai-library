"""UX audit report schema + grading."""

from __future__ import annotations

from pydantic import BaseModel

# Scored 0-5 each. The first nine are the core UX checklist criteria; `hig` is Apple Human
# Interface Guidelines conformance (native components, SF Symbols, 44pt targets, safe areas,
# Dynamic Type, standard navigation) — the factory ships iOS apps, so platform fit is first-class.
CRITERIA = ["hierarchy", "patterns", "rhythm", "contrast", "consistency",
            "scannability", "readability", "emphasis", "flow", "hig"]


class UXReport(BaseModel):
    scores: dict[str, int]   # criterion -> 0..5
    notes: str = ""

    def average(self) -> float:
        vals = [int(self.scores.get(c, 0)) for c in CRITERIA]
        return sum(vals) / len(vals) if vals else 0.0

    def grade(self) -> str:
        a = self.average()
        return "A" if a >= 4.5 else "B" if a >= 4 else "C" if a >= 3 else "D" if a >= 2 else "F"
