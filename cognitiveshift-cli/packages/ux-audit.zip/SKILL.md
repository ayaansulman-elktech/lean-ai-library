---
name: ux-audit
description: Audit a screen (or screen video) against the UX checklist and saliency, return a scored PDF. Use after a screen is designed and before sign-off.
allowed-tools: Read, Write, Bash
---
# UX audit

A real agent (`src/ux_audit/`, on `agent-core`): scores a screen 0-5 on the ten HIG-anchored
checklist criteria (`references/ux-checklist.md`, incl. `hig` conformance) and grades A-F.

```python
from ux_audit import UXAuditAgent
res = UXAuditAgent(ctx).run(screen_html_or_description)   # res.output["grade"], ["scores"], ["average"]
```

**Saliency attention check — live, from real pixels.** Add a rendered screenshot and the audit
predicts an attention heatmap, checks it peaks on the primary action, and embeds a colour-mapped
heatmap image in the report:

```python
res = UXAuditAgent(ctx).run({"screen": html, "screenshot": "screen.png",
                             "cta_region": [0.25, 0.80, 0.50, 0.12]})
res.output["saliency"]   # {status, passes, primary_attention, focal_point, heatmap: "data:image/png;base64,..."}
```

Backends (`vis_models.saliency.build_saliency`), best → simplest:
- **SUM** — deep model for stills; used when its weights are in `libraries/ios-ready/raw/SUM`.
- **classical** *(default)* — a real, pixel-based center-surround + edge saliency, **stdlib-only**,
  so it runs anywhere (no torch/weights). This is what `UXAuditAgent` auto-builds when you pass a
  screenshot but no model.
- **mock** — deterministic, pixel-ignoring; for unit tests/demos (`offline=True`).

The report renders the heatmap (cool = ignored, warm = high attention, white box = the CTA) so it
**shows the weak areas**, not just scores them. **ViNet (onboarding video) stays deferred.**
