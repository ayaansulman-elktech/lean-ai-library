#!/usr/bin/env python3
"""saliency.py — CLI over the canonical saliency adapter (`vis_models.saliency`).

The integration now lives in the models library (`libraries/models/src/vis_models/saliency`):
SUM for stills, a dependency-free mock offline. This script is a thin CLI for spot-checking a
screenshot from the terminal; agents import `vis_models.saliency` directly.

Usage:
  python saliency.py <image.png> [--cta x y w h] [--backend sum|mock]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Make vis_models importable when run straight from the repo (no install needed).
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "libraries" / "models" / "src"))

from vis_models.saliency import Region, analyze, build_saliency  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("image")
    ap.add_argument("--backend", default="sum", choices=["sum", "mock"])
    ap.add_argument("--cta", nargs=4, type=float, metavar=("X", "Y", "W", "H"),
                    help="primary-action box in normalized [0,1] coords")
    args = ap.parse_args()

    model = build_saliency(args.backend)        # falls back to mock if SUM weights are absent
    region = Region(*args.cta) if args.cta else None
    report = analyze(model.predict(args.image), region)
    print(json.dumps(report.to_dict(), indent=2))
    return 0 if report.passes else 2


if __name__ == "__main__":
    sys.exit(main())
