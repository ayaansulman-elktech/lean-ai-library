# UX checklist

Score each screen 0–5 on ten criteria — nine core UX checklist criteria plus `hig`:

- Hierarchy, Patterns, Rhythm, Contrast, Consistency, Scannability, Readability, Emphasis, Flow
- HIG: native components, SF Symbols, 44pt hit targets, safe areas, Dynamic Type
- Reading pattern: does the eye follow F/Z toward the primary action?

**Saliency** (`vis_models.saliency`): the predicted attention heatmap must peak on the primary
action — `analyze(map, cta_region).passes` enforces it, and the report embeds the colour-mapped
heatmap so weak spots are visible. Backends: **SUM** (deep, stills, weights in
`libraries/ios-ready/raw/SUM`) → **classical** (real pixel-based center-surround + edge, stdlib-only,
the default when SUM is absent) → **mock** (deterministic, pixel-free, for CI/tests). **ViNet**
(onboarding video) stays deferred.
