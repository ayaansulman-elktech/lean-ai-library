# Wireframing (corpus)

> The knowledge the wireframing agent + `libraries/mcp/wireframing` draw on when turning a
> charter into a screen flow. This is the *why*; the machine-applied thresholds live in
> `agents/wireframing/references/flow-rules.md` and are enforced by `wireframing/audit.py`
> (mirrored in the Wireframing MCP and the `wireframe-studio` editor).

---

## What a wireframe is (and isn't)

A wireframe fixes **structure and flow** before any visual design: which screens exist, what
each contains, and how a user gets from one to the next. It is deliberately low-fidelity —
grey boxes, real labels, real links — so review focuses on *the flow*, not colour or polish.
Skinning (tokens, type, imagery) happens later, once the flow scores **"A"**.

Three failure modes a wireframe must eliminate:
- **Buttons to nowhere** — an action with no target (a dead link).
- **Orphan screens** — a screen nothing links to (unreachable from the start).
- **Buried actions** — the primary task takes too many taps to reach.

## Flow rules (the "A" bar)

| Rule | Threshold | Why |
|---|---|---|
| Clicks to a key action (login / checkout / capture / cancel) | ≤ 3 | The core job must be near-instant; each extra tap sheds users. |
| Interactive elements per screen | ≤ 7 | Cognitive load — a screen that does one thing well beats a busy one. |
| Max navigation depth | ≤ 4 | Deep trees get people lost; keep the map shallow. |
| Orphan screens / dead links | 0 | Every screen reachable, every control leads somewhere. |
| A primary **action** is defined & reachable | required | The audit measures clicks-to-*action*; without one there's nothing to grade. |

Grade drops one letter per rule broken (A→B→C→D→F). Hand off only at **A**.

## Layout heuristics

- **One primary action per screen.** Make it the visually dominant, thumb-reachable control;
  everything else is secondary. Attention should land on it first.
- **Progressive disclosure.** Show the minimum now; reveal detail on demand. Don't front-load.
- **Consistent placement.** Nav bar on top, primary action bottom, back on the left — the same
  everywhere, so the app is predictable.
- **Group by task, not by data.** Screens map to *what the user is doing*, not to database tables.
- **Shallow over wide.** Prefer a few clear steps to one crowded screen or a deep tunnel.

## iOS-native patterns (this factory ships Apple-native apps)

- **Tab bar** (2–5 tabs) for top-level, co-equal sections; use it, don't reinvent global nav.
- **Navigation stack** (push/pop with a back button) for drill-down hierarchies.
- **Modal sheet** for a self-contained, interruptible task (compose, filter, sign-in) — with a
  clear cancel.
- **List / table** for homogeneous, scannable content; a row that navigates gets a chevron.
- **Primary button** = filled/prominent; **secondary** = plain. One prominent button per screen.
- Respect Apple HIG: standard components, safe areas, thumb zones. (Compliance is gated later by
  the `apple-compliance` agent; a HIG-shaped wireframe passes more easily.)

## A good starter flow

`Launch → (onboard if first run) → Home (the core job, one primary action) → Result → back to Home`,
with Settings/Account reachable in ≤2 taps from Home. Keep the happy path to the key action ≤3 taps.

## How this corpus is used

1. The **wireframing agent** turns a charter into a `WireframeSpec` guided by these rules, generates
   one link-complete HTML page per screen, then loops on the flow-audit until grade "A".
2. The **Wireframing MCP** exposes the same operations (place elements, link screens, audit, export)
   so any agent — or the human `wireframe-studio` editor — edits one shared spec.
3. A human adjusts the flow in the studio; the "A"-grade result feeds the sprint gate
   (ux-audit → apple-compliance → security).

> Add sourced entries as the corpus grows — keep them small and mergeable, like `color-theory/`.
