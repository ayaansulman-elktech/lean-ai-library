# Wireframing (theory)

> Source reference (UX/UI): `Wireframing.pdf`. Full text — the corpus the wireframing / design agents draw on. The curated flow-rules cheat-sheet lives in `wireframing.md`; machine-applied flow thresholds live with the wireframing agent.

---

#UI  #UX  #Design  #Wireframe  #tool
Browsing a well-crafted, intuitive, and compelling interface is like reading a
great story. Wireframing is a crucial step of product development that allows
team members to figure out what their website or app will tell users through
multiple drafts and sketches.
To do this, the team should balance out user needs and business
requirements while integrating user journeys that they want and should take.
Arrange a brainstorming session with your colleagues and
generate ideas and insights by focusing on questions like:
How would you explain to a friend what the product helps with?
How can it make life easier for people?
What can users do on your website?
What goals can they accomplish?
Before jumping into wireframing, you can start by jotting down the team's
ideas in a text editor and write an actual story.
What is a wireframe?

A wireframe, also known as a wire, is a simplified black and white version of
designs that work as a bridge between developers, designers, project
managers, and clients. They ensure everyone is on the same page while
discussing the overall structure and functionality of the future product.
Wireframes define dimensions and placement of page elements, information
architecture, intended behaviors, and navigation for your website. Usually,
they're stripped of any decorative elements like logos, visuals, fonts, and
colors that could distract team members at this point of the product
discussion.[1]
Focus on the content and keep wireframes monochromatic — aesthetics
should come later.
Wireframes explore concepts
Wireframing is a part of the exploratory phase. It's the time when the team
collaborates on ideas and concepts, explores competitors, evaluates
business requirements, and decides on how to implement each feature.
Due to technical or business limitations, you may develop a couple of
variants for crafting a search functionality or profile page. Wireframing
provides a low-cost and speedy method to sketch all ideas, test them on
team members, clients, or users, and decide the winner.
Low-fidelity wireframes are perfect for exploring concepts. You can create
rough drafts with simplistic images and block shapes with only a pen and
paper.

Wireframes make the design process iterative
The iterative design process is an approach that designers and developers
use to continually improve a product's design. It includes creating
prototypes, testing them, analyzing team and user feedback, and refining
the product as a result. While any part of the design process can be
iterative, it's worth starting as early as possible — full design mock-ups take
more time to be reworked than simplified wireframes.
Wireframes let you test and improve 4 things — the structure, layout,
content, and functionality of your website or app, without touching the

creative and branding aspects of the product.
Wireframes display site architecture
In the physical world, architects are responsible for planning building
structures and arranging rooms so people can navigate and use them for
living or working. Digital products also require a well-thought organization of
content throughout a page, referred to as information architecture.[1]
Based on information gathered during research about users' mental models
and behavioral patterns, information architects can craft wireframes to
demonstrate the hierarchy of content and navigation. They focus on
categorizing, distributing, and placing content so that users can navigate
between screens intuitively.
Wireframes clarify and define features
One of the greatest advantages of wireframes is their visual representation.
They make it much easier to demonstrate things like user paths, clarify and
define features, and stay on the same page when using terms like
"hamburger menu," "hero image," or "call to action."
Visualizing the features on a wireframe allows you to demonstrate how
things will eventually work and may prompt you to remove unnecessary
elements, develop new ideas, and restructure certain areas. Wireframing

helps save time and effort, allowing you to spot technical inconsistencies
and potential difficulties during the exploratory stage. Plus, establishing a
rapport with clients and speaking the same language will contribute to more
efficient product development.
Wireframes keep usability at the forefront
Usability measures how well users in a specific context can use a product to
achieve a defined goal efficiently and satisfactorily. Creating wireframes
allows you to answer the 2 most common questions software builders come
across:
What are some ways to solve the problems faced by our customers? To
answer this question, you need to generate as many ideas as possible.
The more ideas you have, the easier it will be to see the faults and
highlights of each.
How do I know if this solution actually solves their problems? To
answer this question, you show your wireframes to others to validate
and improve your ideas. That's when everyone looks objectively at a
website's ease of use, conversion paths, naming of links, visual
hierarchy, navigation, and feature placement.
Wireframes can point out flaws in your site architecture or how a specific
feature may work. Finding these issues early on is always better.
Wireframes allow for rapid testing
So, you have some unique ideas about a future product design, the team is
on board, and the client is excited. How can you verify that those ideas will
satisfy your users' needs and help them complete their tasks efficiently?
Wireframing is the cheapest tool that designers can use for rapid testing,
evaluating their assumptions, and adjusting concepts until they meet users'
expectations.
You don't need to dwell on images, colors, or interactive elements to get user
feedback right away. Wireframes are usually a single-use tool that should be
easy to craft and update. You can attach wireframes to surveys, use them
while interviewing users, or share them with clients — do whatever you think
will help you get feedback, then make adjustments, and test again.

Sketch fast and don't get attached to your wireframes — they're meant
for testing and are part of an iterative process.
Wireframes keep the concept user-focused
Wireframes are excellent communication devices — they facilitate user
feedback, instigate conversations with the stakeholders, and generate ideas
between designers. Conducting user testing during the early wireframing
stage allows designers to get honest feedback and identify key pain points,
which in turn can help develop the product concept.[1]
To collect qualitative data, you should ask open-ended questions. For
example, instead of showing a page with text and asking if users find it
helpful, you can use placeholder text and ask what kind of content users
expect to be there. This kind of insight helps designers understand what
feels intuitive to users and create comfortable and easy-to-use products.
Wireframes address scalability and ease-of-
updates
Another upside of using wireframes is that they allow you to immediately
identify how well your site will handle content growth. Scalability and
flexibility are especially crucial for clients who need content-managed
websites, where they can publish, edit, and modify content without changing
the code.
If your website offers a couple of products now, but you plan to expand in
the future, you need the website to accommodate the growth of your line of
products without impacting the design, site architecture, or usability.
Wireframes will identify these critical areas of content growth.
Using low-fidelity wireframes
When should you use low-fidelity wireframes? This type of wireframe
explains the basic functionality and includes simple explanations of the main
steps, phases, requirements, and layout.
Using low-fidelity wireframes is a good idea if:

You're at the very beginning of the design process. Start with low-
fidelity wireframes as your first draft and add more details in subsequent
iterations.
You have a lot of wireframes to create. If you're working on a big
project, it might make sense to start with low-fidelity wireframes for
most pages and then add only to wireframes that need more clarity.
You need to complete a project quickly. The fewer details wireframes
have, the faster they are to make.
Medium-fidelity wireframes
Medium-fidelity wireframes are essentially more detailed low-fidelity
wireframes. For example, they might have real copy instead of placeholder
text, be in grayscale or even contain some colors instead of a monochrome
palette to better convey visual hierarchy. The purpose of medium-fidelity
wireframes is to help communicate to teams how aesthetic features can
support essential functionality.
Using simple but detailed medium-fidelity wireframes is a good idea if:
You're putting together a wireframe map — a visual sitemap with
wireframes for each page.[1] In cases like this, low-fidelity wireframes
aren't detailed enough to follow, especially if you want to gather user
feedback.
It's the next step in a comprehensive design process. If your project has
the time and budget, medium-fidelity wireframes are the next iteration
after low-fidelity wireframes are established. Adding a bit more detail to
your wireframes may help with fleshing out your design ideas.
link to wireframe: https://www.justinmind.com/wireframe
High-fidelity wireframes
High-fidelity wireframes reveal how the product will look at project
completion. This type of wireframe is created with digital tools and usually
takes more effort to make. They typically incorporate the final color palette
and possibly some images.
The look of high-fidelity wireframes is similar to prototypes, but don't be
confused. Wireframes and prototypes are used at different stages of the

design process, and their aims and focuses differ. Wireframes are static, and
their purpose is to convey the structure of the page.
Prototypes are interactive — their goal is to show UI elements' interactions,
style, and positioning. Prototypes are great for validating usability and the
overall value of solution design.
When should you use high-fidelity wireframes?
At the end of the design process, when you've already established how
the design needs to look, and the functionality comes to the forefront of
the design conversation.
When you need to test complex user interactions. More detail allows for
more accurate judgment of the UI elements.
If you have the time and budget. High-fidelity wireframes consume a lot
of design time and are more expensive to produce.
You're working with a partner you want to impress. High-fidelity
wireframes give this third party a better visualization of the final product
and speaks of your professionalism.
You're working on a personal project. When you are in charge of your
own deadlines, you can decide how much time and effort you're willing
to put in. High-fidelity wireframes are great for explaining your product's
potential to investors.
Dummy content
Dummy content refers to placeholder text and images that share some
characteristics of real content. Image placeholders — like the image with
the mountain and the sun or the one with two diagonal lines — are
commonly used in low and medium-fidelity wireframes, while there's some
debate over text placeholders like Lorem ipsum.
Dummy text
Every designer has used lorem ipsum at least once during their career.
Dummy text is a combination of modified Latin words that work as
placeholder text and is expected to be replaced by the actual copy. On the
plus side, it can be useful in wireframes that are in the early stages of
planning and brainstorming ideas.

On the flip side, dummy text doesn't provide enough detail and may result in
multiple adjustments in the future.
🧬 Trick: If you don't have content yet, use similar length text with a
similar tone of voice, or borrow from competitors' websites.
Use actual copy early in the process
Balsamiq recommends[1] using the actual copy that will appear in the final
design early in the design process for two reasons. First, it lets you see how
real content will fit the layout. Second, relevant content encourages more
thoughtful feedback during wireframe review sessions. If the copy isn't ready
yet, it's better to quickly draft text similar to length and tone of voice so
people can give their opinions on what it conveys.
Text wrapping
When designing for mobile and web, ensure your wireframes illustrate how
the text would display responsively on various devices. There are a few
things to consider, like appropriate font size for body text, line length, and
height. When it comes to wireframing, the most important thing is making
the text wrap and maintaining the hierarchy.

Headlines: Use truncation and add an ellipsis (…), making sure users can
still view the full title on hovering or seeing tooltips. There must be at
least 4 characters of non-truncated content in a truncated string.
Text blocks: Use truncation and the "Show more" button to indicate that
people can view overflow content below the fold or on another page.[1]
Apply truncation to breadcrumbs, pagination, and long URL links.
Edge cases
When you're working on how to fit your content nicely and escape text
clashing or overflowing, think outside the box and consider edge cases.
Simply put, edges cases are anything that can and probably will go wrong
during product presentation, user testing, or further development stages.[1]
Error texts: Errors will happen inevitably, and you should indicate where
a notification or field validation message will appear.
Character numbers: You should consider scenarios when text blocks are
empty, have a small amount of text, or oppositely, the character limit is
reached.
Accessibility: Make sure your product is available to all users, and your
wireframes include alt text for images, links, and buttons.

Task flow
A task flow is a diagram that shows a linear sequence of steps that
illustrate how a user will complete a particular task — for example, a login
task flow. Task flows use natural language and don't show any design. They
also don't usually explore deviations from the ideal path — for example, if a
user forgets their password.
Task flows are useful in planning optimal paths for task completion. One way
to create task flows is to conduct task analysis to observe how users
perform their tasks and achieve their intended goals.[1]

Wireflow
The term 'wireflow' comes from the combination of words 'wireframe' and
'flowchart,' coined by Nielsen Norman Group.[1] As the name suggests,
wireflows combine the benefits of both wireframes and flow diagrams.
Wireflows show visual UI changes as users interact with an application or
website. They can also contain annotations to indicate what happens in the
back-end at that time. Think of wireflows as illustrated task flows and
flowcharts.
Wireflows are particularly useful when documenting mobile, desktop, or web
apps that don't have many unique pages but instead feature a few core
pages that change content dynamically based on user interaction. This
allows designers to show design in the context of common user tasks.
Simplified wireflow
Simplified wireflows allow you to take a more abstract approach,
diagraming the flow using smaller screen representations. This type of
simplified wireflow is something of a hybrid between a task flow and a
regular wireflow. Instead of creating custom wireframes for different screens,

you basically create a task flow illustrated with symbols representing
different screen types.
In the example, you can see a simplified purchase flow that starts with users
searching for the item on the home page and ultimately ends with the
purchase confirmation screen.
Wireflow organization and usage
The classic use case for wireflows is to document the journey of a user
working through a common task on the product — for example, adding a
song to a playlist.
Simple wireframes show the screens available to users at each step in the
workflow. Arrows connect specific UI components that users interact with —
for example, tap a button or a link — with wireframes that show what
happens as a result of the interaction. Wireframes in the flow don't need to
show separate pages. Very often, the page stays the same but the content
changes, reflecting feedback to users' actions (a ticked checkbox or a popup
menu).
You can also use wireflows to document complex workflows of desktop and
web apps. No need to show a full-screen wireframe for each step — creating

wireframes for the portion of the screen that changes will provide enough
context.
Can you use wireflows for documenting task flows in traditional static
websites? It works for mobile but might not be the best idea when it comes
to desktop websites — when wireframes show different big pages, it's easy
to lose the context of the user flow.
Flowchart
Flowcharts are similar to task flows but more detailed. Besides the path
users take when interacting with the system, it also shows their decisions
on that journey (is a user signed in? yes/no) and the reactive back-end
processes they may trigger (send a request to the server).
Because of their nature, flowcharts allow us to document the user and
system flows more thoroughly, showing the branching of paths at decision
points and how data flows through the system. They're excellent for
representing the product's complexity, but the downside they share with
task flows is that they don't show any UI design.
Prototyping with wireframes

Wireframes usually precede the prototyping stage and present a general
idea of a future product, working as a skeleton for building up more relevant
content. Wireframes use simple blocks and contain minimum interactivity —
just enough to test ideas without diverting users' attention to colors and
typography.
On the contrary, prototypes are more high-fidelity and reminiscent of a
nearly finished product. Hence, they allow you to conduct more effective
user testing with interactions and functionality.
The best approach is an iterative process, where each iteration includes a
new level of fidelity. Start with low-cost wireframes, test assumptions, refine,
and improve. Since it's more costly to make changes to prototypes, approach
them only once you've already tested your ideas a couple of times.
Wireframing for navigation design
Navigation design is the discipline responsible for organizing information
on a page so users can easily navigate through a website or app and find
the information they need. Simply put, navigation helps users get from point
A to point B in the least frustrating way.
Using wireframes, designers decide on things such as:
Logical and consistent placement of the primary navigational links

Placement of secondary navigational elements, such as submenus,
breadcrumbs, and search
The expected behavior of navigational elements
With wireframes, designers can establish consistency among pages. The
same navigational elements should be at the same location. For example,
most users expect the logo to sit in the header or the search to be in the
upper right area of a page. It means the logo and the search buttons should
be at these locations on each page.
Tabs, menus, accordions, breadcrumbs, buttons, and other navigational
elements should behave the way users expect them to. If users click on a
menu, they assume to see the list of options and don't expect to be
redirected to another page. Otherwise, they experience friction and are likely
to abandon the site.[1]
Wireframing for interaction design
Interaction design (IxD) refers to the practice of designing interactive
digital products and services with a focus on improving the interactive
experience between users and a product.[1]
Generally, IxD relies on 5 dimensions: words, visuals (including icons,
typography, images, etc.), physical objects (like computer, mouse, touchpad,

etc.), time (relates to animations, videos, and sounds), and behavior.
At the wireframing stage, interactive designers don't focus on depicting
graphical elements, though. Instead, they try to understand user needs and
define interactions to satisfy those needs.
Usability.gov suggests considering the following questions when working
on interactions, for example:
What commands can users give to interact with the interface?
What information do you provide to let users know what will happen
before they perform an action?
Are there constraints put in place to help prevent errors?
Is information chunked into a few items at a time?[1]
Wireframing for information design
Information design is a practice that strives to represent content in the
most efficient manner. The discipline is closely related and overlaps with
communication design, data visualization, and information architecture.[1]
If you look around, you'll notice that we're surrounded by information.
However, if it's presented poorly it's hard to digest and users will struggle
with your product.

Wireframing helps information designers make sense of data for users. With
wireframes, you can:
Plan content strategy
Proofread and review copy for each page
Organize and categorize information
Plan the layout of each unique page
Test organization and layouts with clients and users
Wireframes benefits for product managers
Wireframes are an easy way to communicate the functionality you are
looking for, and you don't need much experience to create them. It's a great
idea for product managers to share wireframes with designers, developers,
and other teams involved in the process. Together you can identify possible
issues and suggest solutions.
Wireframes also work great in agile environments. For example, a product
manager can use wireframes to plan what each team should tackle for each
product iteration. For example, tackle the Main page first, then add a
catalogue, etc.
When working in iterative chunks, you start getting feedback early in the
process. This allows you to refine the design and development process as

you go, saving time and money.
Wireframes benefits for developers
Involving developers in wireframing has several benefits:
Specification documents and emails are okay, but they can be hard to
visualize. Wireframes visualize technical requirements, user interactions,
and data flows. That's why wireflows can give developers a much better
idea about the final product.
Developers can spot problematic features and architectural flaws early
in the process and suggest improvements. Involving developers in the
wireframing stage will save you time and money on unnecessary
development.

Wireframes benefits for clients
Many designers have had bad experiences with clients interfering in the
design process. Still, it's possible to share wireframes with clients without
losing control of your project, and doing so has many benefits.
First, it allows you to tackle the problem from several different angles. Clients
may bring up potential issues that you haven't considered. To avoid
interference, use clients' help at the ideation phase when the goal is to
generate as many ideas as possible. Later you can refine, discard, and
combine them — until you have two or three that could work.
Second, sharing wireframes with clients gives them an understanding of the
product and a sense of ownership. A client who has seen a wireframe and
provided feedback is more likely to sign off on the final design — or even
defend it to others. It's less about implementing all of the clients'

suggestions and more about keeping them involved.
Step 1: Formulate a user story and its
acceptance criteria
Your client — a news and entertainment website — has decided to collect
more information about its users and encourage them to register. The
solution is to add Like and Comment options that all users can see but only
registered users can interact with.
In this sprint, you're tackling the following user story: As a registered user, I
want to log in, so I can like and comment.
The acceptance criteria:
Are fast, simple, and easy
Request as little information as possible
Don't interrupt the browsing experience
Talk with clients to outline a user story.

Step 2: Write the explanation of the user journey
Start with formulating the user journey from a user persona's perspective.
Mike, a 26-year old barista, is looking at a funny cat compilation article. One
cat is extremely fluffy, and Mike presses the Like button under the photo.
What happens next, provided that Mike is a registered user? Write it down.
When writing the user journey, use non-technical language and don't make it
too long. Its purpose is to concisely explain the solution offered to the users'

problem.
Step 3: Create a flowchart
After having written the explanation of the user journey, it's time to map it on
a flowchart. You don't need to map the entire Registration/Login flow, but a
small chunk that reflects your user story. It starts when users press the Like
or Comment buttons and ends when they have been logged in, redirected to
the page they were looking at.
Plan how users would move through screens and how their actions and other
conditions can influence their user journeys. Having done that, you'll get a
pretty clear idea about how many screens you need to wireframe. In this

case, it's the login screen, the retry login screen, and the confirmation modal.
Step 4: Create several different wireframes for
each screen
When you know how many screens you need, start by deciding what should
be on each page and get to sketching.
For the login page, some elements you might need are:
Third-party login with the most commonly used apps among our target
audience
A login form with email/username and password for registered users and
a Log In button
The link to recover the password
The link to sign up
The brand's logo
A meaningful headline
When you have decided what elements must be on each screen, create
several wireframe designs for each one. This will help you explore different
ways you could design each screen.

Step 5: Get inspiration from competitors
Don't shy away from looking up how other successful companies have
solved the problem you're trying to solve.[1] Find products and services that
are similar to what you offer and study the competition.
The objective isn't to copy the things your competitors do — it's to check if
you are missing anything in your design. For instance, after looking at some
examples, you might consider adding links to your Terms and Conditions and
Privacy Policy.
Another thing to look for is better ways to solve your users' problems. You
might get inspiration and end up overhauling your design.
How to checkout the competition: https://www.uxbooth.com/articles/how-
to-check-out-the-competition/

Step 6: Polish wireframes to the needed fidelity
After you have finalized the basic structure and functionality of your screens,
you can start adding details. At this stage, the wireframe should already
have the actual copy instead of Lorem ipsum.
Now it's time to perfect the layout and hierarchy and add brand colors. You
can add actual images instead of placeholders if you have the time and
they're available. However, there's no need for polishing the wireframes to
high fidelity at this stage. Simply add details that can help people to better
understand the user story.

Step 7: Annotate wireframes to prepare for
collaboration
In truth, it's very difficult to add meaningful annotations after you have
finalized the wireframe. The best practice is to annotate as you go and
finalize your notes once you have finished.
Annotations are there to explain things that are impossible to illustrate with
the wireframe, such as design rationale, scenarios, edge cases, or
interactions.[1] What happens when users interact with these elements? Is
this banner shown to all users or only those who are redirected from certain
pages? Annotate it. You've succeeded if developers or clients can read your
notes and understand not only what that element does but also why.
Check out our lesson about how to create meaningful annotations.

Document usability inspection findings
Documenting your testing is as essential as planning. First, it keeps things
recorded so you can refer to them at any time and share them with other
team members. Second, documented insights and notes may provide some
food for thought at later iterations. Third, documenting allows everyone to
follow the track of the inspection flow.
For example, if you conduct a heuristic evaluation, document the following:
Wireframe name or UI element
Violated usability heuristic
The issue's severity
Recommendations on how things can be improved
You'll also need this information for formulating the final report on usability
inspection findings.

Usability inspection
Usability inspection is great if your team doesn't have a lot of time or
resources. Usability inspection is the generic name for a set of methods for
idea evaluation and finding usability issues. The advantage is that you don't
need to contact users. Instead, the evaluation relies on usability principles
and user needs.
Usability inspection usually involves evaluators — experts in evaluating
interfaces — and a list of usability principles.
The most popular methods of usability inspection include:
Heuristic evaluation
Cognitive walkthrough
Feature inspection
Consistency inspection, etc[1]

Compose an evaluation plan #Evaluation
To conduct an efficient usability inspection, you need to plan it beforehand.
It will give you a sense of control over your work and help foresee
inconsistencies. It also lets you discuss the plan with your team. A plan will
help you define levels of severity, details of wireframes, what evaluators you
want to involve, and other important things.
You might need to have at hand:
1. User profile(s)
2. Goals
3. Scenarios
4. Wireframes
5. Evaluators
Ultimately, the usability inspection should define the scope — you can't test
all functionality at once. Based on user goals, you decide what features and
scenarios you want to include in the scope. Then select wireframes that you
need for this testing session. Leave out scenarios that are outside the scope
at this point.

Choose evaluators
Evaluators are individuals who have the expertise to perform usability
inspections. Typically, they are user researchers or designers who work on
the product. In reality, it's not possible to find an unbiased evaluator,
because we all are humans, after all.
Regardless of evaluators' skills and experience, their opinions can still be
skewed by their own biases. Another issue is that they're not typical users of
the product, which means that their simulated experience isn't 100%
accurate.
Companies can involve several independent evaluators to receive a more
comprehensive evaluation.
Cognitive walkthrough
Cognitive walkthrough is one of the usability inspection methods. Like
other methods, it allows evaluating interfaces without user involvement. A
cognitive walkthrough uses personas — user profiles — to represent users.
Then it assesses task performance by persona. In other words, evaluators
walk through specific wireflows as these personas. After each step, the

evaluators leave relevant notes in the walkthrough document. These notes
usually provide recommendations on how the journey can be improved.
At first glance, usability inspection seems like a perfect tool to test designs.
It's cheap, fast, and can be done at any stage of a product lifecycle.
However, there are some downsides.
First off, usability inspection methods are based on theoretical
principles. They can't replace an actual user interview or observation of
users performing tasks in your app. Ideally, inspection should be
followed by user testing.
Secondly, an evaluator is a human being, and they have their own
biases.
Thirdly, while heuristics and usability principles are universal they can
become outdated over time. A better strategy is to create heuristics
tailored to your product and brand.
Define user goals

Usually, goals define a need that users want to fulfill. But in inspection
evaluation, goals are what users actually get when they complete a task.
Also, having goals helps evaluators stay on track when they go through a
scenario. Basically, evaluators assess if it's easy to accomplish the goal — or
if the journey involves guesswork or friction.
When formulating goals, be specific and highlight the benefits for users. For
example, the goal "I want to write good essays" is too generic. Be more
specific — for example:
"I want to get topic recommendations."
"I want to improve my grammar and style."
"I need writing tips."
Annotations are for everyone
Annotations, like with any kind writing, require you to know your audience.
Who are these annotations for? People you should consider involving in
wireframing include clients, developers, visual designers, and copywriters.
Keep in mind that each party has different expectations from the
wireframes:

Clients want to understand if the design corresponds to their business
goals.
Developers want to see what they have to support and how the product
works.
Visual designers want to see what visual elements need to be on the
page.
Copywriters want to see what they need to write.
And, most importantly, the future you will need to remember why you made
that form element a checkbox instead of a radio button.
If you can communicate in person with your audience, consider presenting
your wireframes to them. You can use your annotations as talking points and
go into more detail if needed.
Choose the correct level of annotation detail
Annotating wireframes, just like wireframing itself, is an iterative process. As
a rule of thumb, your notes will get more detailed as the fidelity increases.
For example, you might start with a couple of comments about your thought
process on a paper sketch. As you move into digital tools, your annotations

will become more elaborate. After talking with developers, you might add
more technical information.
Here are some suggestions about what you need to concentrate on at
different fidelity levels:
In sketches, add comments on ideas, personas, and scenarios.
In low-fidelity wireframes, concentrate on initial design decisions and
explore various UI options.
In medium-fidelity wireframes, describe the functionality and layout
reasoning.
In high-fidelity wireframes, detail in-depth functionality, content and
design decisions, and scenario rationale.
In theory, any element can be annotated. However, let's not forget about
the limits of people's attention. You need to prioritize what has to be
annotated and what should be self-explanatory.
One of the types of elements that almost always needs annotation is
conditional items — for example, a banner that is only shown to certain users
but not others. Without extra information, it's impossible to guess under
which conditions it shows. And if the wireframe doesn't provide this
information directly, people who look at the wireframe should be able to find
it in the notes.
Annotate links and buttons
Users think of interactive elements in terms of "What happens if I tap this?"
But people involved in creating the product require more information.
When annotating interactive elements like links and buttons, ask yourself
questions like:
How many states does this element have?
What triggers the change of state?
What happens when users click, hover, or tap?
How are visited links displayed?
Where are users redirected?
Also include any other information that isn't obvious from the wireframe.

Describe content and functionality in your
annotations
So, what exactly should you describe in your annotations? You can separate
them into 2 main sections: content and functionality. Developers will mainly
look at the functional notes and copywriters at the content. Clients,
designers, and other stakeholders will look at both.
Annotations are often shown using numbers. The numbers in the wireframe
should have a sharp enough contrast to stand out from the design. You can
add colored circles around them and, if you like, use different colors for
different types of annotations. These numbers are then listed again on the
side or bottom of the wireframe with the text explanation.
Be smart about what you put in the wireframe and how. The clearer you
make the actual wireframe, the less you will have to explain in annotations.
Annotate anything with a business, logical, or technical constraint
Annotate anything with a business, logical, or technical constraint. For
example, full password requirements or the longest possible length of a
username.

In cases like this, annotations should capture not only what is being
displayed (and where and when) but also why. The more you can document
your thought process and the decisions you made, the easier it is to explain
your work, justify your choices, or fix it in case you’ve made a wrong
decision.
There is a vast difference between an annotation that reads, “Show first 10
new messages,” and one that reads, “Due to possibly hundreds of new
messages, only show the first 10.”
Heuristic evaluation
Heuristic evaluation is a method based on usability heuristics. Heuristics
are the general principles for interaction design. They are more like broad
rules of thumb and not specific usability guidelines. An evaluator uses
heuristics to measure design usability and assess problem severity. Simply
put, evaluators study a screen or an interaction and see if they meet usability
standards.
Jacob Nielsen's heuristics are the most commonly used list of usability
heuristics. They were written back in the 1990s and are still relevant,
although you might want to adjust them to current technologies.
The list includes 10 heuristics:

1. Visibility of system status
2. Match between system and the real world
3. User control and freedom
4. Consistency and standards
5. Error prevention
6. Recognition rather than recall
7. Flexibility and efficiency of use
8. Aesthetic and minimalist design
9. Help users recognize, diagnose, and recover from errors
10. Help and documentation[1]
User Research
Step 1: Identify the target audience and the
problem
Creating good wireframes requires a combination of research analysis and
intuition. You must first understand who you are designing for and what
problem you are trying to solve.
To get started, try to answer these questions:[1]
1. Who will be using this feature?
2. What's the users' goal? What problem does this feature solve for them?
3. What are some of the actions users are likely to perform?
If you can't answer these, you'll need to do more research. Common
methods that can help you gather this data are user and stakeholder
interviews and surveys, focus groups, contextual inquiry, and field studies.[1]
When you are satisfied with your responses to these questions, you are
ready for the next step.

Include front/back template
Step 2: Create a user flow
Before you start wireframing, you need to know how many screens need to
be designed and how users will interact with them. Creating a user flow is
one of the best ways to determine that.
A user flow shows the steps a user takes to achieve a specific goal.[1]
Mapping it out will help you understand what wireframes you'll need to
create and how they should be connected.
User flows aren't always linear because users might take different paths to
achieve the same goal. Considering different approaches will help you make
sure you didn't miss any screens.
You can create user flows on paper or use digital tools like Miro.
Download
Step 3: Sketch out core screens

After you have defined the user flow, it's time to get sketching. This is the
stage when you want to generate as many ideas as possible and not worry
about the quality. You can use pen and paper or digital tools — depending on
what works better for you. However, avoid jumping into prototyping right
away. It requires more effort and doesn't allow you to explore many
approaches quickly.
When creating sketches, always keep users' goals in mind. For every
design screen, ask yourself:
What's the purpose of this page?
How does this page help users achieve their goals?
Try to approach the problem from different angles. Create several versions
of each screen, get feedback, and iterate upon them until you have a couple
of working ideas.
Step 4: Set up a mobile frame
After you have created and tested low-fidelity sketches, it's time to move to
medium-fidelity wireframes. The sketches from the previous step will form a
foundation for this one.

Start by setting up a mobile frame. This will create the illusion of an actual
design but also prevent you from putting too many elements on the screen.
Which dimensions should you use if you need to design for a range of
devices? The best practice is to start with the device with a mid-sized
screen. For instance, if you developed an app for iOS in 2019, you could use
an iPhone 7 frame.
Step 5: Determine layout using boxes
In the early stages of the wireframing process, your goal is to create a clear
visual hierarchy. For now, don't focus on the content. Instead, focus on the
way you want to present it — namely, the layout and structure.
When planning the layout, think about how you want users to process the
information and in what order. Draw content boxes on the canvas and
arrange them depending on their priority. Put more important information
where users are more likely to look. The F-shaped pattern still works for both
desktop and mobile screens, but there are other common scanning patterns.
[1] Generally, though, the top and left sides of the screen get more attention.
Step 6: Use design patterns

Familiarity is one of the most important properties of good UX design. When
encountering a new product, users base their expectations on their previous
experience. Both Android and iOS have native design patterns users of these
platforms are used to.[1] This really simplifies designers' work. We can use
these design patterns as reusable content blocks.
For example, the bottom tab bar, the side drawer, and the Floating Action
Button (FAB) are the most used patterns for top-level mobile navigation. If
you want to design clear and simple navigation paths, use one of these
patterns in your app.
Step 7: Bring in actual copy
After you've established a visual hierarchy, start replacing placeholder text
and images with real content. At this stage, it's important to communicate
how the page supports users in reaching their goals.
Content should influence your design. Using actual copy and images will
help you understand:
If the layout works
If all UI elements are necessary and at the right place
If the page flows for the user

If something doesn't work, this is the perfect moment to reorganize the
content and improve the composition.
Step 8: Ensure your content scales well
After you have added real images and copy, you need to check how your
design scales. It can look great on a medium-size phone screen like iPhone
XS but distorted on bigger and smaller screens. Even if you started with a
medium-sized screen, check how the content looks on different screen sizes
and adjust it if necessary.
Step 9: Connect the screens to create a flow
It's possible to ship your design as a collection of individual screens. But a
better option is to create a wireflow.[1]
There are several benefits of creating a wireflow:
Flows are easier for the team to understand as they show interactions.
Arrows as visual instruments work better than lengthy descriptions.
Creating flows makes you think about the app's functionality as a whole.
For example, you might realize that it takes a few seconds to fetch

search results, and you'd need to design an extra state or loading
screen.
Giving each screen a reference number makes it much easier to discuss
them with team members or stakeholders.
Step 10: Test your design decisions
Testing wireframes helps validate ideas, discover functionality issues, and
explore user flows. It also saves a lot of time and money. Studies show that it
can cost 10 times more to fix something later in development.[1]
Testing methods vary from observation sessions to full-on eye-tracking,
depending on the budget. NNG recommends regularly testing in small
groups of up to 5 people — anything more elaborate is a waste of time and
resources.[2] So all you need is your wireframes, a small meeting room, and
2-3 colleagues.
When planning the testing session, decide which parts of the flow to test
and write a short script. Think of the task and goals to complete that you can
give to participants. It’s best to stick to a single task to maintain focus.
Common user testing methodologies include:

A/B testing
Focus groups
Heatmaps
Surveys
Observation
Usability testing
After the testing session, analyze the results and iterate on these findings.
Then rinse and repeat until you find the best solutions.
For a responsive Design:
Identify your content
Start with content analysis. Content is what users come to websites for, and
our job is to help them find the information they need. To create a website
wireframe system, it's important to identify what content your website will
provide.
For example, if you're designing an e-commerce website, you might need
these types of pages:
Home page

Product categories
Product details page
Cart page
Order confirmation page
Each of these pages will have its own content and need its own layout. So,
the next step is to identify mandatory and optional content sections for each
type of page.
For example, for a home page, you can consider sections like the header,
global navigation, hero banner, footer, etc.
Define user flows
After you decide what content should be on each page, start creating user
flows. This will help you define scenarios of interaction and measure the
importance of the content in the context. Think of your content from the
user's perspective. How will your visitors interact with the content?
Map out a target user flow — a series of steps a user takes to achieve a
specific goal. A user flow will help you understand which wireframes you'll
need to create and how they should be connected. After that, sketch out the
core screens.

Next, you can start to define the foundation for responsive wireframe
templates for each type of page. Templates should designate the areas of
content within them. When working on templates, look for reusable elements
(components and design patterns). In many cases, it's possible to define
containers that can be reused on many pages. For example, websites often
reuse the same headers and footers on different pages.[1]
Choose the grid
Flexible grids are foundational elements of responsive design. Using grids to
align elements helps establish visual hierarchy. Grid designs look consistent
across all devices and are well-organized.
The design starts with a certain number of columns — typically 12. This
number is so popular because it can be broken into 2, 3, 4, and 6 columns,
allowing for symmetrical or asymmetrical designs. The column width doesn't
change. Instead, the number of columns adjusts from 12 on a desktop to 8
on a tablet and 4 on mobile in this particular layout.
There are many different layouts to explore, not just the 12-column grid.[1]
The type you choose will depend on the type of product, content, and
technical limitations. Generally, most grids have 60–80px column widths.[2]
Choosing a column width that works for you is the most important decision
since it's the main determinant of your content width.

Decide on your target screens & layouts
After you have selected the grid layout, define your screen dimensions. If
you design a website, you need to account for at least three types of
screens: desktop, phone, and tablet. Other factors to consider are the
product's content and the target audience's device preferences.
Web frameworks like Bootstrap or Foundation have default responsive grids.
For example, Bootstrap’s tablet portrait mode width is 768px while
smartphone max width is 480px. If you work with a design tool, you can
customize breakpoints by clicking and setting the dimensions. But as soon
as you start translating your design from a graphic design tool to a browser,
breakpoints are set using CSS Media Queries.[1]
Identify content zones
The next step is to identify content zones. It will help you to create a clear
visual hierarchy for every type of page you've defined earlier in steps one
and two. At this stage, don't focus on the content itself. Instead, think about
how to arrange it for fast scanning. Plan the layout according to how you
want your users to process the information and start by drawing boxes on
the canvas.

For each type of responsive wireframe template you define, you need to
create zone diagrams. Zones are boxes and labels that indicate the types of
content and components that will appear on a page.[1] These diagrams show
zones of content and functional elements on the page.
Add content and UI elements
When you're happy with the visual hierarchy, start filling zones with content
and UI elements. The goal is to arrange elements in a way that allows fast
scanning. Put a strong focus on the order of information you want to present
to your users. People scan web pages from top to bottom, from left to right.
The F-shaped pattern works both for desktop and mobile screens.[1] So, you
can improve the scanning by rearranging boxes in both size and placement.
Avoid adding colors and choosing typefaces at this point. The goal is to see
if the layout is the best fit for the content. After adding real text and images,
you might find that the layout isn't working well. Don't hesitate to change it
and look for a better way to present the information. Also, remember to
check how your UI looks on different screen sizes and adjust it if needed.
Follow a mobile-first mindset and start with the mobile version of your
design. After you have created a good visual hierarchy there, move on to
another screen dimension.[2]

Wireframe only key screens
There's no need to lay out every single view — just the key screens.
Wireframes' purpose is to give you adequate information so that you can
make decisions and begin building. This is especially important when
wireframing responsive layouts. After deciding what works, you can start
building the real thing and work with real data in code.[1]
Wireframing for Responsive Design | Wireframing Academy | Balsamiq
Share your wireframes with the team and clients
Sharing responsive wireframes with your team has several benefits. First, it
makes it easier to imagine how the final design will look. Second, it allows
testing the layout on various screen sizes and resolutions.
When you finish wireframing, share them with developers and clients.
Regular designer-developer collaboration is essential for your design
workflow. Wireframes give developers a clear picture of the elements that
they will need to code. Sometimes they can even reuse the code from some
wireframe tools. As for clients, it's vital to ensure that they understand and
agree with content prioritization.[1]

Give each screen a reference number to make discussions easier.
Beauty and fashion wireframing
When you’re designing for an industry that’s known for its aesthetics — such
as the fashion industry — you step up the style of your wireframes a notch.
Be sure that you convey a sense of the mood with your wireframes, make
excellent use of white space, and don’t be afraid to include a few stylistic
elements like typography choices.
While you don’t want to go overboard with the stylistic elements of a
wireframe like this, you’ll want to include more than you might for other
industries. Add touches that imply and reinforce the mood of the brand.

Music app wireframing
People use music apps in different ways. Some use them to access the
music of their favorite artists while others use the same apps to find new
music (and, of course, some use them for both).
While the actual music interface should be pretty self-explanatory, with play,
pause, and skip or repeat options, you’ll want to pay closer attention to the
wireframes for finding music. Search and browse screens with clear-cut
categories and genres should be focused on, along with things like
recommended artists or playlists.
Your wireframes should also demonstrate how users can save their favorites,
create their own playlists or stations, and customize their experience.

Social media app wireframing
Most people access social media sites from their mobile devices than on
desktop computers (for example, more than 98% of Facebook users access
the site on their mobile devices).[1] Or at least they do if the mobile version
of their favorite social media site is well designed.
Your social media mobile wireframes should include the most important
features users want to access: their timeline, buttons for creating new
content, and the search feature. Consider, too, how users actually scroll
through social media sites. Make sure photos are prominent, that long blocks
of text are hidden with a “show more” button, and that the button for
creating their own post is easy to access at all times.

Ecommerce website wireframing
Ecommerce sites have one goal: to sell products or services. When creating
wireframes for them, it’s important to emphasize how the customer will
navigate through the selection and purchase process. The CTA is one of the
most important parts of this type of site, whether it’s a “buy now,” “add to
cart,” or some other type of button.
Beyond the CTA, your ecommerce wireframes should show clear categories
of goods, include a search function, show how multiple products will be
displayed, and show how product pages will be laid out.[1] Adapt those
functions as necessary for your specific use case (such as a site selling a

single product or service).
Banking dashboard wireframing
Dashboards for things like banking websites can be complex; they need to
show a lot of data in a way that’s easy for users to both understand and find
what they’re looking for. To that end, it’s helpful to include sample data in a
wireframe, to really demonstrate how the dashboard layout makes that data
easy to understand.
That said, early wireframes for things like financial dashboards and other
data-heavy sites can be more basic. An early version might simply show

which sections will go where with data examples added in later versions.
Wireframes should focus on a team's plan and
goals
The way you style your wireframes depends on a few things: the goals for
your product, the costs associated with developing the wireframes, and the
time and effort available to focus on the wireframing process. So how do you
decide?
First, think about how the wireframe will be used. Is it purely an internal
document? In that case, you can likely get by with low-fidelity, or even hand-
drawn, wireframes. Will they be shown to clients, potential users, or high-
level stakeholders? You’ll probably want to create something more polished.
You’ll likely need to strike a balance between creating high-fidelity
wireframes and not spending too much time styling them.
Remember that the higher-fidelity your wireframes are, the less creative
feedback stakeholders may offer.[1]
Weather forecast app wireframing
Being able to check the weather when planning your day or week is crucial
for many people. We want to know whether we need to bring a sweater or

umbrella, or if it’ll be clear skies all day. That said, the average person is only
concerned with a couple of key points: what the temperature will be and the
chances of rain or snow.
Your wireframes should focus on clearly showing the temperature,
precipitation, and upcoming forecast. There should be plenty of white space
around these key pieces of information so that they stand out and are easy
to find.
If your app will include more detailed information that only a small subset of
users are likely to access, be sure to include separate wireframe screens for
displaying them.
Maintain consistency in wireframes
While you don’t want to stylize your wireframes too much, you should keep
them consistent. Small things, like using consistent sizes, shapes, and colors
for various elements, go a long way toward making your wireframes appear
professional.

Minimize the use of color in wireframes
In general, wireframes should be done in shades of black, white, and gray.
Grayscale wireframes imply that the design isn’t finished, making it easier to
throw away designs that aren’t working and try again. They also give the
same impression to clients and other stakeholders, who will be more willing
to give creative feedback if they feel like the wireframe is just an early
prototype.
That said, there are instances where color in wireframes can be useful. If you
need to show a client that their existing color palette isn’t going to work for
the design, need to show contrast in certain situations, or feel like color
usage will help get buy-in for your designs, then using color may be the right
choice.[1]
Why are we colouring in wireframes? | Medium
Use basic components in wireframes
In general, you want to use very basic components in your wireframes. You
want to express which elements go where, and not much else. Leave the
stylistic elements for later mockups and prototypes.

The more stylized your wireframe is, the more it will feel like a finished
design, which can hinder useful feedback. By using more basic
representations, you’ll find that stakeholders and clients feel free to offer
more honest and creative comments about what’s working in the design and
what’s not.
Select the right tool
Finding the right tool for creating your wireframes is a very personal
decision. There are tons of options out there, from simple pen and paper to
complex apps that let you move beyond just wireframing. So how do you
decide which one to use?
There are a few things to keep in mind. One is the simplicity of the
wireframes created by the program. Some apps make wireframes that
appear more like finished UI designs, which can defeat the purpose of
wireframing.
The second thing to consider is how easy it is to collaborate with your team
and share the wireframes with stakeholders to collect feedback. This should
be an easy process even for those who aren’t particularly familiar with the
app.

And third is the learning curve. If it takes you days or weeks to learn how to
use the program to create a wireframe, you’re wasting time. If you can’t
master at least the basic functionality of the program in an hour or two (even
if more advanced features take additional time), then you’re better off to find
a different solution.
Use real content in wireframes
Content should drive your design decisions. Content-first design ensures
that your UI evolves in a way that supports the content, which in turn better
supports your user experience.[1]
Using real content offers a few benefits. Seeing real content within your
wireframes also makes it easier for stakeholders to give feedback. It makes it
easier to figure out actual product requirements around content, particularly
around things like space constraints. And it can speed up the entire process
of developing the product, since having the content ready early on means
fewer content-related delays down the road.[2]
Content-First Design: Let the Content Determine the Design |
Wireframing Academy | Balsamiq
4 Reasons Why You Should Use More Realistic Content In Your
Wireframes | Sarah Doody
