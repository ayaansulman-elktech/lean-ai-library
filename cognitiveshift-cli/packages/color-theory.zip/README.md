# color-theory

A lean-ai-factory block.
