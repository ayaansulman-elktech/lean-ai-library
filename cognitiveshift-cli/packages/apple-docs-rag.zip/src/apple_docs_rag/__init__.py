"""Apple-docs RAG agent: grounded answers about Apple development, on agent-core + rag."""

from apple_docs_rag.agent import AppleDocsRAGAgent

__all__ = ["AppleDocsRAGAgent"]
