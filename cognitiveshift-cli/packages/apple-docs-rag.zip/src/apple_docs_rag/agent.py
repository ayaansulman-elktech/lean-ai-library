"""AppleDocsRAGAgent — answer Apple-development questions grounded ONLY in the indexed docs.

Retrieve the top-k relevant chunks from the corpus, then have the LLM answer using only that
context, with citations. Refuses ("not found") when the corpus doesn't cover the question — so
the agent can't hallucinate Apple behavior. On agent-core; retrieval via the dependency-free
`rag` library (TF-IDF today; swap in an embedding retriever later without touching this agent).
"""

from __future__ import annotations

from pathlib import Path

from agent_core import Agent, AgentContext
from pydantic import BaseModel
from rag import LexicalRetriever, Retriever, load_corpus

_AGENT_ROOT = Path(__file__).resolve().parents[2]
_DEFAULT_CORPUS = _AGENT_ROOT / "corpus"
# Canonical, shared knowledge corpora reused across the factory (single source of truth).
# The full App Store Review Guidelines live here rather than being re-collected per agent.
_SHARED_KNOWLEDGE = (_AGENT_ROOT.parents[1] / "libraries" / "knowledge" / "apple-guidelines",)


def _default_corpus():
    """Local Apple docs (HIG, Core ML, Foundation Models) plus the shared, canonical
    knowledge corpora when running inside the monorepo. Degrades to just the local docs
    if the shared library isn't present (e.g. the agent is vendored standalone)."""
    corpus = load_corpus(_DEFAULT_CORPUS)
    for d in _SHARED_KNOWLEDGE:
        if d.is_dir():
            load_corpus(d, corpus)
    return corpus

SYSTEM = (
    "You answer questions about Apple development using ONLY the provided CONTEXT excerpts. "
    "Cite the source of each claim inline like [Title]. If the answer is not in the context, "
    "set grounded=false and answer exactly: 'Not found in the indexed Apple docs.' "
    "Never use outside knowledge.\n"
    'Return ONLY JSON: {"answer": "<with [Title] citations>", "grounded": true|false}.'
)


class _Answer(BaseModel):
    answer: str
    grounded: bool = True


class AppleDocsRAGAgent(Agent):
    name = "apple-docs-rag"

    def __init__(self, ctx: AgentContext, *, corpus_dir: str | Path | None = None,
                 retriever: Retriever | None = None, k: int = 4, model: str | None = None) -> None:
        super().__init__(ctx)
        if retriever is None:
            corpus = load_corpus(corpus_dir) if corpus_dir is not None else _default_corpus()
            retriever = LexicalRetriever(corpus)
        self.retriever = retriever
        self.k = k
        self.model = model

    def _run(self, question: str) -> dict:
        hits = self.retriever.search(question, self.k)
        if not hits:
            return {"answer": "Not found in the indexed Apple docs.", "grounded": False,
                    "citations": [], "sources": [], "retrieved": 0}
        context = "\n\n".join(f"[{c.title}] (source: {c.source})\n{c.text}" for c, _ in hits)
        rep = self.llm_json(system=SYSTEM, user=f"CONTEXT:\n{context}\n\nQUESTION: {question}",
                            model=self.model, schema=_Answer)
        rep["citations"] = sorted({c.title for c, _ in hits})
        rep["sources"] = sorted({c.source for c, _ in hits})
        rep["retrieved"] = len(hits)
        self.ctx.tracker.log_metrics({"grounded": 1.0 if rep.get("grounded") else 0.0,
                                      "retrieved": len(hits)})
        return rep
