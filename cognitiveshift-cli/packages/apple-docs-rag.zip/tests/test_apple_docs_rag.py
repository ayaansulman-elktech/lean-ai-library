from agent_core import AgentContext
from apple_docs_rag.agent import AppleDocsRAGAgent
from ml_core import CostMeter, ProvidersConfig, build_gateway
from ml_core.config import ModelSpec
from rag import Corpus, LexicalRetriever

ANSWER = ('{"answer":"Guideline 4.3 bars cosmetic-variant apps [App Store Guidelines].",'
          '"grounded":true}')


def _ctx(responder):
    cfg = ProvidersConfig(gateway="mock",
                          models={"deepseek": ModelSpec(provider="deepseek", model="deepseek-chat")})
    meter = CostMeter(budget_usd=1.0)
    return AgentContext(gateway=build_gateway(cfg, meter, offline=True, responder=responder),
                        meter=meter, default_model="deepseek")


def _retriever():
    c = Corpus()
    c.add("g", "App Store Guidelines", "https://x/guidelines",
          "Guideline 4.3 Spam: do not ship duplicate or variant apps that differ only "
          "cosmetically; each must change the core value proposition.")
    c.add("ml", "Core ML", "https://x/coreml",
          "Core ML runs models on device; convert with coremltools.")
    return LexicalRetriever(c)


def test_grounded_answer_with_citations():
    r = AppleDocsRAGAgent(_ctx(lambda a, m: ANSWER), retriever=_retriever()).run(
        "what does guideline 4.3 say about variant apps?")
    assert r.success
    assert r.output["grounded"] is True
    assert "App Store Guidelines" in r.output["citations"]
    assert r.output["retrieved"] >= 1


def test_not_found_short_circuits_without_llm():
    ctx = _ctx(lambda a, m: ANSWER)
    r = AppleDocsRAGAgent(ctx, retriever=LexicalRetriever(Corpus())).run("anything at all")
    assert r.success
    assert r.output["grounded"] is False
    assert r.output["retrieved"] == 0
    assert ctx.meter.calls == 0          # empty corpus -> no LLM call, no spend


def test_bundled_corpus_loads_and_retrieves_4_3():
    # default corpus_dir = the committed Apple docs under ../corpus
    r = AppleDocsRAGAgent(_ctx(lambda a, m: ANSWER)).run(
        "how does Guideline 4.3 treat duplicate apps?")
    assert r.success
    assert r.output["retrieved"] >= 1
    assert any("Guidelines" in c for c in r.output["citations"])
