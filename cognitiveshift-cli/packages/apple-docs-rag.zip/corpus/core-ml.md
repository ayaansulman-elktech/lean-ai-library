# Core ML
source: https://developer.apple.com/documentation/coreml

Core ML is Apple's framework for running machine-learning models **on device** (iOS, macOS,
watchOS, tvOS, visionOS) — local inference with no server, low latency, and privacy by default.

- **Conversion:** use the `coremltools` Python package to convert trained models from TensorFlow,
  PyTorch, or scikit-learn into the Core ML format (`.mlpackage` / `.mlmodel`).
- **Model types:** neural networks, tree ensembles, SVMs, generalized linear models, and pipelines,
  plus vision models (image classifiers, object detectors) and tabular models.
- **Integration flow:** convert the model → add it to the Xcode project → call the generated Swift
  API to make predictions. Core ML optimizes execution across CPU, GPU, and the Neural Engine.
- **Factory relevance:** this is how iOS Ready ships an "on-device" capability — train/evaluate in
  Python, convert with coremltools, then run inside the app with zero token cost.
