# Human Interface Guidelines (HIG)
source: https://developer.apple.com/design/human-interface-guidelines

Apple's design guidance for building apps that feel native across its platforms.

- **Principles:** clarity, deference (content first), and depth (meaningful layering/motion).
- **Native components & conventions:** prefer system controls, navigation patterns, and layouts so
  the app behaves the way users already expect; this also helps App Store ranking and trust.
- **SF Symbols:** use Apple's icon set for consistent, accessible iconography that adapts to weight,
  scale, and rendering mode.
- **Accessibility:** support Dynamic Type, sufficient contrast, VoiceOver, and adequate hit targets
  (≥ 44×44 pt).
- **Factory relevance:** the Lean Design System encodes HIG so every app is Apple-native by default;
  the more faithful to HIG, the lower the cognitive load and the better the store visibility.
