# Foundation Models framework
source: https://developer.apple.com/documentation/foundationmodels

The Foundation Models framework gives a native **Swift API** to the **on-device large language
model** that powers Apple Intelligence.

- **On-device + private + free:** inference runs locally, works offline, and has **no token cost**
  (no server calls).
- **Guided generation:** annotate Swift types (e.g. `@Generable` / `@Guide`) to get **structured,
  type-safe output** directly from the model.
- **Tool calling:** the model can call app-provided tools to fetch data or take actions.
- **Availability + limits:** requires Apple Intelligence–capable devices and recent OS versions;
  the on-device model is **small** (a few billion parameters) with a **limited context window**, so
  it suits focused tasks, not heavy long-context reasoning — push complex work to Core ML models or
  rethink the feature.
- **Factory relevance:** the "local-AI-first" pillar — use it for on-device text features to keep
  cost at zero and data on the phone.
