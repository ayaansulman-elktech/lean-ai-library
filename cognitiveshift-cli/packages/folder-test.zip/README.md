# Folder test

Test article using a content folder instead of a single PDF or Markdown file.
