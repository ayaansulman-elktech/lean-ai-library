"""Score a wireframe directory and return an A-F grade + the specific issues.

Checks the flow-rules thresholds (see ../../references/flow-rules.md): clicks-to-action,
features per page, navigation depth, orphan pages, dead links.

CLI:  python -m wireframing.audit <wireframe_dir> [--entry index.html] [--json]
Exit code is 0 when grade == A, else 1 (so the loop can gate on it).
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import deque
from html.parser import HTMLParser
from pathlib import Path

# Thresholds (keep in sync with ../../references/flow-rules.md)
MAX_CLICKS_TO_ACTION = 3
MAX_FEATURES_PER_PAGE = 7
MAX_NAV_DEPTH = 4
INTERACTIVE_TAGS = {"a", "button", "input", "select", "textarea"}


class PageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []
        self.features = 0
        self.actions: list[str] = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in INTERACTIVE_TAGS:
            self.features += 1
        if tag == "a" and a.get("href"):
            href = a["href"].split("#")[0].strip()
            if href and not href.startswith(("http://", "https://", "mailto:")):
                self.links.append(href)
        if a.get("data-action"):
            self.actions.append(a["data-action"])


def parse_dir(d: Path) -> dict:
    pages: dict[str, PageParser] = {}
    for f in sorted(d.glob("*.html")):
        p = PageParser()
        p.feed(f.read_text(encoding="utf-8", errors="ignore"))
        pages[f.name] = p
    return pages


def bfs_depths(pages: dict, entry: str) -> dict:
    depth = {entry: 0}
    q = deque([entry])
    while q:
        cur = q.popleft()
        for nxt in pages[cur].links:
            if nxt in pages and nxt not in depth:
                depth[nxt] = depth[cur] + 1
                q.append(nxt)
    return depth


def clicks_to_actions(pages: dict, entry: str) -> dict:
    found: dict[str, int] = {}
    depth = {entry: 0}
    q = deque([entry])
    while q:
        cur = q.popleft()
        for act in pages[cur].actions:
            found.setdefault(act, depth[cur])
        for nxt in pages[cur].links:
            if nxt in pages and nxt not in depth:
                depth[nxt] = depth[cur] + 1
                q.append(nxt)
    return found


def audit(d: str | Path, entry: str = "index.html") -> dict:
    d = Path(d)
    pages = parse_dir(d)
    issues: list[str] = []
    if not pages:
        return {"grade": "F", "issues": ["no .html pages found"], "metrics": {}}
    if entry not in pages:
        entry = next(iter(pages))

    depth = bfs_depths(pages, entry)
    orphans = [name for name in pages if name not in depth]
    dead = [(name, lnk) for name, p in pages.items() for lnk in p.links if lnk not in pages]
    over_feature = {n: p.features for n, p in pages.items() if p.features > MAX_FEATURES_PER_PAGE}
    max_depth = max(depth.values()) if depth else 0
    actions = clicks_to_actions(pages, entry)
    far_actions = {a: c for a, c in actions.items() if c > MAX_CLICKS_TO_ACTION}

    if orphans:
        issues.append(f"orphan pages (unreachable): {orphans}")
    if dead:
        issues.append(f"dead links (target missing): {dead}")
    if over_feature:
        issues.append(f"too many features/page (>{MAX_FEATURES_PER_PAGE}): {over_feature}")
    if max_depth > MAX_NAV_DEPTH:
        issues.append(f"nav depth {max_depth} > {MAX_NAV_DEPTH}")
    if far_actions:
        issues.append(f"key actions too deep (>{MAX_CLICKS_TO_ACTION} clicks): {far_actions}")

    grade = ["A", "B", "C", "D", "F"][min(len(issues), 4)]
    return {
        "grade": grade,
        "issues": issues,
        "metrics": {"pages": len(pages), "entry": entry, "max_nav_depth": max_depth,
                    "orphans": len(orphans), "dead_links": len(dead), "actions": actions},
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("dir")
    ap.add_argument("--entry", default="index.html")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    result = audit(args.dir, args.entry)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"GRADE: {result['grade']}")
        for i in result["issues"]:
            print(" -", i)
    return 0 if result["grade"] == "A" else 1


if __name__ == "__main__":
    sys.exit(main())
