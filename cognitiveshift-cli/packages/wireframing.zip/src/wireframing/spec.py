"""The wireframe screen-spec schema — the contract between the LLM step and the generator."""

from __future__ import annotations

from pydantic import BaseModel


class Link(BaseModel):
    label: str
    to: str                    # must reference another screen's id
    action: str | None = None  # set when this nav link is also the primary action (renders as a prominent button)


class Tab(BaseModel):
    label: str
    to: str | None = None    # a tab may be unlinked (no destination yet)


class Element(BaseModel):
    kind: str = "text"       # title|text|image|list|card|textfield|searchbar|toggle
    label: str = ""
    rows: int | None = None        # list: number of rows
    placeholder: str | None = None  # textfield/searchbar


class Screen(BaseModel):
    id: str
    title: str = ""
    navbar: str | None = None   # optional top nav-bar title
    elements: list[str | Element] = []   # str = legacy plain box; Element = a typed component
    links: list[Link] = []
    actions: list[str] = []   # primary buttons (data-action), e.g. capture / subscribe
    tabbar: list[Tab] = []    # optional bottom tab bar (iOS-style)


class WireframeSpec(BaseModel):
    screens: list[Screen]
