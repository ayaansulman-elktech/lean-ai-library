"""Screen spec -> link-complete HTML/CSS wireframe.

`generate(spec, out_dir)` writes one HTML page per screen (all linked) using the base template
in `../../assets/wireframe-template/`, so `audit.py` can grade the result.

CLI:  python -m wireframing.generate <spec.json> <out_dir>
      python -m wireframing.generate --example <out_dir>
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# src/wireframing/generate.py -> parents[2] == agents/wireframing
TEMPLATE_DIR = Path(__file__).resolve().parents[2] / "assets" / "wireframe-template"

EXAMPLE = {
    "screens": [
        {"id": "index", "title": "Welcome", "elements": ["Headline", "Subhead"],
         "links": [{"label": "Get started", "to": "capture"}], "actions": []},
        {"id": "capture", "title": "Take a selfie", "elements": ["Camera frame", "Shutter"],
         "links": [{"label": "Analyze", "to": "palette"}], "actions": ["capture"]},
        {"id": "palette", "title": "Your palette", "elements": ["Season", "Swatches"],
         "links": [{"label": "Back", "to": "index"}], "actions": []},
    ]
}


def render(screen: dict) -> str:
    base = (TEMPLATE_DIR / "base.html").read_text(encoding="utf-8")
    def _element(e):
        if isinstance(e, str):                       # legacy plain string -> grey box
            return f'      <div class="element">{e}</div>\n'
        kind, label = e.get("kind", "text"), e.get("label", "")
        if kind == "title":
            return f'      <div class="wf-title">{label}</div>\n'
        if kind == "text":
            return f'      <div class="wf-text">{label}</div>\n'
        if kind == "image":
            return f'      <div class="wf-image">{label or "Image"}</div>\n'
        if kind == "card":
            return f'      <div class="wf-card">{label}</div>\n'
        if kind == "list":
            rows = "".join(f'<div class="wf-row">{label} {i + 1}</div>' for i in range(e.get("rows") or 3))
            return f'      <div class="wf-list">{rows}</div>\n'
        if kind == "textfield":
            return f'      <input class="wf-field" placeholder="{e.get("placeholder") or label}" readonly>\n'
        if kind == "searchbar":
            return f'      <input class="wf-field wf-search" placeholder="{e.get("placeholder") or "Search"}" readonly>\n'
        if kind == "toggle":
            return f'      <label class="wf-toggle"><span>{label}</span><input type="checkbox" checked disabled></label>\n'
        return f'      <div class="element">{label}</div>\n'
    items = "".join(_element(e) for e in screen.get("elements", []))
    def _link(lnk):
        if lnk.get("action"):   # a nav link that is also the primary action -> one prominent button
            return f'      <a class="nav primary" href="{lnk["to"]}.html" data-action="{lnk["action"]}">{lnk["label"]}</a>\n'
        return f'      <a class="nav" href="{lnk["to"]}.html" data-action="{lnk["to"]}">{lnk["label"]} -&gt;</a>\n'
    links = "".join(_link(lnk) for lnk in screen.get("links", []))
    actions = "".join(
        f'      <button class="action" data-action="{a}">{a}</button>\n'
        for a in screen.get("actions", [])
    )
    nb = screen.get("navbar")
    navbar = f'    <div class="navbar">{nb}</div>\n' if nb else ""
    tabs = screen.get("tabbar") or []
    tabbar = ""
    if tabs:
        # linked tabs are real <a> links (so audit still counts them for reachability);
        # unlinked tabs are inert spans.
        rows = "".join(
            (f'      <a class="tab" href="{t["to"]}.html" data-action="{t["to"]}">{t["label"]}</a>\n'
             if t.get("to") else
             f'      <span class="tab off">{t["label"]}</span>\n')
            for t in tabs)
        tabbar = f'    <nav class="tabbar">\n{rows}    </nav>\n'
    return (base
            .replace("{{TITLE}}", screen.get("title", screen["id"]))
            .replace("{{NAVBAR}}", navbar)
            .replace("{{ELEMENTS}}", items)
            .replace("{{ACTIONS}}", actions)
            .replace("{{LINKS}}", links)
            .replace("{{TABBAR}}", tabbar))


def generate(spec: dict, out_dir: str | Path) -> list[str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    # Clean stale pages so the output reflects exactly this spec (e.g. across revise iterations,
    # where a previous, larger spec would otherwise leave orphan pages behind).
    for stale in out.glob("*.html"):
        stale.unlink()
    (out / "styles.css").write_text((TEMPLATE_DIR / "styles.css").read_text(encoding="utf-8"),
                                    encoding="utf-8")
    written = []
    for s in spec["screens"]:
        (out / (s["id"] + ".html")).write_text(render(s), encoding="utf-8")
        written.append(s["id"] + ".html")
    return written


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("spec", nargs="?")
    ap.add_argument("out")
    ap.add_argument("--example", action="store_true")
    args = ap.parse_args()
    spec = EXAMPLE if args.example or not args.spec else json.loads(Path(args.spec).read_text())
    files = generate(spec, args.out)
    print(f"wrote {len(files)} pages -> {args.out}: {files}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
