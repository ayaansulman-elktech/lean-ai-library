"""Charter -> WireframeSpec (deterministic, no LLM).

Route C of the three ways to produce a spec (studio by hand / the wireframing agent / this).
Turns a project charter's `suggestedWireframeAreas` into an importable factory WireframeSpec
skeleton: one screen per area, common funnel steps merged, and a shallow home→hub flow so the
result imports cleanly and grades well. It is deterministic and free — refine the output in the
studio, or use `WireframingAgent` (LLM) when you want the flow auto-tuned to grade A.

CLI:  python -m wireframing.charter <charter.json> [out.wireframe.json]
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# Allow running this file directly (python .../wireframing/charter.py <charter>): put src/ on the
# path so the sibling wireframing.generate / wireframing.audit modules import for the grade step.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# An area is assigned to the FIRST group whose pattern matches; a run of >= 2 CONSECUTIVE areas
# with the same key collapses into one screen (e.g. four camera-capture steps -> one Scan screen).
# analysis is listed before capture so "Scan progress/analysis state" reads as analysis, not scan.
_GROUPS = [
    ("analysis", re.compile(r"analy|process|progress|loading|locked|complete", re.I), "Analysis"),
    ("capture", re.compile(r"camera|photo|upload|capture|selfie|scan intro|\bscan\b", re.I), "Scan"),
    ("auth", re.compile(r"sign[\s-]?in|log[\s-]?in|create account|apple pay|payment|checkout|purchase", re.I),
     "Sign in & pay"),
]
# The "hub" is the screen the app opens up into after the funnel (results/home/dashboard).
_HUB = re.compile(r"result|overview|dashboard|\bhome\b|profile|\bmain\b", re.I)


def _key(area: str) -> str | None:
    for key, pat, _ in _GROUPS:
        if pat.search(area):
            return key
    return None


def _slug(text: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return s or "screen"


def _merge(areas: list[str]) -> list[tuple[str, list[str]]]:
    """Collapse consecutive same-key runs (len >= 2) into one screen. Returns [(title, sources)]."""
    gtitle = {k: t for k, _, t in _GROUPS}
    out: list[tuple[str, list[str]]] = []
    i, n = 0, len(areas)
    while i < n:
        k = _key(areas[i])
        j = i
        if k:
            while j + 1 < n and _key(areas[j + 1]) == k:
                j += 1
        if k and j > i:                          # a run of 2+ -> one merged screen
            out.append((gtitle[k], areas[i:j + 1]))
        else:                                    # lone area keeps its own title
            out.append((areas[i], [areas[i]]))
        i = j + 1
    return out


def _elements(title: str) -> list[str]:
    return [f"{title}", "Primary content for this screen", "Secondary detail / controls"]


def charter_to_spec(charter: dict, *, flatten: bool = True) -> dict:
    """Build a factory WireframeSpec from a charter's `suggestedWireframeAreas`.

    flatten=True merges consecutive funnel steps and adds a home->hub shortcut so the post-funnel
    section stays shallow (depth). The first screen is always `index`.
    """
    areas = [str(a) for a in (charter.get("suggestedWireframeAreas") or [])]
    if not areas:
        raise ValueError("charter has no 'suggestedWireframeAreas' to convert")
    groups = _merge(areas) if flatten else [(a, [a]) for a in areas]
    titles = [t for t, _ in groups]

    ids: list[str] = []
    used: set[str] = set()
    for i, t in enumerate(titles):
        sid = "index" if i == 0 else _slug(t)
        base, k = sid, 2
        while sid in used:
            sid = f"{base}-{k}"
            k += 1
        used.add(sid)
        ids.append(sid)

    # hub = first non-entry screen that looks like results/home; else the last screen.
    hub_i = next((i for i in range(1, len(groups)) if _HUB.search(titles[i])), len(groups) - 1)

    screens = [{"id": ids[i], "title": titles[i], "elements": _elements(titles[i]),
                "links": [], "actions": []} for i in range(len(groups))]

    def link(a: int, b: int, label: str) -> None:
        screens[a]["links"].append({"label": label, "to": ids[b]})

    # funnel: index .. hub, sequential
    for i in range(hub_i):
        link(i, i + 1, "Get started" if i == 0 else "Continue")
    # flatten: index -> hub shortcut (returning-user path) keeps the post-funnel section shallow
    if flatten and hub_i > 1:
        link(0, hub_i, titles[hub_i])
    # post-hub screens fan out from the hub, each with a Back link
    for i in range(hub_i + 1, len(groups)):
        link(hub_i, i, titles[i])
        link(i, hub_i, "Back")

    # one shallow key action so the flow has a measurable primary task
    scan_i = next((i for i, t in enumerate(titles)
                   if re.search(r"scan|capture|photo|camera", t, re.I)), None)
    if scan_i is not None:
        screens[scan_i]["actions"].append("capture")

    return {"screens": screens}


def _grade(spec: dict) -> dict:
    """Grade the spec through the canonical generate + audit (same result as downstream)."""
    import shutil
    import tempfile

    from wireframing.audit import audit
    from wireframing.generate import generate

    d = tempfile.mkdtemp(prefix="charter-audit-")
    try:
        generate(spec, d)
        return audit(d, "index.html")
    finally:
        shutil.rmtree(d, ignore_errors=True)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Charter -> importable WireframeSpec (no LLM).")
    ap.add_argument("charter")
    ap.add_argument("out", nargs="?", help="output path (default: <charter>.wireframe.json)")
    ap.add_argument("--no-flatten", action="store_true", help="faithful 1:1 (no merge / no hub shortcut)")
    ap.add_argument("--no-grade", action="store_true", help="skip the flow-audit report")
    args = ap.parse_args(argv)

    charter = json.loads(Path(args.charter).read_text(encoding="utf-8"))
    spec = charter_to_spec(charter, flatten=not args.no_flatten)
    out = args.out or (re.sub(r"[-_]?(project[-_]?)?charter$", "", Path(args.charter).stem, flags=re.I)
                       + ".wireframe.json")
    Path(out).write_text(json.dumps(spec, indent=2), encoding="utf-8")
    print(f"wrote {len(spec['screens'])} screens -> {out}")

    if not args.no_grade:
        res = _grade(spec)
        issues = res.get("issues", [])
        print(f"flow grade: {res['grade']}  ({len(issues)} issue{'' if len(issues) == 1 else 's'})")
        for it in issues:
            print("  - " + (it if isinstance(it, str) else str(it)))
        if any("features/page" in str(it) for it in issues):
            print("  hint: the hub links to every section - split those into sub-groups in the "
                  "studio (or use WireframingAgent) to reach grade A.")
    print("next: open the studio and Import this file.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
