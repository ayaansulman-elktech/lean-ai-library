"""Wireframing agent: charter -> A-grade flow wireframe, on agent-core.

`WireframingAgent` is imported lazily (PEP 562) so the deterministic CLIs — `generate`, `audit`,
and `charter` — run without pulling in agent-core (they need no LLM).
"""

from wireframing.spec import Link, Screen, WireframeSpec

__all__ = ["WireframingAgent", "WireframeSpec", "Screen", "Link"]


def __getattr__(name: str):
    if name == "WireframingAgent":              # pulls in agent-core only when actually used
        from wireframing.agent import WireframingAgent
        return WireframingAgent
    raise AttributeError(f"module 'wireframing' has no attribute {name!r}")
