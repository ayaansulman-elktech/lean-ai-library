"""WireframingAgent — charter -> A-grade flow wireframe.

Pipeline: charter text -> (LLM) screen spec -> generate HTML -> flow-audit -> if not "A",
feed the audit issues back to the LLM and revise, looping up to `max_iterations`. The LLM
step is the only non-deterministic part; the generator and auditor are deterministic, so the
flow is bounded and reproducible. Runs under the agent-core contract (budget, cost, tracking).
"""

from __future__ import annotations

import json
from pathlib import Path

from agent_core import Agent, AgentContext

from wireframing.audit import (
    MAX_CLICKS_TO_ACTION,
    MAX_FEATURES_PER_PAGE,
    MAX_NAV_DEPTH,
    audit,
)
from wireframing.generate import generate
from wireframing.spec import WireframeSpec

_GRADE_NUM = {"A": 5, "B": 4, "C": 3, "D": 2, "F": 1}

SYSTEM = (
    "You convert a product charter into a wireframe SCREEN SPEC.\n"
    'Return ONLY a JSON object: {"screens": [{"id", "title", "elements": [str], '
    '"links": [{"label", "to"}], "actions": [str]}]}.\n'
    "Rules:\n"
    "- ids are short kebab-case; the FIRST screen's id is 'index'.\n"
    "- every link 'to' MUST reference an existing screen id (no dead links; no orphan screens).\n"
    f"- keep flows shallow: key actions reachable within {MAX_CLICKS_TO_ACTION} clicks; "
    f"max navigation depth {MAX_NAV_DEPTH}; <= {MAX_FEATURES_PER_PAGE} interactive elements per screen.\n"
    "- 'actions' are primary buttons (e.g. capture, subscribe); one primary action per screen.\n"
    "Output JSON only — no prose, no code fences."
)


class WireframingAgent(Agent):
    name = "wireframing"

    def __init__(self, ctx: AgentContext, *, out_dir: str | Path,
                 max_iterations: int = 3, model: str | None = None) -> None:
        super().__init__(ctx)
        self.out_dir = Path(out_dir)
        self.max_iterations = max_iterations
        self.model = model

    def _run(self, charter: str) -> dict:
        spec = self.llm_json(system=SYSTEM, user=f"Charter:\n{charter}",
                             model=self.model, schema=WireframeSpec)
        result = None
        for i in range(1, self.max_iterations + 1):
            generate(spec, self.out_dir)
            result = audit(self.out_dir, "index.html")
            self.ctx.tracker.log_metrics({"grade_num": _GRADE_NUM.get(result["grade"], 0),
                                          "iteration": i})
            if result["grade"] == "A":
                return self._result(result, i, spec)
            if i < self.max_iterations:
                spec = self._revise(charter, spec, result["issues"])
        return self._result(result, self.max_iterations, spec)

    def _revise(self, charter: str, spec: dict, issues: list[str]) -> dict:
        user = (f"Charter:\n{charter}\n\nCurrent spec:\n{json.dumps(spec)}\n\n"
                "The flow audit FAILED with:\n- " + "\n- ".join(issues) +
                "\n\nReturn a corrected spec JSON that fixes every issue. JSON only.")
        return self.llm_json(system=SYSTEM, user=user, model=self.model, schema=WireframeSpec)

    def _result(self, audit_res: dict, iterations: int, spec: dict) -> dict:
        return {"grade": audit_res["grade"], "iterations": iterations,
                "out_dir": str(self.out_dir), "issues": audit_res["issues"],
                "metrics": audit_res["metrics"], "spec": spec}
