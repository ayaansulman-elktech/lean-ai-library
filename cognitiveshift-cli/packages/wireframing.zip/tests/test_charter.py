"""Offline tests for the deterministic charter -> WireframeSpec converter (no LLM)."""

import collections

from wireframing.charter import charter_to_spec

CHARTER = {
    "suggestedWireframeAreas": [
        "Welcome screen",
        "Camera step for face",
        "Camera step for eyes",
        "Camera step for hair",          # 3 consecutive capture steps -> merged into one
        "Scan progress/analysis state",
        "Analysis complete but locked",  # 2 consecutive analysis steps -> merged
        "Paywall",
        "Sign-in",
        "Apple Pay confirmation",        # 2 consecutive auth steps -> merged
        "Results overview",              # the hub
        "Season detail",
        "Palette detail",
    ],
}


def _spec():
    return charter_to_spec(CHARTER)


def _depths(spec):
    ids = {s["id"] for s in spec["screens"]}
    adj = {s["id"]: [lk["to"] for lk in s["links"]] for s in spec["screens"]}
    d = {"index": 0}
    q = collections.deque(["index"])
    while q:
        n = q.popleft()
        for m in adj[n]:
            if m in ids and m not in d:
                d[m] = d[n] + 1
                q.append(m)
    return d


def test_first_screen_is_index_and_ids_unique():
    spec = _spec()
    ids = [s["id"] for s in spec["screens"]]
    assert ids[0] == "index"
    assert len(ids) == len(set(ids))


def test_merges_consecutive_funnel_runs():
    spec = _spec()
    titles = [s["title"] for s in spec["screens"]]
    # 3 camera + 2 analysis + 2 auth collapse to one screen each -> 12 areas become fewer screens
    assert titles.count("Scan") == 1
    assert titles.count("Analysis") == 1
    assert titles.count("Sign in & pay") == 1
    assert len(spec["screens"]) < len(CHARTER["suggestedWireframeAreas"])


def test_no_dead_links_and_no_orphans():
    spec = _spec()
    ids = {s["id"] for s in spec["screens"]}
    for s in spec["screens"]:
        for lk in s["links"]:
            assert lk["to"] in ids, f"dead link {s['id']}->{lk['to']}"
    reachable = set(_depths(spec))
    assert reachable == ids, f"orphans: {ids - reachable}"


def test_home_hub_keeps_depth_shallow():
    # index links into the funnel AND straight to the hub, so the whole post-funnel area is shallow.
    spec = _spec()
    d = _depths(spec)
    assert max(d.values()) <= 4


def test_has_a_shallow_key_action():
    spec = _spec()
    scan = next(s for s in spec["screens"] if s["title"] == "Scan")
    assert "capture" in scan["actions"]
    d = _depths(spec)
    assert d[scan["id"]] <= 3          # key action reachable within 3 clicks


def test_deterministic():
    assert charter_to_spec(CHARTER) == charter_to_spec(CHARTER)


def test_no_flatten_keeps_every_area():
    spec = charter_to_spec(CHARTER, flatten=False)
    assert len(spec["screens"]) == len(CHARTER["suggestedWireframeAreas"])


def test_raises_without_areas():
    import pytest
    with pytest.raises(ValueError):
        charter_to_spec({"projectName": "x"})
