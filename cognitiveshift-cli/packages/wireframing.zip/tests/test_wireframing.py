"""Offline tests — mock gateway returns a canned spec; no providers, no keys, no spend."""

from agent_core import AgentContext
from ml_core import CostMeter, ProvidersConfig, build_gateway
from ml_core.config import ModelSpec
from wireframing.agent import WireframingAgent

# A shallow, link-complete flow that grades "A": index -> capture -> result, action at depth 1.
GOOD_SPEC = (
    '{"screens":['
    '{"id":"index","title":"Home","elements":["Headline"],'
    '"links":[{"label":"Start","to":"capture"}],"actions":[]},'
    '{"id":"capture","title":"Capture","elements":["Camera"],'
    '"links":[{"label":"See result","to":"result"}],"actions":["capture"]},'
    '{"id":"result","title":"Result","elements":["Palette"],'
    '"links":[{"label":"Home","to":"index"}],"actions":[]}'
    ']}'
)

# A flawed flow: a chain index->a->b->c->d with the action 4 clicks deep (fails the click rule).
BAD_SPEC = (
    '{"screens":['
    '{"id":"index","title":"H","elements":[],"links":[{"label":"n","to":"a"}],"actions":[]},'
    '{"id":"a","title":"A","elements":[],"links":[{"label":"n","to":"b"}],"actions":[]},'
    '{"id":"b","title":"B","elements":[],"links":[{"label":"n","to":"c"}],"actions":[]},'
    '{"id":"c","title":"C","elements":[],"links":[{"label":"n","to":"d"}],"actions":[]},'
    '{"id":"d","title":"D","elements":[],"links":[],"actions":["go"]}'
    ']}'
)


def _ctx(responder, budget=1.0):
    cfg = ProvidersConfig(gateway="mock",
                          models={"deepseek": ModelSpec(provider="deepseek", model="deepseek-chat")})
    meter = CostMeter(budget_usd=budget)
    gw = build_gateway(cfg, meter, offline=True, responder=responder)
    return AgentContext(gateway=gw, meter=meter, default_model="deepseek")


def test_produces_grade_A(tmp_path):
    ctx = _ctx(lambda alias, msgs: GOOD_SPEC)
    res = WireframingAgent(ctx, out_dir=tmp_path / "wf", max_iterations=2).run("charter text")
    assert res.success
    assert res.output["grade"] == "A"
    assert res.output["iterations"] == 1
    assert (tmp_path / "wf" / "index.html").exists()
    assert (tmp_path / "wf" / "styles.css").exists()


def test_revises_then_succeeds(tmp_path):
    calls = {"n": 0}

    def responder(alias, msgs):
        calls["n"] += 1
        return BAD_SPEC if calls["n"] == 1 else GOOD_SPEC

    res = WireframingAgent(ctx := _ctx(responder), out_dir=tmp_path / "wf", max_iterations=3).run("c")
    assert res.success
    assert res.output["grade"] == "A"
    assert res.output["iterations"] == 2   # first audit failed, revised, then passed
    assert ctx.meter.calls == 2            # one spec call + one revision call


def test_stops_at_max_iterations(tmp_path):
    # Always-bad spec: never reaches A; should stop at max_iterations with the last grade.
    res = WireframingAgent(_ctx(lambda a, m: BAD_SPEC), out_dir=tmp_path / "wf",
                           max_iterations=2).run("c")
    assert res.success                      # ran cleanly even though it didn't reach A
    assert res.output["grade"] != "A"
    assert res.output["iterations"] == 2
    assert res.output["issues"]
