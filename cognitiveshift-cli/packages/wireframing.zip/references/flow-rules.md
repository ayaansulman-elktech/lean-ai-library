# Flow-audit rules

The wireframe must score "A" before hand-off. Thresholds (tune per niche):

- Clicks to a key action (login / checkout / cancel): ≤ N
- Features per page: ≤ N
- Max navigation depth: ≤ N
- Orphan pages / dead buttons: 0

Scoring lives in `scripts/flow_audit.py`. Best-practice reference flows come from
`libraries/memory` (App-Benchmark).
