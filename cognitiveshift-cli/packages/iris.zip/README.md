# iris (model card)

Iris / eye-landmark detection — pupil center + iris boundary
([Morris88826/MediaPipe_Iris](https://github.com/Morris88826/MediaPipe_Iris), a PyTorch port of
Google's MediaPipe Iris).

- **Task:** locate the **iris** (pupil center + boundary) and eye contour in an eye.
- **Inputs:** an **eye crop**, or a **face image + a normalized eye box** `(x,y,w,h)` — the box comes
  from **face-parsing** (Task 4), so the two compose: face-parsing finds the eye, iris pinpoints it.
- **Outputs:** an `IrisResult` (center, radius, boundary points) + `metrics.eye_color` — the
  person's **eye colour**, sampled from the iris ring (the Colors Matching payload).
- **Status:** `raw`, self-contained (`deps: []`). Weights are a one-time TFLite→PyTorch conversion
  (`iris_landmark.pth`, ~2.7MB); after that it's **torch-only** and CPU-fast. The upstream MediaPipe
  face-mesh crop stage is skipped (we supply the eye box), so **no mediapipe/tensorflow at runtime**.
- **Apple-native:** *partial* — Vision gives single **pupil points**, ARKit gives gaze/eye
  transforms (TrueDepth), but neither localizes the **iris disc** on an arbitrary photo.

## Use
```python
from blocks.iris.src import build
from blocks.iris.src.metrics import eye_color

model = build()                                    # real model when weights are on the box
res   = model.predict("selfie.jpg", eye_box=(0.36, 0.34, 0.10, 0.06))   # box from face-parsing
res.center, res.radius                             # where the iris is (normalized in the crop)
eye_color("selfie.jpg", res)                       # -> {"rgb": [...], "hex": "#.."} eye colour
```

## Producing the weights (one-time)
The repo ships `data/iris_landmark.tflite`; convert it to `iris_landmark.pth` (read the TFLite with
`ai-edge-litert` — no full TensorFlow needed), then place it under `ios-ready/raw/iris/`. Done once on
the farm; the block auto-discovers `libs/iris.py` + the `.pth` and runs torch-only.
