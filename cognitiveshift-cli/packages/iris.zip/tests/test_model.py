"""Offline tests for the iris block — mock-backed, no torch/weights (green in CI)."""

import json
from pathlib import Path

from blocks.iris.src import build
from blocks.iris.src.iris_result import IrisResult
from blocks.iris.src.metrics import iris_summary
from blocks.iris.src.mock import MockIris

BLOCK = Path(__file__).resolve().parents[1]


def test_offline_build_is_the_mock():
    assert isinstance(build(offline=True), MockIris)


def test_mock_predict_returns_a_centered_iris():
    res = build(offline=True).predict("eye.png", eye_box=(0.1, 0.2, 0.3, 0.3))
    assert isinstance(res, IrisResult)
    assert abs(res.center[0] - 0.5) < 0.01 and abs(res.center[1] - 0.5) < 0.01
    assert res.radius > 0 and len(res.contour) == 4
    assert res.eye_box == (0.1, 0.2, 0.3, 0.3)          # passed through for mapping back


def test_iris_summary_is_pure_and_shaped():
    s = iris_summary(build(offline=True).predict("x"))
    assert set(s) == {"center", "radius", "iris_box"}
    assert s["radius"] > 0 and len(s["iris_box"]) == 4


def test_deterministic():
    a = build(offline=True).predict("x")
    b = build(offline=True).predict("x")
    assert a.center == b.center and a.contour == b.contour


def test_eye_color_samples_the_iris_ring(tmp_path):
    import pytest
    pytest.importorskip("numpy")
    pytest.importorskip("PIL")
    from blocks.iris.src.metrics import eye_color
    from PIL import Image
    p = tmp_path / "eye.png"
    Image.new("RGB", (64, 64), (40, 130, 60)).save(p)   # a solid green "eye"
    color = eye_color(str(p), build(offline=True).predict(str(p)))
    assert color["rgb"][1] > color["rgb"][0] and color["rgb"][1] > color["rgb"][2]  # green dominant
    assert color["hex"].startswith("#")


def test_manifest_and_required_files():
    man = json.loads((BLOCK / "block.json").read_text(encoding="utf-8"))
    for key in ("name", "version", "task", "status", "adapter", "mock", "deps", "apple_native",
                "weights"):
        assert key in man
    assert isinstance(man["deps"], list)
    assert man["adapter"].startswith("blocks.iris.")
    assert man["apple_native"]["verdict"] == "partial"
    for rel in ("block.json", "README.md", "src/__init__.py", "src/model.py", "src/mock.py"):
        assert (BLOCK / rel).exists(), f"missing {rel}"
