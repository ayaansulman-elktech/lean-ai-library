"""Iris block — iris/eye landmark detection (pupil center + iris boundary). See ../README.md."""
