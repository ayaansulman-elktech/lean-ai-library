"""Real iris adapter — MediaPipe Iris (PyTorch port, github.com/Morris88826/MediaPipe_Iris).

Locates the iris (pupil center + iris boundary) and eye contour from a 64x64 eye crop. Weights are
a one-time TFLite->PyTorch conversion (`iris_landmark.pth`, ~2.7MB); after that it's torch-only and
CPU-fast. The upstream repo uses MediaPipe Face Mesh to crop the eye first — this block skips that:
it takes an eye crop, or a face image + an eye bounding box (which face-parsing provides), so no
mediapipe/tensorflow at runtime.

Lazy imports; `is_available()` gates the fallback to the mock. The block auto-discovers the repo
code (`libs/iris.py`) and a `iris_landmark.pth` under `ios-ready/raw/`.
"""

from __future__ import annotations

from pathlib import Path

from blocks.iris.src.iris_result import IrisResult

# libraries/models/blocks/iris/src/model.py -> parents[4] == libraries
_RAW = Path(__file__).resolve().parents[4] / "ios-ready" / "raw"
_PATCH = 64


class MediaPipeIrisModel:
    def __init__(self, *, code_dir=None, weights=None, device: str = "cpu") -> None:
        self.code_dir = Path(code_dir) if code_dir else None
        self.weights = Path(weights) if weights else None
        self.device = device
        self._net = None

    def _find_code(self) -> Path | None:
        if self.code_dir and (self.code_dir / "libs" / "iris.py").exists():
            return self.code_dir
        hit = next(_RAW.glob("**/libs/iris.py"), None)
        return hit.parent.parent if hit else None            # dir that contains libs/

    def _find_weights(self) -> Path | None:
        if self.weights and self.weights.exists():
            return self.weights
        for pat in ("iris/**/iris_landmark.pth", "**/iris_landmark.pth"):
            hit = next(_RAW.glob(pat), None)
            if hit:
                return hit
        return None

    def is_available(self) -> bool:
        """True only if torch is importable AND the iris code + a checkpoint are present."""
        try:
            import torch  # noqa: F401
        except Exception:
            return False
        return self._find_code() is not None and self._find_weights() is not None

    def _load(self):
        if self._net is not None:
            return self._net
        import sys
        import types
        code, wt = self._find_code(), self._find_weights()
        if code is None or wt is None:
            raise RuntimeError(
                f"MediaPipe Iris not available: need torch + the repo (libs/iris.py) and an "
                f"iris_landmark.pth under {_RAW}. Use build(offline=True) for the mock."
            )
        if str(code) not in sys.path:
            sys.path.insert(0, str(code))
        # the repo's iris.py imports its MediaPipe face-mesh module — stub it (we crop eyes ourselves)
        stub = types.ModuleType("iris_face_stub")
        stub.FaceLandmarksDetector = object
        sys.modules.setdefault("libs.face", stub)
        sys.modules.setdefault("face", stub)
        from libs.iris import MediaPipeIris
        net = MediaPipeIris(pretrained=True, ckpt_path=str(wt))
        net.to(self.device).eval()
        self._net = net
        return net

    def predict(self, image, eye_box=None, is_left: bool = True) -> IrisResult:
        """Locate the iris in an eye crop (or a face image + normalized eye_box (x,y,w,h)).

        Matches the repo's preprocessing: crop -> 64x64 -> /255 -> (1,3,64,64). The right eye is
        horizontally flipped in and out (the model is trained on left eyes).
        """
        import numpy as np
        import torch
        from PIL import Image

        net = self._load()
        im = Image.open(image).convert("RGB") if isinstance(image, (str, Path)) else image.convert("RGB")
        if eye_box:
            x, y, w, h = eye_box
            wpx, hpx = im.size
            im = im.crop((int(x * wpx), int(y * hpx), int((x + w) * wpx), int((y + h) * hpx)))
        arr = np.asarray(im.resize((_PATCH, _PATCH), Image.BILINEAR), "float32")   # (64,64,3), 0-255
        if not is_left:
            arr = arr[:, ::-1].copy()
        t = torch.from_numpy(np.transpose(arr, (2, 0, 1)) / 255.0).unsqueeze(0).float().to(self.device)
        with torch.no_grad():
            _eye_contour, iris = net(t)
        pts = iris.squeeze().reshape(-1, 3).cpu().numpy()      # (5,3): pupil center + 4 boundary, 0-64
        if not is_left:
            pts[:, 0] = _PATCH - pts[:, 0]
        center = (float(pts[0, 0] / _PATCH), float(pts[0, 1] / _PATCH))
        contour = [(float(p[0] / _PATCH), float(p[1] / _PATCH)) for p in pts[1:5]]
        radius = float(np.mean([((cx - center[0]) ** 2 + (cy - center[1]) ** 2) ** 0.5
                                for cx, cy in contour]))
        return IrisResult(center=center, radius=radius, contour=contour, eye_box=eye_box)
