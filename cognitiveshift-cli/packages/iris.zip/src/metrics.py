"""What the Colors Matching app wants from the iris: where it is, and its colour.

`iris_summary` is pure Python (the iris centre / radius / box). `eye_color` samples the iris ring
to get the person's eye colour — it reads pixels, so it lazily needs numpy + Pillow (the same deps
the real model already brings).
"""

from __future__ import annotations

from pathlib import Path


def iris_summary(res) -> dict:
    """Iris centre, radius, and a normalized bounding box — no pixels needed."""
    cx, cy = res.center
    return {
        "center": [round(cx, 4), round(cy, 4)],
        "radius": round(res.radius, 4),
        "iris_box": [round(cx - res.radius, 4), round(cy - res.radius, 4),
                     round(2 * res.radius, 4), round(2 * res.radius, 4)],
    }


def eye_color(image, res) -> dict:
    """Dominant iris colour (the eye colour). Samples the iris ring (skips the dark pupil and the
    rim). `image` is the eye crop, or the source image if `res.eye_box` is set. Needs numpy + PIL."""
    import numpy as np
    from PIL import Image

    im = Image.open(image).convert("RGB") if isinstance(image, (str, Path)) else image.convert("RGB")
    if res.eye_box:
        x, y, w, h = res.eye_box
        wpx, hpx = im.size
        im = im.crop((int(x * wpx), int(y * hpx), int((x + w) * wpx), int((y + h) * hpx)))
    im = im.resize((64, 64))
    a = np.asarray(im, "float32")
    cx, cy, r = res.center[0] * 64, res.center[1] * 64, max(res.radius * 64, 2.0)
    ys, xs = np.mgrid[0:64, 0:64]
    d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
    ring = (d >= 0.35 * r) & (d <= 0.9 * r)          # iris annulus: past the pupil, inside the rim
    if ring.sum() < 5:
        ring = d <= r
    rgb = a[ring].mean(axis=0)
    r8, g8, b8 = (int(round(v)) for v in rgb)
    return {"rgb": [r8, g8, b8], "hex": f"#{r8:02x}{g8:02x}{b8:02x}"}
