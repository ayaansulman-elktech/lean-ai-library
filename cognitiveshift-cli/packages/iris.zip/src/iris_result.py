"""Lightweight iris-detection result — dependency-free (plain floats), so the mock, metrics, and
tests run in CI. Coordinates are normalized [0,1] within the 64px eye crop the model saw."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class IrisResult:
    center: tuple[float, float]              # pupil center, normalized in the eye crop
    radius: float                            # iris radius, normalized (fraction of the crop)
    contour: list = field(default_factory=list)      # 4 iris-boundary points, normalized
    eye_box: tuple | None = None             # the crop box (x, y, w, h) in the source image, if any

    def to_dict(self) -> dict:
        return {"center": [round(c, 4) for c in self.center], "radius": round(self.radius, 4),
                "contour": [[round(x, 4), round(y, 4)] for x, y in self.contour],
                "eye_box": list(self.eye_box) if self.eye_box else None}
