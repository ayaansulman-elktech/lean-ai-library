"""Deterministic offline stand-in for MediaPipe Iris — no torch, runs in CI.

Returns a plausible centered iris (pupil at the crop centre, a symmetric 4-point boundary). Pixels
are ignored by design — for offline tests/demos, not real detection.
"""

from __future__ import annotations

from blocks.iris.src.iris_result import IrisResult

_R = 0.18


class MockIris:
    def is_available(self) -> bool:
        return True

    def predict(self, image, eye_box=None, is_left: bool = True) -> IrisResult:  # noqa: ARG002
        return IrisResult(
            center=(0.5, 0.5), radius=_R,
            contour=[(0.5 + _R, 0.5), (0.5, 0.5 - _R), (0.5 - _R, 0.5), (0.5, 0.5 + _R)],
            eye_box=eye_box,
        )
