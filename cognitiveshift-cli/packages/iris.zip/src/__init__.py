"""Iris block factory. `build(offline=False)` returns the real MediaPipe-Iris adapter when torch +
the converted weight are on the box, else the deterministic mock."""

from __future__ import annotations

from blocks.iris.src.mock import MockIris
from blocks.iris.src.model import MediaPipeIrisModel


def build(offline: bool = False, **kwargs):
    if not offline:
        model = MediaPipeIrisModel(**{k: v for k, v in kwargs.items()
                                      if k in {"code_dir", "weights", "device"}})
        if model.is_available():
            return model
    return MockIris()


__all__ = ["build", "MediaPipeIrisModel", "MockIris"]
