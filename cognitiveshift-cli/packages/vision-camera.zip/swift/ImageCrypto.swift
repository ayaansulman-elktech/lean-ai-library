// ImageCrypto.swift - encrypt captured images at rest before persistence.
// Reusable across any on-device "scan" app. Uses CryptoKit (no third-party deps).
// Starter: key handling is simplified — wire `key` to the Keychain in production.

import Foundation
import CryptoKit

enum ImageCrypto {
    /// Encrypts raw image data with AES-GCM. Returns combined nonce+ciphertext+tag.
    static func encrypt(_ data: Data, key: SymmetricKey) throws -> Data {
        let sealed = try AES.GCM.seal(data, using: key)
        guard let combined = sealed.combined else {
            throw NSError(domain: "ImageCrypto", code: 1)
        }
        return combined
    }

    /// Decrypts data produced by `encrypt`.
    static func decrypt(_ combined: Data, key: SymmetricKey) throws -> Data {
        let box = try AES.GCM.SealedBox(combined: combined)
        return try AES.GCM.open(box, using: key)
    }

    // TODO: store/retrieve the SymmetricKey via Keychain (kSecAttrAccessibleWhenUnlocked).
}
