"""Detection tests — skipped in CI (needs the image stack); the pure-rules tests always run."""
import pytest

pytest.importorskip("numpy")
pytest.importorskip("PIL")
pytest.importorskip("scipy")

from blocks.ux_position_mask.src.detect import audit_image, detect_elements  # noqa: E402
from PIL import Image, ImageDraw  # noqa: E402


def _screen(tmp_path, button_y):
    img = Image.new("RGB", (300, 600), (247, 248, 250))
    d = ImageDraw.Draw(img)
    d.rectangle([40, 80, 260, 300], fill=(214, 226, 246))          # hero (content)
    d.rounded_rectangle([40, button_y, 260, button_y + 56], 20, fill=(63, 120, 232))  # a CTA button
    p = tmp_path / "screen.png"
    img.save(p)
    return str(p)


def test_detects_saturated_button_as_primary(tmp_path):
    els = detect_elements(_screen(tmp_path, 500))
    assert any(e["role"] == "primary" for e in els)
    prim = next(e for e in els if e["role"] == "primary")
    assert prim["box"][1] > 0.6                                     # button is in the lower band


def test_audit_image_returns_score(tmp_path):
    res = audit_image(_screen(tmp_path, 500))
    assert res["detected"] >= 1
    assert 0 <= res["score"] <= 100 and res["grade"] in {"A", "B", "C", "D", "F"}


def test_bottom_button_good_top_button_dangerous(tmp_path):
    low = audit_image(_screen(tmp_path, 500))     # thumb zone -> primary good
    high = audit_image(_screen(tmp_path, 20))     # top edge -> primary dangerous
    assert low["score"] > high["score"]
