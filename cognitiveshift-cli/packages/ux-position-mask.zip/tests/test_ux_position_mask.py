from blocks.ux_position_mask.src.ux_position_mask import audit


def _one(role, box):
    return audit([{"name": "el", "role": role, "box": box}])["elements"][0]


# ---- primary action (thumb reach) ---------------------------------------------------------
def test_primary_cta_in_thumb_zone_is_good():
    r = _one("primary", [0.2, 0.80, 0.6, 0.08])   # bottom-center
    assert r["reach"] == "easy"
    assert r["verdict"] == "good"


def test_primary_cta_at_top_is_dangerous():
    r = _one("primary", [0.2, 0.04, 0.6, 0.08])    # top of screen -> also edge, still dangerous
    assert r["verdict"] == "dangerous"


def test_primary_cta_upper_mid_is_ok():
    # upper-middle: outside the lower-center easy circle but not yet hard
    r = _one("primary", [0.2, 0.26, 0.6, 0.08])   # center ~ (0.5, 0.30)
    assert r["reach"] == "ok"
    assert r["verdict"] == "ok"


def test_reach_is_radial_top_hard_bottom_easy():
    # away from safe-area edges: high up = out of thumb reach (hard), a bottom corner = easy
    top = _one("primary", [0.30, 0.10, 0.40, 0.08])     # center ~ (0.5, 0.14)
    assert top["reach"] == "hard" and top["verdict"] == "dangerous"
    corner = _one("primary", [0.06, 0.84, 0.34, 0.08])  # bottom-left, still in the thumb arc
    assert corner["reach"] == "easy" and corner["verdict"] == "good"


# ---- content (attention / active zones) ---------------------------------------------------
def test_hero_content_in_high_attention_zone_is_good():
    r = _one("content", [0.1, 0.20, 0.8, 0.15])
    assert r["attention"] == "high"
    assert r["verdict"] == "good"


def test_content_in_passive_zone_is_ok():
    r = _one("content", [0.1, 0.80, 0.8, 0.10])
    assert r["attention"] == "low"
    assert r["verdict"] == "ok"


# ---- safe areas ---------------------------------------------------------------------------
def test_element_overlapping_home_indicator_is_dangerous():
    r = _one("secondary", [0.1, 0.94, 0.8, 0.05])   # crosses y=0.95 (1-BOTTOM)
    assert r["verdict"] == "dangerous"
    assert any("home indicator" in reason for reason in r["reasons"])


def test_element_crossing_side_edge_is_flagged():
    r = _one("content", [0.0, 0.4, 0.5, 0.1])        # x=0 < SIDE
    assert r["verdict"] == "dangerous"
    assert any("side edge" in reason for reason in r["reasons"])


# ---- aggregate ----------------------------------------------------------------------------
def test_score_grade_and_flags():
    out = audit([
        {"name": "cta", "role": "primary", "box": [0.2, 0.82, 0.6, 0.08]},   # good
        {"name": "hero", "role": "content", "box": [0.1, 0.18, 0.8, 0.2]},   # good
        {"name": "banner", "role": "content", "box": [0.1, 0.95, 0.8, 0.06]},  # dangerous (home indicator)
    ])
    assert out["flags"] == ["banner"]
    assert 0 <= out["score"] <= 100
    assert out["grade"] in {"A", "B", "C", "D", "F"}


def test_empty_input():
    out = audit([])
    assert out["elements"] == [] and out["score"] == 0.0
