# ux-position-mask (code block)

Audits a screen design: **which elements sit in good vs dangerous positions.** Two layers:

- **`audit(elements)`** — the pure, stdlib rules engine. Maps each element onto a UX zone mask
  (thumb reach, rule-of-thirds active zones, safe areas) → per-element verdict (good / ok /
  dangerous) + reasons + score/grade. Inputs: `[{name, role, box:[x,y,w,h]}]`, normalized `[0,1]`,
  origin top-left. Roles: `primary` (main CTA), `secondary` (supporting), `content` (hero/text/media).
- **`audit_image(path)`** — for an arbitrary screen **design/screenshot**: a classical, offline
  detector (background subtraction → connected components → role heuristics; Pillow/numpy/scipy)
  finds the elements, then `audit` scores them. Best-effort — correct it in the tester UI.

**Outputs:** `{ elements:[{verdict, reach, attention, reasons}], flags, score, grade, detected }`.

**First needed by:** UX auditing (code.md Task 4). Complements the `ux-audit` agent's saliency check.

**Migration path:** when auditing *generated* screens, drop `audit_image`'s detection and feed the
element boxes from the known layout into `audit` — the rules don't change.

## The rules
Grounded in the **Design Composition** knowledge corpus (`../../../knowledge/composition` — active
vs passive zones, rule of thirds: *"place header text, hero images, or CTA buttons in the active
zones"*) and the standard mobile thumb-zone reachability map.

- **Thumb reach** (radial, one-handed — the dominant ~49% grip): a circular comfort zone centered
  in the **lower-middle** of the screen (where the thumb rests and sweeps). The green **EASY**
  circle sits lower-center and reaches up to about the middle; the yellow **OK** ring surrounds it;
  the **top — especially the top corners — is red HARD** (out of reach one-handed). Primary actions
  belong in the easy circle.
- **Active zones** (rule of thirds / F-pattern top-weighting): the upper region and thirds lines get
  the most attention → key content belongs there; passive zones get less.
- **Safe areas**: elements crossing the status bar/notch, the home indicator, or the screen edges
  are flagged dangerous (may be clipped or hard to tap).

## Use
```python
from blocks.ux_position_mask.src.ux_position_mask import audit
audit([{"name": "Buy", "role": "primary", "box": [0.2, 0.82, 0.6, 0.08]}])
# -> primary action in the natural thumb zone -> "good"
```

Grounded in `../../../knowledge/composition` (active/passive zones, rule of thirds). Deterministic
and offline — no model, no LLM.
