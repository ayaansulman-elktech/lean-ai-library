"""UX position mask — flag which screen elements sit in good vs dangerous positions.

Deterministic, offline, no model. Given a screen's elements (a role + a normalized bounding box),
it maps each onto a screen "mask" of UX zones and returns a per-element verdict (good / ok /
dangerous) with reasons, plus an overall score and grade. It answers the Task-4 question — "which
elements are in a good, or dangerous position" — from three well-established rules:

- **Thumb-reach ergonomics** (portrait phone): the lower-center is the easy/natural reach; the top
  (especially corners) is a stretch. Primary, tappable actions belong where the thumb lands.
- **Rule-of-thirds active zones** (see ../../../knowledge/composition): the upper region and the
  thirds lines draw the eye first — good for key content; the passive zones get less attention.
- **Safe areas**: elements crossing the status-bar/notch, the home-indicator, or the screen edges
  risk being clipped or hard to tap.

Coordinates are normalized [0,1] with origin at the top-left, y increasing downward:
`box = [x, y, w, h]`. Roles: "primary" (the main call-to-action), "secondary" (supporting
controls), "content" (hero/text/media).

CLI:  python ux_position_mask.py elements.json   ->   JSON audit
"""

from __future__ import annotations

# --- safe-area margins (fractions of screen) ----------------------------------------------
SIDE = 0.04       # left/right edge
TOP = 0.05        # status bar / notch
BOTTOM = 0.05     # home indicator

# --- thumb-reach zones (radial) -----------------------------------------------------------
# One-handed use is the dominant mobile grip (~49%). Reachability is a circular comfort zone
# centered in the lower-middle of the screen (where the thumb naturally rests and sweeps), matching
# the standard mobile thumb-zone map: the green EASY circle sits lower-center, the yellow OK ring
# surrounds it, and the top — especially the top corners — is red HARD (out of reach one-handed).
_COMFORT = (0.48, 0.82)  # centre of the easy thumb arc (normalized), lower-middle
_EASY_R = 0.40           # green: comfortable to reach
_OK_R = 0.62             # yellow: a stretch


def _reach(cx: float, cy: float) -> str:
    d = ((cx - _COMFORT[0]) ** 2 + (cy - _COMFORT[1]) ** 2) ** 0.5
    if d <= _EASY_R:
        return "easy"
    if d <= _OK_R:
        return "ok"
    return "hard"


# --- attention by center position (rule of thirds / F-pattern top-weighting) --------------
def _attention(cx: float, cy: float) -> str:
    near_third = min(abs(cy - 1 / 3), abs(cy - 2 / 3)) < 0.06
    if cy <= 0.38 or near_third:
        return "high"
    if cy <= 0.72:
        return "medium"
    return "low"


# --- safe-area / edge check ---------------------------------------------------------------
def _edge_flags(box) -> list[str]:
    x, y, w, h = box
    flags = []
    if x < SIDE or x + w > 1 - SIDE:
        flags.append("crosses a side edge")
    if y < TOP:
        flags.append("overlaps the status bar / notch")
    if y + h > 1 - BOTTOM:
        flags.append("overlaps the home indicator")
    return flags


def _center(box) -> tuple[float, float]:
    x, y, w, h = box
    return x + w / 2, y + h / 2


def _verdict(role: str, reach: str, attention: str, edges: list[str]) -> tuple[str, list[str]]:
    reasons: list[str] = []
    verdict = "ok"

    if edges:
        return "dangerous", [*edges, "may be clipped or hard to tap — keep inside the safe area"]

    if role == "primary":
        if reach == "easy":
            verdict, reasons = "good", ["primary action sits in the natural thumb zone"]
        elif reach == "hard":
            verdict, reasons = "dangerous", ["primary action is out of easy thumb reach — "
                                             "move it to the lower-center of the screen"]
        else:
            verdict, reasons = "ok", ["primary action is reachable but not in the prime thumb zone"]
    elif role == "content":
        if attention == "high":
            verdict, reasons = "good", ["key content is in a high-attention (active) zone"]
        elif attention == "low":
            verdict, reasons = "ok", ["content is in a passive zone — consider moving it up if it matters"]
        else:
            verdict, reasons = "ok", ["content is in a medium-attention zone"]
    else:  # secondary
        if reach == "easy":
            verdict, reasons = "ok", ["secondary control is in the prime thumb zone — make sure it "
                                      "doesn't compete with the primary action"]
        else:
            verdict, reasons = "good", ["secondary control is appropriately out of the prime zone"]

    return verdict, reasons


_SCORE = {"good": 1.0, "ok": 0.6, "dangerous": 0.0}


def _grade(score: float) -> str:
    return ("A" if score >= 90 else "B" if score >= 80 else "C" if score >= 65
            else "D" if score >= 50 else "F")


def audit(elements, orientation: str = "portrait") -> dict:
    """Audit element positions. `elements` = [{"name", "role", "box": [x,y,w,h]}] in normalized
    [0,1] coords. Returns per-element verdicts, an overall 0-100 score, a grade, and the list of
    dangerous elements (`flags`)."""
    results = []
    for el in elements:
        name = el.get("name", "element")
        role = el.get("role", "content")
        box = el["box"]
        cx, cy = _center(box)
        reach = _reach(cx, cy)
        attention = _attention(cx, cy)
        edges = _edge_flags(box)
        verdict, reasons = _verdict(role, reach, attention, edges)
        results.append({"name": name, "role": role, "reach": reach, "attention": attention,
                        "verdict": verdict, "reasons": reasons})

    score = round(100 * sum(_SCORE[r["verdict"]] for r in results) / len(results), 1) if results else 0.0
    return {
        "orientation": orientation,
        "elements": results,
        "flags": [r["name"] for r in results if r["verdict"] == "dangerous"],
        "score": score,
        "grade": _grade(score),
    }


def _main(argv: list[str]) -> int:
    import json
    import sys
    if len(argv) < 2:
        print("usage: python ux_position_mask.py elements.json", file=sys.stderr)
        return 2
    with open(argv[1], encoding="utf-8") as f:
        data = json.load(f)
    elements = data["elements"] if isinstance(data, dict) else data
    print(json.dumps(audit(elements), indent=2))
    return 0


if __name__ == "__main__":
    import sys
    raise SystemExit(_main(sys.argv))
