"""UX position mask block — the public seam.

`audit(elements)` is the entry named in `block.json` `entry` (pure, stdlib). `audit_image(path)`
adds a classical detector so an arbitrary screen design can be audited from pixels; it needs the
image stack (Pillow/numpy/scipy) at call time and is imported lazily.
"""

from __future__ import annotations

from blocks.ux_position_mask.src.detect import audit_image, detect_elements
from blocks.ux_position_mask.src.ux_position_mask import audit

__all__ = ["audit", "audit_image", "detect_elements"]
