"""Classical UI-element detection for arbitrary screen designs (offline, no ML weights).

Turns a screen image into a list of `{name, role, box}` elements that `ux_position_mask.audit`
can score — so you can audit an arbitrary screenshot/design, not just hand-drawn boxes. It is a
best-effort heuristic detector (background subtraction -> connected components -> role heuristics),
meant to be corrected in the tester UI. When we migrate to *generated* screens, this whole step is
replaced by reading element boxes from the known layout — `audit` stays the same.

Runtime deps: Pillow + numpy + scipy (image stack). Kept out of CI: tests importorskip these, and
the pure-rules module (`ux_position_mask.py`) stays stdlib.

    detect_elements(path) -> [{"name","role","box":[x,y,w,h]}]   # normalized [0,1]
    audit_image(path)     -> detect_elements + ux_position_mask.audit
"""

from __future__ import annotations


def detect_elements(path, max_dim: int = 900) -> list[dict]:
    import numpy as np
    from PIL import Image
    from scipy import ndimage

    img = Image.open(path).convert("RGB")
    W0, H0 = img.size
    scale = min(1.0, max_dim / max(W0, H0))
    if scale < 1.0:
        img = img.resize((max(1, int(W0 * scale)), max(1, int(H0 * scale))))
    a = np.asarray(img).astype(np.int16)
    H, W, _ = a.shape

    # background = median of a thin border frame
    b = 6
    border = np.concatenate([a[:b].reshape(-1, 3), a[-b:].reshape(-1, 3),
                             a[:, :b].reshape(-1, 3), a[:, -b:].reshape(-1, 3)])
    bg = np.median(border, axis=0)

    # foreground = pixels that differ from the background
    dist = np.sqrt(((a - bg) ** 2).sum(axis=2))
    mask = dist > 30
    # merge glyphs into words/lines (wide horizontal close), then knit nearby rows
    mask = ndimage.binary_closing(mask, structure=np.ones((3, 21)))
    mask = ndimage.binary_closing(mask, structure=np.ones((9, 3)))
    mask = ndimage.binary_dilation(mask, structure=np.ones((3, 3)))

    lbl, n = ndimage.label(mask)
    out = []
    for i, sl in enumerate(ndimage.find_objects(lbl) or [], start=1):
        if sl is None:
            continue
        ys, xs = sl
        x, y, w, h = xs.start, ys.start, xs.stop - xs.start, ys.stop - ys.start
        frac = (w * h) / (W * H)
        if frac < 0.004 or frac > 0.55 or w < 10 or h < 10:
            continue
        comp = lbl[sl] == i
        px = a[ys, xs][comp]
        mx, mn = px.max(axis=1), px.min(axis=1)
        sat = float(((mx - mn) / (mx + 1.0)).mean())     # 0=grey, 1=vivid
        fill = float(comp.mean())                         # how solid the bbox is
        out.append({"x": x / W, "y": y / H, "w": w / W, "h": h / H,
                    "frac": frac, "sat": sat, "fill": fill, "ar": w / max(1, h)})

    return _assign_roles(out)


def _assign_roles(cands: list[dict]) -> list[dict]:
    """Heuristic role assignment: solid, saturated, wide-ish blobs are buttons; the strongest is
    the primary action; large/other blobs are content."""
    def button_score(c):
        if not (0.008 <= c["frac"] <= 0.22 and c["fill"] > 0.55 and 1.4 <= c["ar"] <= 9):
            return 0.0
        return c["sat"] * c["fill"] * (0.5 + c["frac"]) * (0.6 + c["y"])  # lower + vivid + solid

    scored = [(button_score(c), c) for c in cands]
    buttons = [c for s, c in scored if s > 0.05]
    primary = max(buttons, key=button_score, default=None)

    els = []
    for c in cands:
        if c is primary:
            role, name = "primary", "primary action"
        elif c in buttons:
            role, name = "secondary", "button"
        else:
            role = "content"
            name = "hero/image" if c["frac"] > 0.12 else "text"
        els.append({"name": name, "role": role,
                    "box": [round(c["x"], 4), round(c["y"], 4), round(c["w"], 4), round(c["h"], 4)]})
    # top-to-bottom, then left-to-right
    els.sort(key=lambda e: (round(e["box"][1], 2), e["box"][0]))
    return els


def audit_image(path) -> dict:
    """Detect elements in a screen image, then score their positions."""
    from blocks.ux_position_mask.src.ux_position_mask import audit
    els = detect_elements(path)
    result = audit(els)
    result["detected"] = len(els)
    return result
