"""Offline tests for the SUM block — mock/classical stand-ins, no torch/weights (green in CI)."""

import json
from pathlib import Path

from blocks.sum.src import build
from vis_models.saliency import ClassicalSaliencyModel, MockSaliencyModel, Region, analyze

BLOCK = Path(__file__).resolve().parents[1]
CTA = Region(0.25, 0.80, 0.50, 0.12)


def test_offline_build_is_the_deterministic_mock():
    assert isinstance(build(offline=True), MockSaliencyModel)


def test_default_build_uses_real_pixels_when_sum_absent():
    # No torch/weights on the box -> SUM falls back to the pixel-based classical model, not the mock.
    assert isinstance(build(), ClassicalSaliencyModel)


def test_attention_check_on_the_cta():
    model = build(offline=True, hot_regions=[CTA])       # mock attention modelled onto the CTA
    rep = analyze(model.predict("screen.png"), CTA)
    assert rep.passes and rep.primary_attention >= rep.threshold


def test_manifest_and_required_files():
    man = json.loads((BLOCK / "block.json").read_text(encoding="utf-8"))
    for key in ("name", "version", "task", "status", "adapter", "mock", "apple_native", "weights"):
        assert key in man
    assert man["adapter"].startswith("blocks.sum.") and man["mock"].startswith("blocks.sum.")
    assert man["apple_native"]["verdict"] == "partial"   # Vision has general saliency
    for rel in ("block.json", "README.md", "src/__init__.py", "src/model.py", "src/mock.py"):
        assert (BLOCK / rel).exists(), f"missing {rel}"
