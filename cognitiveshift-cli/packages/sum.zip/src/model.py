"""SUM adapter — re-exported from the shared saliency core.

SUM's real adapter lives in `vis_models.saliency.sum_model` because ux-audit consumes it directly
and it produces the shared `SaliencyMap`. This block re-exports it (no second copy of the code) so
the block is self-contained and its manifest resolves under `blocks.sum.*`.
"""

from vis_models.saliency.sum_model import SUMSaliencyModel

__all__ = ["SUMSaliencyModel"]
