"""Deterministic offline stand-in for SUM — re-exported from the shared saliency core.

`build(offline=True)` returns this `MockSaliencyModel` (pixel-free, deterministic). Offline but not
forced, `build()` returns a real pixel-based `ClassicalSaliencyModel` instead (see build()).
"""

from vis_models.saliency.mock import MockSaliencyModel

__all__ = ["MockSaliencyModel"]
