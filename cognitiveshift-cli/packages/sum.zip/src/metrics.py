"""Still-screen saliency metric: does predicted attention land on the primary action?

Re-exports the canonical `vis_models.saliency.analyze` (focal point, dispersion, CTA attention,
pass/fail) so it's discoverable under the block. There is no SUM-specific post-processing.
"""

from vis_models.saliency import DEFAULT_CTA_THRESHOLD, analyze

__all__ = ["analyze", "DEFAULT_CTA_THRESHOLD"]
