"""SUM block factory — delegates to the shared, tested `vis_models.saliency.build_saliency('sum')`:
real SUM when torch + weights are on the box, else a real pixel-based classical model, or the
deterministic mock when `offline=True`."""

from __future__ import annotations

from vis_models.saliency import build_saliency

from blocks.sum.src.mock import MockSaliencyModel
from blocks.sum.src.model import SUMSaliencyModel

_BUILD_KEYS = {"grid", "sum_dir", "weights", "device", "condition",
               "center_bias", "baseline", "edge_weight", "hot_regions", "sigma"}


def build(offline: bool = False, **kwargs):
    return build_saliency("sum", offline=offline,
                          **{k: v for k, v in kwargs.items() if k in _BUILD_KEYS})


__all__ = ["build", "SUMSaliencyModel", "MockSaliencyModel"]
