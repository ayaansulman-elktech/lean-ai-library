"""SUM block — still-image saliency (attention on a screen). See ../README.md."""
