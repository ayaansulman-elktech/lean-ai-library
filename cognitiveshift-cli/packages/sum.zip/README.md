# sum (model card)

Still-image saliency — where viewers look on a screen
([Arhosseini77/SUM](https://github.com/Arhosseini77/SUM), *Saliency Unification through Mamba*).

- **Task:** predict a human-attention heatmap for a still screen/image (UI/web-page condition).
- **Inputs:** an image (screen or screenshot). **Outputs:** a `vis_models` `SaliencyMap`.
- **Status:** `raw` — the adapter is the shared `vis_models.saliency` core (used by ux-audit). Real
  `.pth` weights run in iOS Ready (`ios-ready/raw/SUM`); offline it falls back to a real
  pixel-based classical model, or a deterministic mock when forced.
- **Apple-native:** *partial* — Vision's `VNGenerateAttentionBasedSaliencyImageRequest` gives
  general on-device saliency, but not a UI-tuned model; SUM's interface condition is why it's used.

## Use
```python
from blocks.sum.src import build
from blocks.sum.src.metrics import analyze
from vis_models.saliency import Region

model = build()                              # real SUM on the farm; classical pixel model elsewhere
smap  = model.predict("screen.png")
analyze(smap, Region(0.25, 0.80, 0.50, 0.12))   # does attention peak on the primary action?
```

The SUM vs ViNet split: **SUM = still screens, ViNet = video/onboarding clips.**

## Running the real model (iOS Ready)
Fetch the SUM repo + checkpoint into `ios-ready/raw/SUM/`, install `torch`, then `build()` returns
the real `SUMSaliencyModel` (`is_available()` gates the fallback).
