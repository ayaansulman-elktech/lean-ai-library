"""Wireframing MCP server — exposes the editable-flow tools over the MCP protocol.

Any MCP-capable agent (Codex / Claude) connects to this server and drives one shared
wireframe turn by turn: add screens, place elements, link screens, grade, export.

Run (needs the transport):  pip install "wireframing-mcp[server]"  then  python -m wireframing_mcp.server
The tool logic lives in `core.py` and is fully offline-testable without this transport.
"""
from __future__ import annotations

from . import core


def build_server():
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as e:  # pragma: no cover - transport is optional
        raise SystemExit(
            "The Wireframing MCP server needs the 'mcp' package.\n"
            "  pip install \"wireframing-mcp[server]\"\n"
            "(The core tools + HTTP bridge run without it.)"
        ) from e

    mcp = FastMCP("wireframing")
    state = {"spec": core.new_wireframe()}

    @mcp.tool()
    def new_wireframe(name: str = "App") -> dict:
        """Start a fresh wireframe with one entry screen (id 'index')."""
        state["spec"] = core.new_wireframe(name)
        return state["spec"]

    @mcp.tool()
    def add_screen(title: str, screen_id: str | None = None) -> str:
        """Add a screen to the current wireframe; returns its id."""
        return core.add_screen(state["spec"], title, screen_id)

    @mcp.tool()
    def rename_screen(screen_id: str, title: str) -> dict:
        """Rename a screen."""
        core.rename_screen(state["spec"], screen_id, title)
        return state["spec"]

    @mcp.tool()
    def place_element(screen_id: str, element: str) -> dict:
        """Add a content element (label) to a screen."""
        core.place_element(state["spec"], screen_id, element)
        return state["spec"]

    @mcp.tool()
    def add_action(screen_id: str, action: str) -> dict:
        """Mark a primary action (key tap target) on a screen, e.g. 'checkout'."""
        core.add_action(state["spec"], screen_id, action)
        return state["spec"]

    @mcp.tool()
    def link_screens(from_id: str, label: str, to_id: str) -> dict:
        """Add a navigation link (a button/row -> target screen)."""
        core.link_screens(state["spec"], from_id, label, to_id)
        return state["spec"]

    @mcp.tool()
    def unlink(from_id: str, to_id: str) -> int:
        """Remove links from one screen to another; returns how many were removed."""
        return core.unlink(state["spec"], from_id, to_id)

    @mcp.tool()
    def remove_screen(screen_id: str) -> dict:
        """Delete a screen (links to it become dead links, surfaced by audit)."""
        core.remove_screen(state["spec"], screen_id)
        return state["spec"]

    @mcp.tool()
    def audit() -> dict:
        """Grade the current flow A–F with the specific issues and metrics."""
        return core.audit(state["spec"])

    @mcp.tool()
    def export_html(out_dir: str) -> list[str]:
        """Write one link-complete HTML page per screen to out_dir."""
        return core.export_html(state["spec"], out_dir)

    @mcp.tool()
    def get_spec() -> dict:
        """Return the current WireframeSpec (hand off to the wireframe-studio editor)."""
        return state["spec"]

    @mcp.tool()
    def load_spec(spec: dict) -> dict:
        """Replace the current wireframe with one edited elsewhere (e.g. the studio)."""
        core.validate(spec)
        state["spec"] = spec
        return spec

    return mcp


def main():  # pragma: no cover
    build_server().run()


if __name__ == "__main__":  # pragma: no cover
    main()
