"""Wireframing MCP — core tool logic (pure Python, offline, no MCP SDK needed).

These functions are the editable-flow operations the MCP exposes: create a wireframe,
add/rename screens, place elements, add primary actions, link screens (add a button ->
target), then audit and export. They operate on a plain-dict `WireframeSpec`
(`{"screens": [{"id","title","elements","links":[{"label","to"}],"actions"}]}`) — the same
contract the wireframing agent and the `wireframe-studio` editor use.

Grading and HTML generation are **reused** from `agents/wireframing` (single source of truth),
not reimplemented here. `server.py` wraps these as MCP tools; `bridge.py` serves them over HTTP
to the browser studio.
"""
from __future__ import annotations

import shutil
import sys
import tempfile
from pathlib import Path

# --- reuse the canonical spec / generator / auditor from agents/wireframing ------------
_here = Path(__file__).resolve()
_ROOT = next((p for p in _here.parents if (p / "agents" / "wireframing" / "src").exists()), None)
if _ROOT:
    for _rel in ("agents/wireframing/src", "libraries/agent-core/src", "libraries/ml-core/src"):
        _p = str(_ROOT / _rel)
        if _p not in sys.path:
            sys.path.insert(0, _p)

from wireframing.audit import audit as _audit  # noqa: E402
from wireframing.generate import generate as _generate  # noqa: E402
from wireframing.spec import WireframeSpec  # noqa: E402  (pydantic validation)

Spec = dict  # {"screens": [...]}


# --- helpers --------------------------------------------------------------------------
def _slug(text: str) -> str:
    s = "".join(c if c.isalnum() else "-" for c in (text or "").lower()).strip("-")
    return s or "screen"


def _screen(spec: Spec, screen_id: str) -> dict:
    for s in spec.get("screens", []):
        if s["id"] == screen_id:
            return s
    raise KeyError(f"no screen with id {screen_id!r}")


def _unique_id(spec: Spec, base: str) -> str:
    base = _slug(base)
    ids = {s["id"] for s in spec.get("screens", [])}
    if base not in ids:
        return base
    i = 2
    while f"{base}-{i}" in ids:
        i += 1
    return f"{base}-{i}"


# --- editable-flow operations ---------------------------------------------------------
def new_wireframe(name: str = "App") -> Spec:
    """Start an empty wireframe with a single entry screen (id ``index``, the audit's default)."""
    return {"name": name, "screens": [{"id": "index", "title": name or "Home",
                                        "elements": [], "links": [], "actions": []}]}


def add_screen(spec: Spec, title: str, screen_id: str | None = None) -> str:
    """Add a screen; returns its id."""
    sid = _unique_id(spec, screen_id or title)
    spec.setdefault("screens", []).append(
        {"id": sid, "title": title or sid, "elements": [], "links": [], "actions": []})
    return sid


def rename_screen(spec: Spec, screen_id: str, title: str) -> None:
    _screen(spec, screen_id)["title"] = title


def place_element(spec: Spec, screen_id: str, element: str) -> None:
    """Add a content element (label) to a screen."""
    _screen(spec, screen_id)["elements"].append(element)


def add_action(spec: Spec, screen_id: str, action: str) -> None:
    """Mark a primary action (key tap target) on a screen, e.g. 'checkout'."""
    acts = _screen(spec, screen_id)["actions"]
    if action not in acts:
        acts.append(action)


def link_screens(spec: Spec, from_id: str, label: str, to_id: str) -> None:
    """Add a navigation link (a button/row -> target screen). Raises if the target is missing."""
    _screen(spec, to_id)  # validate target exists
    _screen(spec, from_id)["links"].append({"label": label, "to": to_id})


def unlink(spec: Spec, from_id: str, to_id: str) -> int:
    """Remove all links from ``from_id`` to ``to_id``; returns how many were removed."""
    s = _screen(spec, from_id)
    before = len(s["links"])
    s["links"] = [lnk for lnk in s["links"] if lnk.get("to") != to_id]
    return before - len(s["links"])


def remove_screen(spec: Spec, screen_id: str) -> None:
    """Delete a screen. Links pointing to it become dead links (surfaced by audit)."""
    _screen(spec, screen_id)
    spec["screens"] = [s for s in spec["screens"] if s["id"] != screen_id]


# --- grade + export (reused from agents/wireframing) ----------------------------------
def validate(spec: Spec) -> WireframeSpec:
    """Validate the spec against the shared pydantic ``WireframeSpec`` contract."""
    return WireframeSpec.model_validate({"screens": spec.get("screens", [])})


def audit(spec: Spec) -> dict:
    """Grade the flow (A–F + issues + metrics), reusing the factory's canonical audit."""
    validate(spec)
    tmp = Path(tempfile.mkdtemp(prefix="wf_mcp_"))
    try:
        _generate({"screens": spec["screens"]}, tmp)
        screens = spec.get("screens", [])
        entry = (screens[0]["id"] + ".html") if screens else "index.html"
        return _audit(tmp, entry)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def export_html(spec: Spec, out_dir: str | Path) -> list[str]:
    """Write one link-complete HTML page per screen (reuses the agent's generator)."""
    validate(spec)
    return _generate({"screens": spec["screens"]}, out_dir)
