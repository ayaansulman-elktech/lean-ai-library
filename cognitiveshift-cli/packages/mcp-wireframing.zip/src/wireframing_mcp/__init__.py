"""Wireframing MCP — the editable-flow server behind the wireframing skill.

`core` holds the pure, offline-testable tool logic; `server` exposes it as MCP tools;
`bridge` serves it over HTTP to the `wireframe-studio` browser editor.
"""
from .core import (
    add_action,
    add_screen,
    audit,
    export_html,
    link_screens,
    new_wireframe,
    place_element,
    remove_screen,
    rename_screen,
    unlink,
    validate,
)

__all__ = [
    "new_wireframe", "add_screen", "rename_screen", "place_element", "add_action",
    "link_screens", "unlink", "remove_screen", "audit", "export_html", "validate",
]
