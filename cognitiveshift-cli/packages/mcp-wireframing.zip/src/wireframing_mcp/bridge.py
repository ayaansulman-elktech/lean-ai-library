"""HTTP bridge — the browser `wireframe-studio` cannot speak MCP stdio, so this exposes the
same shared wireframe over plain HTTP (with CORS) so the human editor and the agent pipeline
work on one spec.

    python -m wireframing_mcp.bridge            # serves http://localhost:8765

Endpoints (all JSON, CORS-open for the studio origin):
    GET  /spec    -> the current WireframeSpec
    POST /spec    -> replace it (validated); body = WireframeSpec
    GET  /audit   -> grade the current spec (A–F + issues + metrics)
    GET  /health  -> {"ok": true}

The spec is persisted to a JSON file (default ./wireframe.session.json) so a running MCP
server and the studio can share it. Stdlib only — offline, no keys.
"""
from __future__ import annotations

import json
import socket
import socketserver
import sys
from http.server import BaseHTTPRequestHandler
from pathlib import Path

from . import core

PORT = 8765
STATE_FILE = Path("wireframe.session.json")


def _load() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return core.new_wireframe()


def _save(spec: dict) -> None:
    STATE_FILE.write_text(json.dumps(spec, indent=2), encoding="utf-8")


class Handler(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-store")

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self._cors()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/spec"):
            self._json(_load())
        elif self.path.startswith("/audit"):
            try:
                self._json(core.audit(_load()))
            except Exception as e:
                self._json({"error": str(e)}, 400)
        elif self.path.startswith("/health"):
            self._json({"ok": True})
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        if not self.path.startswith("/spec"):
            self._json({"error": "not found"}, 404)
            return
        try:
            n = int(self.headers.get("Content-Length", 0))
            spec = json.loads(self.rfile.read(n).decode("utf-8"))
            core.validate(spec)          # reject malformed specs
            _save(spec)
            self._json({"ok": True, "screens": len(spec.get("screens", []))})
        except Exception as e:
            self._json({"error": str(e)}, 400)

    def log_message(self, *a):
        pass


class DualStack(socketserver.ThreadingMixIn, socketserver.TCPServer):
    address_family = socket.AF_INET6
    allow_reuse_address = True
    daemon_threads = True

    def server_bind(self):
        try:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        except OSError:
            pass
        super().server_bind()

    def handle_error(self, request, client_address):
        pass


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    port = int(argv[0]) if argv else PORT
    with DualStack(("::", port), Handler) as httpd:
        print(f"Wireframing bridge -> http://localhost:{port}/  (spec file: {STATE_FILE.resolve()})",
              flush=True)
        httpd.serve_forever()


if __name__ == "__main__":  # pragma: no cover
    main()
