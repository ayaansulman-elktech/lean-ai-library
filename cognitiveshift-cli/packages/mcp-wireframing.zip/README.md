# Wireframing MCP

The MCP server behind the wireframing skill: given a project charter + screen spec, it places
elements per page, links screens, and returns the wireframe plus an **editable flow** a human can
adjust (add a button → target, rename, add content). The `agents/wireframing` skill drives this
server; the `wireframe-studio` editor is the human face of the same shared `WireframeSpec`.

Grading and HTML generation are **reused** from `agents/wireframing` (`spec` / `generate` / `audit`) —
one source of truth, not reimplemented here.

## Layout
```
libraries/mcp/wireframing/
├── src/wireframing_mcp/
│   ├── core.py      # pure tool logic (offline): new/add_screen/place_element/add_action/
│   │                #   link_screens/unlink/remove_screen/rename_screen/audit/export_html
│   ├── server.py    # MCP transport — exposes core as MCP tools (FastMCP)
│   └── bridge.py    # HTTP bridge (CORS) so the browser studio shares the same spec
└── tests/test_core.py
```

## Run

**Tests** (offline, no keys, no MCP SDK):
```bash
cd libraries/mcp/wireframing && python -m pytest -q
```

**MCP server** (for agents — Codex / Claude):
```bash
pip install "wireframing-mcp[server]"     # installs the `mcp` transport
python -m wireframing_mcp.server
```
Tools: `new_wireframe`, `add_screen`, `rename_screen`, `place_element`, `add_action`,
`link_screens`, `unlink`, `remove_screen`, `audit`, `export_html`, `get_spec`, `load_spec`.

**HTTP bridge** (for the human `wireframe-studio` editor — stdlib only, no install):
```bash
python -m wireframing_mcp.bridge          # http://localhost:8765
```
`GET /spec` · `POST /spec` · `GET /audit` · `GET /health`. In the studio, click **⇅ MCP** →
**Push** / **Pull** to share the flow. The shared contract is the factory `WireframeSpec`
(`{screens:[{id,title,elements,links,actions}]}`); the studio projects its rich layout to/from it.

## How it fits
```
charter ─▶ wireframing agent ─┐
                              ├─▶ Wireframing MCP (one shared WireframeSpec) ─▶ audit (A–F) ─▶ export HTML
wireframe-studio (human) ─────┘        ▲ reuses agents/wireframing spec/generate/audit
```
`navigation-flow` (sibling MCP) grades a flow; this server's `audit` uses the same canonical logic.
