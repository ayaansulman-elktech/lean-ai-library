"""MCP transport smoke test — builds the FastMCP server and drives its tools in-memory.

Skips cleanly if the optional `mcp` transport isn't installed (the core stays offline-testable).
"""
import asyncio

import pytest

pytest.importorskip("mcp", reason="MCP transport is optional (pip install 'wireframing-mcp[server]')")

from wireframing_mcp.server import build_server  # noqa: E402


def _run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def test_server_builds_and_lists_tools():
    m = build_server()
    tools = _run(m.list_tools())
    names = {t.name for t in tools}
    for expected in ("new_wireframe", "add_screen", "link_screens", "add_action",
                     "audit", "export_html", "get_spec", "load_spec"):
        assert expected in names, f"missing tool {expected}; got {names}"


def test_server_drives_a_flow_to_grade_A():
    m = build_server()
    _run(m.call_tool("new_wireframe", {"name": "Selfie"}))
    cap = _run(m.call_tool("add_screen", {"title": "Capture"}))
    res = _run(m.call_tool("add_screen", {"title": "Result"}))
    # call_tool returns (content_blocks, structured_result) or similar; pull the id out of structured output
    cap_id = _structured(cap)
    res_id = _structured(res)
    _run(m.call_tool("link_screens", {"from_id": "index", "label": "Start", "to_id": cap_id}))
    _run(m.call_tool("add_action", {"screen_id": cap_id, "action": "capture"}))
    _run(m.call_tool("link_screens", {"from_id": cap_id, "label": "Analyze", "to_id": res_id}))
    _run(m.call_tool("link_screens", {"from_id": res_id, "label": "Back", "to_id": "index"}))
    audit = _structured(_run(m.call_tool("audit", {})))
    assert audit["grade"] == "A", audit


def _structured(result):
    """FastMCP.call_tool returns (content, structured) in recent versions, or just content.
    Scalar returns are wrapped as {"result": value} — unwrap those."""
    val = None
    if isinstance(result, tuple) and len(result) == 2:
        val = result[1]
    elif isinstance(result, dict):
        val = result
    else:  # content-block list
        import json
        text = getattr(result[0], "text", None) if result else None
        try:
            val = json.loads(text)
        except Exception:
            val = text
    if isinstance(val, dict) and set(val.keys()) == {"result"}:
        return val["result"]
    return val
