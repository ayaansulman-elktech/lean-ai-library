"""Offline tests for the Wireframing MCP core — no MCP SDK, no network, no keys."""
from pathlib import Path

from wireframing_mcp import core


def _good_flow():
    """Home -> capture(action) -> result, all linked, one primary action within 3 clicks."""
    spec = core.new_wireframe("Selfie")
    core.rename_screen(spec, "index", "Welcome")
    cap = core.add_screen(spec, "Capture")
    res = core.add_screen(spec, "Result")
    core.place_element(spec, "index", "Headline")
    core.link_screens(spec, "index", "Get started", cap)
    core.add_action(spec, cap, "capture")
    core.link_screens(spec, cap, "Analyze", res)
    core.link_screens(spec, res, "Back", "index")
    return spec, cap, res


def test_build_and_grade_A():
    spec, cap, res = _good_flow()
    result = core.audit(spec)
    assert result["grade"] == "A", result["issues"]
    assert result["metrics"]["orphans"] == 0
    assert result["metrics"]["dead_links"] == 0


def test_unique_ids_and_add_screen():
    spec = core.new_wireframe()
    a = core.add_screen(spec, "Home")   # index already 'index'; "Home" -> "home"
    b = core.add_screen(spec, "Home")   # collision -> "home-2"
    assert a != b
    assert len({s["id"] for s in spec["screens"]}) == len(spec["screens"])


def test_dead_link_detected():
    spec = core.new_wireframe()
    core.add_action(spec, "index", "go")
    # link to a missing screen by editing directly (mirrors a user pointing a button at nothing)
    spec["screens"][0]["links"].append({"label": "ghost", "to": "missing"})
    result = core.audit(spec)
    assert result["metrics"]["dead_links"] == 1
    assert result["grade"] != "A"


def test_orphan_detected():
    spec, cap, res = _good_flow()
    core.add_screen(spec, "Lonely")     # unreachable
    result = core.audit(spec)
    assert result["metrics"]["orphans"] >= 1
    assert result["grade"] != "A"


def test_action_too_deep_flagged():
    # index -> a -> b -> c -> d, with the key action 4 clicks away (> the 3-click bar)
    spec = core.new_wireframe()
    prev = "index"
    for name in ("a", "b", "c", "d"):
        sid = core.add_screen(spec, name)
        core.link_screens(spec, prev, f"to {name}", sid)
        prev = sid
    core.add_action(spec, prev, "checkout")   # on 'd', depth 4
    result = core.audit(spec)
    assert any("too deep" in i for i in result["issues"]), result["issues"]
    assert result["grade"] != "A"


def test_unlink_and_remove():
    spec, cap, res = _good_flow()
    assert core.unlink(spec, "index", cap) == 1
    # index no longer links to capture -> capture/result become orphans
    assert core.audit(spec)["metrics"]["orphans"] >= 1
    core.remove_screen(spec, res)
    assert all(s["id"] != res for s in spec["screens"])


def test_export_html(tmp_path: Path):
    spec, cap, res = _good_flow()
    files = core.export_html(spec, tmp_path)
    assert len(files) == 3
    assert (tmp_path / "index.html").exists()
    assert (tmp_path / "styles.css").exists()
    # generated pages are link-complete: capture page links to result
    assert "result.html" in (tmp_path / f"{cap}.html").read_text(encoding="utf-8")


def test_validate_rejects_bad_spec():
    import pytest
    with pytest.raises(ValueError):
        core.validate({"screens": [{"title": "no id"}]})  # missing required 'id'
