# Lean Design System

Apple-native component shell. **Built once, shared by every app.**
