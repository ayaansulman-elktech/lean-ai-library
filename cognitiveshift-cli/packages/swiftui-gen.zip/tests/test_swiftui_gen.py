import json
import re

from agent_core import AgentContext
from ml_core import CostMeter, ProvidersConfig, build_gateway
from ml_core.config import ModelSpec
from swiftui_gen import SwiftUIGenAgent, check_swift, view_name


def _good_swift(view: str) -> str:
    return (
        "import SwiftUI\n\n"
        f"struct {view}: View {{\n"
        "    var body: some View {\n"
        "        NavigationStack {\n"
        "            VStack(spacing: Tokens.spacingMd) {\n"
        '                Text("Hi").font(Tokens.typographyTitle).foregroundColor(Tokens.colorTextPrimary)\n'
        '                Button("Go") { }.foregroundColor(Tokens.colorTextInverse)\n'
        "            }\n"
        "            .padding(Tokens.spacingLg)\n"
        "            .background(Tokens.colorSurface)\n"
        "        }\n"
        "    }\n"
        "}\n"
    )


def _view_from(messages) -> str:
    m = re.search(r"VIEW NAME: (\w+)", messages[-1]["content"])
    return m.group(1) if m else "ScreenView"


def _good_responder(alias, messages):
    view = _view_from(messages)
    return json.dumps({"filename": f"{view}.swift", "swift": _good_swift(view)})


def _flaky_responder():
    """First reply uses an unknown token (fails the check); second is clean."""
    calls = {"n": 0}

    def r(alias, messages):
        calls["n"] += 1
        view = _view_from(messages)
        swift = _good_swift(view)
        if calls["n"] == 1:
            swift = swift.replace("Tokens.colorSurface", "Tokens.colorNope")
        return json.dumps({"filename": f"{view}.swift", "swift": swift})

    return r


def _ctx(responder):
    cfg = ProvidersConfig(gateway="mock",
                          models={"deepseek": ModelSpec(provider="deepseek", model="deepseek-chat")})
    meter = CostMeter(budget_usd=2.0)
    return AgentContext(gateway=build_gateway(cfg, meter, offline=True, responder=responder),
                        meter=meter, default_model="deepseek")


def test_view_name():
    assert view_name("onboarding") == "OnboardingView"
    assert view_name("outfit_scan") == "OutfitScanView"
    assert view_name("color-analysis") == "ColorAnalysisView"


def test_check_swift_flags_problems():
    toks = {"colorBrand", "spacingMd"}
    ok = ("import SwiftUI\nstruct XView: View { var body: some View { "
          'Text("a").foregroundColor(Tokens.colorBrand) } }')
    assert check_swift(ok, toks, view="XView") == []
    assert any("unknown token" in i for i in
               check_swift(ok.replace("colorBrand", "colorNope"), toks, view="XView"))
    assert any("import SwiftUI" in i for i in
               check_swift(ok.replace("import SwiftUI\n", ""), toks))
    assert any("hardcoded Color" in i for i in
               check_swift(ok + '\nlet c = Color(hex: "#fff")', toks, view="XView"))


def test_generates_writes_and_passes(tmp_path):
    spec = {"screens": [{"id": "onboarding", "title": "Welcome", "elements": ["Headline"],
                         "links": [{"label": "Start", "to": "capture"}], "actions": []}]}
    agent = SwiftUIGenAgent(_ctx(_good_responder), out_dir=str(tmp_path))
    r = agent.run({"spec": spec, "app": "ColorMatching"})
    assert r.success and r.output["all_passed"]
    f = r.output["files"][0]
    assert f["view"] == "OnboardingView" and f["passed"] and f["issues"] == []
    written = (tmp_path / "OnboardingView.swift").read_text(encoding="utf-8")
    assert "import SwiftUI" in written and "Tokens." in written


def test_multi_screen_generates_a_file_each(tmp_path):
    spec = {"screens": [{"id": "onboarding"}, {"id": "capture"}, {"id": "paywall"}]}
    r = SwiftUIGenAgent(_ctx(_good_responder), out_dir=str(tmp_path)).run({"spec": spec})
    assert r.output["all_passed"]
    assert {f["view"] for f in r.output["files"]} == {"OnboardingView", "CaptureView", "PaywallView"}
    assert (tmp_path / "PaywallView.swift").exists()


def test_bad_output_is_corrected_on_retry(tmp_path):
    spec = {"screens": [{"id": "capture", "actions": ["capture"]}]}
    ctx = _ctx(_flaky_responder())
    r = SwiftUIGenAgent(ctx, out_dir=str(tmp_path)).run({"spec": spec})
    assert r.output["files"][0]["passed"]      # first attempt failed the token check, retry fixed it
    assert ctx.meter.calls == 2
    assert (tmp_path / "CaptureView.swift").exists()


def test_unknown_token_survives_and_is_reported(tmp_path):
    # If it never passes, the screen is returned failed with issues (not written).
    def always_bad(alias, messages):
        view = _view_from(messages)
        return json.dumps({"filename": f"{view}.swift",
                           "swift": _good_swift(view).replace("Tokens.colorSurface", "Tokens.colorNope")})

    r = SwiftUIGenAgent(_ctx(always_bad), out_dir=str(tmp_path)).run({"spec": {"screens": [{"id": "x"}]}})
    f = r.output["files"][0]
    assert not f["passed"] and any("unknown token" in i for i in f["issues"])
    assert not (tmp_path / "XView.swift").exists()
