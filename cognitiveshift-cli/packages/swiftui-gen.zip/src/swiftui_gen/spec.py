"""SwiftUI-gen contracts: the per-screen output schema + the base token allow-list."""

from __future__ import annotations

from pydantic import BaseModel

# Base design-system token names (camelCase of the DTCG keys, as emitted into Tokens.swift).
# The orchestrator passes the REAL list (base + the app's universe override); this is the
# fallback / minimum set so the agent is usable standalone and in tests.
DEFAULT_TOKENS = [
    "colorAccent", "colorBrand", "colorFeedbackError", "colorFeedbackSuccess", "colorFeedbackWarning",
    "colorNeutral0", "colorNeutral50", "colorNeutral100", "colorNeutral200", "colorNeutral400",
    "colorNeutral600", "colorNeutral900", "colorSurface", "colorTextInverse", "colorTextPrimary",
    "colorTextSecondary", "radiusSm", "radiusMd", "radiusLg", "radiusPill", "spacingXs", "spacingSm",
    "spacingMd", "spacingLg", "spacingXl", "typographyBody", "typographyCaption",
    "typographyDisplay", "typographyTitle", "materialThin", "materialRegular", "materialThick",
]


class ScreenFile(BaseModel):
    filename: str          # e.g. "OnboardingView.swift"
    swift: str             # the full SwiftUI source


def view_name(screen_id: str) -> str:
    """onboarding -> OnboardingView ; color-analysis / color_analysis -> ColorAnalysisView."""
    parts = [p for p in screen_id.replace("-", "_").split("_") if p]
    return "".join(p[:1].upper() + p[1:] for p in parts) + "View"
