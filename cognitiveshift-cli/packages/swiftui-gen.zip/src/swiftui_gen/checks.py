"""Deterministic static checks on generated SwiftUI — catch the unambiguous problems (missing
import, no View struct, unknown/absent tokens, hardcoded styles, unbalanced brackets) with no
compiler. Mirrors the wireframing flow-audit: the LLM step is non-deterministic, this gate is not.
"""

from __future__ import annotations

import re


def check_swift(swift: str, allowed_tokens: set[str], *, view: str | None = None) -> list[str]:
    """Return a list of issue strings (empty = passes)."""
    issues: list[str] = []

    if "import SwiftUI" not in swift:
        issues.append("missing 'import SwiftUI'")
    if ": View" not in swift or "var body" not in swift:
        issues.append("missing a SwiftUI View struct with a `var body`")
    if view and f"struct {view}" not in swift:
        issues.append(f"expected `struct {view}: View`")

    for opn, cls, name in (("{", "}", "braces"), ("(", ")", "parens")):
        if swift.count(opn) != swift.count(cls):
            issues.append(f"unbalanced {name}")

    used = set(re.findall(r"\bTokens\.(\w+)", swift))
    unknown = sorted(used - allowed_tokens)
    if unknown:
        issues.append("unknown token(s): " + ", ".join(unknown))
    if not used:
        issues.append("no design tokens used — style with Tokens.*, not literals")

    # Hardcoded color literals defeat the token system (the whole per-app identity mechanism).
    if re.search(r"Color\(\s*(?:hex:|red:|\.sRGB)", swift):
        issues.append("hardcoded Color(...) — use a Tokens color")

    return issues
