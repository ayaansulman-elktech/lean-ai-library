"""SwiftUIGenAgent — wireframe screen spec -> token-driven SwiftUI source.

The prototype step of the design-automation pipeline (deck p.60 step 2, transcript 46:00):
take the A-graded wireframe + the design tokens and emit one SwiftUI View per screen, styled
ONLY with `Tokens.*` and wired for navigation. Generation is **per screen** (fits the
audit-and-adjust loop); each screen is statically checked and, on failure, re-asked once with the
issues — the LLM is the only non-deterministic step, the checker is not.
"""

from __future__ import annotations

import json
from pathlib import Path

from agent_core import Agent, AgentContext

from swiftui_gen.checks import check_swift
from swiftui_gen.spec import DEFAULT_TOKENS, ScreenFile, view_name

SYSTEM = (
    "You convert ONE wireframe screen into a SwiftUI view for a native iOS app.\n"
    "Rules:\n"
    "- Use native SwiftUI (NavigationStack / VStack / HStack / List / Text / Button / Image).\n"
    "- Style ONLY with the provided design tokens as `Tokens.<name>` — colors, fonts (Font),\n"
    "  spacing/radius (CGFloat). NEVER hardcode colors, fonts, or sizes.\n"
    "- Exactly one `struct <View>: View` with `var body: some View`.\n"
    "- Map each wireframe ACTION to a Button; each LINK to a NavigationLink to <target>View.\n"
    "- Keep 44pt minimum hit targets; use token spacing/radius for padding and corners.\n"
    'Return ONLY JSON: {"filename": "<View>.swift", "swift": "<full SwiftUI source>"}.'
)


class SwiftUIGenAgent(Agent):
    name = "swiftui-gen"

    def __init__(self, ctx: AgentContext, *, model: str | None = None,
                 out_dir: str | None = None, max_fix_attempts: int = 2) -> None:
        super().__init__(ctx)
        self.model = model
        self.out_dir = Path(out_dir) if out_dir else None
        self.max_fix_attempts = max_fix_attempts

    def _run(self, task: dict) -> dict:
        # task = {"spec": WireframeSpec-dict (or the wireframing output), "tokens": [names],
        #         "app": str, "copy": {screen_id: {...}}, "out_dir": path}
        spec = task.get("spec", task)
        screens = spec.get("screens", [])
        tokens = set(task.get("tokens") or DEFAULT_TOKENS)
        copy = task.get("copy") or {}
        app = task.get("app", "App")
        out_dir = Path(task["out_dir"]) if task.get("out_dir") else self.out_dir

        files = [self._gen_screen(s, tokens, copy.get(s.get("id"), {}), out_dir) for s in screens]
        all_passed = bool(files) and all(f["passed"] for f in files)
        self.ctx.tracker.log_metrics({"screens": len(files),
                                      "screens_passed": sum(f["passed"] for f in files)})
        return {"app": app, "files": files, "all_passed": all_passed,
                "out_dir": str(out_dir) if out_dir else None}

    def _gen_screen(self, screen: dict, tokens: set[str], copy: dict, out_dir: Path | None) -> dict:
        view = view_name(screen.get("id", "screen"))
        base_user = (
            f"SCREEN:\n{json.dumps(screen, indent=2)}\n\n"
            f"VIEW NAME: {view}\n"
            f"AVAILABLE TOKENS (use as Tokens.<name>):\n{', '.join(sorted(tokens))}\n"
            + (f"\nCOPY (use verbatim):\n{json.dumps(copy)}\n" if copy else "")
        )
        user, issues, result = base_user, [], None
        for _ in range(self.max_fix_attempts):
            result = self.llm_json(system=SYSTEM, user=user, model=self.model, schema=ScreenFile)
            issues = check_swift(result["swift"], tokens, view=view)
            if not issues:
                break
            user = base_user + ("\nThe previous attempt FAILED these checks; fix them and return "
                                "the corrected view:\n- " + "\n- ".join(issues))

        passed = not issues
        filename = result.get("filename") or f"{view}.swift"
        if out_dir and passed:
            out_dir.mkdir(parents=True, exist_ok=True)
            (out_dir / filename).write_text(result["swift"], encoding="utf-8")
        return {"screen_id": screen.get("id"), "view": view, "filename": filename,
                "swift": result["swift"], "passed": passed, "issues": issues}
