# Wireframe element → SwiftUI + tokens

The map the agent follows to turn a wireframe screen into token-driven SwiftUI. Style **only**
with `Tokens.*` (from `design-system/tokens/build/Tokens.swift`); never hardcode colors/fonts/sizes.

| Wireframe element | SwiftUI | Tokens |
|---|---|---|
| screen title | `Text(title).font(Tokens.typographyDisplay)` | `typographyDisplay`, `colorTextPrimary` |
| section heading | `Text(...).font(Tokens.typographyTitle)` | `typographyTitle`, `colorTextPrimary` |
| body text | `Text(...).font(Tokens.typographyBody)` | `typographyBody`, `colorTextSecondary` |
| caption / legal | `Text(...).font(Tokens.typographyCaption)` | `typographyCaption`, `colorTextSecondary` |
| primary action (`actions[]`) | `Button { } label: { ... }` filled | `colorBrand`, `colorTextInverse`, `radiusPill`, `spacingMd` |
| secondary button | bordered `Button` | `colorSurface`, `colorNeutral200`, `radiusPill` |
| link (`links[]`) | `NavigationLink { <target>View() } label: {…}` | `colorAccent` |
| list row | `List` / `HStack` row | `colorSurface`, `colorNeutral200`, `spacingMd` |
| image / media | `Image(...)` placeholder | `radiusMd`, `colorNeutral100` |
| card | `VStack{…}.background(Tokens.colorSurface).cornerRadius(Tokens.radiusMd)` | `colorSurface`, `radiusMd` |

## Layout rules
- Root each screen in a `NavigationStack`; group content in a `VStack(spacing: Tokens.spacingMd)`.
- Screen padding = `Tokens.spacingLg`; inter-element = `Tokens.spacingMd`.
- One primary action per screen (`colorBrand` fill); everything else secondary/tinted.
- Min 44pt hit targets. Respect safe areas. Support light/dark (tokens carry both via Color).

## Naming
- screen `id` → `PascalCaseView` (e.g. `outfit_scan` → `OutfitScanView`).
- A `link.to` targets the destination screen's view: `NavigationLink { CaptureView() }`.
