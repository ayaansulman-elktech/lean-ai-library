---
name: security-review
description: Security gate for generated iOS code — deterministic static scan (secrets, dangerous calls, and iOS specifics: UserDefaults secrets, Keychain, App Transport Security, weak crypto) plus an LLM review (injection, auth, secure storage, input validation). Use before shipping any generated code.
allowed-tools: Read, Bash
---
# Security-review gate

Two layers (`src/security_review/`, on `agent-core`):
1. **Static scan** (`scan.py`) — no LLM, no deps:
   - generic: hardcoded secrets, `eval`/`exec`, `os.system`, `subprocess(shell=True)`, unsafe
     `pickle`/`yaml.load`, disabled TLS.
   - iOS/Swift: secrets in Swift source or `UserDefaults` (hard-block), Keychain accessibility,
     App Transport Security (`NSAllowsArbitraryLoads` / insecure HTTP), weak crypto (MD5/SHA1,
     DES/3DES/RC4), pasteboard, sensitive logging, secrets in `Info.plist`.
2. **LLM review** — Swift/iOS-aware: injection, broken auth, secure storage (Keychain vs
   UserDefaults), SSL pinning, missing input validation.

```python
from security_review import SecurityReviewAgent
res = SecurityReviewAgent(ctx).run({"app.py": code, ...})
if not res.output["passes"]:    # gate: block ship
    ...
```

**Hard rule:** any high-severity static finding (e.g. a hardcoded secret) is an automatic block,
regardless of the LLM's verdict — the model can't talk it down.
