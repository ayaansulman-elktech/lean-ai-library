from agent_core import AgentContext
from ml_core import CostMeter, ProvidersConfig, build_gateway
from ml_core.config import ModelSpec
from security_review.agent import SecurityReviewAgent
from security_review.scan import scan

CLEAN_REPORT = '{"verdict":"pass","risk_level":"low","findings":[],"summary":"No issues."}'
# Even if the model says pass, a hardcoded secret must hard-block:
LENIENT_REPORT = '{"verdict":"pass","risk_level":"low","findings":[],"summary":"Looks fine."}'


def _ctx(responder):
    cfg = ProvidersConfig(gateway="mock",
                          models={"deepseek": ModelSpec(provider="deepseek", model="deepseek-chat")})
    meter = CostMeter(budget_usd=1.0)
    return AgentContext(gateway=build_gateway(cfg, meter, offline=True, responder=responder),
                        meter=meter, default_model="deepseek")


def test_static_scan_catches_secret_and_eval():
    findings = scan({"a.py": "API='sk-EXAMPLEfakekey000000000000'\nx = eval(user_input)"})
    cats = {f["category"] for f in findings}
    assert "secret" in cats
    assert "risky-call" in cats
    assert any(f["severity"] == "high" for f in findings)


def test_clean_code_passes():
    r = SecurityReviewAgent(_ctx(lambda a, m: CLEAN_REPORT)).run({"a.py": "def add(x, y): return x + y\n"})
    assert r.success
    assert r.output["passes"] is True


def test_hardcoded_secret_hard_blocks_even_if_model_is_lenient():
    files = {"config.py": "OPENAI_API_KEY = 'sk-proj-EXAMPLEfake0000000000000'\n"}
    r = SecurityReviewAgent(_ctx(lambda a, m: LENIENT_REPORT)).run(files)
    assert r.success
    assert r.output["passes"] is False          # static high-severity overrides a lenient model
    assert any(f["category"] == "secret" for f in r.output["static_findings"])


# --- iOS / Swift hardening -----------------------------------------------------------------

def test_ios_secret_in_userdefaults_hard_blocks():
    files = {"Auth.swift": 'UserDefaults.standard.set(authToken, forKey: "auth")\n'}
    findings = scan(files)
    assert any(f["category"] == "ios-storage" and f["severity"] == "high" for f in findings)
    r = SecurityReviewAgent(_ctx(lambda a, m: LENIENT_REPORT)).run(files)
    assert r.output["passes"] is False          # high-severity iOS finding hard-blocks


def test_ios_ats_disabled_in_plist_spans_lines():
    plist = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
        '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        "<dict>\n"
        "  <key>NSAppTransportSecurity</key>\n  <dict>\n"
        "    <key>NSAllowsArbitraryLoads</key>\n    <true/>\n"
        "  </dict>\n</dict>\n"
    )
    findings = scan({"Info.plist": plist})
    ats = [f for f in findings if f["category"] == "ios-transport"]
    assert ats and ats[0]["severity"] == "high"
    # The Apple DTD URL must NOT be flagged as a cleartext-HTTP false positive.
    assert not any("cleartext" in f["issue"] for f in findings)


def test_ios_keychain_and_weak_crypto_are_flagged_not_blocking():
    files = {"Store.swift": "let acc = kSecAttrAccessibleAlways\nlet h = Insecure.MD5.hash(data: d)\n"}
    findings = scan(files)
    cats = {f["category"] for f in findings}
    assert "ios-keychain" in cats and "crypto" in cats
    assert all(f["severity"] != "high" for f in findings)   # medium -> flag, don't hard-block


def test_clean_swift_passes_no_false_positives():
    files = {"ContentView.swift":
             "import SwiftUI\nstruct ContentView: View {\n  var body: some View { Text(\"Hi\") }\n}\n"}
    findings = scan(files)
    assert findings == []
    r = SecurityReviewAgent(_ctx(lambda a, m: CLEAN_REPORT)).run(files)
    assert r.output["passes"] is True
