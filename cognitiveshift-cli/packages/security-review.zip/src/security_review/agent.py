"""SecurityReviewAgent — gate generated iOS app code before it ships.

Two layers: a deterministic static scan (always runs, no LLM) for the unambiguous stuff —
including iOS/Swift specifics (Keychain, App Transport Security, UserDefaults secret leakage,
weak crypto, pasteboard) — plus an LLM review for the rest. Any HIGH-severity static finding is
an automatic hard block regardless of what the LLM says. `output["passes"]` is the gate.
"""

from __future__ import annotations

import json

from agent_core import Agent, AgentContext

from security_review.models import SecurityReport
from security_review.scan import scan

SYSTEM = (
    "You are a security reviewer for generated iOS (Swift/SwiftUI) application code. You are "
    "given FILES and the result of a STATIC SCAN. Assess for:\n"
    "- secrets / credentials hardcoded in source, Info.plist, or entitlements;\n"
    "- insecure storage: secrets in UserDefaults or plain files instead of the Keychain; wrong "
    "Keychain accessibility (avoid kSecAttrAccessibleAlways); missing Data Protection;\n"
    "- App Transport Security: NSAllowsArbitraryLoads / insecure HTTP exceptions, cleartext URLs;\n"
    "- weak crypto (MD5/SHA1, DES/3DES/RC4), disabled TLS/cert validation, broken SSL pinning;\n"
    "- injection (SQL/command), unsafe deserialization, missing input validation;\n"
    "- privacy leaks: logging secrets, system pasteboard, WKWebView JS from untrusted content; "
    "broken auth / missing biometric or device-passcode gating for sensitive actions.\n"
    "Incorporate the static-scan findings into your report.\n"
    'Return ONLY JSON: {"verdict": "pass|flag|fail", "risk_level": "low|medium|high", '
    '"findings": [{"file", "category", "issue", "severity": "low|medium|high", '
    '"recommendation"}], "summary"}.'
)


class SecurityReviewAgent(Agent):
    name = "security-review"

    def __init__(self, ctx: AgentContext, *, model: str | None = None) -> None:
        super().__init__(ctx)
        self.model = model

    def _run(self, files: dict[str, str]) -> dict:
        static = scan(files)
        listing = "\n".join(f"--- {name} ---\n{content}" for name, content in files.items())
        user = (f"FILES:\n{listing}\n\nSTATIC SCAN FINDINGS:\n{json.dumps(static, indent=2)}")
        report = self.llm_json(system=SYSTEM, user=user, model=self.model, schema=SecurityReport)

        # Hard rule: any high-severity static finding (e.g. a hardcoded secret) is an automatic
        # block, no matter what the model concluded.
        has_critical = any(f["severity"] == "high" for f in static)
        core = {k: report[k] for k in ("verdict", "risk_level", "findings", "summary")}
        passes = SecurityReport(**core).passes() and not has_critical

        report["static_findings"] = static
        report["passes"] = passes
        self.ctx.tracker.log_metrics({"security_pass": 1.0 if passes else 0.0,
                                      "static_findings": len(static)})
        return report
