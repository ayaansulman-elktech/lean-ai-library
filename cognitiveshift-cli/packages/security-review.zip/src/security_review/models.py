"""Security report schema."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

Severity = Literal["low", "medium", "high"]
Verdict = Literal["pass", "flag", "fail"]


class SecFinding(BaseModel):
    file: str = ""
    category: str = ""        # secret | injection | crypto | auth | input-validation | risky-call |
                              # ios-storage | ios-keychain | ios-transport | ios-privacy |
                              # ios-webview | ios-logging | ...
    issue: str
    severity: Severity
    recommendation: str = ""


class SecurityReport(BaseModel):
    verdict: Verdict
    risk_level: Severity
    findings: list[SecFinding] = []
    summary: str = ""

    def passes(self) -> bool:
        return self.verdict != "fail" and self.risk_level != "high"
