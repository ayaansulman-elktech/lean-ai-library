"""Deterministic static scan — runs with no LLM, no deps. Catches the unambiguous stuff
(hardcoded secrets, dangerous calls, iOS/Swift misconfiguration) so a model hiccup can never
let it through.

Tuned for the factory's output: Swift/SwiftUI sources, `Info.plist`, and entitlements. Each
pattern carries its own (category, issue, severity); any HIGH finding hard-blocks in the agent
regardless of the LLM verdict.
"""

from __future__ import annotations

import re

# --- generic (language-agnostic) ----------------------------------------------------------
# (regex, category, issue, severity) — matched per line.
SECRET_PATTERNS = [
    (r"sk-[A-Za-z0-9_\-]{16,}", "secret", "hardcoded API key", "high"),
    (r"AKIA[0-9A-Z]{16}", "secret", "AWS access key id", "high"),
    (r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", "secret", "private key", "high"),
    (r"(?i)(password|passwd|secret|token)\s*[:=]\s*['\"][^'\"]{4,}['\"]",
     "secret", "hardcoded credential", "high"),
]

RISKY_PATTERNS = [
    (r"\beval\s*\(", "risky-call", "use of eval()", "medium"),
    (r"\bexec\s*\(", "risky-call", "use of exec()", "medium"),
    (r"os\.system\s*\(", "risky-call", "shell via os.system", "medium"),
    (r"subprocess\.\w+\([^)]*shell\s*=\s*True", "risky-call", "subprocess with shell=True", "medium"),
    (r"pickle\.loads?\s*\(", "risky-call", "deserialization of untrusted data (pickle)", "medium"),
    (r"yaml\.load\s*\((?![^)]*Loader)", "risky-call", "yaml.load without a safe Loader", "medium"),
    (r"verify\s*=\s*False", "risky-call", "TLS verification disabled", "medium"),
]

# --- iOS / Swift specific -----------------------------------------------------------------
# The factory ships Apple-native apps, so these are first-class, not an afterthought.
IOS_PATTERNS = [
    (r"let\s+\w*(?i:apikey|api_key|secret|token|password)\w*\s*=\s*\"[^\"]{6,}\"",
     "secret", "hardcoded secret in Swift source", "high"),
    (r"UserDefaults\b[^\n]*\.set\([^\n]*(?i:token|passwd|password|secret|apikey|api_key|credential)",
     "ios-storage", "secret written to UserDefaults (use the Keychain)", "high"),
    (r"kSecAttrAccessibleAlways\b",
     "ios-keychain", "Keychain item accessible always (use WhenUnlocked/AfterFirstUnlock)", "medium"),
    (r"\"http://(?!localhost|127\.0\.0\.1|www\.apple\.com/DTDs|www\.w3\.org)[A-Za-z0-9.\-]+",
     "ios-transport", "cleartext HTTP endpoint in code (use HTTPS / ATS)", "medium"),
    (r"\bUIPasteboard\.general\b",
     "ios-privacy", "uses the system pasteboard (sensitive-data leak risk)", "low"),
    (r"\.javaScriptEnabled\s*=\s*true|allowsArbitraryLoadsInWebContent",
     "ios-webview", "WKWebView JavaScript / insecure web content enabled", "low"),
    (r"\b(?:Insecure\.MD5|Insecure\.SHA1|CC_MD5|CC_SHA1)\b",
     "crypto", "weak hash (MD5/SHA1)", "medium"),
    (r"\b(?:kCCAlgorithmDES|kCCAlgorithm3DES|kCCAlgorithmRC4)\b",
     "crypto", "weak/broken cipher (DES/3DES/RC4)", "medium"),
    (r"(?:print|NSLog|os_log)\s*\([^\n]*(?i:password|token|secret|apikey|api_key)",
     "ios-logging", "logs a sensitive value", "low"),
]

LINE_PATTERNS = SECRET_PATTERNS + RISKY_PATTERNS + IOS_PATTERNS

# --- spanning (whole-file) patterns -------------------------------------------------------
# plist key/value pairs span lines, so these run against the full file, not line-by-line.
FILE_PATTERNS = [
    (r"<key>\s*NSAllowsArbitraryLoads\s*</key>\s*<true\s*/>",
     "ios-transport", "App Transport Security disabled app-wide (NSAllowsArbitraryLoads=true)", "high"),
    (r"<key>\s*NSAllowsArbitraryLoadsInWebContent\s*</key>\s*<true\s*/>",
     "ios-transport", "ATS disabled for web content", "medium"),
    (r"<key>\s*NSExceptionAllowsInsecureHTTPLoads\s*</key>\s*<true\s*/>",
     "ios-transport", "ATS exception allows insecure HTTP for a domain", "medium"),
    (r"<key>[^<]*(?i:apikey|api_key|secret|token|password)[^<]*</key>\s*<string>[^<]{6,}</string>",
     "secret", "secret embedded in Info.plist", "high"),
]


def scan(files: dict[str, str]) -> list[dict]:
    """Return findings: [{file, line, category, issue, severity}].

    Line patterns run per line; file patterns run against the whole file (plist key/value pairs
    span lines). High-severity findings hard-block in the agent regardless of the LLM verdict.
    """
    findings: list[dict] = []
    for name, content in files.items():
        for i, line in enumerate(content.splitlines(), start=1):
            for pat, cat, desc, sev in LINE_PATTERNS:
                if re.search(pat, line):
                    findings.append({"file": name, "line": i, "category": cat,
                                     "issue": desc, "severity": sev})
        for pat, cat, desc, sev in FILE_PATTERNS:
            m = re.search(pat, content)
            if m:
                line_no = content.count("\n", 0, m.start()) + 1
                findings.append({"file": name, "line": line_no, "category": cat,
                                 "issue": desc, "severity": sev})
    return findings
