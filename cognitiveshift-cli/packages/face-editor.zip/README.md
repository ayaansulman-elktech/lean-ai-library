# face-editor (model card)

Mask-guided face editing — edit the face mask, the model regenerates the face to match
([CelebAMask-HQ / MaskGAN](https://github.com/switchablenorms/CelebAMask-HQ), CVPR 2020).

- **Task:** given a face image and its 19-class parse, reassign regions (remove glasses, add a
  hat, reshape hair) and regenerate the image so it agrees with the edited mask.
- **Inputs:** an image + a target `SegMask` + the source `SegMask`. **Outputs:** an `RGBImage`.
- **Status:** `raw` — real generator runs in iOS Ready (`ios-ready/raw/celebamask-hq`); CI uses a
  deterministic mock that renders the mask as flat class colours.
- **Composes with:** `blocks/face_parsing`, which produces the `SegMask` this block edits. Both
  use the same 19 CelebAMask-HQ classes.

## ⚠️ Licence: non-commercial research only

CelebAMask-HQ restricts **the software** to *"non-commercial research and educational purposes"*,
and its dataset agreement forbids commercial exploitation of *"any portion of derived data"* —
which includes the trained generator.

This factory ships paid apps. **This block must not reach `apps/` or any shipped artifact.**

The restriction is enforced in code, not in this paragraph. `MaskGANEditor.is_available()` returns
`False` unless the operator acknowledges the terms for that process:

```bash
FACTORY_ALLOW_NONCOMMERCIAL=1
```

Without it, `build()` returns the mock — a machine holding the weights behaves exactly like a
machine that does not. This is a guard rail, not legal advice; whether a given use is permitted is
a decision for whoever owns licensing.

**The gate guards the runtime; a second test guards the build.** Setting the flag in a script and
shipping the output would slip past `is_available()`, so `tests/test_licence_boundary.py` fails if
*any* file under `apps/`, `agents/`, `pipelines/` or `design-system/` references a restricted
block. It reads `license` from every `blocks/*/block.json`, so a future restricted block is covered
without editing the test.

**Permitted here:** research, evaluation, benchmarking a replacement, deciding whether the feature
is worth building. **Not permitted:** anything whose output reaches a shipped app.

If you need this capability *in a product*, the block needs a different generator. The mask side is
already covered permissively (`face_parsing`, MIT code); the regeneration half is what carries the
restriction.

## Use

```python
from blocks.face_editor import build, edit_mask
from blocks.face_parsing.src import build as build_parser

parser = build_parser()                      # real BiSeNet on the farm; mock elsewhere
mask   = parser.predict("selfie.png")        # 19-class SegMask

target = edit_mask(mask, {"eye_g": "skin"})  # remove the glasses
editor = build()                             # real MaskGAN only if licensed + weights present
out    = editor.edit("selfie.png", target, mask)
out.save("edited.png")                       # Pillow imported lazily
```

`edit_mask` reassigns whole classes and returns a new mask; it never mutates the source.

## Setup (iOS Ready, research use only)

```bash
git clone --depth 1 https://github.com/switchablenorms/CelebAMask-HQ.git \
  libraries/ios-ready/raw/celebamask-hq && rm -rf libraries/ios-ready/raw/celebamask-hq/.git
```

The repo ships code only. The pretrained generator is distributed separately; place it at
`MaskGAN_demo/checkpoints/label2face_512p/latest_net_G.pth`. Needs `torch` and Pillow.

Both the repo and its weights are gitignored under `ios-ready/raw/` — only `.gitkeep` is tracked, so
no model or dataset enters the repository.

## Notes

- `demo.py` upstream is a PyQt5 GUI. The library entry underneath it is
  `create_model(opt)` + `model.inference(label, label_ref, image_ref)` — edited mask, source mask,
  source image. This block calls that directly; no Qt required.
- `RGBImage` and `edit_mask` are dependency-free plain Python, so the mock, the edit ops and the
  tests run in CI with no torch and no Pillow.
- The generator was trained at 512×512; masks are nearest-upsampled to that before inference.

## Apple-native alternatives

Not covered on-device. Vision provides face landmarks and `AVSemanticSegmentationMatte` gives
skin/hair mattes (see `blocks/face_parsing`), but Apple ships no generative face-region synthesis.
A shippable editor needs a commercially-licensed generator.
