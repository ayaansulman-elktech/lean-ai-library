"""face-editor block internals: licence guard, dependency-free image/mask types, mock, MaskGAN."""
