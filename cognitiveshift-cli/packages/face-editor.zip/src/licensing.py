"""Licence guard for restricted models.

Some upstream models are usable for research but **not** in a product. CelebAMask-HQ / MaskGAN is
one: its README restricts *the software* to "non-commercial research and educational purposes",
and the dataset agreement forbids commercial exploitation of "any portion of derived data" —
which includes trained weights.

The factory ships apps with a paywall (`apps/*/charter.md`). So the restriction is not a footnote,
it is a constraint on where this code may run. Encoding it as a comment would not survive contact
with a deadline; encoding it as a gate does.

The real adapter therefore refuses to load unless the operator has explicitly acknowledged the
terms for this process:

    FACTORY_ALLOW_NONCOMMERCIAL=1

Without it, `is_available()` is False and `build()` returns the deterministic mock — the same
"never silently downgrade into something you cannot ship" rule the moodboard adapter follows.

This is a guard rail, not legal advice. Whether a given use is permitted is a decision for whoever
owns licensing, not for this module.
"""

from __future__ import annotations

import os

ENV_FLAG = "FACTORY_ALLOW_NONCOMMERCIAL"
_TRUE = {"1", "true", "yes", "on"}


class LicenseRestricted(RuntimeError):
    """The model's licence forbids this use, and nobody has acknowledged the terms."""


def noncommercial_allowed() -> bool:
    """Has the operator acknowledged non-commercial-only terms for this process?"""
    return os.environ.get(ENV_FLAG, "").strip().lower() in _TRUE


def require_noncommercial(model: str, source: str, terms: str) -> None:
    """Raise unless the operator opted in. Call before loading a restricted model."""
    if noncommercial_allowed():
        return
    raise LicenseRestricted(
        f"{model} is licensed for non-commercial research and education only.\n"
        f"  source: {source}\n"
        f"  terms : {terms}\n"
        f"This factory builds paid apps, so it must not reach apps/ or any shipped artifact.\n"
        f"For research/evaluation on this machine, acknowledge the terms explicitly:\n"
        f"  {ENV_FLAG}=1\n"
        f"Otherwise use build(offline=True) for the deterministic mock."
    )
