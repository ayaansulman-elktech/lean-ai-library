"""Real mask-guided face editor — MaskGAN (https://github.com/switchablenorms/CelebAMask-HQ).

You edit the 19-class face mask (remove the glasses, add a hat, reshape the hair) and the
generator regenerates the face to agree with the edited mask. The repo's `demo.py` is a PyQt5 GUI;
the library entry underneath it is `models.models.create_model(opt)` plus
`model.inference(label, label_ref, image_ref)` — edited mask, source mask, source image.

Runs in the **iOS Ready**: needs `torch`, Pillow, the repo in `ios-ready/raw/celebamask-hq`, and the
pretrained generator (`checkpoints/label2face_512p/latest_net_G.pth`), which the repo distributes
separately. Imports are lazy so importing this module never pulls in torch.

**Licence.** CelebAMask-HQ restricts *the software* to non-commercial research and education, and
its dataset agreement forbids commercial exploitation of derived data (which includes the trained
generator). `is_available()` is therefore False unless the operator sets
`FACTORY_ALLOW_NONCOMMERCIAL=1`, and `build()` returns the mock instead. See `licensing.py`.
"""

from __future__ import annotations

from pathlib import Path

from blocks.face_editor.src.image import RGBImage
from blocks.face_editor.src.licensing import require_noncommercial
from blocks.face_parsing.src.labels import NUM_CLASSES
from blocks.face_parsing.src.segmask import SegMask

# libraries/models/blocks/face_editor/src/model.py -> parents[4] == libraries
_DEFAULT_DIR = Path(__file__).resolve().parents[4] / "ios-ready" / "raw" / "celebamask-hq"

SOURCE = "https://github.com/switchablenorms/CelebAMask-HQ"
TERMS = "non-commercial research and educational purposes only (README: Dataset Agreement; License)"

# What the pretrained generator was trained at; the mask is upsampled to this before inference.
RESOLUTION = 512


class MaskGANEditor:
    def __init__(self, *, repo_dir=None, checkpoints_dir=None, name: str = "label2face_512p",
                 device: str = "cpu") -> None:
        self.repo_dir = Path(repo_dir) if repo_dir else _DEFAULT_DIR
        self.demo_dir = self.repo_dir / "MaskGAN_demo"
        self.checkpoints_dir = Path(checkpoints_dir) if checkpoints_dir else self.demo_dir / "checkpoints"
        self.name = name
        self.device = device
        self._model = None

    # --- availability --------------------------------------------------------------------
    def has_repo(self) -> bool:
        return (self.demo_dir / "models" / "pix2pixHD_model.py").is_file()

    def _find_weights(self) -> Path | None:
        hit = self.checkpoints_dir / self.name / "latest_net_G.pth"
        if hit.exists():
            return hit
        return next(self.checkpoints_dir.glob("**/*_net_G.pth"), None)

    def is_available(self) -> bool:
        """Repo + generator + torch present, AND the non-commercial terms acknowledged.

        The licence check comes first on purpose: a machine that has the weights but has not
        opted in must behave exactly like a machine that does not have them.
        """
        from blocks.face_editor.src.licensing import noncommercial_allowed
        if not noncommercial_allowed():
            return False
        try:
            import torch  # noqa: F401
        except Exception:
            return False
        return self.has_repo() and self._find_weights() is not None

    # --- inference -----------------------------------------------------------------------
    def _load(self):
        if self._model is not None:
            return self._model
        require_noncommercial("CelebAMask-HQ / MaskGAN", SOURCE, TERMS)
        if not self.has_repo():
            raise RuntimeError(
                f"MaskGAN not found in {self.demo_dir}. Fetch it per libraries/ios-ready/registry.json, "
                "or use build(offline=True) for the mock."
            )
        if self._find_weights() is None:
            raise RuntimeError(
                f"MaskGAN generator not found under {self.checkpoints_dir}. The repo distributes "
                "checkpoints separately; place latest_net_G.pth in <checkpoints>/label2face_512p/."
            )

        import sys
        if str(self.demo_dir) not in sys.path:
            sys.path.insert(0, str(self.demo_dir))

        from models.models import create_model  # MaskGAN_demo/models
        from options.test_options import TestOptions

        opt = TestOptions().parse(save=False)
        opt.nThreads, opt.batchSize, opt.serial_batches, opt.no_flip = 1, 1, True, True
        opt.name = self.name
        opt.checkpoints_dir = str(self.checkpoints_dir)
        opt.label_nc = NUM_CLASSES
        opt.gpu_ids = [] if self.device == "cpu" else opt.gpu_ids
        opt.isTrain = False
        self._model = create_model(opt)
        return self._model

    def edit(self, image, target_mask: SegMask, source_mask: SegMask) -> RGBImage:
        """Regenerate `image` so it agrees with `target_mask`.

        `source_mask` is the parse of the unedited image; the generator is conditioned on the
        difference between the two.
        """
        import numpy as np
        import torch
        from PIL import Image

        model = self._load()
        im = Image.open(str(image)).convert("RGB").resize((RESOLUTION, RESOLUTION), Image.BILINEAR)
        # pix2pixHD normalizes images to [-1, 1]; masks stay as raw class ids in a 1xHxW tensor.
        img_t = torch.from_numpy(
            (np.asarray(im, dtype="float32") / 127.5 - 1.0).transpose(2, 0, 1)[None]
        )
        tgt_t = _mask_to_tensor(target_mask, torch, np)
        src_t = _mask_to_tensor(source_mask, torch, np)

        with torch.no_grad():
            fake = model.inference(tgt_t, src_t, img_t)

        arr = fake[0].cpu().float().numpy().transpose(1, 2, 0)      # CHW -> HWC, [-1, 1]
        arr = np.clip((arr + 1.0) * 127.5, 0, 255).astype("uint8")
        h, w, _ = arr.shape
        return RGBImage(width=w, height=h, pixels=[tuple(px) for px in arr.reshape(-1, 3)])


def _mask_to_tensor(mask: SegMask, torch, np):
    """SegMask grid -> (1, 1, RESOLUTION, RESOLUTION) float tensor of class ids (nearest upsample)."""
    grid = np.asarray(mask.labels, dtype="float32").reshape(mask.height, mask.width)
    ys = (np.arange(RESOLUTION) * mask.height // RESOLUTION).clip(0, mask.height - 1)
    xs = (np.arange(RESOLUTION) * mask.width // RESOLUTION).clip(0, mask.width - 1)
    full = grid[ys[:, None], xs[None, :]]
    return torch.from_numpy(full[None, None].astype("float32"))
