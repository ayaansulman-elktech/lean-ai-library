"""A dependency-free RGB image + the mask-edit operations that drive the editor.

`RGBImage` is plain Python lists, so the mock, the edit ops and the tests run in CI with no torch
and no Pillow. The real adapter converts its tensor output into one; `save()` imports Pillow lazily.

An "edit" here is an edit to the *mask*, not to pixels: you change which class owns a region
(give the subject a hat, widen the hair, remove the glasses) and the model regenerates the face to
match. `edit_mask` builds that target mask from a source `SegMask`.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from blocks.face_parsing.src.labels import CLASSES
from blocks.face_parsing.src.segmask import SegMask

PathLike = str | Path


@dataclass
class RGBImage:
    width: int
    height: int
    pixels: list[tuple[int, int, int]]      # row-major, len == width * height

    def __post_init__(self) -> None:
        if self.width <= 0 or self.height <= 0:
            raise ValueError("image must be non-empty")
        if len(self.pixels) != self.width * self.height:
            raise ValueError(f"pixels length {len(self.pixels)} != {self.width}x{self.height}")

    def pixel(self, x: int, y: int) -> tuple[int, int, int]:
        return self.pixels[y * self.width + x]

    def save(self, path: PathLike) -> str:
        """Write a PNG. Pillow is imported here so the core stays dependency-free."""
        from PIL import Image

        im = Image.new("RGB", (self.width, self.height))
        im.putdata(self.pixels)
        im.save(str(path))
        return str(path)


def class_id(name: str) -> int:
    """Look up a CelebAMask-HQ class id by name ('hair', 'hat', 'u_lip', ...)."""
    for cid, cname in CLASSES.items():
        if cname == name:
            return cid
    raise KeyError(f"unknown face class {name!r}; known: {sorted(CLASSES.values())}")


def edit_mask(mask: SegMask, changes: dict[str, str]) -> SegMask:
    """Return a new mask with whole classes reassigned, e.g. {"eye_g": "skin"} removes glasses.

    Reassignment is the operation MaskGAN is trained on: the generator sees a mask that disagrees
    with the source image and regenerates the pixels to agree with the mask.
    """
    if not changes:
        raise ValueError("no changes requested")
    remap = {class_id(src): class_id(dst) for src, dst in changes.items()}
    return SegMask(width=mask.width, height=mask.height,
                   labels=[remap.get(v, v) for v in mask.labels])
