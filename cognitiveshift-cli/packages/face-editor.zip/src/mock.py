"""Deterministic offline stand-in for the mask-guided face editor — no torch, runs in CI.

It does not synthesize a face. It renders the *target mask* as flat per-class colours, using
CelebAMask-HQ's own palette. That is enough to exercise everything around the model: that an edit
to the mask reaches the output, that region geometry survives, and that callers handle an
`RGBImage`. It is for tests and demos, not for looking at.
"""

from __future__ import annotations

from blocks.face_editor.src.image import RGBImage
from blocks.face_parsing.src.segmask import SegMask

# The 19 class colours MaskGAN_demo/demo.py paints its mask editor with, in class-id order.
CLASS_COLORS: list[tuple[int, int, int]] = [
    (0, 0, 0), (204, 0, 0), (76, 153, 0), (204, 204, 0), (51, 51, 255), (204, 0, 204),
    (0, 255, 255), (51, 255, 255), (102, 51, 0), (255, 0, 0), (102, 204, 0), (255, 255, 0),
    (0, 0, 153), (0, 0, 204), (255, 51, 153), (0, 204, 204), (0, 51, 0), (255, 153, 51),
    (0, 204, 0),
]


class MockFaceEditor:
    def __init__(self, *, size: int = 128) -> None:
        self.size = size

    def is_available(self) -> bool:
        return True

    def edit(self, image, target_mask: SegMask, source_mask: SegMask | None = None) -> RGBImage:  # noqa: ARG002
        """Render `target_mask` as flat class colours, upsampled to `size`. Pixels are ignored."""
        n = self.size
        pixels: list[tuple[int, int, int]] = []
        for row in range(n):
            my = min(target_mask.height - 1, row * target_mask.height // n)
            for col in range(n):
                mx = min(target_mask.width - 1, col * target_mask.width // n)
                cid = target_mask.labels[my * target_mask.width + mx]
                pixels.append(CLASS_COLORS[cid % len(CLASS_COLORS)])
        return RGBImage(width=n, height=n, pixels=pixels)
