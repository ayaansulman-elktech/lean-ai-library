"""face-editor block factory.

`build(offline=False)` returns the real MaskGAN adapter only when the repo, the generator and torch
are on the box **and** the operator has acknowledged the non-commercial licence
(`FACTORY_ALLOW_NONCOMMERCIAL=1`). Otherwise it returns the deterministic mock — it never silently
serves a model this factory cannot ship. See `src/licensing.py`.
"""

from __future__ import annotations

from blocks.face_editor.src.image import RGBImage, class_id, edit_mask
from blocks.face_editor.src.licensing import ENV_FLAG, LicenseRestricted, noncommercial_allowed
from blocks.face_editor.src.mock import MockFaceEditor
from blocks.face_editor.src.model import MaskGANEditor


def build(offline: bool = False, **kwargs):
    if not offline:
        model = MaskGANEditor(**{k: v for k, v in kwargs.items()
                                 if k in {"repo_dir", "checkpoints_dir", "name", "device"}})
        if model.is_available():
            return model
    return MockFaceEditor(**{k: v for k, v in kwargs.items() if k in {"size"}})


__all__ = ["build", "MaskGANEditor", "MockFaceEditor", "RGBImage", "edit_mask", "class_id",
           "LicenseRestricted", "noncommercial_allowed", "ENV_FLAG"]
