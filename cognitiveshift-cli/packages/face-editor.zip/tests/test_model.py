import pytest
from blocks.face_editor import (
    ENV_FLAG,
    LicenseRestricted,
    MaskGANEditor,
    MockFaceEditor,
    build,
    class_id,
    edit_mask,
    noncommercial_allowed,
)
from blocks.face_editor.src.image import RGBImage
from blocks.face_parsing.src.labels import CLASSES
from blocks.face_parsing.src.mock import MockFaceParsing


@pytest.fixture
def mask():
    """A synthetic parse: hair frame, skin oval, eyes, lips."""
    return MockFaceParsing(grid=32).predict("face.png")


@pytest.fixture(autouse=True)
def _no_ambient_optin(monkeypatch):
    """Never let a developer's exported flag leak into the tests."""
    monkeypatch.delenv(ENV_FLAG, raising=False)


# --- licence gate ---------------------------------------------------------------------
def test_restricted_model_is_unavailable_without_optin():
    """Weights on disk must not be enough: unacknowledged terms == unavailable."""
    assert noncommercial_allowed() is False
    assert MaskGANEditor().is_available() is False


def test_loading_the_restricted_model_raises_with_the_terms():
    with pytest.raises(LicenseRestricted, match="non-commercial"):
        MaskGANEditor()._load()


def test_the_error_says_where_the_terms_come_from_and_how_to_opt_in():
    with pytest.raises(LicenseRestricted) as e:
        MaskGANEditor()._load()
    msg = str(e.value)
    assert "github.com/switchablenorms/CelebAMask-HQ" in msg
    assert ENV_FLAG in msg
    assert "must not reach apps/" in msg


def test_optin_alone_does_not_conjure_a_model(monkeypatch, tmp_path):
    """Acknowledging the licence lifts the gate; it does not fabricate the repo or weights."""
    monkeypatch.setenv(ENV_FLAG, "1")
    assert noncommercial_allowed() is True
    editor = MaskGANEditor(repo_dir=tmp_path)
    assert editor.has_repo() is False
    assert editor.is_available() is False
    with pytest.raises(RuntimeError, match="MaskGAN not found"):
        editor._load()


def test_build_falls_back_to_the_mock():
    assert isinstance(build(), MockFaceEditor)
    assert isinstance(build(offline=True), MockFaceEditor)


def test_build_follows_availability_when_optin_is_set(monkeypatch):
    """Opting in must not raise: with no repo/weights the factory still returns the mock.

    Asserts the contract, not the environment — on a farm box with the checkpoints downloaded the
    real editor is the correct answer, and this test must keep passing there.
    """
    monkeypatch.setenv(ENV_FLAG, "1")
    expected = MaskGANEditor if MaskGANEditor().is_available() else MockFaceEditor
    assert isinstance(build(), expected)


# --- mask editing ---------------------------------------------------------------------
def test_class_id_round_trips_every_label():
    for cid, name in CLASSES.items():
        assert class_id(name) == cid


def test_class_id_rejects_an_unknown_part():
    with pytest.raises(KeyError, match="unknown face class"):
        class_id("moustache")


def test_edit_mask_reassigns_a_whole_class(mask):
    hair, hat = class_id("hair"), class_id("hat")
    assert mask.present([hair]) and not mask.present([hat])

    edited = edit_mask(mask, {"hair": "hat"})
    assert edited.present([hat]) and not edited.present([hair])
    assert edited.coverage([hat]) == pytest.approx(mask.coverage([hair]))
    assert mask.present([hair]), "the source mask must not be mutated"


def test_edit_mask_preserves_geometry(mask):
    edited = edit_mask(mask, {"hair": "hat"})
    assert (edited.width, edited.height) == (mask.width, mask.height)
    assert edited.bbox([class_id("hat")]) == mask.bbox([class_id("hair")])


def test_edit_mask_leaves_other_classes_alone(mask):
    edited = edit_mask(mask, {"hair": "hat"})
    skin = class_id("skin")
    assert edited.coverage([skin]) == pytest.approx(mask.coverage([skin]))


def test_edit_mask_requires_a_change(mask):
    with pytest.raises(ValueError, match="no changes requested"):
        edit_mask(mask, {})


# --- the mock editor ------------------------------------------------------------------
def test_mock_edit_returns_an_image_shaped_by_the_target_mask(mask):
    out = MockFaceEditor(size=64).edit("face.png", edit_mask(mask, {"hair": "hat"}), mask)
    assert isinstance(out, RGBImage)
    assert (out.width, out.height) == (64, 64)
    assert len(out.pixels) == 64 * 64


def test_mock_edit_is_deterministic(mask):
    a = MockFaceEditor(size=32).edit("face.png", mask, mask)
    b = MockFaceEditor(size=32).edit("face.png", mask, mask)
    assert a.pixels == b.pixels


def test_an_edit_to_the_mask_changes_the_output(mask):
    """The whole point: editing the mask must reach the rendered result."""
    before = MockFaceEditor(size=32).edit("face.png", mask, mask)
    after = MockFaceEditor(size=32).edit("face.png", edit_mask(mask, {"hair": "hat"}), mask)
    assert before.pixels != after.pixels


def test_rgbimage_rejects_a_wrong_pixel_count():
    with pytest.raises(ValueError, match="pixels length"):
        RGBImage(width=2, height=2, pixels=[(0, 0, 0)])


def test_rgbimage_saves_a_png(tmp_path):
    pytest.importorskip("PIL", reason="Pillow is only needed to write the image out")
    img = RGBImage(width=2, height=1, pixels=[(255, 0, 0), (0, 255, 0)])
    out = img.save(tmp_path / "out.png")
    assert out.endswith("out.png")
    from PIL import Image
    assert Image.open(out).size == (2, 1)
