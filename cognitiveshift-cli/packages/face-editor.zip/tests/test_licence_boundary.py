"""Repo-wide invariant: restricted-licence blocks must never reach a shipped artifact.

`src/licensing.py` stops a restricted model from *loading* without an explicit opt-in. That is a
guard rail on the runtime, not on the build: someone can export FACTORY_ALLOW_NONCOMMERCIAL=1 in a
script, generate assets, and ship them. This test guards the boundary instead of the door.

It is data-driven, not a hard-coded list of one block: any `blocks/*/block.json` whose `license`
says "non-commercial" is restricted, and no file under a shipping path may reference its module.
Add another restricted block and this test covers it on the next run, with no edit here.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

# Paths whose output reaches a user: the apps themselves, the agents and pipelines that generate
# app code and assets, and the design system baked into every app.
SHIPPING_PATHS = ("apps", "agents", "pipelines", "design-system")

SCAN_SUFFIXES = {".py", ".swift", ".json", ".sh", ".yml", ".yaml", ".toml", ".md"}
SKIP_DIRS = {"__pycache__", ".pytest_cache", ".git", "node_modules", ".venv"}


def _repo_root() -> Path:
    for p in Path(__file__).resolve().parents:
        if (p / "CHARTER.md").is_file() and (p / "libraries").is_dir():
            return p
    raise RuntimeError("factory root not found (looked for CHARTER.md)")


def _restricted_blocks(root: Path) -> dict[str, str]:
    """-> {module_prefix: licence} for every block whose licence forbids commercial use."""
    out: dict[str, str] = {}
    for manifest in (root / "libraries" / "models" / "blocks").glob("*/block.json"):
        meta = json.loads(manifest.read_text(encoding="utf-8"))
        if "non-commercial" in str(meta.get("license", "")).lower():
            out[f"blocks.{manifest.parent.name}"] = meta["license"]
    return out


def _files_under(root: Path, rel: str):
    base = root / rel
    if not base.is_dir():
        return
    for p in base.rglob("*"):
        if p.is_file() and p.suffix in SCAN_SUFFIXES and not (SKIP_DIRS & set(p.parts)):
            yield p


def _offenders(root: Path, needle: str) -> list[str]:
    hits = []
    for rel in SHIPPING_PATHS:
        for f in _files_under(root, rel):
            try:
                if needle in f.read_text(encoding="utf-8", errors="ignore"):
                    hits.append(str(f.relative_to(root)))
            except OSError:
                continue
    return hits


def test_this_repo_has_at_least_one_restricted_block():
    """Sanity: if nothing is restricted, the invariant below would pass vacuously."""
    assert _restricted_blocks(_repo_root()), "expected face-editor to be marked non-commercial"


def test_restricted_blocks_are_not_referenced_from_shipping_paths():
    root = _repo_root()
    restricted = _restricted_blocks(root)

    violations: dict[str, list[str]] = {}
    for module, licence in restricted.items():
        hits = _offenders(root, module)
        if hits:
            violations[f"{module} ({licence})"] = hits

    assert not violations, (
        "Restricted-licence model referenced from a shipping path:\n"
        + "\n".join(f"  {mod}\n    - " + "\n    - ".join(files) for mod, files in violations.items())
        + f"\n\nThese paths produce artifacts we ship: {', '.join(SHIPPING_PATHS)}.\n"
        "A non-commercial model must not reach them, even indirectly."
    )


def test_the_scanner_actually_detects_a_violation(tmp_path):
    """A guard that cannot fail is not a guard. Plant one and prove the scanner finds it."""
    (tmp_path / "CHARTER.md").write_text("x")
    (tmp_path / "libraries").mkdir()
    apps = tmp_path / "apps" / "demo"
    apps.mkdir(parents=True)
    (apps / "Leak.py").write_text("from blocks.face_editor import build\n")

    assert _offenders(tmp_path, "blocks.face_editor") == [str(Path("apps") / "demo" / "Leak.py")]


def test_the_scanner_ignores_non_shipping_paths(tmp_path):
    """The block's own source and tests reference it constantly; that must not trip the guard."""
    (tmp_path / "libraries" / "models" / "blocks").mkdir(parents=True)
    (tmp_path / "libraries" / "models" / "blocks" / "use.py").write_text("import blocks.face_editor")
    assert _offenders(tmp_path, "blocks.face_editor") == []


@pytest.mark.parametrize("rel", SHIPPING_PATHS)
def test_every_shipping_path_is_actually_scanned(rel, tmp_path):
    """If a shipping dir were silently skipped, the invariant would pass for the wrong reason."""
    d = tmp_path / rel
    d.mkdir(parents=True)
    (d / "x.py").write_text("blocks.face_editor")
    assert _offenders(tmp_path, "blocks.face_editor") == [str(Path(rel) / "x.py")]
