# purity

See README.md for details.
