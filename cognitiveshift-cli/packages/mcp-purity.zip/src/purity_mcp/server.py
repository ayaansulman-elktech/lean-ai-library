"""Purity MCP server — moodboard coherence scoring + the per-app universe, over MCP.

Any MCP-capable agent (Codex / Claude) calls these tools to score a persona moodboard and
project it into `apps/<app>/universe/tokens.override.json`.

Run (needs the transport):  pip install "purity-mcp[server]"  then  python -m purity_mcp.server
The tool logic lives in `core.py`, which reuses `vis_models.moodboard` — the real
moodboard-purity adapter, the coherence gate and the DTCG projection all live there.

Every tool takes its `folder` explicitly and the server holds no cross-call state: two agents
sharing one server must not have one's moodboard leak into the other's design tokens.
"""
from __future__ import annotations

from . import core


def build_server():
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as e:  # pragma: no cover - transport is optional
        raise SystemExit(
            "The Purity MCP server needs the 'mcp' package.\n"
            '  pip install "purity-mcp[server]"\n'
            "(The core tools run without it.)"
        ) from e

    mcp = FastMCP("purity")

    @mcp.tool()
    def health() -> dict:
        """Which backend a score would use: real moodboard-purity, or the offline mock (and why)."""
        return core.backend_status()

    @mcp.tool()
    def score_moodboard(folder: str, depth: str = "balanced", allow_heuristic: bool = False) -> dict:
        """Score a folder of persona images: palette, aesthetic tags, coherence, metrics.

        depth: fast | balanced | deep. `issues` block token generation; `notes` are advisory.
        Coherence saturates at 1.0, so rank boards by metrics.latentPurity / metrics.spectralPurity
        rather than by coherence. Without the SigLIP2 weights this returns the deterministic mock
        unless `allow_heuristic=true`, which opts into a score that cannot drive tokens.
        """
        return core.analyze(folder, depth=depth, allow_heuristic=allow_heuristic)

    @mcp.tool()
    def to_tokens(folder: str, app: str = "app", depth: str = "balanced") -> dict:
        """Score `folder` and project its aesthetic into a DTCG token override (does not write)."""
        return core.tokens(folder, app=app, depth=depth)

    @mcp.tool()
    def write_tokens(folder: str, out_path: str, app: str = "app", depth: str = "balanced",
                     force: bool = False, min_coherence: float | None = None) -> str:
        """Write apps/<app>/universe/tokens.override.json from the moodboard. Returns the path.

        Refuses a score the vision model did not produce (heuristic fallback), because that
        coherence is a different quantity under the same name. Pass `min_coherence` to also refuse
        below a threshold you have calibrated on your own boards; none ships, because none is
        validated. `force` overrides.
        """
        return core.write_tokens(folder, out_path, app=app, depth=depth, force=force,
                                 min_coherence=min_coherence)

    return mcp


def main():  # pragma: no cover
    build_server().run()


if __name__ == "__main__":  # pragma: no cover
    main()
