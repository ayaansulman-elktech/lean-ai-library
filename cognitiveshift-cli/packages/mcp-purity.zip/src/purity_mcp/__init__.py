"""Purity MCP — moodboard coherence scoring for the Lean Creative Universe."""
