"""Purity MCP — core tool logic (no MCP SDK needed, fully offline-testable).

Aesthetic extraction, scoring and token projection are **reused** from
`libraries/models/src/vis_models/moodboard` (single source of truth), not reimplemented here.
That package owns the moodboard-purity adapter, the payload contract, the coherence gate and
the DTCG projection; this module only turns those into flat, MCP-friendly dicts.

`server.py` wraps these as MCP tools.
"""
from __future__ import annotations

import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

# --- reuse the canonical moodboard layer from libraries/models ------------------------
_here = Path(__file__).resolve()
_ROOT = next((p for p in _here.parents if (p / "libraries" / "models" / "src").exists()), None)
if _ROOT:
    _p = str(_ROOT / "libraries" / "models" / "src")
    if _p not in sys.path:
        sys.path.insert(0, _p)

from vis_models.moodboard import (  # noqa: E402
    MoodboardPurityModel,
    advisory_notes,
    blocking_issues,
    build_moodboard,
    to_token_override,
    write_universe,
)
from vis_models.moodboard.base import IMAGE_EXTS  # noqa: E402


def images_in(folder: str) -> list[str]:
    """Every image in a flat moodboard folder, matched case-insensitively."""
    d = Path(folder).expanduser()
    if not d.is_dir():
        raise ValueError(f"{d}: not a directory")
    found = sorted(str(p) for p in d.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)
    if not found:
        raise ValueError(f"{d}: no images (accepted: {', '.join(sorted(IMAGE_EXTS))})")
    return found


def backend_status() -> dict[str, Any]:
    """Which backend a score would actually use, and why."""
    model = MoodboardPurityModel()
    real = model.is_available()
    return {
        "repoPresent": model.has_repo(),
        "repoDir": str(model.repo_dir),
        "purityAvailable": real,
        "backend": "moodboard-purity" if real else "mock",
        "note": "" if real else (
            "SigLIP2 cannot run (missing repo, deps, or weights) — build_moodboard falls back to "
            "the deterministic mock rather than serving a heuristic score under the same name."
        ),
    }


def analyze(folder: str, depth: str = "balanced", allow_heuristic: bool = False) -> dict[str, Any]:
    """Score a moodboard folder.

    `issues` block token generation; `notes` are advisory and never refuse. There is deliberately
    no pure/hybrid/dissonant label — see `vis_models.moodboard.metrics` for why.
    """
    model = build_moodboard("purity", depth=depth, allow_heuristic=allow_heuristic)
    result = model.analyze(images_in(folder))
    out = asdict(result)
    out["issues"] = blocking_issues(result)
    out["notes"] = advisory_notes(result)
    return out


def tokens(folder: str, app: str = "app", depth: str = "balanced",
           allow_heuristic: bool = False) -> dict[str, Any]:
    """Score, then project into a DTCG token override. Does not write."""
    model = build_moodboard("purity", depth=depth, allow_heuristic=allow_heuristic)
    return to_token_override(model.analyze(images_in(folder)), app=app)


def write_tokens(folder: str, out_path: str, app: str = "app", depth: str = "balanced",
                 force: bool = False, allow_heuristic: bool = False,
                 min_coherence: float | None = None) -> str:
    """Write apps/<app>/universe/tokens.override.json. Refuses a moodboard that fails the gate."""
    model = build_moodboard("purity", depth=depth, allow_heuristic=allow_heuristic)
    result = model.analyze(images_in(folder))
    return write_universe(result, out_path, app=app, force=force, min_coherence=min_coherence)
