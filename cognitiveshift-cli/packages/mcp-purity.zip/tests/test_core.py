"""Core tests — the MCP's own logic. The scoring/gate/projection contract is tested in
`libraries/models/tests/test_moodboard.py`, which owns it; this file must not duplicate it.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from purity_mcp import core

REPO = Path(__file__).resolve().parents[3] / "ios-ready" / "raw" / "moodboard-purity"
needs_repo = pytest.mark.skipif(
    not (REPO / "app" / "api" / "analyze.py").is_file(),
    reason="moodboard-purity not fetched into libraries/ios-ready/raw (iOS Ready)",
)


COLORS = (("a.png", (14, 27, 42)), ("b.JPG", (217, 140, 95)), ("c.png", (251, 250, 247)))


@pytest.fixture
def board(tmp_path):
    """A moodboard folder. Filenames only — the mock is pixel-free, so CI needs no Pillow."""
    d = tmp_path / "moodboard"
    d.mkdir()
    for name, _ in COLORS:
        (d / name).write_bytes(b"not-really-an-image")
    return d


@pytest.fixture
def offline(monkeypatch):
    """Force the deterministic mock.

    Without this, a dev box that has run scripts/fetch-moodboard.sh would load 1.5GB of weights
    and try to decode the fixture's placeholder bytes as images. These tests are about the MCP's
    own logic, not the model.
    """
    real = core.build_moodboard
    monkeypatch.setattr(core, "build_moodboard", lambda *a, **k: real("purity", offline=True))


@pytest.fixture
def real_board(tmp_path):
    """Actual PNGs — only the real backend decodes pixels."""
    Image = pytest.importorskip("PIL.Image", reason="Pillow needed to synthesize test images")
    d = tmp_path / "real"
    d.mkdir()
    for name, rgb in COLORS:
        Image.new("RGB", (96, 96), rgb).save(d / name, format=Path(name).suffix.lstrip(".").upper()
                                             .replace("JPG", "JPEG"))
    return d


# --- folder scanning ------------------------------------------------------------------
def test_images_in_is_case_insensitive(board):
    names = [Path(p).name for p in core.images_in(str(board))]
    assert names == ["a.png", "b.JPG", "c.png"], "'.JPG' must be found (globs are case-sensitive on Linux)"


def test_images_in_ignores_non_images_and_subfolders(board):
    (board / "notes.txt").write_text("ignored")
    (board / "nested").mkdir()
    (board / "nested" / "deep.png").write_bytes(b"x")
    names = [Path(p).name for p in core.images_in(str(board))]
    assert "notes.txt" not in names
    assert "deep.png" not in names, "a moodboard is one flat folder"


def test_empty_folder_is_a_clear_error(tmp_path):
    with pytest.raises(ValueError, match="no images"):
        core.images_in(str(tmp_path))


def test_missing_folder_is_a_clear_error(tmp_path):
    with pytest.raises(ValueError, match="not a directory"):
        core.images_in(str(tmp_path / "nope"))


# --- backend status -------------------------------------------------------------------
def test_backend_status_never_claims_a_backend_it_cannot_run():
    """`backend` must follow `purityAvailable`, and say why when it falls back."""
    status = core.backend_status()
    if status["purityAvailable"]:
        assert status["backend"] == "moodboard-purity"
        assert status["repoPresent"] is True
        assert status["note"] == ""
    else:
        assert status["backend"] == "mock"
        assert "SigLIP2" in status["note"]


# --- scoring via the mock (the CI path) ------------------------------------------------
def test_analyze_returns_palette_coherence_and_issues(board, offline):
    out = core.analyze(str(board))
    assert out["palette"] and all(c.startswith("#") for c in out["palette"])
    assert 0.0 <= out["coherence"] <= 1.0
    assert out["metrics"]["source"] == "mock"
    assert out["issues"] == []          # blocking
    assert out["notes"] == []           # advisory


def test_a_low_coherence_board_still_writes_tokens(board, offline, tmp_path, monkeypatch):
    """Regression: the old 0.6 gate refused every real moodboard, pure ones included."""
    import purity_mcp.core as c
    from vis_models.moodboard import MoodboardResult

    class _Low:
        def analyze(self, images):
            return MoodboardResult(["#101010", "#E23A2E", "#FFFFFF"], ["bold"],
                                   coherence=0.49, ml_ran=True)

    monkeypatch.setattr(c, "build_moodboard", lambda *a, **k: _Low())
    dest = tmp_path / "tokens.override.json"
    assert core.analyze(str(board))["issues"] == []
    core.write_tokens(str(board), str(dest), app="A")
    assert dest.exists()


def test_a_caller_supplied_threshold_still_refuses(board, offline, tmp_path, monkeypatch):
    """Opt in to a threshold you calibrated, and the gate honours it."""
    import purity_mcp.core as c
    from vis_models.moodboard import MoodboardResult

    class _Low:
        def analyze(self, images):
            return MoodboardResult(["#101010", "#E23A2E", "#FFFFFF"], coherence=0.30, ml_ran=True)

    monkeypatch.setattr(c, "build_moodboard", lambda *a, **k: _Low())
    dest = tmp_path / "t.json"
    with pytest.raises(ValueError, match="below the caller's threshold"):
        core.write_tokens(str(board), str(dest), app="A", min_coherence=0.6)
    assert not dest.exists()


def test_tokens_projects_dtcg(board, offline):
    ov = core.tokens(str(board), app="color-matching")
    assert ov["color"]["$type"] == "color"
    assert set(ov["color"]) >= {"$type", "brand", "accent", "surface"}
    assert "color-matching" in ov["$description"]


# --- live run against the vendored repo (skipped in CI: ios-ready/raw is gitignored) ------
@needs_repo
def test_real_backend_scores_and_refuses_to_write_heuristic_tokens(real_board, tmp_path, monkeypatch):
    monkeypatch.setenv("MOODBOARD_ENABLE_ML", "0")
    monkeypatch.setenv("MOODBOARD_ENABLE_OWLV2", "0")

    out = core.analyze(str(real_board), depth="fast", allow_heuristic=True)
    assert out["ml_ran"] is False
    assert "verdict" not in out, "the pure/hybrid/dissonant label had no signal and was removed"
    assert out["metrics"]["clusterCount"] >= 1
    assert any("heuristic" in i for i in out["issues"])

    dest = tmp_path / "universe" / "tokens.override.json"
    with pytest.raises(ValueError, match="refusing to write the universe"):
        core.write_tokens(str(real_board), str(dest), app="A", allow_heuristic=True)
    assert not dest.exists()

    core.write_tokens(str(real_board), str(dest), app="A", allow_heuristic=True, force=True)
    written = json.loads(dest.read_text())
    assert written["color"]["brand"]["$value"].startswith("#")
