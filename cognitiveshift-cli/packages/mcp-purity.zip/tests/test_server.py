"""MCP transport smoke test — builds the FastMCP server and drives its tools in-memory.

Skips cleanly if the optional `mcp` transport isn't installed (the core stays offline-testable).
"""
from __future__ import annotations

import asyncio
import json

import pytest

pytest.importorskip("mcp", reason="MCP transport is optional (pip install 'purity-mcp[server]')")

from purity_mcp.server import build_server  # noqa: E402


def _run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def _structured(result):
    """FastMCP.call_tool returns (content, structured) in recent versions, or just content.
    Scalar returns are wrapped as {"result": value} — unwrap those."""
    val = None
    if isinstance(result, tuple) and len(result) == 2:
        val = result[1]
    elif isinstance(result, dict):
        val = result
    else:
        text = getattr(result[0], "text", None) if result else None
        try:
            val = json.loads(text)
        except Exception:
            val = text
    if isinstance(val, dict) and set(val.keys()) == {"result"}:
        return val["result"]
    return val


@pytest.fixture
def board(tmp_path):
    """Filenames only — these tests run through the pixel-free mock, so CI needs no Pillow."""
    d = tmp_path / "moodboard"
    d.mkdir()
    for name in ("a.png", "b.png", "c.png"):
        (d / name).write_bytes(b"not-really-an-image")
    return d


@pytest.fixture
def offline(monkeypatch):
    """Force the mock: these tests exercise the transport, not 1.5GB of weights."""
    import purity_mcp.core as core
    real = core.build_moodboard
    monkeypatch.setattr(core, "build_moodboard", lambda *a, **k: real("purity", offline=True))


def test_server_builds_and_lists_tools():
    names = {t.name for t in _run(build_server().list_tools())}
    for expected in ("health", "score_moodboard", "to_tokens", "write_tokens"):
        assert expected in names, f"missing tool {expected}; got {names}"


def test_tools_carry_no_cross_call_state():
    """Every tool takes its folder: one agent's moodboard must not leak into another's tokens."""
    tools = {t.name: t for t in _run(build_server().list_tools())}
    for name in ("score_moodboard", "to_tokens", "write_tokens"):
        assert "folder" in tools[name].inputSchema.get("required", []), f"{name} must require a folder"


def test_health_reports_the_backend():
    h = _structured(_run(build_server().call_tool("health", {})))
    assert h["backend"] in {"moodboard-purity", "mock"}
    assert "repoDir" in h


def test_server_scores_and_writes_tokens(board, tmp_path, offline):
    m = build_server()
    dest = tmp_path / "universe" / "tokens.override.json"

    summary = _structured(_run(m.call_tool("score_moodboard", {"folder": str(board)})))
    assert 0.0 <= summary["coherence"] <= 1.0
    assert summary["palette"]

    tokens = _structured(_run(m.call_tool("to_tokens", {"folder": str(board), "app": "color-matching"})))
    assert tokens["color"]["brand"]["$value"].startswith("#")

    _run(m.call_tool("write_tokens", {"folder": str(board), "out_path": str(dest), "app": "color-matching"}))
    assert json.loads(dest.read_text())["color"]["$type"] == "color"


def _server_with(result, monkeypatch):
    import purity_mcp.core as core

    class _Fixed:
        def analyze(self, images):
            return result

    monkeypatch.setattr(core, "build_moodboard", lambda *a, **k: _Fixed())
    return build_server()


def test_write_tokens_refuses_a_heuristic_score(board, tmp_path, monkeypatch):
    """The one thing that blocks: a coherence the vision model did not produce."""
    from vis_models.moodboard import MoodboardResult

    m = _server_with(MoodboardResult(["#101010", "#E23A2E", "#FFFFFF"], ["bold"],
                                     coherence=0.95, ml_ran=False), monkeypatch)
    dest = tmp_path / "t.json"
    with pytest.raises(Exception, match="refusing to write the universe|heuristic"):
        _run(m.call_tool("write_tokens", {"folder": str(board), "out_path": str(dest)}))
    assert not dest.exists()


def test_write_tokens_admits_a_low_coherence_board(board, tmp_path, monkeypatch):
    """Regression: real moodboards score ~0.48-0.53, and the old 0.6 gate refused all of them."""
    from vis_models.moodboard import MoodboardResult

    m = _server_with(MoodboardResult(["#101010", "#E23A2E", "#FFFFFF"], ["bold"],
                                     coherence=0.49, ml_ran=True), monkeypatch)
    dest = tmp_path / "t.json"
    _run(m.call_tool("write_tokens", {"folder": str(board), "out_path": str(dest)}))
    assert json.loads(dest.read_text())["color"]["$type"] == "color"
