# Purity MCP

Turns a folder of persona images into an app's visual identity.

Given a moodboard, it extracts the palette and aesthetic tags, scores how coherently the images
hang together ("purity"), and projects the result into `apps/<app>/universe/tokens.override.json` —
the per-app design tokens that override the shared design system.

It exposes this over MCP, so any agent can call it, and over a plain Python API.

---

## Quick start

```bash
# 1. Fetch the analysis backend and its models (~4GB, downloaded outside git)
scripts/fetch-moodboard.sh --captions

# 2. Install what the models need
python -m pip install "transformers==4.57.1" sentencepiece torch einops timm accelerate num2words

# 3. Confirm it can really run
scripts/fetch-moodboard.sh          # prints is_available(): True
```

Then, from Python:

```python
from vis_models.moodboard import build_moodboard, write_universe

model = build_moodboard("purity")
result = model.analyze("apps/color-matching/universe/moodboard/")

print(result.coherence)   # 0.0–1.0
print(result.palette)     # ['#0E1B2A', '#FBFAF7', '#D98C5F']
print(result.metrics)     # latentPurity, spectralPurity, dissonance, outliers, …

write_universe(result, "apps/color-matching/universe/tokens.override.json", app="color-matching")
```

Or as an MCP server:

```bash
pip install "purity-mcp[server]"
python -m purity_mcp.server
```

---

## MCP tools

| Tool | Arguments | Returns |
| --- | --- | --- |
| `health` | — | which backend is active, and why |
| `score_moodboard` | `folder`, `depth`, `allow_heuristic` | palette, tags, coherence, metrics, issues, notes |
| `to_tokens` | `folder`, `app`, `depth` | a DTCG token override (does not write) |
| `write_tokens` | `folder`, `out_path`, `app`, `depth`, `force`, `min_coherence` | path written |

`depth` is `fast`, `balanced` (default), or `deep` — it selects how much captioning and analysis
work the backend does, trading time for richer aesthetic tags.

Every tool takes its `folder` explicitly and the server keeps no state between calls, so two
agents sharing one server cannot cross-contaminate each other's results.

A moodboard is **one flat folder** of images. Subfolders are ignored. Accepted extensions:
`.png .jpg .jpeg .webp .heic`, matched case-insensitively.

---

## What you get back

```json
{
  "palette":       ["#FBFAF7", "#0E1B2A", "#D98C5F"],
  "aesthetic_tags": ["central balance", "negative space", "minimal", "soft focus"],
  "coherence":     0.5271,
  "ml_ran":        true,
  "metrics": {
    "latentPurity": 0.6484,      "spectralPurity": 0.2244,
    "harmonicity":  0.2113,      "dissonance":     0.2866,
    "aestheticRegimeCount": 4,   "clusterCount":   2,
    "dominantAesthetic": "Earth Tones",
    "saturated": false,          "outliers": []
  },
  "issues": [],
  "notes":  ["aestheticRegimeCount is at its upstream cap — …"]
}
```

`palette` is dominant-first. `issues` blocks token generation (see the gate, below); an empty list
means the moodboard is good to use. `notes` are advisory and never refuse.

---

## Reading the score

**Do not read `coherence` alone.** Three properties of the underlying score make it misleading
on its own.

### `coherence` saturates

The scoring formula clamps to `[0, 1]`, and several genuinely different moodboards all land on
exactly `1.0`. You cannot rank two strong boards by this number. Compare `metrics.latentPurity`
and `metrics.spectralPurity` instead. When it happens, `metrics.saturated` is `true` and the
board is blocked from generating tokens.

### There is no pure / hybrid / dissonant label

An earlier version reported a `verdict` derived from `aestheticRegimeCount` and `dissonanceScore`.
Eight labelled moodboards, scored through the real backend, killed it:

| board | intent | coherence | latentPurity | regimes |
|---|---|---|---|---|
| ukiyo-e prints | pure | 0.5235 | 0.6289 | 6 |
| botanical engravings | pure | 0.4934 | 0.5872 | 6 |
| Greek pottery | pure | 0.5339 | 0.6532 | 6 |
| Impressionist paintings | pure | 0.4998 | 0.5943 | 6 |
| prints + abstracts | hybrid | 0.4972 | 0.5902 | 6 |
| gothic + pop art | hybrid | 0.4926 | 0.5781 | 6 |
| mixed grab-bag A | dissonant | 0.4821 | 0.5609 | 6 |
| mixed grab-bag B | dissonant | 0.5095 | 0.6078 | 6 |

Every metric overlaps across every label pair, and a deliberately incoherent board outscored six
botanical engravings. `aestheticRegimeCount` is 6 for all of them because upstream caps it — it
measures graph richness, not how many aesthetics are present. So the label was noise dressed as a
judgment, and it is gone. The raw metrics pass through untouched.

Anyone re-adding a classification should first show it separates a labelled set.

### `ml_ran: false` means the score means something else

If the vision model cannot load, the backend still returns a `coherence` between 0 and 1 — but it
is computed from colors alone, with no understanding of symbols, style, or emotion. It is a
different measurement wearing the same name and the same range.

Every result reports `ml_ran`. When it is `false`, the score is not comparable to a real run and
must not drive design tokens. The library enforces this rather than trusting the caller.

---

## The gate

`write_universe` (and the `write_tokens` tool) refuses exactly one thing by default:

- **`ml_ran` is `false`** — a colour-only score, a different quantity under the same name

That is a fact about the pipeline, not a judgment about the images. Everything else is advisory.

**No minimum coherence ships**, because none is validated: all eight boards above scored 0.48–0.53,
so any default would admit or reject them all. The module once defaulted to `0.6`, which rejected
every real moodboard including the pure ones. If you calibrate a threshold on your own boards, pass
`min_coherence` and it will be enforced.

A refused write leaves no file behind. `force=True` overrides once you've read the issues.

Call `blocking_issues(result)` to check without writing, and `advisory_notes(result)` for the
saturation / outlier / regime-cap warnings that never refuse.

---

## How the tokens are derived

| Token | Chosen as |
| --- | --- |
| `color.brand` | the darkest color in the palette |
| `color.surface` | the lightest color |
| `color.accent` | the most saturated of the remaining colors |
| `typography.display` | font chosen from the aesthetic tags |
| `radius.md` | corner radius chosen from the aesthetic tags |

Tag-to-font and tag-to-radius mappings live at the top of `universe.py` and are meant to be edited.

---

## Architecture

```
agent ──MCP──> purity-mcp ──> vis_models.moodboard ──> moodboard-purity backend
              (transport)     (scoring, gate, tokens)   (vision models, in-process)
```

- **`libraries/mcp/purity/`** — this package. MCP transport and folder handling only.
- **`libraries/models/src/vis_models/moodboard/`** — the logic, and the single source of truth:
  - `base.py` — `MoodboardResult`, color helpers
  - `adapter.py` — runs the real backend
  - `mock.py` — deterministic offline stand-in
  - `metrics.py` — reads the backend's output, enforces the payload contract
  - `universe.py` — the gate and the token projection
- **`libraries/ios-ready/raw/moodboard-purity/`** — the vendored analysis backend and its model
  weights. Excluded from git; fetched with `scripts/fetch-moodboard.sh`.

The backend runs in-process. There is no server to start and no port to manage.

`build_moodboard("purity")` returns the real backend when it can genuinely run, and the
deterministic mock otherwise. It never quietly downgrades to a color-only score.

---

## Setup details

`scripts/fetch-moodboard.sh` downloads the backend source plus model weights into
`libraries/ios-ready/raw/moodboard-purity/`. Both are excluded from git — **no model ever enters the
repository.** The script is safe to re-run; it skips work already done, and finishes by reporting
whether real scoring is actually enabled.

| Flag | Effect |
| --- | --- |
| *(none)* | backend source + the image model (SigLIP2, ~1.5GB) |
| `--captions` | also the caption model (SmolVLM2, ~2.6GB) — richer aesthetic tags |
| `--repo-only` | source only, no weights |

Two dependency requirements are strict:

- **`transformers` must be `4.57.1`.** On 5.x the model's text encoder fails with
  `'BaseModelOutputWithPooling' object has no attribute 'norm'`, and tag fusion degrades silently.
- **`sentencepiece` is required.** Without it the tokenizer raises, the backend catches the error,
  and every run falls back to color-only scoring while the weights sit on disk looking installed.

`is_available()` checks both, so it cannot report readiness it doesn't have.

---

## Environment variables

| Variable | Effect |
| --- | --- |
| `MOODBOARD_ENABLE_ML=0` | force color-only scoring; `is_available()` becomes `False` |
| `MOODBOARD_CAPTION_BACKEND=fast` | use SmolVLM2 for captions (recommended) |
| `MOODBOARD_ENABLE_OWLV2=0` | skip object detection; faster |
| `HF_HOME` | override where model weights are read from |

---

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `build_moodboard("purity")` returns the mock | backend can't run | run `scripts/fetch-moodboard.sh` and read its report |
| `ml_ran: false` with weights installed | a dependency is missing | install `sentencepiece`; pin `transformers==4.57.1` |
| `refusing to write the universe` | heuristic-fallback score, or below your `min_coherence` | read `issues`; fix the install, or pass `force=True` |
| `MalformedAnalysis` | backend output changed shape | the error names the missing field |
| `no images` | wrong folder, or images in subfolders | a moodboard is one flat folder |

The library raises `MalformedAnalysis` rather than substituting `0.0` for a missing value, because
a zeroed score reads as a confident, plausible, and wrong result.

---

## Tests

```bash
cd libraries/mcp/purity && python -m pytest -q     # transport, folder handling
cd libraries/models     && python -m pytest -q     # scoring, gate, token projection
```

Both suites run offline with no models installed. The output contract is tested against a real
captured backend response (`libraries/models/tests/fixtures/analyze_heuristic.json`). Tests that
require the backend or its weights skip automatically when those are absent.

---

## Calibration

The quality thresholds were validated, not guessed. Eight moodboards were assembled from
public-domain artwork with a known intent (four coherent, two deliberate hybrids, two incoherent)
and scored through the real backend. Two constants did not survive:

- A `verdict` label derived from `aestheticRegimeCount` — removed. No metric separated the label
  groups; a deliberately incoherent board outscored a genuinely coherent one.
- A `0.6` minimum coherence — removed as a default. Every board, including the coherent ones,
  scored 0.48–0.53, so the gate rejected them all.

What survives is the one check with a mechanism behind it rather than a threshold: a score the
vision model did not produce cannot drive design tokens.

To recalibrate against your own boards, score them, put the numbers beside the images, and set
`min_coherence` only if a cut-off genuinely separates the ones you accept from the ones you don't.
