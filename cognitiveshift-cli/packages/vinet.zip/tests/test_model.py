"""Offline tests for the ViNet block — mock-backed, no torch/weights (green in CI)."""

import json
from pathlib import Path

from blocks.vinet.src import build
from blocks.vinet.src.metrics import analyze_clip
from blocks.vinet.src.mock import MockViNet
from vis_models.saliency import Region, focal_point

BLOCK = Path(__file__).resolve().parents[1]
CTA = Region(0.30, 0.72, 0.40, 0.16)     # a primary button, lower-centre


def test_offline_build_is_the_mock():
    # offline always forces the deterministic mock (env-independent — a box with weights would
    # otherwise return the real model).
    assert isinstance(build(offline=True), MockViNet)


def test_predict_returns_one_map_per_frame():
    m = build(offline=True)
    assert len(m.predict(8)) == 8                                  # int -> N frames
    assert len(m.predict(["a.png", "b.png", "c.png"])) == 3        # list -> len frames


def test_deterministic():
    m = build(offline=True)
    a = m.predict(6)
    b = m.predict(6)
    assert [x.values for x in a] == [x.values for x in b]


def test_attention_sweeps_downward_over_the_clip():
    maps = build(offline=True).predict(10)
    first_y = focal_point(maps[0])[1]
    last_y = focal_point(maps[-1])[1]
    assert last_y > first_y + 0.2          # hot-spot moves toward the lower-centre (the CTA)


def test_clip_metrics_settle_on_a_bottom_cta():
    maps = build(offline=True).predict(12)
    rep = analyze_clip(maps, CTA)
    assert rep["frames"] == 12
    assert rep["settles_on_cta"] is True                          # last frame peaks on the CTA
    assert rep["final_primary_attention"] >= rep["per_frame_attention"][0]  # grows over the clip


def test_clip_metrics_without_cta_are_safe():
    rep = analyze_clip(build(offline=True).predict(5))
    assert rep["frames"] == 5 and rep["settles_on_cta"] is True
    assert rep["mean_primary_attention"] is None


def test_manifest_has_required_fields():
    man = json.loads((BLOCK / "block.json").read_text(encoding="utf-8"))
    for key in ("name", "version", "task", "status", "adapter", "mock", "apple_native", "weights"):
        assert key in man
    assert man["status"] in ("raw", "ready")
    assert man["adapter"].startswith("blocks.vinet.") and man["mock"].startswith("blocks.vinet.")


def test_required_files_exist():
    for rel in ("block.json", "README.md", "src/__init__.py", "src/model.py", "src/mock.py"):
        assert (BLOCK / rel).exists(), f"missing {rel}"
