"""ViNet block factory. `build(offline=False)` returns the real adapter when torch + a checkpoint
are on the box, else the deterministic mock — the same seam as vis_models.build_saliency."""

from __future__ import annotations

from blocks.vinet.src.mock import MockViNet
from blocks.vinet.src.model import ViNetModel


def build(offline: bool = False, **kwargs):
    if not offline:
        model = ViNetModel(**{k: v for k, v in kwargs.items()
                              if k in {"code_dir", "weights", "device", "grid", "clip_size"}})
        if model.is_available():
            return model
    return MockViNet(**{k: v for k, v in kwargs.items()
                        if k in {"grid", "sigma", "baseline"}})


__all__ = ["build", "ViNetModel", "MockViNet"]
