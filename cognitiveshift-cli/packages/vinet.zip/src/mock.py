"""Deterministic offline stand-in for ViNet — no torch, no weights, runs in CI.

Emits one SaliencyMap per frame with a single attention hot-spot that sweeps from the upper area
toward the lower-centre across the clip (a plausible "eye settles on the primary action" arc), so
downstream clip metrics and tests exercise real per-frame shapes without the video model.
Same role as vis_models.saliency.MockSaliencyModel, but for a sequence of frames.
"""

from __future__ import annotations

from pathlib import Path

from vis_models.saliency.base import PathLike, SaliencyMap
from vis_models.saliency.grid import gaussian_map

_FRAME_EXTS = {".jpg", ".jpeg", ".png"}


class MockViNet:
    def __init__(self, *, grid: int = 40, sigma: float = 0.16, baseline: float = 0.02) -> None:
        self.grid = grid
        self.sigma = sigma
        self.baseline = baseline

    def is_available(self) -> bool:
        return True

    def _n_frames(self, clip: PathLike | list | int) -> int:
        if isinstance(clip, int):
            return max(1, clip)
        if isinstance(clip, (list, tuple)):
            return max(1, len(clip))
        p = Path(clip)
        if p.is_dir():
            return max(1, sum(1 for x in p.iterdir() if x.suffix.lower() in _FRAME_EXTS))
        return 16                                   # a plausible default clip length

    def predict(self, clip: PathLike | list | int) -> list[SaliencyMap]:
        n = self._n_frames(clip)
        maps = []
        for i in range(n):
            t = i / (n - 1) if n > 1 else 1.0        # 0 at first frame, 1 at last
            hx, hy = 0.5, 0.32 + 0.46 * t            # hot-spot sweeps top -> lower-centre
            maps.append(gaussian_map(self.grid, [(hx, hy)], sigma=self.sigma, baseline=self.baseline))
        return maps
