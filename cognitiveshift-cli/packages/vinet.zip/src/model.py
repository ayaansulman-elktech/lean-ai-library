"""Real ViNet adapter — video saliency via ViNet-S (ViNet++, github.com/ViNet-Saliency/vinet_v2).

The original ViNet's pretrained weights are no longer published (the authors' link is dead), so
this block targets its maintained successor **ViNet-S** — same task (per-frame video saliency),
a U-Net decoder over an S3D backbone, ~36MB, and CPU-runnable (no CUDA/Mamba).

Runs in iOS Ready, or any host with torch + the `vinet_v2` repo and a `vinet_s*.pt` checkpoint
fetched under `ios-ready/raw/`. Imports are lazy so importing this module never pulls in torch;
`is_available()` gates the fallback to the mock. Preprocessing matches the repo: each frame is
resized to 224x384 and ImageNet-normalized; the model consumes a `clip_size` (32) frame window
per forward and emits one saliency map, so per-frame maps come from sliding the window.
"""

from __future__ import annotations

from pathlib import Path

from vis_models.saliency.base import PathLike, SaliencyMap
from vis_models.saliency.grid import downsample_to_grid

# libraries/models/blocks/vinet/src/model.py -> parents[4] == libraries
_RAW = Path(__file__).resolve().parents[4] / "ios-ready" / "raw"
_FRAME_EXTS = {".jpg", ".jpeg", ".png"}
_MEAN = (0.485, 0.456, 0.406)
_STD = (0.229, 0.224, 0.225)
_CLIP_SIZE = 32


def _frame_paths(clip: PathLike | list) -> list[str]:
    if isinstance(clip, (list, tuple)):
        return [str(p) for p in clip]
    p = Path(clip)
    if p.is_dir():
        return sorted(str(x) for x in p.iterdir() if x.suffix.lower() in _FRAME_EXTS)
    raise ValueError("clip must be a frames directory or a list of frame paths")


def _frame_chw(path: str):
    """Load one frame -> (C, 224, 384) float array, matching the repo's transform."""
    import numpy as np
    from PIL import Image

    im = Image.open(path).convert("RGB").resize((384, 224), Image.BILINEAR)   # (W, H)
    arr = (np.asarray(im, "float32") / 255.0 - _MEAN) / _STD
    return arr.transpose(2, 0, 1)


class ViNetModel:
    def __init__(self, *, code_dir: PathLike | None = None, weights: PathLike | None = None,
                 device: str = "cpu", grid: int = 48, clip_size: int = _CLIP_SIZE) -> None:
        self.code_dir = Path(code_dir) if code_dir else None
        self.weights = Path(weights) if weights else None
        self.device = device
        self.grid = grid
        self.clip_size = clip_size
        self._net = None

    # --- discovery / availability --------------------------------------------------------
    def _find_code(self) -> Path | None:
        if self.code_dir and (self.code_dir / "ViNet_S_model.py").exists():
            return self.code_dir
        hit = next(_RAW.glob("**/ViNet_S_model.py"), None)
        return hit.parent if hit else None

    def _find_weights(self) -> Path | None:
        if self.weights and self.weights.exists():
            return self.weights
        for pat in ("ViNet/**/vinet_s*.pt", "**/vinet_s*.pt"):
            hit = next(_RAW.glob(pat), None)
            if hit:
                return hit
        return None

    def is_available(self) -> bool:
        """True only if torch is importable AND the ViNet-S code + a checkpoint are present."""
        try:
            import torch  # noqa: F401
        except Exception:
            return False
        return self._find_code() is not None and self._find_weights() is not None

    def _load(self):
        if self._net is not None:
            return self._net
        import sys

        import torch
        code, wt = self._find_code(), self._find_weights()
        if code is None or wt is None:
            raise RuntimeError(
                f"ViNet-S not available: need torch + the vinet_v2 repo (ViNet_S_model.py) and a "
                f"vinet_s*.pt checkpoint under {_RAW}. Use build(offline=True) for the mock."
            )
        sys.path.insert(0, str(code))
        from ViNet_S_model import VideoSaliencyModel  # vinet_v2/ViNet_S
        net = VideoSaliencyModel(num_clips=self.clip_size)
        net.load_state_dict(torch.load(str(wt), map_location=self.device))
        net.to(self.device).eval()
        self._net = net
        return net

    def predict(self, clip: PathLike | list) -> list[SaliencyMap]:
        """Run ViNet-S over a clip -> one downsampled SaliencyMap per frame.

        ViNet-S emits one map per `clip_size`-frame window, so the window slides across the clip
        (front frames left-padded with the first frame). Each output map is downsampled to the grid.
        Heavy: one forward per frame — fine on the farm / for short clips.
        """
        import numpy as np
        import torch

        net = self._load()
        frames = _frame_paths(clip)
        if not frames:
            return []
        chw = [_frame_chw(p) for p in frames]
        maps: list[SaliencyMap] = []
        with torch.no_grad():
            for i in range(len(chw)):
                window = [chw[max(0, j)] for j in range(i - self.clip_size + 1, i + 1)]
                arr = np.stack(window, 0)                          # (T, C, H, W)
                t = torch.from_numpy(arr[None].astype("float32")).permute(0, 2, 1, 3, 4)
                out = net(t.to(self.device))                      # (1, H, W)
                sal = np.clip(np.asarray(out.squeeze().cpu(), dtype=float), 0, None)
                maps.append(downsample_to_grid(sal, self.grid))
        return maps
