"""Clip-level saliency metrics — the answer a video wants: does attention END on the primary
action, and how strongly across the clip? Builds on the per-frame `vis_models.saliency.analyze`.

Pure Python, dependency-free (operates on the SaliencyMap grids), so it runs in CI.
"""

from __future__ import annotations

from vis_models.saliency import DEFAULT_CTA_THRESHOLD, Region, analyze


def analyze_clip(maps: list, cta_region: Region | None = None, *,
                 threshold: float = DEFAULT_CTA_THRESHOLD) -> dict:
    """Aggregate per-frame attention over a clip.

    Returns frames, the per-frame CTA attention series, the mean and final attention, the peak
    frame, and `settles_on_cta` — whether the *last* frame's attention peaks on the CTA (the key
    question for an onboarding clip that should lead the eye to the primary action).
    """
    reports = [analyze(m, cta_region, threshold=threshold) for m in maps]
    n = len(reports)
    if n == 0:
        return {"frames": 0, "settles_on_cta": False, "mean_primary_attention": None,
                "final_primary_attention": None, "peak_frame": None, "per_frame_attention": []}

    series = [r.primary_attention for r in reports]     # None if no CTA region supplied
    mean_attn = final_attn = peak_frame = None
    if cta_region is not None:
        vals = [a or 0.0 for a in series]
        mean_attn = round(sum(vals) / n, 4)
        final_attn = series[-1]
        peak_frame = max(range(n), key=lambda i: vals[i])

    return {
        "frames": n,
        "settles_on_cta": bool(reports[-1].passes) if cta_region is not None else True,
        "mean_primary_attention": mean_attn,
        "final_primary_attention": final_attn,
        "peak_frame": peak_frame,
        "per_frame_attention": series,
    }
