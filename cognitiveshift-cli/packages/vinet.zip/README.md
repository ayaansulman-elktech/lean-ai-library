# vinet (model card)

Video saliency — per-frame human-attention heatmaps for a clip. Targets **ViNet-S**
([ViNet++ / vinet_v2](https://github.com/ViNet-Saliency/vinet_v2), U-Net decoder over an S3D
backbone).

> **Why ViNet-S, not the original ViNet:** the original ViNet's pretrained weights are no longer
> published (dead link). ViNet-S is its maintained successor — same task, ~36MB, CPU-runnable.

- **Task:** predict where viewers look across the frames of a video (e.g. an onboarding clip).
- **Inputs:** a clip — a folder of frames, or a list of frame paths. ViNet-S uses a 32-frame
  window per forward; the adapter slides it to yield one map per frame.
- **Outputs:** one `vis_models` `SaliencyMap` per frame; `metrics.analyze_clip` reduces the
  sequence to "does attention settle on the primary action by the end?".
- **Status:** `raw` — Python adapter + offline mock. Real `.pt` weights run in iOS Ready
  (`ios-ready/raw/ViNet`); CI uses the deterministic mock.
- **Apple-native:** none — Apple exposes no video attention/saliency-prediction API.

## Use
```python
from blocks.vinet.src import build
from blocks.vinet.src.metrics import analyze_clip
from vis_models.saliency import Region

model = build()                              # real ViNet-S when torch + weights are on the box
maps  = model.predict("clip/frames")         # list[SaliencyMap], one per frame
analyze_clip(maps, Region(0.30, 0.72, 0.40, 0.16))   # -> settles_on_cta, mean/final attention, …
```

## Running the real model (iOS Ready / any torch box)
Fetch the `vinet_v2` repo and a ViNet-S checkpoint (`vinet_s_dhf1k.pt`, from the repo's Google
Drive bundle) under `ios-ready/raw/` — the adapter auto-discovers `ViNet_S_model.py` and a
`vinet_s*.pt` weight. Then `build()` returns the real `ViNetModel` (`is_available()` gates the
fallback). Preprocessing (224×384 + ImageNet norm, 32-frame clip) matches the repo; verified
running on CPU.
