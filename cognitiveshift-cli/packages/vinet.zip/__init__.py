"""ViNet block — video saliency (per-frame attention for a clip). See ../README.md."""
