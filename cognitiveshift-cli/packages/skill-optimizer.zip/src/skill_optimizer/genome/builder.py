"""Build GenomeConfig instances from the genomes config and render them to a generation plan.

`default_genome` gives the full-featured baseline (every gene on, default params). `sample_genome`
draws a point from the search space using a `suggest` callable — a thin shim so the same code
serves both a plain RNG (now) and an Optuna trial (M3) without depending on Optuna here.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from skill_optimizer.config.models import GenomesConfig
from skill_optimizer.genome.sections import (
    COMPRESSION_DIRECTIVE,
    CONTENT_DIRECTIVES,
    SECTION_BRIEFS,
)
from skill_optimizer.types import GenomeConfig

# suggest(name, choices) -> chosen value. Optuna's trial.suggest_categorical fits this shape.
Suggest = Callable[[str, list[Any]], Any]


def _ordered_genes(cfg: GenomesConfig, enabled: set[str]) -> list[str]:
    return sorted(enabled, key=lambda g: cfg.genes[g].order)


def default_genome(cfg: GenomesConfig) -> GenomeConfig:
    """Baseline: include every gene, first value for each param, no compression."""
    sections: dict[str, dict[str, Any]] = {}
    for name, gene in cfg.genes.items():
        params = {k: choices[0] for k, choices in gene.params.items() if choices}
        sections[name] = params
    order = _ordered_genes(cfg, set(sections))
    content = {k: choices[0] for k, choices in cfg.content.items() if choices}
    runtime_choices = cfg.models.get("runtime") or []
    runtime_model = runtime_choices[0] if runtime_choices else ""
    return GenomeConfig(sections=sections, order=order, compression="none",
                        content=content, runtime_model=runtime_model)


def sample_genome(cfg: GenomesConfig, suggest: Suggest) -> GenomeConfig:
    """Draw a genome from the search space. Non-toggleable genes are always included."""
    sections: dict[str, dict[str, Any]] = {}
    for name, gene in cfg.genes.items():
        if gene.toggle and not suggest(f"gene.{name}.enabled", [True, False]):
            continue
        params: dict[str, Any] = {}
        for pname, choices in gene.params.items():
            if choices:
                params[pname] = suggest(f"gene.{name}.{pname}", choices)
        sections[name] = params

    compression = "none"
    if cfg.global_.compression.search_space:
        compression = suggest("global.compression", cfg.global_.compression.search_space)

    order = _ordered_genes(cfg, set(sections))
    if cfg.global_.ordering == "search":
        # A permutation search is large; M3 can refine this. For now keep declared order.
        pass
    content: dict[str, Any] = {}
    for cname, choices in cfg.content.items():
        if choices:
            content[cname] = suggest(f"content.{cname}", choices)
    runtime_choices = cfg.models.get("runtime") or []
    runtime_model = suggest("models.runtime", runtime_choices) if runtime_choices else ""
    return GenomeConfig(sections=sections, order=order, compression=compression,
                        content=content, runtime_model=runtime_model)


def genome_to_plan(genome: GenomeConfig) -> str:
    """Render a genome into the structural brief handed to the generator LLM."""
    lines: list[str] = [COMPRESSION_DIRECTIVE.get(genome.compression, ""), ""]
    lines.append("Produce a SKILL.md with exactly these sections, in this order:")
    for i, gene in enumerate(genome.order, 1):
        title, desc = SECTION_BRIEFS.get(gene, (gene, ""))
        params = genome.sections.get(gene, {})
        suffix = ""
        if gene == "examples":
            count = params.get("count", 0)
            polarity = params.get("polarity", "good_only")
            suffix = f" (include {count} example(s), polarity={polarity})"
        elif gene == "constraints":
            suffix = f" (intensity={params.get('intensity', 'medium')})"
        lines.append(f"{i}. {title} — {desc}{suffix}")

    directives = [
        f"- {CONTENT_DIRECTIVES[gene][value]}"
        for gene, value in genome.content.items()
        if gene in CONTENT_DIRECTIVES and value in CONTENT_DIRECTIVES[gene]
    ]
    if directives:
        lines.append("")
        lines.append("Writing style (apply throughout):")
        lines.extend(directives)
    return "\n".join(lines).strip()
