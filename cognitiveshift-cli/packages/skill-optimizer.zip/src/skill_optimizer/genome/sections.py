"""Human-readable briefs for each gene/section, fed to the generator LLM.

Keys must match gene names in skill-genomes.yaml. The brief tells the generator what the
section is for; the generator writes the actual content from the D_wm examples.
"""

from __future__ import annotations

SECTION_BRIEFS: dict[str, tuple[str, str]] = {
    "metadata": ("Metadata", "YAML frontmatter: name, description, trigger/invocation."),
    "mission": ("Mission", "One-paragraph statement of what this Skill makes the model do."),
    "scope": ("Scope", "What is in and explicitly out of scope for this Skill."),
    "trigger_conditions": ("Trigger Conditions", "When this Skill should activate."),
    "inputs": ("Inputs", "What the Skill expects as input and in what form."),
    "outputs": ("Outputs", "What the Skill must produce, with format/shape."),
    "general_description": ("General Project Description", "Overview of the target artifact."),
    "architecture_overview": ("Project Architecture Overview", "File/structure layout produced."),
    "prerequisites": ("Prerequisites", "One-time setup or assets required before running."),
    "step_by_step": ("Step-by-Step Process", "The ordered procedure to produce the output."),
    "decision_rules": ("Decision Rules", "If/then rules resolving choices during the task."),
    "best_practices": ("Best Practices", "Heuristics that raise output quality."),
    "constraints": ("Constraints", "Hard rules the output must respect."),
    "templates_components": ("Templates & Components", "Reusable snippets/skeletons."),
    "examples": ("Examples", "Worked examples (and counter-examples) of good output."),
    "edge_cases": ("Edge Cases", "Unusual inputs and how to handle them."),
    "validation_rules": ("Validation Rules", "Checks the output must pass."),
    "quality_criteria": ("Quality Criteria", "What 'good' looks like, measurably."),
    "express_checklist": ("Express Checklist", "Fast final pass/fail checklist."),
    "troubleshooting": ("Troubleshooting", "Common failures and fixes."),
    "settings_pitfalls": ("Useful Settings & Pitfalls", "Tunables and known traps."),
    "references": ("References", "Links/sources the Skill relies on."),
}

# Content-level gene value -> writing directive injected into the generator prompt.
# These shape WHAT the Skill says and HOW, the higher-ceiling optimization lever.
CONTENT_DIRECTIVES: dict[str, dict[object, str]] = {
    "tone": {
        "terse": "Tone: terse and direct — short sentences, no filler.",
        "balanced": "Tone: balanced — clear and readable, not verbose.",
        "detailed": "Tone: thorough — explain fully where it aids correctness.",
    },
    "instruction_style": {
        "high_level": "Instructions: state goals and principles, not micro-steps.",
        "step_by_step": "Instructions: an explicit numbered step-by-step procedure.",
        "checklist": "Instructions: an actionable checklist of concrete checks.",
    },
    "directive_strength": {
        "gentle": "Phrasing: suggestive ('prefer', 'consider', 'when helpful').",
        "firm": "Phrasing: clear directives ('do X', 'use Y').",
        "strict": "Phrasing: strict mandates ('MUST', 'NEVER', 'always').",
    },
    "include_rationale": {
        True: "Include a brief rationale for each key rule (why it matters).",
        False: "Omit rationale — give instructions only, no justification.",
    },
    "example_detail": {
        "minimal": "Examples: minimal — one short illustrative snippet at most.",
        "full": "Examples: complete and detailed, showing the full desired output shape.",
    },
}

# Compression level -> instruction injected into the generator prompt.
COMPRESSION_DIRECTIVE: dict[str, str] = {
    "none": "Write each section in full prose.",
    "light": "Be concise: prefer bullet points and short sentences.",
    "aggressive": "Maximize information density: terse bullets, no filler, minimal tokens.",
}
