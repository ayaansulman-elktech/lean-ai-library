"""The optimization loop: sample a genome -> generate -> run -> evaluate -> tell -> log.

Drives the sampler with ask/tell, honors every stopping criterion (goal reached, max trials,
patience, hard budget cap), and logs each trial to MLflow with its trial index for lineage.
Optimizes the Skill structure only; outputs are evidence, never optimized directly (charter).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from skill_optimizer.config.models import GoalSpec
from skill_optimizer.genome.builder import sample_genome
from skill_optimizer.optimization.agent import ImprovementAgent
from skill_optimizer.optimization.sampler import Sampler
from skill_optimizer.runner.runner import _DEFAULT_TASK, SkillRunner
from skill_optimizer.tracking.mlflow_tracker import NullTracker, Tracker
from skill_optimizer.types import Candidate, Output, Scores

_MAX_CONSECUTIVE_FAILURES = 3  # abort the study if a provider is consistently failing
_PLAYOFF_K = 3  # re-rank this many top candidates across all dev briefs to pick the winner

if TYPE_CHECKING:
    from skill_optimizer.datasets.loader import Dataset
    from skill_optimizer.pipeline import Context

TrackerFactory = Callable[[str], Tracker]


@dataclass
class TrialResult:
    trial: int
    skill_score: float
    flagged: bool
    candidate: Candidate
    scores: Scores


@dataclass
class OptimizeResult:
    best: TrialResult | None
    history: list[TrialResult] = field(default_factory=list)
    cost_summary: dict[str, float] = field(default_factory=dict)
    reason: str = ""
    model_breakdown: dict[str, dict[str, float]] = field(default_factory=dict)

    @property
    def n_trials(self) -> int:
        return len(self.history)


class Optimizer:
    def __init__(self, ctx: Context, goal: GoalSpec, sampler: Sampler,
                 agent: ImprovementAgent | None = None,
                 tracker_factory: TrackerFactory | None = None,
                 dev_tasks: list[str] | None = None) -> None:
        self._ctx = ctx
        self._goal = goal
        self._sampler = sampler
        self._agent = agent
        self._tracker_factory = tracker_factory or (lambda _name: NullTracker())
        # Briefs the optimizer trains on. Rotating real D_dev briefs (vs one fixed generic
        # task) aligns the training distribution with held-out validation. Falls back to the
        # runner's default task if no D_dev is provided.
        self._dev_tasks = dev_tasks or [_DEFAULT_TASK]

    def run(self, d_wm: Dataset, artifacts_dir: str | None = None) -> OptimizeResult:
        best: TrialResult | None = None
        history: list[TrialResult] = []
        no_improve = 0
        reason = "max_trials"
        consecutive_failures = 0

        for i in range(self._goal.max_trials):
            if self._ctx.meter.over_budget():
                reason = "budget_exhausted"
                break

            # A single API failure (rate limit, credits, transient 5xx) must not crash the
            # whole study. Failed trials are skipped; too many in a row means a provider is
            # down — abort, but keep (and persist) the best found so far.
            cost0, time0 = self._ctx.meter.total_cost_usd, self._ctx.meter.total_time_s
            try:
                suggest = self._sampler.ask()
                genome = sample_genome(self._ctx.cfg.genomes, suggest)
                hint = self._agent.propose(best) if (self._agent and best) else None
                candidate = self._ctx.generator.generate(genome, d_wm, hint=hint)

                task = self._dev_tasks[i % len(self._dev_tasks)]  # rotate dev briefs
                trial_dir = f"{artifacts_dir}/trial_{i:04d}" if artifacts_dir else None
                output, scores = self._evaluate(candidate, trial_dir, task)
                self._sampler.tell(scores.skill_score)
            except Exception as e:  # noqa: BLE001 — one bad trial shouldn't kill the run
                self._sampler.tell(0.0)  # close the Optuna trial so it doesn't dangle
                consecutive_failures += 1
                print(f"[trial {i}] FAILED ({type(e).__name__}): "
                      f"{str(e).splitlines()[0][:120]}", flush=True)
                if consecutive_failures >= _MAX_CONSECUTIVE_FAILURES:
                    reason = "provider_errors"
                    break
                continue
            consecutive_failures = 0

            trial_cost = round(self._ctx.meter.total_cost_usd - cost0, 6)
            trial_time = round(self._ctx.meter.total_time_s - time0, 3)
            with self._tracker_factory(f"trial-{i:04d}") as tracker:
                tracker.log_candidate(candidate, output, scores, extra={
                    "trial": i,
                    "runtime_model": genome.runtime_model,
                    "generator_model": self._ctx.cfg.providers.generator_pool[0],
                    "trial_cost_usd": trial_cost,
                    "trial_time_s": trial_time,
                })

            result = TrialResult(i, scores.skill_score, scores.flagged_for_review,
                                 candidate, scores)
            history.append(result)

            if best is None or scores.skill_score > best.skill_score:
                best, no_improve = result, 0
                self._save_best(best, artifacts_dir)  # persist immediately — never lose it
            else:
                no_improve += 1

            # Per-trial progress to stdout so the terminal is watchable during long runs.
            print(
                f"[trial {i}] score={scores.skill_score} "
                f"quality={scores.output.get('quality')} "
                f"best={best.skill_score} "
                f"spend=${self._ctx.meter.total_cost_usd:.4f}",
                flush=True,
            )

            if scores.skill_score >= self._goal.skill_score_goal:
                reason = "goal_reached"
                break
            if no_improve >= self._goal.patience:
                reason = "patience_exhausted"
                break

        # Top-K playoff: per-trial scores are on a single rotating brief (noisy). Re-rank the
        # best candidates across ALL dev briefs and crown the most generalizable one — this is
        # what gets saved as the winner, reducing single-brief selection luck.
        if (best is not None and len(self._dev_tasks) > 1 and len(history) >= 2
                and not self._ctx.meter.over_budget()):
            best = self._playoff(history, best)
            self._save_best(best, artifacts_dir)
            reason = f"{reason}+playoff"

        by_model = self._ctx.meter.by_model()
        print("[cost/latency by model]", flush=True)
        for alias, s in by_model.items():
            print(f"  {alias:9} ${s['cost_usd']:.4f}  {s['time_s']:.1f}s  "
                  f"{s['calls']} calls", flush=True)

        return OptimizeResult(best=best, history=history,
                              cost_summary=self._ctx.meter.summary(), reason=reason,
                              model_breakdown=by_model)

    def _playoff(self, history: list[TrialResult], current_best: TrialResult) -> TrialResult:
        """Re-evaluate the top-K candidates across every dev brief; winner = best mean score."""
        import statistics

        topk = sorted(history, key=lambda t: t.skill_score, reverse=True)[:_PLAYOFF_K]
        print(f"[playoff] re-ranking top {len(topk)} candidates across "
              f"{len(self._dev_tasks)} dev briefs", flush=True)
        ranked: list[TrialResult] = []
        for tr in topk:
            per_brief: list[float] = []
            for brief in self._dev_tasks:
                if self._ctx.meter.over_budget():
                    break
                output = self._ctx.runner.run(tr.candidate.skill_md, task=brief)
                sc = self._ctx.evaluator.evaluate(tr.candidate.skill_md, output)
                per_brief.append(sc.skill_score)
            avg = round(statistics.mean(per_brief), 4) if per_brief else tr.skill_score
            print(f"[playoff] trial {tr.trial}: mean={avg} over {len(per_brief)} briefs",
                  flush=True)
            ranked.append(TrialResult(tr.trial, avg, tr.flagged, tr.candidate, tr.scores))
        winner = max(ranked, key=lambda t: t.skill_score) if ranked else current_best
        print(f"[playoff] winner: trial {winner.trial} (mean {winner.skill_score})", flush=True)
        return winner

    @staticmethod
    def _save_best(best: TrialResult, artifacts_dir: str | None) -> None:
        if not artifacts_dir:
            return
        d = Path(artifacts_dir)
        d.mkdir(parents=True, exist_ok=True)
        (d / "best_SKILL.md").write_text(best.candidate.skill_md, encoding="utf-8")

    def _evaluate(self, candidate: Candidate, artifacts_dir: str | None,
                  task: str) -> tuple[Output, Scores]:
        evaluator, meter = self._ctx.evaluator, self._ctx.meter
        # The website-generation (runtime) model comes from the genome, so Optuna explores
        # which model produces the best output per cost.
        runtime_model = candidate.genome.runtime_model or self._ctx.cfg.providers.generator_pool[0]
        runner = SkillRunner(self._ctx.gateway, runtime_model,
                             self._ctx.cfg.output_metrics.execution)
        output = runner.run(candidate.skill_md, task=task, artifacts_dir=artifacts_dir)
        repeats: list[Output] = []
        stab = self._ctx.cfg.output_metrics.metrics.get("stability")
        if stab and stab.enabled and not meter.over_budget():
            repeats = [runner.run(candidate.skill_md, task=task)
                       for _ in range(max(0, stab.runs - 1))]
        scores = evaluator.evaluate(candidate.skill_md, output, repeats)
        return output, scores
