"""DSPy-library GEPA integration (option b) — the proven reflective prompt optimizer.

Maps our problem onto DSPy: the Skill is the *instruction* of a Predict module that turns a
task brief into website HTML; DSPy's GEPA evolves that instruction using our render + vision
judge as the feedback metric. The evolved instruction is the optimized Skill.

Note: DSPy drives its own LLM calls via litellm, so the student/reflection calls bypass our
CostMeter — only the judge calls (our gateway) are metered here. This is the standard, proven
GEPA implementation, complementary to our in-harness reflective optimizer (optimization/
reflective.py), which is fully metered and offline-testable.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from skill_optimizer.runner.runner import render_to_screenshot
from skill_optimizer.types import Output

if TYPE_CHECKING:
    from skill_optimizer.pipeline import Context

_SEED_INSTRUCTION = (
    "Build a polished, self-contained, Apple-style scroll-driven hero page for the given "
    "brief. Output a SINGLE self-contained HTML document: all CSS and JS inline, NO external "
    "assets (no external images, fonts, or video). Include a bold, well-typeset headline, "
    "strong visual design (deliberate typography, colour, spacing, layout), and a canvas or "
    "CSS scroll-driven animation that indicates motion. Output only the HTML."
)


def _hero_signature() -> Any:
    import dspy

    class HeroSignature(dspy.Signature):
        __doc__ = _SEED_INSTRUCTION
        brief: str = dspy.InputField(desc="One-line description of the site to build")
        html: str = dspy.OutputField(desc="A single self-contained HTML document")

    return HeroSignature


def make_metric(ctx: Context) -> Callable[..., Any]:
    """GEPA feedback metric: render the candidate HTML, judge it (vision), return score+feedback.

    Returns a dspy.Prediction(score in 0..1, feedback=judge rationale) — GEPA reflects on the
    feedback to rewrite the instruction (the Skill).
    """
    import dspy

    from skill_optimizer.evaluation.judge import JudgePanel

    vision = {a for a, s in ctx.cfg.providers.models.items() if s.vision}
    panel = JudgePanel(ctx.gateway, ctx.cfg.objective.judge_panel, ctx.cfg.output_metrics, vision)

    def metric(gold: Any, pred: Any, trace: Any = None,
               pred_name: Any = None, pred_trace: Any = None) -> Any:
        html = (getattr(pred, "html", "") or "").strip()
        if "<" not in html:
            return dspy.Prediction(score=0.0, feedback="No HTML produced.")
        png = render_to_screenshot(html, ctx.cfg.output_metrics.execution.timeout_s)
        output = Output(artifacts={"index.html": html}, render_path=png, failed=False)
        judged = panel.score(skill_md=getattr(gold, "brief", ""), output=output)
        score = float(judged["quality"]) / 10.0
        feedback = str(judged.get("feedback", "")) or f"quality {judged['quality']}/10"
        return dspy.Prediction(score=score, feedback=feedback)

    return metric


def _model_id(ctx: Context, alias: str) -> str:
    spec = ctx.cfg.providers.models[alias]
    return f"{spec.provider}/{spec.model}"


def run_dspy_gepa(ctx: Context, dev_briefs: list[str], *, budget: int = 40,
                  model_alias: str | None = None,
                  reflection_alias: str | None = None) -> tuple[str, Any]:
    """Run DSPy GEPA. Returns (optimized_instruction = the Skill, optimized_program)."""
    import dspy
    import litellm

    litellm.drop_params = True  # so Opus/GPT-5 don't 400 on temperature etc.

    gen_alias = model_alias or ctx.cfg.providers.generator_pool[0]
    refl_alias = reflection_alias or ctx.cfg.providers.judge_pool[0]
    dspy.configure(lm=dspy.LM(model=_model_id(ctx, gen_alias), cache=False, max_tokens=8000))

    student = dspy.Predict(_hero_signature())
    trainset = [dspy.Example(brief=b).with_inputs("brief") for b in dev_briefs]

    gepa = dspy.GEPA(
        metric=make_metric(ctx),
        reflection_lm=dspy.LM(model=_model_id(ctx, refl_alias), temperature=1.0,
                              max_tokens=8000, cache=False),
        max_metric_calls=budget,
        track_stats=True,
        seed=0,
    )
    optimized = gepa.compile(student, trainset=trainset, valset=trainset)

    instruction = _extract_instruction(optimized)
    return instruction, optimized


def _extract_instruction(program: Any) -> str:
    """Pull the evolved instruction (the optimized Skill) out of the GEPA-optimized program."""
    sig = getattr(program, "signature", None)
    if sig is not None and getattr(sig, "instructions", None):
        return str(sig.instructions)
    try:
        preds = program.predictors()
        if preds and getattr(preds[0].signature, "instructions", None):
            return str(preds[0].signature.instructions)
    except Exception:  # noqa: BLE001
        pass
    return _SEED_INSTRUCTION
