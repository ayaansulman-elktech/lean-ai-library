"""Reflective Skill optimizer (GEPA-style: arxiv 2507.19457).

Instead of sampling discrete genome values (Optuna), this optimizer *rewrites the Skill text*
by reflecting on the judge's natural-language feedback — the approach GEPA shows beats MIPROv2
(>10%) and RL. Each round: take the best Skill so far, find the dev brief it does worst on,
feed (Skill + that brief's output + the judge's rationale) to a reflection model, get a
targeted rewrite, evaluate it across ALL dev briefs, and keep it if its cross-brief mean
improves. Integrates with our render+vision judge, MLflow, cost meter, and resilience.

This is the GEPA *method* implemented against our pipeline (so it uses our screenshot+vision
judge and dev briefs and is offline-testable). The DSPy library's GEPA is the alternative
realization; the reflective loop here is the same idea.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from skill_optimizer.genome.builder import default_genome
from skill_optimizer.optimization.optimizer import (
    _MAX_CONSECUTIVE_FAILURES,
    OptimizeResult,
    TrackerFactory,
    TrialResult,
)
from skill_optimizer.tracking.mlflow_tracker import NullTracker, read_trial
from skill_optimizer.types import Candidate, Output, Scores

if TYPE_CHECKING:
    from skill_optimizer.config.models import GoalSpec
    from skill_optimizer.datasets.loader import Dataset
    from skill_optimizer.pipeline import Context

_REFLECT_SYSTEM = (
    "You are a Skill optimization engineer. You are given a SKILL.md, a task it was run on, "
    "the output it produced, and a judge's critique of that output against a fixed objective. "
    "Rewrite the SKILL.md so the next output scores higher against the objective. Keep it a "
    "valid Agent Skill: YAML frontmatter with `name` (lowercase/hyphens, no 'claude'/"
    "'anthropic') and a `description` that says what it does AND when to use it; a concise, "
    "high-density body (well under 5k tokens). Address the critique directly. Output ONLY the "
    "rewritten SKILL.md."
)


@dataclass
class _Candidate:
    skill_md: str
    mean: float
    cases: list[_CaseEval] = field(default_factory=list)


@dataclass
class _CaseEval:
    brief: str
    output: Output
    score: float
    quality: float
    feedback: str


class ReflectiveOptimizer:
    def __init__(self, ctx: Context, goal: GoalSpec, dev_tasks: list[str],
                 tracker_factory: TrackerFactory | None = None,
                 frontier_size: int = 5) -> None:
        self._ctx = ctx
        self._goal = goal
        self._dev_tasks = dev_tasks or [""]
        self._tracker_factory = tracker_factory or (lambda _name: NullTracker())
        self._reflect_model = ctx.cfg.providers.judge_pool[0]  # strong model reflects
        self._frontier_size = frontier_size

    # --- evaluation across the dev-brief distribution -------------------------------------
    def _eval_on_briefs(self, skill_md: str) -> _Candidate:
        cases: list[_CaseEval] = []
        for brief in self._dev_tasks:
            if self._ctx.meter.over_budget():
                break
            output = self._ctx.runner.run(skill_md, task=brief)
            scores = self._ctx.evaluator.evaluate(skill_md, output)
            cases.append(_CaseEval(
                brief=brief, output=output, score=scores.skill_score,
                quality=scores.output.get("quality", 0.0), feedback=scores.feedback,
            ))
        mean = round(statistics.mean(c.score for c in cases), 4) if cases else 0.0
        return _Candidate(skill_md=skill_md, mean=mean, cases=cases)

    def _reflect(self, cand: _Candidate) -> str:
        """Ask the reflection model to rewrite the Skill, targeting its weakest brief."""
        worst = min(cand.cases, key=lambda c: c.score)
        objective = self._ctx.cfg.output_metrics.task.objective.strip()
        artifact = worst.output.artifacts.get("index.html", "")[:2000]
        user = (
            f"# OBJECTIVE (fixed bar)\n{objective}\n\n"
            f"# CURRENT SKILL.md\n{cand.skill_md}\n\n"
            f"# TASK BRIEF IT DID WORST ON\n{worst.brief}\n\n"
            f"# OUTPUT IT PRODUCED (truncated)\n{artifact}\n\n"
            f"# JUDGE CRITIQUE (quality {worst.quality}/10)\n{worst.feedback}\n\n"
            "Rewrite the SKILL.md to fix these weaknesses. Output only the SKILL.md."
        )
        resp = self._ctx.gateway.complete(
            self._reflect_model,
            [{"role": "system", "content": _REFLECT_SYSTEM}, {"role": "user", "content": user}],
            temperature=0.7,
        )
        from skill_optimizer.generator.generator import clean_skill_md
        return clean_skill_md(resp.text)

    # --- the reflective loop --------------------------------------------------------------
    def run(self, d_wm: Dataset, artifacts_dir: str | None = None) -> OptimizeResult:
        # Seed with a generated, spec-aligned Skill. Guard it: if the provider is down at the
        # seed step, abort cleanly instead of crashing the whole run.
        try:
            seed = self._ctx.generator.generate(default_genome(self._ctx.cfg.genomes), d_wm)
            best = self._eval_on_briefs(seed.skill_md)
        except Exception as e:  # noqa: BLE001
            print(f"[reflect 0] seed FAILED ({type(e).__name__}): "
                  f"{str(e).splitlines()[0][:140]}", flush=True)
            return OptimizeResult(best=None, history=[], reason="provider_errors+reflect",
                                  cost_summary=self._ctx.meter.summary(),
                                  model_breakdown=self._ctx.meter.by_model())

        # Log the seed, then read its score back from MLflow: that round-tripped value — not the
        # in-memory one — is what drives selection (D -> metrics -> MLflow -> Optimizer).
        scores0, cand0, run_id0 = self._log_trial(0, best, seed.genome)
        best.mean = self._authoritative_mean(run_id0, best.mean, "reflect 0")
        self._write_best(best, artifacts_dir)
        frontier = [best]
        history: list[TrialResult] = [TrialResult(0, best.mean, False, cand0, scores0)]
        print(f"[reflect 0] seed mean={best.mean}", flush=True)

        no_improve, consecutive_failures, reason = 0, 0, "max_trials"
        for i in range(1, self._goal.max_trials):
            if self._ctx.meter.over_budget():
                reason = "budget_exhausted"
                break
            cost0, time0 = self._ctx.meter.total_cost_usd, self._ctx.meter.total_time_s
            try:
                parent = max(frontier, key=lambda c: c.mean)
                proposal_text = self._reflect(parent)
                child = self._eval_on_briefs(proposal_text)
            except Exception as e:  # noqa: BLE001 — a bad round must not kill the run
                consecutive_failures += 1
                print(f"[reflect {i}] FAILED ({type(e).__name__}): "
                      f"{str(e).splitlines()[0][:120]}", flush=True)
                if consecutive_failures >= _MAX_CONSECUTIVE_FAILURES:
                    reason = "provider_errors"
                    break
                continue
            consecutive_failures = 0

            # Log first, then read the score back from MLflow and decide on THAT value.
            scores_i, cand_i, run_id_i = self._log_trial(
                i, child, seed.genome,
                cost=round(self._ctx.meter.total_cost_usd - cost0, 6),
                time=round(self._ctx.meter.total_time_s - time0, 3))
            child.mean = self._authoritative_mean(run_id_i, child.mean, f"reflect {i}")

            improved = child.mean > best.mean
            if improved:
                best, no_improve = child, 0
                self._write_best(child, artifacts_dir)
            else:
                no_improve += 1
            history.append(TrialResult(i, child.mean, False, cand_i, scores_i))
            print(f"[reflect {i}] mean={child.mean} best={best.mean} "
                  f"spend=${self._ctx.meter.total_cost_usd:.4f}", flush=True)

            frontier.append(child)
            frontier = sorted(frontier, key=lambda c: c.mean, reverse=True)[:self._frontier_size]

            if best.mean >= self._goal.skill_score_goal:
                reason = "goal_reached"
                break
            if no_improve >= self._goal.patience:
                reason = "patience_exhausted"
                break

        # Winner = best score on record; persist it.
        best_result = max(history, key=lambda t: t.skill_score)
        self._write_best_text(best_result.candidate.skill_md, artifacts_dir)

        by_model = self._ctx.meter.by_model()
        print("[cost/latency by model]", flush=True)
        for alias, s in by_model.items():
            print(f"  {alias:9} ${s['cost_usd']:.4f}  {s['time_s']:.1f}s  {s['calls']} calls",
                  flush=True)
        return OptimizeResult(best=best_result, history=history,
                              cost_summary=self._ctx.meter.summary(), reason=f"{reason}+reflect",
                              model_breakdown=by_model)

    # --- MLflow as system of record -------------------------------------------------------
    def _log_trial(self, i: int, cand: _Candidate, genome, *,
                   cost: float = 0.0, time: float = 0.0) -> tuple[Scores, Candidate, str | None]:
        """Persist a trial to MLflow; return (scores, candidate, run_id). The run_id is the
        handle the optimizer uses to read the trial back as its selection metric."""
        rep = cand.cases[0].output if cand.cases else Output(failed=True)
        scores = Scores(
            skill_score=cand.mean,
            output={"quality": round(statistics.mean(c.quality for c in cand.cases), 4)
                    if cand.cases else 0.0},
            feedback=" | ".join(c.feedback for c in cand.cases if c.feedback),
        )
        candidate = Candidate(skill_md=cand.skill_md, genome=genome)
        run_id: str | None = None
        with self._tracker_factory(f"reflect-{i:04d}") as tracker:
            run_id = tracker.log_candidate(candidate, rep, scores, extra={
                "round": i, "cross_brief_mean": cand.mean,
                "reflect_cost_usd": cost, "reflect_time_s": time,
            })
        return scores, candidate, run_id

    def _authoritative_mean(self, run_id: str | None, fallback: float, label: str) -> float:
        """The selection metric, read back from MLflow when tracking is on; else the in-memory
        value (offline / track=False). Makes MLflow the loop's source of truth when available."""
        if not run_id:
            return fallback
        rec = read_trial(run_id)
        if rec and rec.get("skill_score") is not None:
            val = round(float(rec["skill_score"]), 4)
            print(f"[{label}] selection metric from MLflow run {run_id[:8]} -> {val}", flush=True)
            return val
        return fallback

    @staticmethod
    def _write_best(cand: _Candidate, artifacts_dir: str | None) -> None:
        ReflectiveOptimizer._write_best_text(cand.skill_md, artifacts_dir)

    @staticmethod
    def _write_best_text(skill_md: str, artifacts_dir: str | None) -> None:
        if not artifacts_dir:
            return
        from pathlib import Path
        d = Path(artifacts_dir)
        d.mkdir(parents=True, exist_ok=True)
        (d / "best_SKILL.md").write_text(skill_md, encoding="utf-8")
