"""Sampler abstraction over the genome search space.

The loop drives the sampler with ask()/tell(): `ask()` returns a `suggest(name, choices)`
callable for one trial (the exact shape `sample_genome` consumes), `tell(score)` feeds the
result back. Two backends:

- RandomSampler: seeded RNG, no dependencies — keeps the whole loop testable offline.
- OptunaSampler: TPE search via Optuna's ask/tell API (lazy import, so Optuna is only needed
  when actually used).
"""

from __future__ import annotations

import random
from typing import Any, Protocol

from skill_optimizer.genome.builder import Suggest


class Sampler(Protocol):
    def ask(self) -> Suggest: ...
    def tell(self, score: float) -> None: ...


class RandomSampler:
    def __init__(self, seed: int = 0) -> None:
        self._rng = random.Random(seed)

    def ask(self) -> Suggest:
        def suggest(name: str, choices: list[Any]) -> Any:
            return self._rng.choice(choices)
        return suggest

    def tell(self, score: float) -> None:
        return None


class OptunaSampler:
    """Wraps an Optuna study via ask/tell so the loop keeps control of stopping criteria."""

    def __init__(self, seed: int = 0) -> None:
        import optuna

        optuna.logging.set_verbosity(optuna.logging.WARNING)
        self._optuna = optuna
        self._study = optuna.create_study(
            direction="maximize", sampler=optuna.samplers.TPESampler(seed=seed)
        )
        self._trial: Any = None

    def ask(self) -> Suggest:
        self._trial = self._study.ask()
        trial = self._trial

        def suggest(name: str, choices: list[Any]) -> Any:
            return trial.suggest_categorical(name, choices)

        return suggest

    def tell(self, score: float) -> None:
        if self._trial is not None:
            self._study.tell(self._trial, score)

    @property
    def best_value(self) -> float | None:
        try:
            return float(self._study.best_value)
        except (ValueError, RuntimeError):
            return None


def build_sampler(kind: str = "optuna", seed: int = 0) -> Sampler:
    if kind == "random":
        return RandomSampler(seed)
    return OptunaSampler(seed)
