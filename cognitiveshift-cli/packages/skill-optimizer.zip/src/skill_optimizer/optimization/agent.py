"""The Agent: reads the best result so far and proposes one concrete structural improvement.

This is the 'agent-assisted Skill mutation' step from the charter. It returns a short hint
the generator injects into the next candidate's prompt. Kept intentionally small and optional;
M3+ can expand it to read full MLflow history and reason over Optuna proposals.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from skill_optimizer.providers.gateway import LLMGateway

if TYPE_CHECKING:
    from skill_optimizer.optimization.optimizer import TrialResult

_SYSTEM = (
    "You are a Skill optimization agent. Given the best Skill so far and its scores, propose "
    "exactly one concrete, structural improvement to raise the Skill Score. One sentence."
)


class ImprovementAgent:
    def __init__(self, gateway: LLMGateway, model_alias: str) -> None:
        self._gw = gateway
        self._model = model_alias

    def propose(self, best: TrialResult) -> str:
        s = best.scores
        prompt = (
            f"Best Skill Score: {s.skill_score}. "
            f"Quality: {s.output.get('quality')}. "
            f"Constraint adherence: {s.output.get('constraint_adherence')}. "
            f"Token complexity: {s.structural.get('token_complexity')}. "
            f"Sections used: {', '.join(best.candidate.genome.order)}.\n"
            "Propose one structural change to the SKILL.md to improve the score."
        )
        resp = self._gw.complete(
            self._model,
            [{"role": "system", "content": _SYSTEM}, {"role": "user", "content": prompt}],
            temperature=0.6, max_tokens=200,
        )
        return resp.text.strip()
