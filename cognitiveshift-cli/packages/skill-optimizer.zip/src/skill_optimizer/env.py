"""Load environment variables from a .env file before any provider call.

Idempotent and dependency-tolerant: if python-dotenv isn't installed (e.g. a minimal offline
setup) this is a no-op, so the mock path never needs it. Existing env vars are NOT overridden,
so a value exported in the shell wins over .env.
"""

from __future__ import annotations

_loaded = False


def load_env() -> None:
    global _loaded
    if _loaded:
        return
    _loaded = True
    try:
        from dotenv import find_dotenv, load_dotenv
    except ImportError:
        return
    path = find_dotenv(usecwd=True)
    if path:
        load_dotenv(path, override=False)
