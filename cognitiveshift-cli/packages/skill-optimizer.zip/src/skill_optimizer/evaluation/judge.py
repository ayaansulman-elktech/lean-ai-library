"""The judge panel — the project's highest-risk component, so it is calibratable by design.

Strategies (from objective.judge_panel.strategy):
- single:           one judge model.
- panel:            all panel_models vote; aggregate (median/mean/majority).
- screen_then_panel: a cheap screen model scores first; the full panel only runs if the
                     screen score clears a threshold (cost control, see strategy note).

Multi-provider panels are the calibration mechanism: spanning Claude/Grok/Deepseek cancels
single-model bias. High disagreement is surfaced (flagged) for human spot-check, never hidden.
"""

from __future__ import annotations

import json
import statistics
from dataclasses import dataclass

from skill_optimizer.config.models import JudgePanelSpec, OutputMetricsConfig
from skill_optimizer.providers.gateway import LLMGateway
from skill_optimizer.types import Output

_RUBRIC = (
    "You are a strict, calibrated judge. Score the OUTPUT against the fixed TASK OBJECTIVE "
    "below — NOT against the Skill's own claims (a vague Skill must not score well just "
    "because it demanded little). Judge only what is actually visible in the OUTPUT.\n\n"
    "Use this EXACT 0-10 quality scale (pick the band the OUTPUT best fits):\n"
    "0-1: blank, broken, or no discernible page.\n"
    "2-3: renders but generic/unstyled; no clear hero section.\n"
    "4-5: a real styled hero with a headline, but weak design or no sign of scroll-driven "
    "motion.\n"
    "6-7: polished hero with strong design AND a visible scroll-driven or canvas/animated "
    "element.\n"
    "8-10: exceptional, Apple-quality hero — refined typography, layout, and clear "
    "scroll-driven motion.\n\n"
    "Return JSON only: "
    '{"quality": <0-10 float per the scale>, "constraint_adherence": <0-1 float>, '
    '"rationale": <one sentence>}. '
    "constraint_adherence = fraction of the TASK OBJECTIVE's requirements visibly met."
)

_SCREEN_PASS = 5.0  # screen quality (0-10) required to escalate to the full panel


@dataclass
class JudgeVote:
    model: str
    quality: float
    constraint_adherence: float
    rationale: str = ""


def _data_uri(png_path: str) -> str:
    import base64

    with open(png_path, "rb") as fh:
        b64 = base64.b64encode(fh.read()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def _parse(text: str, model: str) -> JudgeVote | None:
    try:
        start, end = text.find("{"), text.rfind("}")
        data = json.loads(text[start : end + 1])
        return JudgeVote(
            model=model,
            quality=float(data.get("quality", 0.0)),
            constraint_adherence=float(data.get("constraint_adherence", 0.0)),
            rationale=str(data.get("rationale", "")),
        )
    except (ValueError, KeyError, json.JSONDecodeError):
        return None


class JudgePanel:
    def __init__(self, gateway: LLMGateway, spec: JudgePanelSpec,
                 out_cfg: OutputMetricsConfig, vision_models: set[str] | None = None) -> None:
        self._gw = gateway
        self._spec = spec
        self._out_cfg = out_cfg
        self._vision_models = vision_models or set()

    def _vote(self, model: str, skill_md: str, output: Output) -> JudgeVote | None:
        artifact = output.artifacts.get("index.html", "")
        objective = self._out_cfg.task.objective.strip() or "(no objective configured)"

        # Render mode: a vision judge scores the actual rendered SCREENSHOT; others fall back
        # to the HTML source. This is the real quality signal vs judging raw markup.
        use_image = (
            self._out_cfg.execution.mode == "render_and_screenshot"
            and output.render_path is not None
            and model in self._vision_models
        )
        header = (
            f"# TASK OBJECTIVE (the fixed bar)\n{objective}\n\n"
            f"# SKILL that produced the output (context only — do not score against this)\n"
            f"{skill_md}\n\n"
        )
        if use_image:
            user_content: object = [
                {"type": "text", "text": header
                 + "# OUTPUT — score the RENDERED SCREENSHOT below.\nReturn JSON."},
                {"type": "image_url", "image_url": {"url": _data_uri(output.render_path)}},
            ]
        else:
            user_content = header + f"# OUTPUT to score (HTML)\n{artifact}\n\nReturn JSON."

        messages = [
            {"role": "system", "content": _RUBRIC},
            {"role": "user", "content": user_content},
        ]
        resp = self._gw.complete(model, messages, temperature=0.0)
        return _parse(resp.text, model)

    def score(self, skill_md: str, output: Output) -> dict[str, object]:
        """Return judged output metrics plus disagreement + review flag + feedback."""
        if output.failed:
            return {"quality": 0.0, "constraint_adherence": 0.0, "judge_disagreement": 0.0,
                    "flagged_for_review": 0.0, "feedback": "output failed to render"}

        # In render mode, judge only with vision-capable models so every panelist scores the
        # SAME screenshot. Mixing a text judge (scoring HTML) with vision judges (scoring the
        # image) was a structural source of all-flagged disagreement.
        render = (self._out_cfg.execution.mode == "render_and_screenshot"
                  and output.render_path is not None)
        if render:
            models = [m for m in self._spec.panel_models if m in self._vision_models] \
                or self._spec.panel_models
            votes = [v for m in models if (v := self._vote(m, skill_md, output))]
            return self._aggregate(votes)

        votes: list[JudgeVote] = []
        if self._spec.strategy == "single":
            v = self._vote(self._spec.panel_models[0], skill_md, output)
            votes = [v] if v else []
        elif self._spec.strategy == "screen_then_panel":
            screen = self._vote(self._spec.screen_model, skill_md, output)
            if screen and screen.quality >= _SCREEN_PASS:
                votes = [v for m in self._spec.panel_models
                         if (v := self._vote(m, skill_md, output))]
            elif screen:
                votes = [screen]  # didn't clear the bar; cheap single score stands
        else:  # panel
            votes = [v for m in self._spec.panel_models
                     if (v := self._vote(m, skill_md, output))]

        return self._aggregate(votes)

    def _aggregate(self, votes: list[JudgeVote]) -> dict[str, object]:
        if not votes:
            return {"quality": 0.0, "constraint_adherence": 0.0,
                    "judge_disagreement": 0.0, "flagged_for_review": 1.0, "feedback": ""}

        qualities = [v.quality for v in votes]
        adherences = [v.constraint_adherence for v in votes]
        agg = statistics.median if self._spec.aggregation == "median" else statistics.mean

        # Disagreement = normalized spread of quality across judges (0..1).
        disagreement = 0.0
        if len(qualities) > 1:
            disagreement = round((max(qualities) - min(qualities)) / 10.0, 4)
        flagged = disagreement >= self._spec.disagreement_flag_threshold

        feedback = " | ".join(f"{v.model}: {v.rationale}" for v in votes if v.rationale)

        return {
            "quality": round(float(agg(qualities)), 4),
            "constraint_adherence": round(float(agg(adherences)), 4),
            "judge_disagreement": disagreement,
            "flagged_for_review": 1.0 if flagged else 0.0,
            "feedback": feedback,
        }
