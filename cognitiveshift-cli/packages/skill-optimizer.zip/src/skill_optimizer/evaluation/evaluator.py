"""Evaluator: combine structural metrics + judged output metrics + stability into Scores.

Stability is computed from optional repeat runs supplied by the caller (the pipeline owns the
runner; the evaluator stays runner-free). Failure rate and the review flag are surfaced too.
"""

from __future__ import annotations

import statistics

from skill_optimizer.config.models import Configs
from skill_optimizer.evaluation.judge import JudgePanel
from skill_optimizer.evaluation.score import NormBounds, SkillScorer
from skill_optimizer.evaluation.structural import compute_structural
from skill_optimizer.providers.gateway import LLMGateway
from skill_optimizer.types import Output, Scores


class Evaluator:
    def __init__(self, cfg: Configs, gateway: LLMGateway, bounds: NormBounds | None = None) -> None:
        self._cfg = cfg
        vision_models = {a for a, s in cfg.providers.models.items() if s.vision}
        self._panel = JudgePanel(gateway, cfg.objective.judge_panel, cfg.output_metrics,
                                 vision_models)
        self._scorer = SkillScorer(cfg.objective, bounds)

    def evaluate(self, skill_md: str, output: Output,
                 repeats: list[Output] | None = None) -> Scores:
        structural = compute_structural(skill_md, self._cfg.skill_metrics)

        judged = self._panel.score(skill_md, output)
        out_metrics: dict[str, float] = {
            "quality": judged["quality"],
            "constraint_adherence": judged["constraint_adherence"],
        }

        enabled = self._cfg.output_metrics.enabled()
        if "failure_rate" in enabled:
            out_metrics["failure_rate"] = 1.0 if output.failed else 0.0
        if "stability" in enabled:
            out_metrics["stability"] = self._stability(skill_md, output, repeats or [])

        # Skill Score reads from both metric groups under one flat namespace.
        score_inputs = {**out_metrics, "token_complexity": structural.get("token_complexity", 0.0)}
        cost = output.run_cost_usd + sum(r.run_cost_usd for r in (repeats or []))
        skill_score = self._scorer.compute(score_inputs, cost)

        return Scores(
            structural=structural,
            output=out_metrics,
            skill_score=skill_score,
            cost_usd=cost,
            flagged_for_review=bool(judged["flagged_for_review"]),
            judge_disagreement=float(judged["judge_disagreement"]),
            feedback=str(judged.get("feedback", "")),
        )

    def _stability(self, skill_md: str, base: Output, repeats: list[Output]) -> float:
        """1.0 = identical quality across reruns; lower = more variance."""
        if not repeats:
            return 1.0
        qualities = [self._panel.score(skill_md, o)["quality"] for o in [base, *repeats]]
        if len(qualities) < 2:
            return 1.0
        spread = statistics.pstdev(qualities) / 10.0  # quality is 0..10
        return round(max(0.0, 1.0 - spread), 4)
