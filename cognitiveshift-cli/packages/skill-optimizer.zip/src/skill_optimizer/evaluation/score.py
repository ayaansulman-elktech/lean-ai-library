"""Skill Score: the single number Optuna maximizes.

Weighted sum of normalized benefit terms, minus cost penalty. Normalization maps every term
to 0..1 so weights are comparable. `minmax_per_study` bounds can be supplied later (M3) once a
study has a population to scale against; until then per-candidate reference caps are used.
"""

from __future__ import annotations

from dataclasses import dataclass

from skill_optimizer.config.models import ObjectiveConfig

_TOKEN_REF = 8000.0   # tokens at which the token-complexity benefit hits 0
_COST_REF = 1.0       # USD at which the cost penalty saturates


@dataclass
class NormBounds:
    """Optional per-study min/max for true minmax normalization (M3)."""

    token_min: float = 0.0
    token_max: float = _TOKEN_REF


def _norm_benefit(name: str, value: float, bounds: NormBounds) -> float:
    if name == "quality":
        return max(0.0, min(1.0, value / 10.0))
    if name in ("constraint_adherence", "stability"):
        return max(0.0, min(1.0, value))
    if name == "token_complexity":
        # Benefit: fewer tokens is better. Invert against the reference cap.
        return max(0.0, 1.0 - min(1.0, value / max(1.0, bounds.token_max)))
    return max(0.0, min(1.0, value))


class SkillScorer:
    def __init__(self, cfg: ObjectiveConfig, bounds: NormBounds | None = None) -> None:
        self._cfg = cfg.skill_score
        self._bounds = bounds or NormBounds()

    def compute(self, metrics: dict[str, float], cost_usd: float) -> float:
        weights = self._cfg.weights
        total_w = sum(weights.values()) or 1.0
        score = 0.0
        for name, w in weights.items():
            score += (w / total_w) * _norm_benefit(name, metrics.get(name, 0.0), self._bounds)

        pen = self._cfg.penalties.cost_per_run_usd
        if pen.enabled:
            score -= pen.lambda_ * min(1.0, cost_usd / _COST_REF)
        return round(max(0.0, score), 4)
