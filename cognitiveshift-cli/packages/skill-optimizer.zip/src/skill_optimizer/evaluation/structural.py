"""Structural metrics: scored from the SKILL.md text alone, no model run required.

These are cheap and deterministic — the 'is this Skill well-built' view. Expensive metrics
that need ablation (entropy, MSS, modularity) are deferred and stay disabled in config.
"""

from __future__ import annotations

import re

from skill_optimizer.config.models import SkillMetricsConfig

_IMPERATIVE = re.compile(r"^\s*(?:\d+[.)]|[-*])\s+|^\s*(?:do|use|write|ensure|avoid|never|"
                         r"always|set|run|check|validate|return)\b", re.IGNORECASE | re.MULTILINE)
_HEADING = re.compile(r"^#{1,6}\s", re.MULTILINE)


def count_tokens(text: str) -> int:
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except Exception:
        return max(1, len(text) // 4)


def _instruction_density(text: str) -> float:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if not lines:
        return 0.0
    imperative = len(_IMPERATIVE.findall(text))
    return round(min(1.0, imperative / len(lines)), 4)


def _knowledge_density(text: str) -> float:
    """Fraction of non-boilerplate content (rough proxy: non-blank, non-frontmatter lines)."""
    lines = text.splitlines()
    if not lines:
        return 0.0
    boilerplate = sum(1 for ln in lines if ln.strip() in {"---", ""} or ln.strip().startswith("#"))
    return round(max(0.0, (len(lines) - boilerplate) / len(lines)), 4)


def _skill_complexity(text: str) -> float:
    """Structural complexity proxy: heading count + list depth. Lower-is-simpler (raw count)."""
    headings = len(_HEADING.findall(text))
    list_items = len(re.findall(r"^\s*(?:\d+[.)]|[-*])\s", text, re.MULTILINE))
    return float(headings + list_items)


def compute_structural(skill_md: str, cfg: SkillMetricsConfig) -> dict[str, float]:
    results: dict[str, float] = {}
    enabled = cfg.enabled()
    if "token_complexity" in enabled:
        results["token_complexity"] = float(count_tokens(skill_md))
    if "skill_complexity" in enabled:
        results["skill_complexity"] = _skill_complexity(skill_md)
    if "instruction_density" in enabled:
        results["instruction_density"] = _instruction_density(skill_md)
    if "knowledge_density" in enabled:
        results["knowledge_density"] = _knowledge_density(skill_md)
    return results
