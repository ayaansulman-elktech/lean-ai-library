"""Cost + token + latency accounting. Every LLM call flows through here, so spend and time
are always visible — including a per-model breakdown (which model cost how much / took how
long) for the cost/latency analysis in MLflow."""

from __future__ import annotations

from dataclasses import dataclass, field

from skill_optimizer.config.models import ModelSpec
from skill_optimizer.types import LLMResponse


@dataclass
class ModelStats:
    cost_usd: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    calls: int = 0
    time_s: float = 0.0

    def as_dict(self) -> dict[str, float]:
        return {
            "cost_usd": round(self.cost_usd, 6),
            "tokens_in": self.tokens_in,
            "tokens_out": self.tokens_out,
            "calls": self.calls,
            "time_s": round(self.time_s, 3),
        }


@dataclass
class CostMeter:
    """Accumulates token + USD + time spend across a run, per model. Enforces a budget cap."""

    budget_usd: float | None = None
    total_cost_usd: float = 0.0
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_time_s: float = 0.0
    calls: int = 0
    _by_model: dict[str, ModelStats] = field(default_factory=dict)

    @staticmethod
    def price(spec: ModelSpec, tokens_in: int, tokens_out: int) -> float:
        return (tokens_in / 1_000_000) * spec.price_in + (
            tokens_out / 1_000_000
        ) * spec.price_out

    def record(self, resp: LLMResponse) -> None:
        self.total_cost_usd += resp.cost_usd
        self.total_tokens_in += resp.tokens_in
        self.total_tokens_out += resp.tokens_out
        self.total_time_s += resp.latency_s
        self.calls += 1
        m = self._by_model.setdefault(resp.model, ModelStats())
        m.cost_usd += resp.cost_usd
        m.tokens_in += resp.tokens_in
        m.tokens_out += resp.tokens_out
        m.calls += 1
        m.time_s += resp.latency_s

    def over_budget(self) -> bool:
        return self.budget_usd is not None and self.total_cost_usd >= self.budget_usd

    def by_model(self) -> dict[str, dict[str, float]]:
        return {alias: stats.as_dict() for alias, stats in sorted(self._by_model.items())}

    def summary(self) -> dict[str, float]:
        return {
            "total_cost_usd": round(self.total_cost_usd, 6),
            "total_tokens_in": self.total_tokens_in,
            "total_tokens_out": self.total_tokens_out,
            "total_time_s": round(self.total_time_s, 3),
            "calls": self.calls,
        }
