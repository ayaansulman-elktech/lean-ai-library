"""The single seam every LLM call goes through.

`LLMGateway.complete(alias, messages)` resolves a model alias (claude/codex/grok/kimi/
deepseek) to a concrete provider+model, calls it, prices the result, and records spend on
the shared CostMeter. Two backends:

- LiteLLMGateway: real calls (needs API keys in env).
- MockGateway: deterministic canned responses so the whole pipeline runs offline.

Pool selection (generator vs judge) is the caller's job; the gateway just dispatches an alias.
"""

from __future__ import annotations

import hashlib
import os
import re
import time
from typing import Protocol

from skill_optimizer.config.models import ModelSpec, ProvidersConfig
from skill_optimizer.providers.meter import CostMeter
from skill_optimizer.types import LLMResponse


class LLMGateway(Protocol):
    def complete(self, alias: str, messages: list[dict[str, str]],
                 temperature: float = 0.7, max_tokens: int = 4096) -> LLMResponse: ...


_SEED = 42  # fixed seed for reproducibility on providers that honor it

# Transient provider failures worth retrying (e.g. OpenAI's intermittent 500s on gpt-5-codex,
# rate limits, brief network/timeout blips). Matched by exception CLASS NAME so we don't import
# litellm at module load. Permanent errors (BadRequest, Authentication, NotFound) are NOT here,
# so they fail fast instead of wasting retries.
_RETRYABLE = {
    "InternalServerError", "ServiceUnavailableError", "RateLimitError",
    "APIConnectionError", "APIError", "Timeout", "APITimeoutError",
}
_MAX_RETRIES = 3       # total attempts = 1 + retries
_BACKOFF_BASE_S = 1.5  # 1.5s, 3s, 6s ...


def _is_retryable(exc: Exception) -> bool:
    return type(exc).__name__ in _RETRYABLE


def _flatten(content: object) -> str:
    """Extract text from a message content that may be a string or a list of parts (vision)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(
            part.get("text", "") for part in content
            if isinstance(part, dict) and part.get("type") == "text"
        )
    return ""


def _estimate_tokens(text: str) -> int:
    """Cheap token estimate; the real gateway uses provider-reported counts when available."""
    return max(1, len(text) // 4)


class LiteLLMGateway:
    """Real provider calls via LiteLLM's unified completion interface."""

    def __init__(self, models: dict[str, ModelSpec], meter: CostMeter) -> None:
        self._models = models
        self._meter = meter

    def _resolve(self, alias: str) -> ModelSpec:
        if alias not in self._models:
            raise KeyError(f"Unknown model alias '{alias}'")
        return self._models[alias]

    def complete(self, alias: str, messages: list[dict[str, str]],
                 temperature: float = 0.7, max_tokens: int = 4096) -> LLMResponse:
        import litellm  # imported lazily so offline runs never need the dep installed

        # Providers differ in which params they accept (e.g. Opus 4.8 / GPT-5 reject
        # `temperature`). Drop unsupported params rather than 400 — the agnostic choice.
        litellm.drop_params = True

        spec = self._resolve(alias)
        if spec.api_key_env and not os.environ.get(spec.api_key_env):
            raise RuntimeError(
                f"Model '{alias}' needs {spec.api_key_env} in the environment. "
                f"Set keys or run with the mock gateway (--offline)."
            )
        model_id = f"{spec.provider}/{spec.model}"
        t0 = time.perf_counter()
        resp = None
        for attempt in range(_MAX_RETRIES + 1):
            try:
                resp = litellm.completion(
                    model=model_id, messages=messages,
                    temperature=temperature, max_tokens=max_tokens,
                    seed=_SEED,  # deterministic where the provider supports it (dropped otherwise)
                )
                break
            except Exception as e:  # noqa: BLE001 — re-raised below unless transient + retries left
                if not _is_retryable(e) or attempt == _MAX_RETRIES:
                    raise
                wait = _BACKOFF_BASE_S * (2 ** attempt)
                print(f"[gateway] {alias} {type(e).__name__} (attempt {attempt + 1}/"
                      f"{_MAX_RETRIES + 1}); retrying in {wait:.1f}s", flush=True)
                time.sleep(wait)
        latency = time.perf_counter() - t0
        text = resp.choices[0].message.content or ""
        usage = getattr(resp, "usage", None)
        tin = getattr(usage, "prompt_tokens", None) or _estimate_tokens(
            "".join(_flatten(m["content"]) for m in messages))
        tout = getattr(usage, "completion_tokens", None) or _estimate_tokens(text)
        cost = CostMeter.price(spec, tin, tout)
        out = LLMResponse(text=text, model=alias, tokens_in=tin, tokens_out=tout,
                          cost_usd=cost, latency_s=latency)
        self._meter.record(out)
        return out


class MockGateway:
    """Deterministic offline backend. Same alias+prompt -> same response (reproducible)."""

    def __init__(self, models: dict[str, ModelSpec], meter: CostMeter) -> None:
        self._models = models
        self._meter = meter

    def complete(self, alias: str, messages: list[dict[str, str]],
                 temperature: float = 0.7, max_tokens: int = 4096) -> LLMResponse:
        spec = self._models.get(alias)
        system = _flatten(next((m["content"] for m in messages if m.get("role") == "system"), ""))
        prompt = "\n".join(_flatten(m.get("content", "")) for m in messages)
        digest = hashlib.sha256(f"{alias}:{prompt}".encode()).hexdigest()
        t0 = time.perf_counter()
        text = self._canned(system, prompt, digest)
        latency = time.perf_counter() - t0
        tin, tout = _estimate_tokens(prompt), _estimate_tokens(text)
        cost = CostMeter.price(spec, tin, tout) if spec else 0.0
        out = LLMResponse(text=text, model=alias, tokens_in=tin, tokens_out=tout,
                          cost_usd=cost, latency_s=latency)
        self._meter.record(out)
        return out

    @staticmethod
    def _canned(system: str, prompt: str, digest: str) -> str:
        """Route on the caller's ROLE (system prompt), not fragile content substrings.

        Judge -> JSON score (stable pseudo-score from the digest, and slightly higher for the
        strong calibration Skill so the gate is meaningful offline). Skill engineer -> a
        SKILL.md. Execution agent -> an HTML artifact.
        """
        sys_low, low = system.lower(), prompt.lower()
        if "judge" in sys_low:
            # A real judge keys on Skill structure + whether the output looks built. The mock
            # approximates that: a richly-sectioned Skill outscores a vague one. Section count
            # is the dominant signal; a small per-model jitter creates realistic disagreement.
            headings = low.count("# ")                            # rubric(2) + skill sections
            output_built = 1.0 if ("canvas" in low and "scroll" in low) else 0.0
            jitter = (int(digest[:4], 16) / 0xFFFF) - 0.5         # -0.5..+0.5, per model+prompt
            quality = round(max(0.0, min(10.0, 3 + headings + output_built + jitter)), 2)
            adherence = round(max(0.0, min(1.0, 0.3 + 0.1 * headings + 0.2 * output_built)), 3)
            return (f'{{"quality": {quality}, "constraint_adherence": {adherence}, '
                    '"rationale": "mock judgement"}')
        if "skill engineer" in sys_low:
            # Mirror the requested genome: one section per planned entry, so candidates with
            # different genomes score differently and the search has a real gradient to climb.
            n = max(1, len(re.findall(r"(?m)^\s*\d+\.\s", prompt)))
            body = "\n\n".join(
                f"# Section {i}\nConcrete guidance for step {i}; pin canvas, map scroll."
                for i in range(1, n + 1)
            )
            return f"---\nname: scroll-driven-hero\n---\n\n{body}\n"
        if "execution agent" in sys_low:
            return ("<!doctype html><html><body><canvas id='hero'></canvas>"
                    "<script>/* scroll-driven */</script></body></html>")
        if "optimization agent" in sys_low:
            return "Add a concise Constraints section and trim filler to lower token count."
        if "optimization engineer" in sys_low:
            # Reflection: return a slightly richer Skill (one more section) so reflected
            # candidates differ and the mock judge can show improvement offline.
            n = max(2, len(re.findall(r"(?m)^#\s+", prompt)) + 1)
            body = "\n\n".join(f"# Section {j}\nRefined guidance for step {j}; pin canvas."
                               for j in range(1, n + 1))
            return ("---\nname: scroll-driven-hero\ndescription: Build a scroll-driven hero "
                    "page; use when asked for a landing hero.\n---\n\n" + body + "\n")
        if "skill compressor" in sys_low:
            # Keep every heading (preserves judged quality) but strip the bodies (cuts tokens).
            heads = re.findall(r"(?m)^#\s+(.+)$", prompt)
            body = "\n".join(f"# {h.strip()}\n-" for h in heads) or "# Skill\n-"
            return f"---\nname: scroll-driven-hero\n---\n{body}\n"
        return "MOCK_RESPONSE"


def build_gateway(cfg: ProvidersConfig, meter: CostMeter, *, offline: bool) -> LLMGateway:
    """Pick the backend. `offline` or gateway=mock -> MockGateway."""
    if offline or cfg.gateway == "mock":
        return MockGateway(cfg.models, meter)
    return LiteLLMGateway(cfg.models, meter)
