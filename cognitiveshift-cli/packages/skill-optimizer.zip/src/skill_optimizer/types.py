"""Shared data structures passed across the three core seams (gateway, runner, judge)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class LLMResponse:
    """Result of a single LLM call, with the accounting the cost meter needs."""

    text: str
    model: str
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    latency_s: float = 0.0


@dataclass
class GenomeConfig:
    """A concrete point in the search space: which sections, their order, their params.

    `sections` maps gene name -> resolved params (empty dict if the gene is just on).
    `order` is the ordered list of enabled gene names.
    """

    sections: dict[str, dict[str, Any]]
    order: list[str]
    compression: str = "none"
    content: dict[str, Any] = field(default_factory=dict)  # content-level gene choices
    runtime_model: str = ""  # which model runs the Skill to generate the website output

    def is_enabled(self, gene: str) -> bool:
        return gene in self.sections


@dataclass
class Candidate:
    """A generated Skill plus the genome that produced it."""

    skill_md: str
    genome: GenomeConfig
    gen_cost_usd: float = 0.0


@dataclass
class Output:
    """Observable evidence produced by running a Skill. Never optimized directly."""

    artifacts: dict[str, str] = field(default_factory=dict)  # filename -> content
    render_path: str | None = None  # screenshot path if render_and_screenshot
    failed: bool = False
    run_cost_usd: float = 0.0


@dataclass
class Scores:
    """All metric values for one candidate, plus the aggregated Skill Score."""

    structural: dict[str, float] = field(default_factory=dict)
    output: dict[str, float] = field(default_factory=dict)
    skill_score: float = 0.0
    cost_usd: float = 0.0
    flagged_for_review: bool = False
    judge_disagreement: float = 0.0
    feedback: str = ""  # judges' rationale — the reflective optimizer learns from this

    def flat(self) -> dict[str, float]:
        """Flatten for MLflow logging."""
        out: dict[str, float] = {}
        for k, v in self.structural.items():
            out[f"structural.{k}"] = v
        for k, v in self.output.items():
            out[f"output.{k}"] = v
        out["skill_score"] = self.skill_score
        out["cost_usd"] = self.cost_usd
        out["judge_disagreement"] = self.judge_disagreement
        return out
