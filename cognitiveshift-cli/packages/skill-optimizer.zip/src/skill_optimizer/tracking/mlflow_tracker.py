"""MLflow wrapper. Logs config, genome, scores, cost, and the SKILL.md + output as artifacts.

Reproducibility rule (charter): every candidate is linked to its genome, scores, generated
output, and (in M3) Optuna trial ID + MLflow run ID. NullTracker lets the pipeline run with
tracking disabled (tests, quick offline checks) without branching everywhere.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Protocol

from skill_optimizer.types import Candidate, Output, Scores


class Tracker(Protocol):
    def __enter__(self) -> Tracker: ...
    def __exit__(self, *exc: object) -> None: ...
    def log_candidate(self, candidate: Candidate, output: Output, scores: Scores,
                      extra: dict[str, Any] | None = None) -> str | None: ...


class NullTracker:
    """No-op tracker. Returns no run_id, so callers fall back to in-memory values."""

    def __enter__(self) -> NullTracker:
        return self

    def __exit__(self, *exc: object) -> None:
        return None

    def log_candidate(self, candidate: Candidate, output: Output, scores: Scores,
                      extra: dict[str, Any] | None = None) -> str | None:
        return None


class MLflowTracker:
    def __init__(self, experiment: str, run_name: str | None = None,
                 tracking_uri: str | None = None) -> None:
        import mlflow
        self._mlflow = mlflow
        if tracking_uri:
            mlflow.set_tracking_uri(tracking_uri)
        mlflow.set_experiment(experiment)
        self._run_name = run_name
        self._active = None

    def __enter__(self) -> MLflowTracker:
        self._active = self._mlflow.start_run(run_name=self._run_name)
        return self

    def __exit__(self, *exc: object) -> None:
        self._mlflow.end_run()

    def log_candidate(self, candidate: Candidate, output: Output, scores: Scores,
                      extra: dict[str, Any] | None = None) -> str | None:
        g = candidate.genome
        self._mlflow.log_params({
            "genome.order": ",".join(g.order),
            "genome.compression": g.compression,
            "genome.n_sections": len(g.order),
            **{f"gene.{k}": json.dumps(v) for k, v in g.sections.items()},
            **{f"content.{k}": json.dumps(v) for k, v in g.content.items()},
            **(extra or {}),
        })
        self._mlflow.log_metrics(scores.flat())
        # Artifacts: the Skill, the produced output, the judge feedback, and a lineage record.
        # SKILL.md + feedback.txt are read back by the optimizer (MLflow as system of record).
        self._log_text(candidate.skill_md, "SKILL.md")
        self._log_text(scores.feedback or "", "feedback.txt")
        for name, content in output.artifacts.items():
            self._log_text(content, f"output/{name}")
        run_id = self._active.info.run_id if self._active else None
        lineage = {
            "genome": {"order": g.order, "compression": g.compression,
                       "sections": g.sections, "content": g.content,
                       "runtime_model": g.runtime_model},
            "scores": scores.flat(),
            "flagged_for_review": scores.flagged_for_review,
            "run_id": run_id,
        }
        self._log_text(json.dumps(lineage, indent=2), "lineage.json")
        if output.render_path and Path(output.render_path).exists():
            self._mlflow.log_artifact(output.render_path, artifact_path="output")
        return run_id

    def _log_text(self, text: str, artifact_file: str) -> None:
        self._mlflow.log_text(text, artifact_file)


def read_trial(run_id: str, *, tracking_uri: str = "sqlite:///mlflow.db") -> dict[str, Any] | None:
    """Read a logged trial back from MLflow — the system-of-record read path.

    Returns {skill_score, quality, feedback, skill_md} or None if unavailable. Lets the
    optimizer drive selection from what MLflow actually stored (not just in-memory values),
    so the running loop matches the architecture: D -> metrics -> MLflow -> Optimizer.
    """
    try:
        import mlflow
        from mlflow.tracking import MlflowClient

        client = MlflowClient(tracking_uri=tracking_uri)
        run = client.get_run(run_id)
        metrics = run.data.metrics
        art = run.info.artifact_uri
        def _load(name: str) -> str:
            try:
                return mlflow.artifacts.load_text(f"{art}/{name}")
            except Exception:  # noqa: BLE001
                return ""
        return {
            "skill_score": metrics.get("skill_score"),
            "quality": metrics.get("output.quality"),
            "feedback": _load("feedback.txt"),
            "skill_md": _load("SKILL.md"),
        }
    except Exception:  # noqa: BLE001 — never let a read-back failure break the loop
        return None


def build_tracker(experiment: str, run_name: str | None = None, *,
                  enabled: bool = True, tracking_uri: str | None = None) -> Tracker:
    if not enabled:
        return NullTracker()
    # Pin to a local SQLite store so the tracker and `mlflow ui` read the same place.
    # MLflow 3.x put the file store ('./mlruns') in maintenance mode and the UI server
    # refuses to serve it, so SQLite is the supported local backend.
    tracking_uri = tracking_uri or "sqlite:///mlflow.db"
    try:
        return MLflowTracker(experiment, run_name, tracking_uri)
    except Exception:
        # MLflow not installed / misconfigured: degrade to no-op rather than fail the run.
        return NullTracker()
