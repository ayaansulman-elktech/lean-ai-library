"""Discover and load the example datasets.

Folders are located by name (D_wm / D_test / D_guard) anywhere under a root, so the existing
nested `Dataset/Dataset/...` layout works without moving files. D_guard carries a hard
guardrail: accessing its examples requires an explicit `final_validation=True`, so it cannot
leak into the optimization loop by accident.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

_GOOD_HINTS = ("good",)
_BAD_HINTS = ("bad",)
_TEXT_SUFFIXES = {".md", ".txt", ".html", ".css", ".js", ".json", ".yaml", ".yml"}


_PROMPT_FILES = {"prompt.md", "prompt.txt"}


class GuardViolationError(RuntimeError):
    """Raised if D_guard is read outside final validation."""


@dataclass
class Example:
    path: Path
    polarity: str  # "good" | "bad" | "neutral"

    def read_text(self) -> str:
        return self.path.read_text(encoding="utf-8", errors="replace")


@dataclass
class Dataset:
    name: str
    root: Path
    examples: list[Example] = field(default_factory=list)
    _frozen: bool = False

    def good(self) -> list[Example]:
        self._check()
        return [e for e in self.examples if e.polarity == "good"]

    def bad(self) -> list[Example]:
        self._check()
        return [e for e in self.examples if e.polarity == "bad"]

    def all(self) -> list[Example]:
        self._check()
        return list(self.examples)

    def _check(self) -> None:
        if self._frozen:
            raise GuardViolationError(
                f"{self.name} is frozen (D_guard). Load it with final_validation=True only "
                f"during final validation — never inside the optimization loop."
            )


def _polarity_of(path: Path, base: Path) -> str:
    # Only inspect path parts BELOW the dataset root, so an unrelated ancestor folder name
    # (e.g. a temp dir containing "good") can never leak into classification.
    try:
        rel_parts = [p.lower() for p in path.relative_to(base).parts]
    except ValueError:
        rel_parts = [path.name.lower()]
    if any(h in part for part in rel_parts for h in _GOOD_HINTS):
        return "good"
    if any(h in part for part in rel_parts for h in _BAD_HINTS):
        return "bad"
    return "neutral"


def _find_dir(root: Path, name: str) -> Path | None:
    if root.name == name:
        return root
    matches = [p for p in root.rglob(name) if p.is_dir()]
    return matches[0] if matches else None


def load_dataset(root: str | Path, name: str, *, final_validation: bool = False) -> Dataset:
    """Load a named dataset (D_wm/D_test/D_guard) discovered under `root`.

    Skips macOS resource-fork files (`__MACOSX`, `._*`). D_guard requires final_validation.
    """
    if name == "D_guard" and not final_validation:
        raise GuardViolationError(
            "D_guard may only be loaded with final_validation=True."
        )
    root_path = Path(root)
    base = _find_dir(root_path, name)
    if base is None:
        raise FileNotFoundError(f"Dataset folder '{name}' not found under {root_path}")

    examples: list[Example] = []
    for p in sorted(base.rglob("*")):
        if not p.is_file():
            continue
        if "__MACOSX" in p.parts or p.name.startswith("._") or p.name == ".DS_Store":
            continue  # skip macOS Finder metadata / AppleDouble cruft
        examples.append(Example(path=p, polarity=_polarity_of(p, base)))

    ds = Dataset(name=name, root=base, examples=examples)
    if name == "D_guard":
        ds._frozen = False  # caller passed final_validation; allow reads this session
    return ds


def task_briefs(dataset: Dataset) -> list[tuple[str, str]]:
    """Return (case_name, brief_text) for every prompt.md/prompt.txt in the dataset.

    Used both to drive optimization tasks (D_dev) and to validate (D_test/D_guard), so the
    optimizer trains on the same task distribution it's validated against.
    """
    out: list[tuple[str, str]] = []
    for ex in dataset.all():
        if ex.path.name.lower() in _PROMPT_FILES:
            out.append((ex.path.parent.name, ex.read_text()))
    return out
