"""Run an optimized Skill against a held-out dataset and report generalization.

Each dataset case is a folder containing a `prompt.md` task brief; the Skill runs on each,
its output is judged, and scores are aggregated. Used for D_test (generalization during
optimization) and D_guard (frozen final validation — loaded only with final_validation=True).
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from skill_optimizer.datasets.loader import Dataset, task_briefs
from skill_optimizer.runner.runner import _DEFAULT_TASK

if TYPE_CHECKING:
    from skill_optimizer.pipeline import Context


@dataclass
class CaseScore:
    name: str
    skill_score: float
    quality: float
    flagged: bool


@dataclass
class ValidationReport:
    dataset: str
    n_cases: int
    mean_skill_score: float
    mean_quality: float
    flagged: int
    cases: list[CaseScore] = field(default_factory=list)

    def overfitting_gap(self, train_score: float) -> float:
        """Train score minus held-out score: positive => the Skill overfit the train set."""
        return round(train_score - self.mean_skill_score, 4)


class Validator:
    def __init__(self, ctx: Context) -> None:
        self._ctx = ctx

    def validate(self, skill_md: str, dataset: Dataset) -> ValidationReport:
        cases = task_briefs(dataset) or [("default", _DEFAULT_TASK)]
        scored: list[CaseScore] = []
        for name, brief in cases:
            if self._ctx.meter.over_budget():
                break
            output = self._ctx.runner.run(skill_md, task=brief)
            scores = self._ctx.evaluator.evaluate(skill_md, output)
            scored.append(CaseScore(
                name=name,
                skill_score=scores.skill_score,
                quality=scores.output.get("quality", 0.0),
                flagged=scores.flagged_for_review,
            ))
        mean_ss = round(statistics.mean(s.skill_score for s in scored), 4) if scored else 0.0
        mean_q = round(statistics.mean(s.quality for s in scored), 4) if scored else 0.0
        return ValidationReport(
            dataset=dataset.name,
            n_cases=len(scored),
            mean_skill_score=mean_ss,
            mean_quality=mean_q,
            flagged=sum(1 for s in scored if s.flagged),
            cases=scored,
        )
