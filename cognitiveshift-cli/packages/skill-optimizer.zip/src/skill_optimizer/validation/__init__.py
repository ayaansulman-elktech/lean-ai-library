"""M4: generalization (D_test), frozen final validation (D_guard), portability, compression."""

from skill_optimizer.validation.compression import CompressionResult, Compressor
from skill_optimizer.validation.portability import PortabilityChecker, PortabilityReport
from skill_optimizer.validation.validator import CaseScore, ValidationReport, Validator

__all__ = [
    "CompressionResult",
    "Compressor",
    "PortabilityChecker",
    "PortabilityReport",
    "CaseScore",
    "ValidationReport",
    "Validator",
]
