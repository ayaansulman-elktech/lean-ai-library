"""Portability: does the optimized Skill hold up across different foundation models?

Runs the same Skill on each runtime model and measures score preservation. A Skill that only
works on the model it was tuned against has poor portability; preservation = min/max score.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from skill_optimizer.runner.runner import _DEFAULT_TASK, SkillRunner

if TYPE_CHECKING:
    from skill_optimizer.pipeline import Context


@dataclass
class PortabilityReport:
    per_model: dict[str, float] = field(default_factory=dict)
    mean: float = 0.0
    preservation: float = 0.0  # min/max across models: 1.0 = perfectly portable

    @property
    def worst_model(self) -> str | None:
        return min(self.per_model, key=self.per_model.get) if self.per_model else None


class PortabilityChecker:
    def __init__(self, ctx: Context) -> None:
        self._ctx = ctx

    def check(self, skill_md: str, models: list[str],
              task: str = _DEFAULT_TASK) -> PortabilityReport:
        per: dict[str, float] = {}
        for alias in models:
            if self._ctx.meter.over_budget():
                break
            runner = SkillRunner(self._ctx.gateway, alias, self._ctx.cfg.output_metrics.execution)
            output = runner.run(skill_md, task=task)
            scores = self._ctx.evaluator.evaluate(skill_md, output)
            per[alias] = scores.skill_score

        if not per:
            return PortabilityReport()
        vals = list(per.values())
        mx = max(vals)
        return PortabilityReport(
            per_model=per,
            mean=round(statistics.mean(vals), 4),
            preservation=round(min(vals) / mx, 4) if mx > 0 else 0.0,
        )
