"""Skill compression: shrink token count while preserving the Skill Score.

A compressor LLM rewrites the Skill more tersely; a candidate is accepted only if it uses
fewer tokens AND keeps the score within tolerance of the best so far. Iterates a few rounds.
This is Phase-2 'optimize Skill compression' — improving Skill Compression Ratio (SCR).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from skill_optimizer.evaluation.structural import count_tokens
from skill_optimizer.providers.gateway import LLMGateway

if TYPE_CHECKING:
    from skill_optimizer.pipeline import Context

_SYSTEM = (
    "You are a Skill compressor. Rewrite the given SKILL.md to use as few tokens as possible "
    "while preserving every section and all behavior. Keep section headings. Output only the "
    "compressed SKILL.md."
)


@dataclass
class CompressionResult:
    orig_tokens: int
    orig_score: float
    comp_tokens: int
    comp_score: float
    ratio: float           # comp_tokens / orig_tokens (lower = more compressed)
    accepted: bool
    compressed_skill: str


class Compressor:
    def __init__(self, ctx: Context, model_alias: str) -> None:
        self._ctx = ctx
        self._gw: LLMGateway = ctx.gateway
        self._model = model_alias

    def _score(self, skill_md: str) -> float:
        output = self._ctx.runner.run(skill_md)
        return self._ctx.evaluator.evaluate(skill_md, output).skill_score

    def compress(self, skill_md: str, tolerance: float = 0.05,
                 rounds: int = 2) -> CompressionResult:
        orig_tokens = count_tokens(skill_md)
        orig_score = self._score(skill_md)

        best, best_tokens, best_score = skill_md, orig_tokens, orig_score
        current = skill_md
        for _ in range(rounds):
            if self._ctx.meter.over_budget():
                break
            resp = self._gw.complete(
                self._model,
                [{"role": "system", "content": _SYSTEM},
                 {"role": "user", "content": current}],
                temperature=0.2,
            )
            cand = resp.text.strip()
            if not cand:
                break
            cand_tokens = count_tokens(cand)
            cand_score = self._score(cand)
            # Accept only if smaller AND score retained within tolerance.
            if cand_tokens < best_tokens and cand_score >= best_score - tolerance:
                best, best_tokens, best_score = cand, cand_tokens, cand_score
                current = cand

        return CompressionResult(
            orig_tokens=orig_tokens,
            orig_score=round(orig_score, 4),
            comp_tokens=best_tokens,
            comp_score=round(best_score, 4),
            ratio=round(best_tokens / orig_tokens, 4) if orig_tokens else 1.0,
            accepted=best_tokens < orig_tokens,
            compressed_skill=best,
        )
