"""Run a candidate Skill to produce an output.

A runtime LLM is given the SKILL.md as its instructions plus a task brief, and produces the
artifact (for the pilot: a scroll-driven hero page = HTML/CSS/JS). Optionally the artifact is
rendered to a screenshot for visual judging.

Output is observable evidence ONLY — it is never optimized directly (charter rule).
"""

from __future__ import annotations

import re
import tempfile
from pathlib import Path

from skill_optimizer.config.models import ExecutionSpec
from skill_optimizer.providers.gateway import LLMGateway
from skill_optimizer.types import Output


def _extract_html(text: str) -> str:
    """Pull clean HTML out of a model response that may wrap it in prose or markdown fences.

    Models like DeepSeek often prefix 'This is a self-contained HTML document...' or wrap the
    page in ```html ... ``` — both break rendering. Strip to the actual document.
    """
    t = text.strip()
    fence = re.search(r"```(?:html)?\s*(.*?)```", t, re.DOTALL | re.IGNORECASE)
    if fence:
        t = fence.group(1).strip()
    start = re.search(r"<!doctype html|<html|<svg|<body", t, re.IGNORECASE)
    if start:
        return t[start.start():].strip()
    return t[t.index("<"):].strip() if "<" in t else t


def render_to_screenshot(html: str, timeout_s: int = 60) -> str | None:
    """Write HTML to a temp dir, render it in headless Chromium, return the screenshot path.

    Returns None if Playwright/Chromium aren't available (caller falls back to text judging).
    Shared by the SkillRunner and the DSPy GEPA metric.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return None
    try:
        d = Path(tempfile.mkdtemp(prefix="skillrun_"))
        html_path = d / "index.html"
        html_path.write_text(html, encoding="utf-8")
        png_path = d / "screenshot.png"
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1280, "height": 800})
            page.goto(html_path.as_uri(), timeout=timeout_s * 1000)
            page.wait_for_timeout(500)
            page.screenshot(path=str(png_path))
            browser.close()
        return str(png_path)
    except Exception:
        return None


def sweep_temp_renders() -> None:
    """Remove leftover temp render dirs (screenshots for stability/calibration runs)."""
    import glob
    import shutil

    for d in glob.glob(str(Path(tempfile.gettempdir()) / "skillrun_*")):
        shutil.rmtree(d, ignore_errors=True)


_SYSTEM = (
    "You are an execution agent. Follow the provided SKILL.md exactly as your operating "
    "instructions, then complete the task. Output only the requested artifact."
)

_DEFAULT_TASK = (
    "Build the output the SKILL.md is designed to produce. Return a SINGLE self-contained "
    "HTML document with ALL CSS and JS inline and NO external assets (no external images, "
    "fonts, or video files) — it must render fully on its own in a browser. Implement a "
    "scroll-driven hero section using CSS scroll-driven animation, inline SVG, or "
    "canvas drawing, with a bold headline. Output only the HTML."
)


class SkillRunner:
    def __init__(self, gateway: LLMGateway, model_alias: str, execution: ExecutionSpec) -> None:
        self._gw = gateway
        self._model = model_alias
        self._exec = execution

    def run(self, skill_md: str, task: str = _DEFAULT_TASK,
            artifacts_dir: str | Path | None = None) -> Output:
        messages = [
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": f"# SKILL.md\n{skill_md}\n\n# Task\n{task}"},
        ]
        try:
            resp = self._gw.complete(self._model, messages, temperature=0.5)
        except Exception:  # a failed run is a data point, not a crash
            return Output(failed=True)

        content = _extract_html(resp.text)
        failed = not content or "<" not in content
        out = Output(artifacts={"index.html": content}, failed=failed,
                     run_cost_usd=resp.cost_usd)

        # Persist the artifact (to artifacts_dir if given, else a temp dir so we can render).
        render = self._exec.mode == "render_and_screenshot" and not failed
        if artifacts_dir is None and not render:
            return out  # nothing to write and nothing to render

        d = Path(artifacts_dir) if artifacts_dir else Path(tempfile.mkdtemp(prefix="skillrun_"))
        d.mkdir(parents=True, exist_ok=True)
        html_path = d / "index.html"
        html_path.write_text(content, encoding="utf-8")
        if render:
            out.render_path = self._render(html_path, d / "screenshot.png")
        return out

    def _render(self, html_path: Path, png_path: Path) -> str | None:
        """Render HTML to a viewport screenshot via Playwright. Degrades gracefully.

        Captures the rendered hero (1280x800) — a real visual signal vs raw HTML. Returns
        None (caller falls back to text judging) if Playwright/Chromium aren't available.
        """
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            return None  # render extra not installed; static text judging still runs
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch()
                page = browser.new_page(viewport={"width": 1280, "height": 800})
                page.goto(html_path.as_uri(), timeout=self._exec.timeout_s * 1000)
                page.wait_for_timeout(500)  # let initial animation/layout settle
                page.screenshot(path=str(png_path))  # viewport only (bounds image cost)
                browser.close()
            return str(png_path)
        except Exception:
            return None
