"""Multi-file runner — the REAL task adapter (scroll-driven *video* sites).

Unlike SkillRunner (which renders one self-contained HTML), this builds a real multi-file
project the way the target skill does:

  1. extract frames from the brief's video (bundled ffmpeg)            <- harness plumbing
  2. ask the agent, guided by the SKILL.md, to author the page + charte <- the skill's job
  3. assemble the project: reuse engine (base.css/sections.css/scroll-video.js) + frames
  4. serve over HTTP, scrub to several scroll positions, screenshot each, montage
  5. return the montage as the render the judge scores against check-list.md

The split is deliberate: ffmpeg/serving are fixtures we automate; the agent only makes the
creative decisions the skill describes (key frames, panel timing/placement, sections, charte).
"""

from __future__ import annotations

import contextlib
import http.server
import json
import re
import shutil
import socket
import socketserver
import statistics
import subprocess
import threading
from dataclasses import dataclass, field
from pathlib import Path

from skill_optimizer.types import Output

# A consecutive-frame change above this (mean abs pixel diff, 0..1) means the video genuinely
# scrubs with scroll. Calibrated on a working build (~0.08) vs a static page (~0).
_SCRUB_OK = 0.06

# --- the engine contract the agent must target (from the dataset's good examples) -----------
_AGENT_SYSTEM = (
    "You are an execution agent that builds a scroll-driven VIDEO website by following the "
    "provided SKILL. The frame images are ALREADY extracted and a reusable engine is already "
    "present (assets/css/base.css, assets/css/sections.css, assets/js/scroll-video.js). Do NOT "
    "rewrite the engine. Author exactly TWO files for this site:\n"
    "  1. <slug>.html — the page\n"
    "  2. assets/css/<slug>.css — the charte (fonts, colors)\n\n"
    "The HTML MUST:\n"
    "- link, in <head>: a Google font, assets/css/base.css, assets/css/sections.css, "
    "assets/css/<slug>.css\n"
    "- include this EXACT loader markup as the first child of <body> (the engine hides it via "
    "the data- attributes — omitting them leaves a black overlay): "
    "<div class=\"loader\" data-loader><div class=\"loader__box\"><div class=\"loader__meta\">"
    "<span>Chargement</span><span data-loader-count>0%</span></div>"
    "<div class=\"loader__track\"><div class=\"loader__bar\" data-loader-bar></div></div>"
    "</div></div>\n"
    "- contain: <section class=\"scroll-track\"><div class=\"scene\">"
    "<canvas id=\"scroll-canvas\"></canvas> ...panels... </div></section>\n"
    "- panels: <div class=\"panel panel--<v> panel--<h> [panel--glass]\" "
    "data-reveal-start=\"0..1\" "
    "data-reveal-end=\"0..1\" data-reveal-from=\"up|down|left|right\">"
    "<div class=\"panel__inner\">"
    "<span class=\"eyebrow\">..</span><h2 class=\"title\">..</h2>"
    "<p class=\"lede\">..</p></div></div>"
    " (v=top|center|bottom, h=left|mid|right; put text on the EMPTY side of the frame; first "
    "panel data-reveal-start=\"0\")\n"
    "- after the track: <main class=\"content theme-<slug>\"> with editorial sections using "
    "data-anim=\"fade|fade-up|zoom|stagger\" (you may reuse a frame image as a visual)\n"
    "- at the end: <script src=\"assets/js/scroll-video.js\"></script> then "
    "<script>initScrollVideo({ framesPath:\"assets/frames/<slug>/\", frameCount:<N>, pad:3, "
    "ext:\"jpg\", scrollVh:<~2.7*N> });</script>\n"
    "The <slug>.css MUST set the charte, including a theme rule "
    "`.content.theme-<slug>{ --accent:..; --bg:..; --bg-soft:..; }` and "
    "`:root{ --font-display:..; --font-body:..; }`.\n\n"
    "Return ONLY the two files, each delimited EXACTLY as:\n"
    "===FILE <path>===\n<content>\n===END===\n"
    "No prose."
)

_FILE_RE = re.compile(r"===FILE\s+(?P<path>[^\n=]+?)===\s*\n(?P<body>.*?)\n===END===", re.DOTALL)


@dataclass
class BuildResult:
    project_dir: Path
    files: dict[str, str] = field(default_factory=dict)  # agent-authored files (path -> content)
    frame_count: int = 0
    montage_path: str | None = None
    shots: list[str] = field(default_factory=list)       # per-scroll screenshots
    scrub: float = 0.0                                    # objective scroll-scrub metric (0..1)
    failed: bool = False
    reason: str = ""


def scrub_metric(shots: list[str]) -> float:
    """Objective 'does the video scrub with scroll' signal: mean consecutive-frame pixel change
    across the in-track screenshots. Deterministic — no vision model needed."""
    from PIL import Image, ImageChops

    grays = [Image.open(s).convert("L").resize((320, 200)) for s in shots]
    if len(grays) < 2:
        return 0.0
    diffs = []
    for a, b in zip(grays, grays[1:], strict=False):
        px = list(ImageChops.difference(a, b).getdata())
        diffs.append(sum(px) / len(px) / 255.0)
    return round(statistics.mean(diffs), 4)


def _ffmpeg_exe() -> str:
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def extract_frames(video: Path, out_dir: Path, *, fps: int = 12, width: int = 1280,
                   max_frames: int = 240) -> int:
    """Extract numbered jpg frames (001.jpg…) from a video. Returns the frame count."""
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("*.jpg"):
        old.unlink()
    cmd = [
        _ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-i", str(video),
        "-vf", f"fps={fps},scale={width}:-1", "-q:v", "4", "-frames:v", str(max_frames),
        "-start_number", "1", str(out_dir / "%03d.jpg"),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return len(list(out_dir.glob("*.jpg")))


def parse_agent_files(text: str) -> dict[str, str]:
    return {m.group("path").strip(): m.group("body").strip() for m in _FILE_RE.finditer(text)}


class _QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):  # silence
        return


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _Server:
    """Threaded static HTTP server rooted at a directory (frame preloading needs http://)."""

    def __init__(self, root: Path):
        self._root = str(root)
        self.port = _free_port()
        handler = lambda *a, **k: _QuietHandler(*a, directory=self._root, **k)  # noqa: E731
        self._httpd = socketserver.TCPServer(("127.0.0.1", self.port), handler)
        self._t = threading.Thread(target=self._httpd.serve_forever, daemon=True)

    def __enter__(self):
        self._t.start()
        return self

    def __exit__(self, *exc):
        self._httpd.shutdown()
        self._httpd.server_close()


_DESIGN_RUBRIC = (
    "You are a SENIOR design director reviewing a scroll-driven video site, shown as a vertical "
    "montage of scroll stills (top=start, bottom=end). Motion is measured separately and "
    "objectively — do NOT score motion. Be HARSH and DISCRIMINATING and use the FULL 0-10 range: "
    "most competent outputs land 5-7; reserve 8+ for genuinely exceptional, award-quality work; "
    "9-10 is a once-a-year portfolio piece. Two 'nice dark premium' pages must NOT get the same "
    "numbers — find what separates them. Score each dimension 0-10:\n"
    "  type     — typographic hierarchy, scale, tracking, restraint (generic system fonts = low)\n"
    "  color    — palette sophistication, contrast, mood fitting the brief (default dark = mid)\n"
    "  layout   — composition, whitespace, rhythm, alignment\n"
    "  panels   — editorial copy quality AND precise placement on the empty side of the frame\n"
    "  editorial— depth, variety, and polish of the sections below the video\n"
    'Return JSON only: {"type":n,"color":n,"layout":n,"panels":n,"editorial":n,'
    '"rationale":"what separates this from a generic version"}'
)
_DESIGN_DIMS = ["type", "color", "layout", "panels", "editorial"]


def _design_vote(gw, model: str, brief: str, uri: str) -> dict | None:
    """One vision judge's harsh design sub-scores, or None if it errors/parses badly."""
    try:
        resp = gw.complete(model, [
            {"role": "system", "content": _DESIGN_RUBRIC},
            {"role": "user", "content": [
                {"type": "text", "text": f"BRIEF: {brief}\nScore the static design of the montage. "
                                         "Be harsh and use the full range. Return JSON."},
                {"type": "image_url", "image_url": {"url": uri}},
            ]},
        ], temperature=0.0, max_tokens=400)
        t = resp.text
        v = json.loads(t[t.find("{"):t.rfind("}") + 1])
        vals = [float(v[k]) for k in _DESIGN_DIMS if isinstance(v.get(k), (int, float))]
        if not vals:
            return None
        return {"model": model, "design": round(statistics.mean(vals), 2),
                "sub_scores": {k: v.get(k) for k in _DESIGN_DIMS},
                "rationale": v.get("rationale", "")}
    except Exception:  # noqa: BLE001 — a failed judge just drops out of the panel
        return None


def judge_site(gw, model, brief: str, montage_png: str, scrub: float) -> dict:
    """Trustworthy task score: objective scrub metric GATES a discriminating vision design score.

    `model` may be a single alias or a LIST (a panel) of vision judges — their design scores are
    averaged (panel cancels single-model bias; a failed judge drops out). motion_frac =
    clamp(scrub/_SCRUB_OK); quality = design * (0.6 + 0.4*motion_frac), so a working site's
    quality == its design (full 0-10 spread) while a non-scrubbing site is heavily penalised.
    """
    import base64

    models = [model] if isinstance(model, str) else list(model)
    with open(montage_png, "rb") as fh:
        uri = "data:image/png;base64," + base64.b64encode(fh.read()).decode()
    votes = [v for m in models if (v := _design_vote(gw, m, brief, uri))]
    design = round(statistics.mean(v["design"] for v in votes), 2) if votes else 0.0
    motion_frac = min(scrub / _SCRUB_OK, 1.0)
    quality = round(design * (0.6 + 0.4 * motion_frac), 2)
    return {
        "quality": quality, "motion_score": round(10.0 * motion_frac, 2), "design_score": design,
        "scrub_metric": scrub, "scrubs": scrub >= _SCRUB_OK,
        "panel": {v["model"]: v["design"] for v in votes},
        "sub_scores": votes[0]["sub_scores"] if votes else {},
        "rationale": votes[0]["rationale"] if votes else "no judge returned a score",
    }


class MultiFileRunner:
    """Builds + renders the real multi-file scroll-video site for one brief."""

    def __init__(self, gateway, run_model: str, engine_dir: Path,
                 scroll_positions: tuple[float, ...] = (0.0, 0.25, 0.5, 0.75, 0.95),
                 viewport=(1280, 800)) -> None:
        self._gw = gateway
        self._model = run_model
        self._engine_dir = Path(engine_dir)  # a dir holding base.css/sections.css/scroll-video.js
        self._positions = scroll_positions
        self._vw, self._vh = viewport

    # --- 2. agent authors the page + charte ----------------------------------------------
    def _author(self, skill_md: str, brief: str, slug: str, frame_count: int) -> dict[str, str]:
        scroll_vh = int(round(2.7 * frame_count))
        user = (
            f"# SKILL (follow it)\n{skill_md}\n\n"
            f"# BRIEF\n{brief}\n\n"
            f"# SITE FACTS\nslug = {slug}\nframeCount = {frame_count}\n"
            f"framesPath = assets/frames/{slug}/  (images 001.jpg … {frame_count:03d}.jpg)\n"
            f"suggested scrollVh = {scroll_vh}\n\n"
            "Author the two files now, delimited exactly as instructed."
        )
        resp = self._gw.complete(
            self._model,
            [{"role": "system", "content": _AGENT_SYSTEM}, {"role": "user", "content": user}],
            temperature=0.6, max_tokens=8000,
        )
        return parse_agent_files(resp.text)

    # --- 3. assemble the project ----------------------------------------------------------
    def _assemble(self, project: Path, slug: str, frames_dir: Path,
                  files: dict[str, str]) -> None:
        (project / "assets" / "css").mkdir(parents=True, exist_ok=True)
        (project / "assets" / "js").mkdir(parents=True, exist_ok=True)
        # reusable engine (never rewritten)
        for name in ("base.css", "sections.css"):
            shutil.copy(self._engine_dir / name, project / "assets" / "css" / name)
        shutil.copy(
            self._engine_dir / "scroll-video.js",
            project / "assets" / "js" / "scroll-video.js"
        )
        # frames
        dest_frames = project / "assets" / "frames" / slug
        dest_frames.mkdir(parents=True, exist_ok=True)
        for jpg in frames_dir.glob("*.jpg"):
            shutil.copy(jpg, dest_frames / jpg.name)
        # agent files
        for rel, content in files.items():
            p = project / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")

    # --- 4. serve + scrub + screenshot + montage -----------------------------------------
    def _render(self, project: Path, page: str, out_png: Path) -> tuple[str | None, list[str]]:
        from PIL import Image
        from playwright.sync_api import sync_playwright

        shots: list[Path] = []
        with _Server(project) as srv:
            url = f"http://127.0.0.1:{srv.port}/{page}"
            with sync_playwright() as p:
                browser = p.chromium.launch()
                pg = browser.new_page(viewport={"width": self._vw, "height": self._vh},
                                      device_scale_factor=1)
                pg.goto(url, wait_until="networkidle", timeout=30000)
                # The engine adds body.is-ready once frames preload; wait for it, then settle.
                with contextlib.suppress(Exception):  # noqa: BLE001 — fall back if never signalled
                    pg.wait_for_selector("body.is-ready", timeout=15000)
                pg.wait_for_timeout(1200)
                # Sample where motion actually happens: spread most shots ACROSS the
                # scroll-track (the video scrub range), then one in the editorial section.
                geom = pg.evaluate(
                    "() => { const t=document.querySelector('.scroll-track');"
                    " const scrub=t?Math.max(t.offsetHeight-window.innerHeight,1):1;"
                    " const maxs=Math.max(document.body.scrollHeight-window.innerHeight,1);"
                    " return {scrub, maxs}; }")
                scrub, maxs = geom["scrub"], geom["maxs"]
                targets = [scrub * f for f in (0.0, 0.25, 0.5, 0.75, 1.0)]  # video scrub
                targets.append(min(maxs, scrub + (maxs - scrub) * 0.6))     # editorial
                for i, y in enumerate(targets):
                    pg.evaluate(f"window.scrollTo(0, {y})")
                    pg.wait_for_timeout(700)
                    s = out_png.with_name(f"{out_png.stem}_{i}.png")
                    pg.screenshot(path=str(s))
                    shots.append(s)
                browser.close()
        if not shots:
            return None, []
        imgs = [Image.open(s) for s in shots]
        w = max(im.width for im in imgs)
        montage = Image.new("RGB", (w, sum(im.height for im in imgs)), "black")
        y = 0
        for im in imgs:
            montage.paste(im, (0, y))
            y += im.height
        montage.save(out_png)
        return str(out_png), [str(s) for s in shots]

    # --- orchestration --------------------------------------------------------------------
    def run(self, skill_md: str, brief: str, slug: str, video: Path,
            workdir: Path, frames_dir: Path | None = None) -> tuple[Output, BuildResult]:
        workdir = Path(workdir)
        workdir.mkdir(parents=True, exist_ok=True)
        # Reuse a pre-extracted frame cache across rounds if one is supplied & populated.
        cached = frames_dir is not None and Path(frames_dir).is_dir() \
            and any(Path(frames_dir).glob("*.jpg"))
        frames_dir = Path(frames_dir) if frames_dir is not None else workdir / "frames"
        project = workdir / "project"
        project.mkdir(parents=True, exist_ok=True)
        br = BuildResult(project_dir=project)
        try:
            br.frame_count = (len(list(frames_dir.glob("*.jpg"))) if cached
                              else extract_frames(Path(video), frames_dir))
            if br.frame_count < 2:
                br.failed, br.reason = True, "frame_extraction_empty"
                return Output(failed=True), br
            br.files = self._author(skill_md, brief, slug, br.frame_count)
            page = f"{slug}.html"
            if page not in br.files or f"assets/css/{slug}.css" not in br.files:
                br.failed = True
                br.reason = f"agent_missing_files (got {list(br.files)})"
                return Output(artifacts=br.files, failed=True), br
            self._assemble(project, slug, frames_dir, br.files)
            br.montage_path, br.shots = self._render(project, page, workdir / "montage.png")
            br.scrub = scrub_metric(br.shots[:5]) if br.shots else 0.0  # in-track positions
            out = Output(
                artifacts={"index.html": br.files[page], **br.files},
                render_path=br.montage_path,
                failed=br.montage_path is None,
            )
            return out, br
        except subprocess.CalledProcessError as e:  # noqa: BLE001
            br.failed, br.reason = True, f"ffmpeg_failed: {e.stderr[:160] if e.stderr else e}"
            return Output(failed=True), br
        except Exception as e:  # noqa: BLE001
            br.failed, br.reason = True, f"{type(e).__name__}: {str(e)[:160]}"
            return Output(artifacts=br.files, failed=True), br
