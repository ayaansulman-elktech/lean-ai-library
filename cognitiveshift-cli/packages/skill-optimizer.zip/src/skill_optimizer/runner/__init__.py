"""Runner: executes a Skill to produce an output (observable evidence only)."""

from skill_optimizer.runner.runner import SkillRunner

__all__ = ["SkillRunner"]
