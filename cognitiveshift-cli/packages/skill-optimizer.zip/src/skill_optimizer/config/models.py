"""Pydantic models that load and validate the five YAML config files.

The four skill-defining configs (genomes, skill-metrics, output-metrics, objective) plus
the operational providers config. Validation here is the single source of truth: if a YAML
is malformed the pipeline fails fast at load, not deep inside a 3-hour optimization run.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, model_validator


def _read_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with path.open(encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"Config {path} must be a YAML mapping, got {type(data).__name__}")
    return data


# --------------------------------------------------------------------------- genomes
class CompressionSpec(BaseModel):
    search_space: list[str] = ["none", "light", "aggressive"]


class GenomeGlobal(BaseModel):
    ordering: Literal["fixed", "search"] = "fixed"
    compression: CompressionSpec = Field(default_factory=CompressionSpec)


class Gene(BaseModel):
    toggle: bool = True          # may Optuna include/exclude this section?
    order: int = 999
    params: dict[str, list[Any]] = Field(default_factory=dict)


class GenomesConfig(BaseModel):
    version: int = 1
    global_: GenomeGlobal = Field(default_factory=GenomeGlobal, alias="global")
    genes: dict[str, Gene]
    content: dict[str, list[Any]] = Field(default_factory=dict)  # content-level gene choices
    models: dict[str, list[str]] = Field(default_factory=dict)   # e.g. {runtime: [aliases]}

    model_config = {"populate_by_name": True}


# ----------------------------------------------------------------------- skill metrics
class StructuralMetric(BaseModel):
    enabled: bool = True
    method: str | None = None  # only required for enabled metrics; deferred ones omit it


class SkillMetricsConfig(BaseModel):
    version: int = 1
    metrics: dict[str, StructuralMetric]

    def enabled(self) -> dict[str, StructuralMetric]:
        return {k: v for k, v in self.metrics.items() if v.enabled}


# ----------------------------------------------------------------------- output metrics
class ExecutionSpec(BaseModel):
    mode: Literal["static_only", "render_and_screenshot"] = "static_only"
    renderer: str = "headless_chromium"
    timeout_s: int = 60


class TaskSpec(BaseModel):
    objective: str = ""  # fixed bar the judge scores every output against


class OutputMetric(BaseModel):
    enabled: bool = True
    type: Literal["judge", "repeat_variance", "deterministic"]
    scale: list[float] | None = None
    runs: int = 3


class OutputMetricsConfig(BaseModel):
    version: int = 1
    task: TaskSpec = Field(default_factory=TaskSpec)
    execution: ExecutionSpec = Field(default_factory=ExecutionSpec)
    metrics: dict[str, OutputMetric]

    def enabled(self) -> dict[str, OutputMetric]:
        return {k: v for k, v in self.metrics.items() if v.enabled}


# -------------------------------------------------------------------------- objective
class CostPenalty(BaseModel):
    enabled: bool = True
    lambda_: float = Field(default=0.05, alias="lambda")
    model_config = {"populate_by_name": True}


class Penalties(BaseModel):
    cost_per_run_usd: CostPenalty = Field(default_factory=CostPenalty)


class SkillScoreSpec(BaseModel):
    weights: dict[str, float]
    penalties: Penalties = Field(default_factory=Penalties)
    normalization: str = "minmax_per_study"

    @model_validator(mode="after")
    def _weights_positive(self) -> SkillScoreSpec:
        if not self.weights:
            raise ValueError("skill_score.weights must define at least one term")
        if any(w < 0 for w in self.weights.values()):
            raise ValueError("skill_score weights must be non-negative")
        return self


class GoalSpec(BaseModel):
    skill_score_goal: float = 0.85
    max_trials: int = 100
    max_spend_usd: float = 50.0
    patience: int = 15


class JudgePanelSpec(BaseModel):
    strategy: Literal["single", "panel", "screen_then_panel"] = "screen_then_panel"
    screen_model: str = "deepseek"
    panel_models: list[str] = ["claude", "grok", "deepseek"]
    aggregation: Literal["median", "mean", "majority"] = "median"
    disagreement_flag_threshold: float = 0.25
    # Max quality drift (0-10 scale) between two judgings of the same output for the
    # calibration gate to call the judge reproducible. LLM judges have irreducible variance;
    # ~1.5 is realistic for a median-aggregated panel.
    reproducibility_tolerance: float = 1.5


class ObjectiveConfig(BaseModel):
    version: int = 1
    skill_score: SkillScoreSpec
    goal: GoalSpec = Field(default_factory=GoalSpec)
    judge_panel: JudgePanelSpec = Field(default_factory=JudgePanelSpec)


# -------------------------------------------------------------------------- providers
class ModelSpec(BaseModel):
    provider: str
    model: str
    api_key_env: str | None = None
    price_in: float = 0.0   # USD per 1M input tokens
    price_out: float = 0.0  # USD per 1M output tokens
    vision: bool = False    # can this model judge a screenshot image?


class ProvidersConfig(BaseModel):
    gateway: Literal["litellm", "mock"] = "litellm"
    generator_pool: list[str]
    judge_pool: list[str]
    models: dict[str, ModelSpec]

    @model_validator(mode="after")
    def _pools_reference_known_models(self) -> ProvidersConfig:
        for pool_name, pool in [("generator_pool", self.generator_pool),
                                ("judge_pool", self.judge_pool)]:
            for alias in pool:
                if alias not in self.models:
                    raise ValueError(f"{pool_name} references unknown model alias '{alias}'")
        return self


# ----------------------------------------------------------------------------- bundle
class Configs(BaseModel):
    genomes: GenomesConfig
    skill_metrics: SkillMetricsConfig
    output_metrics: OutputMetricsConfig
    objective: ObjectiveConfig
    providers: ProvidersConfig


def load_configs(config_dir: str | Path) -> Configs:
    """Load and validate all configs from a directory. Fails fast on any error."""
    d = Path(config_dir)
    return Configs(
        genomes=GenomesConfig.model_validate(_read_yaml(d / "skill-genomes.yaml")),
        skill_metrics=SkillMetricsConfig.model_validate(_read_yaml(d / "skill-metrics.yaml")),
        output_metrics=OutputMetricsConfig.model_validate(_read_yaml(d / "output-metrics.yaml")),
        objective=ObjectiveConfig.model_validate(_read_yaml(d / "objective-skill-metrics.yaml")),
        providers=ProvidersConfig.model_validate(_read_yaml(d / "providers.yaml")),
    )
