"""End-to-end orchestration for M0 (single closed loop) and the M1 calibration gate.

`run_once` is the vertical slice: load configs -> default genome -> generate -> run -> evaluate
-> track. `calibrate` is the gate that must pass before we trust the judge: it scores a strong
Skill against a deliberately weak one and checks the judge ranks good > bad and is reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from skill_optimizer.config import Configs, load_configs
from skill_optimizer.datasets.loader import Dataset, load_dataset
from skill_optimizer.evaluation.evaluator import Evaluator
from skill_optimizer.generator.generator import SkillGenerator
from skill_optimizer.genome.builder import default_genome
from skill_optimizer.providers.gateway import build_gateway
from skill_optimizer.providers.meter import CostMeter
from skill_optimizer.runner.runner import SkillRunner, sweep_temp_renders
from skill_optimizer.tracking.mlflow_tracker import build_tracker
from skill_optimizer.types import Candidate, Scores


@dataclass
class RunResult:
    candidate: Candidate
    scores: Scores
    cost_summary: dict[str, float]


@dataclass
class Context:
    cfg: Configs
    meter: CostMeter
    gateway: object
    generator: SkillGenerator
    runner: SkillRunner
    evaluator: Evaluator


def build_context(config_dir: str | Path, *, offline: bool) -> Context:
    from skill_optimizer.env import load_env
    load_env()  # pick up API keys from .env before any provider call
    cfg = load_configs(config_dir)
    meter = CostMeter(budget_usd=cfg.objective.goal.max_spend_usd)
    gateway = build_gateway(cfg.providers, meter, offline=offline)
    gen_model = cfg.providers.generator_pool[0]
    run_model = cfg.providers.generator_pool[0]  # runtime uses a generator-pool model
    return Context(
        cfg=cfg,
        meter=meter,
        gateway=gateway,
        generator=SkillGenerator(gateway, gen_model),
        runner=SkillRunner(gateway, run_model, cfg.output_metrics.execution),
        evaluator=Evaluator(cfg, gateway),
    )


def run_once(config_dir: str | Path, dataset_root: str | Path, *,
             offline: bool = False, track: bool = True,
             artifacts_dir: str | Path | None = "artifacts") -> RunResult:
    ctx = build_context(config_dir, offline=offline)
    d_wm: Dataset = load_dataset(dataset_root, "D_wm")

    genome = default_genome(ctx.cfg.genomes)
    candidate = ctx.generator.generate(genome, d_wm)

    output = ctx.runner.run(candidate.skill_md, artifacts_dir=artifacts_dir)

    # Stability needs reruns; honor the configured run count if the metric is enabled.
    repeats = []
    stab = ctx.cfg.output_metrics.metrics.get("stability")
    if stab and stab.enabled and not ctx.meter.over_budget():
        repeats = [ctx.runner.run(candidate.skill_md) for _ in range(max(0, stab.runs - 1))]

    scores = ctx.evaluator.evaluate(candidate.skill_md, output, repeats)

    tracker = build_tracker("skill-optimizer", run_name="m0-run", enabled=track)
    with tracker:
        tracker.log_candidate(candidate, output, scores)

    sweep_temp_renders()
    return RunResult(candidate=candidate, scores=scores, cost_summary=ctx.meter.summary())


def _load_dev_tasks(dataset_root: str | Path) -> list[str] | None:
    """Load the D_dev briefs (same distribution as held-out validation), or None if absent."""
    from skill_optimizer.datasets.loader import GuardViolationError, task_briefs
    try:
        dev = load_dataset(dataset_root, "D_dev")
        return [text for _name, text in task_briefs(dev)] or None
    except (FileNotFoundError, GuardViolationError):
        return None


def evolve(config_dir: str | Path, dataset_root: str | Path, *,
           offline: bool = False, track: bool = True, max_trials: int | None = None,
           goal_override: float | None = None, artifacts_dir: str | Path | None = "artifacts"):
    """GEPA-style reflective optimization: rewrite the Skill from the judge's feedback."""
    from skill_optimizer.optimization.reflective import ReflectiveOptimizer

    ctx = build_context(config_dir, offline=offline)
    d_wm = load_dataset(dataset_root, "D_wm")
    goal = ctx.cfg.objective.goal
    updates: dict[str, float] = {}
    if max_trials is not None:
        updates["max_trials"] = max_trials
    if goal_override is not None:
        updates["skill_score_goal"] = goal_override
    if updates:
        goal = goal.model_copy(update=updates)

    def tracker_factory(name: str):
        return build_tracker("skill-optimizer", run_name=name, enabled=track)

    optimizer = ReflectiveOptimizer(ctx, goal, _load_dev_tasks(dataset_root) or [],
                                    tracker_factory)
    result = optimizer.run(d_wm, str(artifacts_dir) if artifacts_dir else None)
    sweep_temp_renders()
    return result


def evolve_dspy(config_dir: str | Path, dataset_root: str | Path, *,
                offline: bool = False, budget: int = 40,
                out_path: str | Path = "artifacts/best_dspy_SKILL.md") -> dict:
    """Option (b): DSPy-library GEPA. Live-only (DSPy drives its own LLM calls)."""
    from skill_optimizer.optimization.dspy_gepa import run_dspy_gepa

    ctx = build_context(config_dir, offline=offline)
    dev = _load_dev_tasks(dataset_root) or []
    if not dev:
        raise ValueError("DSPy GEPA needs D_dev briefs; none found under the dataset root.")
    instruction, _program = run_dspy_gepa(ctx, dev, budget=budget)

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(instruction, encoding="utf-8")
    sweep_temp_renders()
    return {"skill_path": str(out), "skill": instruction,
            "judge_cost_summary": ctx.meter.summary()}


def optimize(config_dir: str | Path, dataset_root: str | Path, *,
             offline: bool = False, track: bool = True, sampler: str = "optuna",
             use_agent: bool = False, max_trials: int | None = None,
             goal_override: float | None = None, seed: int = 0,
             artifacts_dir: str | Path | None = "artifacts"):
    """M3: run the optimization study over the genome search space."""
    from skill_optimizer.optimization.agent import ImprovementAgent
    from skill_optimizer.optimization.optimizer import Optimizer
    from skill_optimizer.optimization.sampler import build_sampler

    ctx = build_context(config_dir, offline=offline)
    d_wm = load_dataset(dataset_root, "D_wm")

    goal = ctx.cfg.objective.goal
    updates: dict[str, float] = {}
    if max_trials is not None:
        updates["max_trials"] = max_trials
    if goal_override is not None:
        updates["skill_score_goal"] = goal_override
    if updates:
        goal = goal.model_copy(update=updates)

    agent = None
    if use_agent:
        agent = ImprovementAgent(ctx.gateway, ctx.cfg.providers.judge_pool[0])

    def tracker_factory(name: str):
        return build_tracker("skill-optimizer", run_name=name, enabled=track)

    optimizer = Optimizer(ctx, goal, build_sampler(sampler, seed), agent, tracker_factory,
                          dev_tasks=_load_dev_tasks(dataset_root))
    result = optimizer.run(d_wm, str(artifacts_dir) if artifacts_dir else None)

    # Persist the winning Skill so the validation/portability/compress steps can pick it up.
    if result.best and artifacts_dir:
        out = Path(artifacts_dir)
        out.mkdir(parents=True, exist_ok=True)
        (out / "best_SKILL.md").write_text(result.best.candidate.skill_md, encoding="utf-8")
    sweep_temp_renders()
    return result


def validate_skill(config_dir: str | Path, dataset_root: str | Path, skill_path: str | Path,
                   *, offline: bool = False, final: bool = False):
    """M4: evaluate a Skill on D_test (generalization), or D_guard when final=True.

    D_guard is the frozen set — loaded only here, with final_validation=True, and never during
    optimization.
    """
    from skill_optimizer.validation.validator import Validator

    ctx = build_context(config_dir, offline=offline)
    skill_md = Path(skill_path).read_text(encoding="utf-8")
    name = "D_guard" if final else "D_test"
    dataset = load_dataset(dataset_root, name, final_validation=final)
    return Validator(ctx).validate(skill_md, dataset)


def check_portability(config_dir: str | Path, skill_path: str | Path, *,
                      offline: bool = False, models: list[str] | None = None):
    """M4: run the Skill across multiple foundation models and measure score preservation."""
    from skill_optimizer.validation.portability import PortabilityChecker

    ctx = build_context(config_dir, offline=offline)
    skill_md = Path(skill_path).read_text(encoding="utf-8")
    models = models or ctx.cfg.providers.judge_pool
    return PortabilityChecker(ctx).check(skill_md, models)


def compress_skill(config_dir: str | Path, skill_path: str | Path, *,
                   offline: bool = False, rounds: int = 2,
                   out_path: str | Path | None = None):
    """M4: compress the Skill (fewer tokens, score retained). Optionally write the result."""
    from skill_optimizer.validation.compression import Compressor

    ctx = build_context(config_dir, offline=offline)
    skill_md = Path(skill_path).read_text(encoding="utf-8")
    model = ctx.cfg.providers.generator_pool[0]
    result = Compressor(ctx, model).compress(skill_md, rounds=rounds)
    if out_path and result.accepted:
        Path(out_path).write_text(result.compressed_skill, encoding="utf-8")
    return result


# --------------------------------------------------------------------------- calibration
@dataclass
class CalibrationReport:
    good_quality: float
    bad_quality: float
    separates: bool          # does the judge rank good > bad?
    margin: float
    reproducible: bool       # same score on a repeat judging?
    detail: dict[str, float]

    def passed(self) -> bool:
        return self.separates and self.reproducible


_GOOD_SKILL = (
    "---\nname: scroll-driven-hero\ndescription: Build a self-contained scroll-driven hero "
    "page.\n---\n\n"
    "# Mission\nProduce a polished, Apple-style scroll-driven hero page that is fully "
    "self-contained (all CSS/JS inline, NO external assets) and renders standalone.\n\n"
    "# Step-by-Step Process\n1. Full-viewport hero with a bold headline.\n"
    "2. Drive motion from scroll using CSS scroll-driven animation or a canvas drawn in JS "
    "(generate visuals in code — do not reference external image frames).\n"
    "3. Reveal editorial text at scroll milestones.\n\n"
    "# Constraints\n- Single self-contained HTML file; renders with no external assets.\n"
    "- 60fps; no layout jank.\n\n"
    "# Quality Criteria\n- Visually polished hero, clear headline, smooth scroll motion.\n"
)

_BAD_SKILL = (
    "---\nname: thing\n---\nmake a website. do whatever. it should look ok i guess. "
    "no rules. figure it out.\n"
)


def calibrate(config_dir: str | Path, *, offline: bool = False) -> CalibrationReport:
    """M1 gate: the judge must rank a strong Skill's output above a weak one, reproducibly."""
    ctx = build_context(config_dir, offline=offline)

    good_out = ctx.runner.run(_GOOD_SKILL)
    bad_out = ctx.runner.run(_BAD_SKILL)

    good = ctx.evaluator.evaluate(_GOOD_SKILL, good_out)
    bad = ctx.evaluator.evaluate(_BAD_SKILL, bad_out)
    good_again = ctx.evaluator.evaluate(_GOOD_SKILL, good_out)

    sweep_temp_renders()
    gq = good.output.get("quality", 0.0)
    bq = bad.output.get("quality", 0.0)
    gq2 = good_again.output.get("quality", 0.0)
    tolerance = ctx.cfg.objective.judge_panel.reproducibility_tolerance
    reproducible = abs(gq - gq2) <= tolerance

    return CalibrationReport(
        good_quality=gq,
        bad_quality=bq,
        separates=gq > bq,
        margin=round(gq - bq, 4),
        reproducible=reproducible,
        detail={
            "good_quality_repeat": gq2,
            "good_skill_score": good.skill_score,
            "bad_skill_score": bad.skill_score,
            "good_disagreement": good.judge_disagreement,
        },
    )
