"""Command-line entry point: `skill-opt run|calibrate|validate-config`."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from skill_optimizer.config import load_configs
from skill_optimizer.pipeline import (
    calibrate,
    check_portability,
    compress_skill,
    evolve,
    evolve_dspy,
    optimize,
    run_once,
    validate_skill,
)

app = typer.Typer(add_completion=False, help="Skill Optimizer CLI")
console = Console()


@app.command()
def run(
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
    dataset_root: str = typer.Option("Dataset", help="Root containing D_wm/D_test."),
    offline: bool = typer.Option(False, help="Use the mock provider (no API keys)."),
    track: bool = typer.Option(True, help="Log to MLflow."),
) -> None:
    """M0: run one candidate end-to-end (generate -> run -> evaluate -> log)."""
    result = run_once(config_dir, dataset_root, offline=offline, track=track)
    table = Table(title="Skill Optimizer - single run")
    table.add_column("metric")
    table.add_column("value", justify="right")
    for k, v in result.scores.flat().items():
        table.add_row(k, f"{v}")
    for k, v in result.cost_summary.items():
        table.add_row(f"cost.{k}", f"{v}")
    table.add_row("flagged_for_review", str(result.scores.flagged_for_review))
    console.print(table)


@app.command()
def calibrate_judge(
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
    offline: bool = typer.Option(False, help="Use the mock provider (no API keys)."),
) -> None:
    """M1 gate: verify the judge ranks a strong Skill above a weak one, reproducibly."""
    report = calibrate(config_dir, offline=offline)
    table = Table(title="Judge calibration gate")
    table.add_column("check")
    table.add_column("value", justify="right")
    table.add_row("good quality", f"{report.good_quality}")
    table.add_row("bad quality", f"{report.bad_quality}")
    table.add_row("separates (good>bad)", "yes" if report.separates else "no")
    table.add_row("margin", f"{report.margin}")
    table.add_row("reproducible", "yes" if report.reproducible else "no")
    console.print(table)
    if report.passed():
        console.print("[bold green]GATE PASSED[/] - judge is usable.")
    else:
        console.print("[bold red]GATE FAILED[/] - fix the judge before optimizing.")
        raise typer.Exit(code=1)


@app.command()
def optimize_skill(
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
    dataset_root: str = typer.Option("Dataset", help="Root containing D_wm/D_test."),
    offline: bool = typer.Option(False, help="Use the mock provider (no API keys)."),
    track: bool = typer.Option(True, help="Log each trial to MLflow."),
    sampler: str = typer.Option("optuna", help="Search backend: optuna | random."),
    use_agent: bool = typer.Option(False, help="Enable the improvement Agent."),
    trials: int = typer.Option(None, help="Override max_trials from the objective config."),
    goal: float = typer.Option(None, help="Override the Skill Score Goal."),
    seed: int = typer.Option(0, help="Sampler seed for reproducibility."),
) -> None:
    """M3: optimize the Skill — search the genome space until the goal/stop criteria hit."""
    result = optimize(config_dir, dataset_root, offline=offline, track=track,
                      sampler=sampler, use_agent=use_agent, max_trials=trials,
                      goal_override=goal, seed=seed)
    table = Table(title="Optimization study")
    table.add_column("field")
    table.add_column("value", justify="right")
    table.add_row("trials run", str(result.n_trials))
    table.add_row("stop reason", result.reason)
    if result.best:
        table.add_row("best skill_score", f"{result.best.skill_score}")
        table.add_row("best trial #", str(result.best.trial))
        table.add_row("best quality", f"{result.best.scores.output.get('quality')}")
        table.add_row("best runtime model", result.best.candidate.genome.runtime_model or "-")
        table.add_row("best n_sections", str(len(result.best.candidate.genome.order)))
        table.add_row("best flagged", str(result.best.flagged))
    for k, v in result.cost_summary.items():
        table.add_row(f"cost.{k}", f"{v}")
    console.print(table)

    if result.model_breakdown:
        mt = Table(title="Cost / latency by model")
        mt.add_column("model")
        mt.add_column("cost $", justify="right")
        mt.add_column("time s", justify="right")
        mt.add_column("calls", justify="right")
        mt.add_column("tok in", justify="right")
        mt.add_column("tok out", justify="right")
        for alias, s in result.model_breakdown.items():
            mt.add_row(alias, f"{s['cost_usd']}", f"{s['time_s']}", str(s["calls"]),
                       str(s["tokens_in"]), str(s["tokens_out"]))
        console.print(mt)
    if result.history:
        traj = "  ".join(f"t{t.trial}={t.skill_score}" for t in result.history)
        console.print(f"[dim]trajectory:[/] {traj}")


@app.command()
def evolve_skill(
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
    dataset_root: str = typer.Option("Dataset", help="Root containing D_wm/D_dev."),
    offline: bool = typer.Option(False, help="Use the mock provider (no API keys)."),
    track: bool = typer.Option(True, help="Log each round to MLflow."),
    trials: int = typer.Option(None, help="Max reflection rounds (override config)."),
    goal: float = typer.Option(None, help="Override the Skill Score Goal."),
) -> None:
    """GEPA-style reflective optimization — rewrite the Skill from the judge's feedback."""
    result = evolve(config_dir, dataset_root, offline=offline, track=track,
                    max_trials=trials, goal_override=goal)
    table = Table(title="Reflective optimization")
    table.add_column("field")
    table.add_column("value", justify="right")
    table.add_row("rounds", str(result.n_trials))
    table.add_row("stop reason", result.reason)
    if result.best:
        table.add_row("best cross-brief mean", f"{result.best.skill_score}")
        table.add_row("best round #", str(result.best.trial))
    for k, v in result.cost_summary.items():
        table.add_row(f"cost.{k}", f"{v}")
    console.print(table)


@app.command()
def evolve_dspy_skill(
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
    dataset_root: str = typer.Option("Dataset", help="Root containing D_wm/D_dev."),
    budget: int = typer.Option(40, help="GEPA metric-call budget."),
) -> None:
    """Option (b): optimize the Skill with the DSPy-library GEPA optimizer (live only)."""
    result = evolve_dspy(config_dir, dataset_root, offline=False, budget=budget)
    console.print(f"[bold green]Optimized Skill written to[/] {result['skill_path']}")
    console.print(f"judge cost: {result['judge_cost_summary']}")
    console.print("[dim](DSPy student/reflection LLM spend is billed separately by the "
                  "provider — not in the judge cost above.)[/]")


@app.command()
def validate(
    skill: str = typer.Option("artifacts/best_SKILL.md", help="Path to the SKILL.md."),
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
    dataset_root: str = typer.Option("Dataset", help="Root containing D_test/D_guard."),
    offline: bool = typer.Option(False, help="Use the mock provider (no API keys)."),
    final: bool = typer.Option(False, help="Run on the FROZEN D_guard (final validation)."),
    train_score: float = typer.Option(None, help="Optimization score, to report overfitting."),
) -> None:
    """M4: evaluate a Skill on held-out D_test (or frozen D_guard with --final)."""
    report = validate_skill(config_dir, dataset_root, skill, offline=offline, final=final)
    table = Table(title=f"Validation on {report.dataset}")
    table.add_column("field")
    table.add_column("value", justify="right")
    table.add_row("cases", str(report.n_cases))
    table.add_row("mean skill_score", f"{report.mean_skill_score}")
    table.add_row("mean quality", f"{report.mean_quality}")
    table.add_row("flagged for review", str(report.flagged))
    if train_score is not None:
        table.add_row("overfitting gap", f"{report.overfitting_gap(train_score)}")
    console.print(table)


@app.command()
def portability(
    skill: str = typer.Option("artifacts/best_SKILL.md", help="Path to the SKILL.md."),
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
    offline: bool = typer.Option(False, help="Use the mock provider (no API keys)."),
) -> None:
    """M4: run the Skill across foundation models and report score preservation."""
    report = check_portability(config_dir, skill, offline=offline)
    table = Table(title="Portability across models")
    table.add_column("model")
    table.add_column("skill_score", justify="right")
    for model, score in report.per_model.items():
        table.add_row(model, f"{score}")
    table.add_row("[bold]mean[/]", f"{report.mean}")
    table.add_row("[bold]preservation (min/max)[/]", f"{report.preservation}")
    console.print(table)


@app.command()
def compress(
    skill: str = typer.Option("artifacts/best_SKILL.md", help="Path to the SKILL.md."),
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
    offline: bool = typer.Option(False, help="Use the mock provider (no API keys)."),
    rounds: int = typer.Option(2, help="Compression rounds."),
    out: str = typer.Option("artifacts/best_SKILL.compressed.md", help="Where to write it."),
) -> None:
    """M4: compress the Skill (fewer tokens, score retained)."""
    result = compress_skill(config_dir, skill, offline=offline, rounds=rounds, out_path=out)
    table = Table(title="Skill compression")
    table.add_column("field")
    table.add_column("value", justify="right")
    table.add_row("orig tokens", str(result.orig_tokens))
    table.add_row("compressed tokens", str(result.comp_tokens))
    table.add_row("ratio", f"{result.ratio}")
    table.add_row("orig score", f"{result.orig_score}")
    table.add_row("compressed score", f"{result.comp_score}")
    table.add_row("accepted", str(result.accepted))
    console.print(table)


@app.command()
def validate_config(
    config_dir: str = typer.Option("configs", help="Directory with the YAML configs."),
) -> None:
    """Load and validate all five YAML configs; fail fast on any error."""
    cfg = load_configs(config_dir)
    console.print("[bold green]Configs valid.[/]")
    console.print(f"genes: {len(cfg.genomes.genes)} | "
                  f"generator_pool: {cfg.providers.generator_pool} | "
                  f"judge_pool: {cfg.providers.judge_pool} | "
                  f"gateway: {cfg.providers.gateway}")


if __name__ == "__main__":
    app()
