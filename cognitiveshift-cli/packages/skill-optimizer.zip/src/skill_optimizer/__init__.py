"""Skill Optimizer — build-time MLOps platform for optimizing SKILL.md artifacts."""

__version__ = "0.1.0"
