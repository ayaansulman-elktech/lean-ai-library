"""Generator: turns a genome + D_wm examples into a candidate SKILL.md."""

from skill_optimizer.generator.generator import SkillGenerator

__all__ = ["SkillGenerator"]
