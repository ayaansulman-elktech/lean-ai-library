"""The Generator LLM: writes a candidate SKILL.md from a genome plan + D_wm examples.

It learns the target style from good examples (and contrasts with bad ones) and emits a Skill
following exactly the section structure the genome dictates. Provider comes from the generator
pool (Codex/Claude).
"""

from __future__ import annotations

import re

from skill_optimizer.datasets.loader import Dataset
from skill_optimizer.genome.builder import genome_to_plan
from skill_optimizer.providers.gateway import LLMGateway
from skill_optimizer.types import Candidate, GenomeConfig

_SYSTEM = (
    "You are a Skill engineer writing a SKILL.md in the official Anthropic Agent Skills "
    "format. Requirements:\n"
    "- Start with YAML frontmatter containing exactly two fields: `name` (lowercase letters, "
    "numbers, hyphens only; <=64 chars; must NOT contain 'claude' or 'anthropic') and "
    "`description`.\n"
    "- `description` is the most important field: state BOTH what the Skill does AND when to "
    "use it (the trigger), in <=1024 chars — this is what makes the Skill activate.\n"
    "- Keep the body concise and high-density (well under 5k tokens): procedural guidance, "
    "rules, and at most a couple of tight examples. Prefer principles over verbosity "
    "(progressive disclosure — detail belongs in referenced files, not inline).\n"
    "- Maximize behavioral quality per token. Output ONLY the SKILL.md, nothing else."
)

_MAX_EXAMPLE_CHARS = 4000  # cap per example so the generator prompt stays bounded

# Only learn from instructional/source text; never feed binaries, images, or metadata.
_TEXT_SUFFIXES = {".md", ".html", ".htm", ".css", ".js", ".txt", ".json", ".yaml", ".yml"}
_SUFFIX_PRIORITY = {".md": 0, ".html": 1, ".htm": 1, ".js": 2, ".css": 3, ".txt": 4}


def clean_skill_md(text: str) -> str:
    """Normalize a model-produced SKILL.md to spec: strip an outer markdown fence and convert
    a ```yaml ... ``` frontmatter block to proper `---` delimiters."""
    t = text.strip()
    outer = re.match(r"^```(?:markdown|md)?\s*\n(.*)\n```$", t, re.DOTALL)
    if outer:
        t = outer.group(1).strip()
    front = re.match(r"^```(?:yaml|yml)\s*\n(.*?)\n```\s*(.*)$", t, re.DOTALL)
    if front:
        t = f"---\n{front.group(1).strip()}\n---\n\n{front.group(2).strip()}".strip()
    return t


def _summarize_examples(ds: Dataset, polarity: str, limit: int = 3) -> str:
    picker = ds.good if polarity == "good" else ds.bad
    # Keep only meaningful text files, instructional docs first (.md/.html before css/js).
    text = [e for e in picker() if e.path.suffix.lower() in _TEXT_SUFFIXES]
    text.sort(key=lambda e: _SUFFIX_PRIORITY.get(e.path.suffix.lower(), 99))
    items = text[:limit]
    blocks: list[str] = []
    for ex in items:
        try:
            text = ex.read_text()[:_MAX_EXAMPLE_CHARS]
        except (OSError, ValueError):
            text = f"<binary asset: {ex.path.name}>"
        blocks.append(f"### {polarity.upper()} example: {ex.path.name}\n{text}")
    return "\n\n".join(blocks) if blocks else f"(no {polarity} examples)"


class SkillGenerator:
    def __init__(self, gateway: LLMGateway, model_alias: str) -> None:
        self._gw = gateway
        self._model = model_alias

    def generate(self, genome: GenomeConfig, d_wm: Dataset,
                 hint: str | None = None) -> Candidate:
        plan = genome_to_plan(genome)
        good = _summarize_examples(d_wm, "good")
        parts = [
            "Write a SKILL.md for the target task, learning the desired output style from "
            "the GOOD examples below.",
            "",
            "## GOOD examples (emulate these)",
            good,
        ]
        # Only show bad examples if the genome opted into counter-examples.
        if genome.sections.get("examples", {}).get("polarity") == "good_and_bad":
            parts += ["", "## BAD examples (avoid these failure modes)",
                      _summarize_examples(d_wm, "bad")]
        parts += ["", "## Required structure", plan]
        # Agent-proposed improvement from prior optimization trials, if any.
        if hint:
            parts += ["", "## Improvement hint from prior runs", hint]

        messages = [
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": "\n".join(parts)},
        ]
        resp = self._gw.complete(self._model, messages, temperature=0.4)
        return Candidate(skill_md=clean_skill_md(resp.text), genome=genome,
                         gen_cost_usd=resp.cost_usd)
