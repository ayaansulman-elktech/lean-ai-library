from __future__ import annotations

from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]


@pytest.fixture
def config_dir() -> Path:
    return REPO / "configs"


@pytest.fixture
def tmp_dataset(tmp_path: Path) -> Path:
    """Minimal D_wm with one good and one bad example, plus a D_test."""
    good = tmp_path / "Dataset" / "D_wm" / "Good-exemples"
    bad = tmp_path / "Dataset" / "D_wm" / "Bad-exemples"
    test = tmp_path / "Dataset" / "D_test" / "t1"
    guard = tmp_path / "Dataset" / "D_guard" / "g1"
    dev = tmp_path / "Dataset" / "D_dev" / "d1"
    for d in (good, bad, test, guard, dev):
        d.mkdir(parents=True, exist_ok=True)
    (good / "index.html").write_text("<html><canvas></canvas></html>", encoding="utf-8")
    (bad / "broken.txt").write_text("just a div, no scroll logic", encoding="utf-8")
    (test / "prompt.md").write_text("Build a scroll-driven hero page for a watch brand.",
                                    encoding="utf-8")
    (guard / "prompt.md").write_text("Build a scroll-driven hero page for a car brand.",
                                     encoding="utf-8")
    (dev / "prompt.md").write_text("Build a scroll-driven hero page for a coffee brand.",
                                   encoding="utf-8")
    return tmp_path / "Dataset"
