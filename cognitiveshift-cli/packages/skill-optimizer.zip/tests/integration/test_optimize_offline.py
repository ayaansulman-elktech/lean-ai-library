"""M3 optimization loop tests — offline, RandomSampler (no Optuna dependency needed)."""

from __future__ import annotations

from skill_optimizer.pipeline import optimize


def test_optimize_runs_and_returns_best(config_dir, tmp_dataset, tmp_path):
    result = optimize(config_dir, tmp_dataset, offline=True, track=False,
                      sampler="random", max_trials=5, seed=1,
                      artifacts_dir=tmp_path / "artifacts")
    assert result.n_trials >= 1
    assert result.best is not None
    assert 0.0 <= result.best.skill_score <= 1.0
    # best is the max over history
    assert result.best.skill_score == max(t.skill_score for t in result.history)


def test_optimize_stops_at_max_trials(config_dir, tmp_dataset):
    result = optimize(config_dir, tmp_dataset, offline=True, track=False,
                      sampler="random", max_trials=3, seed=2, artifacts_dir=None)
    assert result.n_trials <= 3
    assert result.reason in {"max_trials", "goal_reached", "patience_exhausted"}


def test_optimize_with_agent(config_dir, tmp_dataset):
    result = optimize(config_dir, tmp_dataset, offline=True, track=False,
                      sampler="random", use_agent=True, max_trials=3, seed=3,
                      artifacts_dir=None)
    assert result.best is not None


def test_optimize_playoff_runs_with_multiple_dev_briefs(config_dir, tmp_dataset):
    # Add a 2nd D_dev brief so the top-K playoff triggers (>1 brief required).
    d2 = tmp_dataset / "D_dev" / "d2"
    d2.mkdir(parents=True, exist_ok=True)
    (d2 / "prompt.md").write_text("hero page for a car brand", encoding="utf-8")

    result = optimize(config_dir, tmp_dataset, offline=True, track=False,
                      sampler="random", max_trials=4, goal_override=1.1, seed=7,
                      artifacts_dir=None)
    assert result.best is not None
    assert "playoff" in result.reason


def test_optimize_survives_provider_failure(config_dir, tmp_dataset, monkeypatch):
    """A persistently failing provider aborts gracefully — no crash, best preserved (None)."""
    from skill_optimizer.generator.generator import SkillGenerator

    def boom(*_a, **_k):
        raise RuntimeError("api down: credits exhausted")

    monkeypatch.setattr(SkillGenerator, "generate", boom)
    result = optimize(config_dir, tmp_dataset, offline=True, track=False,
                      sampler="random", max_trials=10, seed=4, artifacts_dir=None)
    assert result.reason == "provider_errors"
    assert result.best is None
    assert result.n_trials == 0  # no successful trials recorded
