"""Offline tests for the DSPy GEPA adapter — the metric wiring and object construction.

The full GEPA compile drives real LLMs (DSPy/litellm), so it is not run here; these tests
validate everything we can without spending: the feedback metric and optimizer construction.
"""

from __future__ import annotations

import pytest

dspy = pytest.importorskip("dspy")

from skill_optimizer.optimization.dspy_gepa import (  # noqa: E402
    _hero_signature,
    make_metric,
    run_dspy_gepa,
)
from skill_optimizer.pipeline import build_context  # noqa: E402


def test_metric_scores_html(config_dir):
    ctx = build_context(config_dir, offline=True)
    metric = make_metric(ctx)
    gold = dspy.Example(brief="a site for a coffee brand").with_inputs("brief")
    pred = dspy.Prediction(
        html="<!doctype html><html><body><canvas id='hero'></canvas>"
             "<script>/* scroll-driven */</script></body></html>")
    result = metric(gold, pred)
    assert 0.0 <= float(result.score) <= 1.0
    assert isinstance(result.feedback, str)


def test_metric_handles_non_html(config_dir):
    ctx = build_context(config_dir, offline=True)
    metric = make_metric(ctx)
    gold = dspy.Example(brief="x").with_inputs("brief")
    result = metric(gold, dspy.Prediction(html="no html here"))
    assert float(result.score) == 0.0


def test_gepa_constructs_without_compile(config_dir):
    # Build the student + GEPA optimizer (no .compile, so no LLM calls / no spend).
    student = dspy.Predict(_hero_signature())
    assert student is not None
    gepa = dspy.GEPA(metric=lambda *a, **k: dspy.Prediction(score=0.0, feedback=""),
                     reflection_lm=dspy.LM(model="openai/gpt-5-codex", cache=False),
                     max_metric_calls=10, seed=0)
    assert gepa is not None
    assert callable(run_dspy_gepa)
