"""Offline tests for the GEPA-style reflective optimizer (mock provider)."""

from __future__ import annotations

from skill_optimizer.pipeline import evolve


def test_evolve_runs_and_returns_best(config_dir, tmp_dataset, tmp_path):
    result = evolve(config_dir, tmp_dataset, offline=True, track=False,
                    max_trials=4, goal_override=1.1, artifacts_dir=tmp_path / "art")
    assert result.best is not None
    assert "reflect" in result.reason
    assert result.n_trials >= 1
    # best is the max cross-brief mean over the rounds
    assert result.best.skill_score == max(t.skill_score for t in result.history)
    assert (tmp_path / "art" / "best_SKILL.md").exists()


def test_evolve_records_per_model_cost(config_dir, tmp_dataset):
    result = evolve(config_dir, tmp_dataset, offline=True, track=False,
                    max_trials=3, goal_override=1.1, artifacts_dir=None)
    assert result.model_breakdown  # per-model cost/latency captured
    assert "total_time_s" in result.cost_summary
