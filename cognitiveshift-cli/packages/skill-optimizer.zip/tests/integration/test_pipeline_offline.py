"""Integration tests that exercise the full pipeline with the mock gateway (no API spend)."""

from __future__ import annotations

from skill_optimizer.pipeline import calibrate, run_once


def test_run_once_offline(config_dir, tmp_dataset, tmp_path):
    result = run_once(config_dir, tmp_dataset, offline=True, track=False,
                      artifacts_dir=tmp_path / "artifacts")
    assert result.candidate.skill_md
    assert 0.0 <= result.scores.skill_score <= 1.0
    assert (tmp_path / "artifacts" / "index.html").exists()


def test_calibration_runs_offline(config_dir):
    report = calibrate(config_dir, offline=True)
    # With the mock judge we just assert the gate computes a coherent report.
    assert report.good_quality >= 0
    assert isinstance(report.passed(), bool)
