"""M4 tests — validation, portability, compression. Offline via the mock provider."""

from __future__ import annotations

from skill_optimizer.pipeline import check_portability, compress_skill, validate_skill

_SKILL = (
    "---\nname: scroll-driven-hero\n---\n\n# Mission\nBuild a scroll-driven hero page.\n\n"
    "# Step-by-Step Process\nPin canvas; map scroll to frame.\n\n# Constraints\n60fps.\n\n"
    "# Quality Criteria\nSmooth scrub.\n"
)


def _skill_file(tmp_path):
    p = tmp_path / "best_SKILL.md"
    p.write_text(_SKILL, encoding="utf-8")
    return p


def test_validate_on_d_test(config_dir, tmp_dataset, tmp_path):
    skill = _skill_file(tmp_path)
    report = validate_skill(config_dir, tmp_dataset, skill, offline=True, final=False)
    assert report.dataset == "D_test"
    assert report.n_cases >= 1
    assert 0.0 <= report.mean_skill_score <= 1.0


def test_final_validation_uses_d_guard(config_dir, tmp_dataset, tmp_path):
    skill = _skill_file(tmp_path)
    report = validate_skill(config_dir, tmp_dataset, skill, offline=True, final=True)
    assert report.dataset == "D_guard"
    assert report.n_cases >= 1


def test_portability_across_models(config_dir, tmp_path):
    skill = _skill_file(tmp_path)
    report = check_portability(config_dir, skill, offline=True,
                               models=["claude", "grok", "deepseek"])
    assert set(report.per_model) == {"claude", "grok", "deepseek"}
    assert 0.0 <= report.preservation <= 1.0


def test_compression_reduces_tokens_keeping_score(config_dir, tmp_path):
    skill = _skill_file(tmp_path)
    result = compress_skill(config_dir, skill, offline=True, rounds=2)
    assert result.comp_tokens <= result.orig_tokens
    # mock compressor preserves headings -> score retained within tolerance
    assert result.comp_score >= result.orig_score - 0.05
