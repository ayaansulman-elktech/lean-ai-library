from __future__ import annotations

from skill_optimizer.runner.runner import _extract_html


def test_strips_prose_preamble():
    raw = "This is a self-contained HTML document for X.\n\n<!doctype html><html></html>"
    assert _extract_html(raw).lower().startswith("<!doctype html")


def test_strips_markdown_fence():
    raw = "Here you go:\n```html\n<html><body>hi</body></html>\n```"
    assert _extract_html(raw) == "<html><body>hi</body></html>"


def test_passthrough_clean_html():
    raw = "<!doctype html><html></html>"
    assert _extract_html(raw) == raw


def test_no_html_returns_text():
    assert _extract_html("no tags here") == "no tags here"
