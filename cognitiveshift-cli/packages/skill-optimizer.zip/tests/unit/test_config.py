from __future__ import annotations

import pytest

from skill_optimizer.config import load_configs
from skill_optimizer.config.models import ProvidersConfig


def test_loads_all_configs(config_dir):
    cfg = load_configs(config_dir)
    assert cfg.genomes.genes  # non-empty
    assert cfg.providers.generator_pool
    assert cfg.objective.skill_score.weights["quality"] > 0


def test_pool_references_must_be_known_models():
    with pytest.raises(ValueError):
        ProvidersConfig.model_validate({
            "gateway": "mock",
            "generator_pool": ["ghost"],
            "judge_pool": ["claude"],
            "models": {"claude": {"provider": "anthropic", "model": "x"}},
        })


def test_weights_must_be_non_negative(config_dir):
    cfg = load_configs(config_dir)
    # sanity: all configured weights are non-negative (validator would have rejected otherwise)
    assert all(w >= 0 for w in cfg.objective.skill_score.weights.values())
