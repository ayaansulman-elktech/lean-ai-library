from __future__ import annotations

import pytest

from skill_optimizer.datasets.loader import GuardViolationError, load_dataset


def test_loads_good_and_bad(tmp_dataset):
    ds = load_dataset(tmp_dataset, "D_wm")
    assert ds.good() and ds.bad()
    assert all("__MACOSX" not in str(e.path) for e in ds.all())


def test_guard_requires_final_validation(tmp_dataset):
    with pytest.raises(GuardViolationError):
        load_dataset(tmp_dataset, "D_guard")


def test_task_briefs_reads_prompt_files(tmp_dataset):
    from skill_optimizer.datasets.loader import task_briefs

    briefs = task_briefs(load_dataset(tmp_dataset, "D_dev"))
    assert len(briefs) == 1
    assert "coffee brand" in briefs[0][1]
