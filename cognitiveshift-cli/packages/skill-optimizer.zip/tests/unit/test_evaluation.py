from __future__ import annotations

from skill_optimizer.config import load_configs
from skill_optimizer.evaluation.judge import _parse
from skill_optimizer.evaluation.score import SkillScorer
from skill_optimizer.evaluation.structural import compute_structural, count_tokens


def test_count_tokens_positive():
    assert count_tokens("hello world") > 0


def test_structural_metrics(config_dir):
    cfg = load_configs(config_dir)
    skill = "---\nname: x\n---\n# Mission\nDo the thing.\n- use canvas\n1. pin it\n"
    m = compute_structural(skill, cfg.skill_metrics)
    assert m["token_complexity"] > 0
    assert 0 <= m["instruction_density"] <= 1
    assert 0 <= m["knowledge_density"] <= 1


def test_judge_parse_handles_noise():
    vote = _parse('blah {"quality": 8.0, "constraint_adherence": 0.9} trailing', "claude")
    assert vote and vote.quality == 8.0
    assert _parse("not json", "claude") is None


def test_skill_score_monotonic_in_quality(config_dir):
    cfg = load_configs(config_dir)
    scorer = SkillScorer(cfg.objective)
    low = scorer.compute({"quality": 2, "constraint_adherence": 0.5,
                          "stability": 1.0, "token_complexity": 1000}, 0.0)
    high = scorer.compute({"quality": 9, "constraint_adherence": 0.5,
                           "stability": 1.0, "token_complexity": 1000}, 0.0)
    assert high > low
