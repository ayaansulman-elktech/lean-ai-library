from __future__ import annotations

from skill_optimizer.config import load_configs
from skill_optimizer.genome.builder import default_genome, genome_to_plan, sample_genome


def test_default_genome_includes_all_genes(config_dir):
    cfg = load_configs(config_dir)
    g = default_genome(cfg.genomes)
    assert set(g.sections) == set(cfg.genomes.genes)
    assert g.order == sorted(g.order, key=lambda n: cfg.genomes.genes[n].order)


def test_sample_genome_respects_toggles(config_dir):
    cfg = load_configs(config_dir)

    # suggester that always disables toggleable genes and picks first param value
    def suggest(name, choices):
        if name.endswith(".enabled"):
            return False
        return choices[0]

    g = sample_genome(cfg.genomes, suggest)
    # non-toggleable genes must survive
    for name, gene in cfg.genomes.genes.items():
        if not gene.toggle:
            assert name in g.sections


def test_plan_is_ordered_and_mentions_examples(config_dir):
    cfg = load_configs(config_dir)
    plan = genome_to_plan(default_genome(cfg.genomes))
    assert "SKILL.md" in plan
    assert "example" in plan.lower()


def test_default_genome_includes_content_genes(config_dir):
    cfg = load_configs(config_dir)
    g = default_genome(cfg.genomes)
    assert set(g.content) == set(cfg.genomes.content)
    assert g.content  # non-empty (content genes configured)


def test_plan_renders_content_directives(config_dir):
    cfg = load_configs(config_dir)
    plan = genome_to_plan(default_genome(cfg.genomes))
    assert "Writing style" in plan


def test_sample_genome_varies_content(config_dir):
    cfg = load_configs(config_dir)

    def suggest(name, choices):
        return choices[-1]  # pick last choice for everything

    g = sample_genome(cfg.genomes, suggest)
    for cname in cfg.genomes.content:
        assert g.content[cname] == cfg.genomes.content[cname][-1]


def test_genome_selects_runtime_model(config_dir):
    cfg = load_configs(config_dir)
    runtime_choices = cfg.genomes.models["runtime"]
    assert default_genome(cfg.genomes).runtime_model == runtime_choices[0]

    def suggest(name, choices):
        return choices[-1]

    assert sample_genome(cfg.genomes, suggest).runtime_model == runtime_choices[-1]
