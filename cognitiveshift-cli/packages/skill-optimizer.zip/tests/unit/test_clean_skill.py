from __future__ import annotations

from skill_optimizer.generator.generator import clean_skill_md


def test_converts_yaml_fence_to_delimiters():
    raw = "```yaml\nname: hero\ndescription: build a hero\n```\n\n# Mission\nDo it."
    out = clean_skill_md(raw)
    assert out.startswith("---\nname: hero")
    assert "---\n\n# Mission" in out
    assert "```" not in out


def test_unwraps_outer_markdown_fence():
    raw = "```markdown\n---\nname: hero\n---\n\n# Mission\nx\n```"
    out = clean_skill_md(raw)
    assert out.startswith("---\nname: hero")
    assert "```" not in out


def test_passthrough_clean_frontmatter():
    raw = "---\nname: hero\ndescription: d\n---\n\n# Mission\nx"
    assert clean_skill_md(raw) == raw
