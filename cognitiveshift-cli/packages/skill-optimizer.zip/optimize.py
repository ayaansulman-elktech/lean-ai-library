import json
import time
import random
from pathlib import Path

class OutputDiscriminator:
    """Scores responses based on Slide 78 metrics."""
    def __init__(self):
        self.weights = {"compactness": 0.4, "safety": 0.4, "token_count": 0.2}

    def score(self, code_response: str) -> dict:
        tokens = len(code_response.split())
        token_score = max(0, 100 - (tokens / 10))
        
        compactness = max(0, 100 - code_response.count("\n"))
        safety = 100 if "eval(" not in code_response and "os.system" not in code_response else 0
        
        final_score = (
            (token_score * self.weights["token_count"]) +
            (compactness * self.weights["compactness"]) +
            (safety * self.weights["safety"])
        )
        return {
            "final_score": round(final_score, 2),
            "metrics": {
                "tokens": tokens,
                "compactness": compactness,
                "safety": safety
            }
        }

def mock_llm_run(prompt: str, task: str) -> str:
    """Simulate a local LLM run."""
    # Simulate variations in output based on the mutated prompt
    if "concise" in prompt.lower():
        return f"def {task.replace(' ', '_')}(): return True"
    else:
        return f"# Let's solve {task}\nimport os\n\ndef {task.replace(' ', '_')}():\n    # Do something\n    return True\n"

def run_optimization():
    target_task = "Sort array locally"
    baseline_gene = "Write a Python function to solve the task."
    
    mutations = [
        "Write a Python function to solve the task. Be concise and use no standard libraries.",
        "Write a verbose Python function with docstrings to solve the task.",
        "Write a Python function to solve the task. Use minimal tokens and high compactness."
    ]

    discriminator = OutputDiscriminator()
    logs_dir = Path(__file__).resolve().parent / "mlruns" / "skill-opt"
    logs_dir.mkdir(parents=True, exist_ok=True)
    
    run_id = int(time.time())
    log_file = logs_dir / f"run_{run_id}.json"
    
    results = []
    
    print(f"Starting Skill Optimizer Run (ID: {run_id})...")
    print(f"Target Task: {target_task}")
    print("-" * 50)
    
    for idx, mutated_prompt in enumerate(mutations):
        print(f"Testing Gene Mutation {idx + 1}: '{mutated_prompt}'")
        
        # 1. Run the Prompt
        response = mock_llm_run(mutated_prompt, target_task)
        
        # 2. Discriminator Scoring
        score_data = discriminator.score(response)
        
        result = {
            "mutation_id": idx + 1,
            "prompt": mutated_prompt,
            "response": response,
            "score": score_data
        }
        results.append(result)
        
        print(f"  -> Score: {score_data['final_score']} (Tokens: {score_data['metrics']['tokens']}, Compact: {score_data['metrics']['compactness']})")
    
    # 3. Log runs locally (Simulated MLflow schema)
    log_data = {
        "run_id": run_id,
        "task": target_task,
        "baseline": baseline_gene,
        "trials": results
    }
    
    with open(log_file, "w") as f:
        json.dump(log_data, f, indent=2)
        
    print("-" * 50)
    print(f"Optimization complete. Best variation logged to {log_file}")

if __name__ == "__main__":
    run_optimization()
