# Subagent Architecture (V1)

Dev-time **subagents** for the factory — specialized Codex agents that Codex spawns in parallel and collects into one result (codebase exploration, review, verification). Reference: Codex *Subagents* docs.
